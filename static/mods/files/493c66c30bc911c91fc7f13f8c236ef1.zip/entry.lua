-- TODO: Check highlight on fire deletion when animations are fixed. Comment marks the location

function package_init(package)
    package:declare_package_id("com.alrysc.player.CybeastGregar")
    package:set_special_description("The original Cybeast!")
  --  package:set_speed(1.0)
    package:set_attack(1)
   -- package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."Gregar_ow2.animation")
    package:set_overworld_texture_path(_modpath.."Gregar_overw2.png")
 --   package:set_icon_texture(Engine.load_texture(_modpath.."NormalNavi_face.png"))
  --  package:set_mugshot_animation_path(_modpath.."mug.animation")
    --package:set_mugshot_texture_path(_modpath.."gregar_mug.png")
  --  package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Gregar")
    player:set_health(2000)
    player:set_element(Element.None)
    player:set_height(65.0)

    local base_texture = Engine.load_texture(_modpath.."CybeastGregar.png")
    local base_animation_path = _modpath.."Gregar.animation"

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(-8, -20)

    player.fire_texture = Engine.load_texture(_modpath.."fire.png")
    player.fire_sfx = Engine.load_audio(_modpath.."fire_sfx.ogg")
    player.lightning_sfx = Engine.load_audio(_modpath.."thunder2.ogg")
    player.lightning_sfx2 = Engine.load_audio(_modpath.."thunder.ogg")
    player.hit_sfx = Engine.load_audio(_modpath.."hit.ogg")
    player.roar_sfx = Engine.load_audio(_modpath.."roar.ogg")
    player.rock_break = Engine.load_audio(_modpath.."rockbreak.ogg")
    player.stomp = Engine.load_audio(_modpath.."stomp.ogg")
    player.current_charge = 1


    local first = true
    player.second_entity_tile = nil
    player.last_tile = nil
    player.moved = false
    player.rock_cooldown = 200

    local function create_extra_box(player)
        local extra_box = Battle.Character.new(player:get_team(), Rank.V1) -- I think making a character needs a rank; doesn't do anything hopefully
        extra_box:share_tile(true)
        extra_box:set_health(1)
       
        extra_box.delete_func = function(self)
            self:erase()
        end

        extra_box.can_move_to_func = function()
            return true
        end

        extra_box.was_hit = false

        -- This is how I'll pass the spell from the defense rule to the component for spawning
        extra_box.spell_attack = nil

        -- Scene lifetime so that it'll trigger during time freeze
        local extra_box_component = Battle.Component.new(extra_box, Lifetimes.Scene)

        extra_box_component.update_func = function()

            -- The get_current_tile check may be bad if the player's hitbox is toggled off
                -- Everything else will probably be fine; may want to check later
                    -- The and check is probably unecessary, since I don't call this unless there is a spell attack to spawn
            if extra_box.was_hit and extra_box.spell_attack then 
                print("Spawning attack")
                player:get_field():spawn(extra_box.spell_attack, player:get_current_tile())

                extra_box.was_hit = false
                extra_box.spell_attack = nil
            end

            if player:will_erase_eof() then
                extra_box:delete()
            end
        end

        local spawn_tile = player:get_current_tile():get_tile(player:get_facing_away(), 1)
    
        extra_box.update_func = function(self)
            local target_tile = player:get_current_tile():get_tile(player:get_facing_away(), 1)

            -- I want to check the tile behind the player, since that's where I want this to be
                -- If it isn't there at any point in time, I want it to move there
            if self:get_current_tile() ~= target_tile then 
                self:teleport(target_tile, ActionOrder.Immediate, nil)
            end
    
          --  print("Extra box is on ", self:get_current_tile():x(), self:get_current_tile():y())
    
        end

        local extra_box_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)

        -- This will be the defense rule that redirects the attack to Gregar
            -- So it'll create a new spell when it gets hit, then spawn that on the player's panel
            -- There are probably some special cases I should think about that I'm not sure what to do with yet
                -- Should I pass if it's non-Impact?
                    -- Check GDS EX
                -- Should I pass if damage is 0?
                    -- It'll matter for paralyze or other statuses, I guess

        extra_box_defense.can_block_func = function(judge, attacker, defender)
            print("Was hit by something")
            
            local attacker_hit_props = attacker:copy_hit_props()
            --judge:block_impact()
            judge:block_damage()

            extra_box.spell_attack = Battle.Spell.new(attacker:get_team()) -- Team might not matter here, as in, maybe I can do get_opposing_team or whatever it was
            
            extra_box.spell_attack.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self:delete()
                print("Attack is dead")
                -- I want it to delete right away so I don't have it lingering in the case the player is somehow able to dodge it
            end

            -- The error was actually down here, because I put () on the variable.
            extra_box.spell_attack:set_hit_props(attacker_hit_props)
            extra_box.was_hit = true
            -- Defense rule should finish processing before the scene lifetime component comes in, but I'll put this toggle down here anyway

        end
        

        extra_box:add_defense_rule(extra_box_defense)
        extra_box:register_component(extra_box_component)

        player:get_field():spawn(extra_box, spawn_tile)

    end

    player.update_func = function(self)
        if first then 
            create_extra_box(self)
            first = false
        end


        if not self.moved and self.rock_cooldown < 1 and self:is_moving() and self:get_current_tile() ~= self.last_tile then 
            self.moved = true
        end

        if self.moved then 
            drop_rocks(self)
            self.moved = false
            self.rock_cooldown = 200
        end

        self.rock_cooldown = self.rock_cooldown - 1
        self.last_tile = self.current_tile
        

    end



    function drop_rocks(user)
        local spell = Battle.Spell.new(user:get_team())
        local tile1 = nil
        local tile2 = nil
        local counter1 = 13
        local counter2 = 26

        local function shake()
            local spell = Battle.Spell.new(user:get_team())
            local time = 0
            Engine.play_audio(user.stomp, AudioPriority.Low)

            spell.update_func = function(self)
                
                self:shake_camera(250, 0.016)
                if time == 31 then 
                    self:delete()
                end
          
                time = time+1
            end

            user:get_field():spawn(spell, 1, 1)
        end

        local tile_filter = function(tile)
            return not tile:is_edge() and tile:get_team() ~= user:get_team()
        end

        local tile_list = nil
        tile_list = user:get_field():find_tiles(tile_filter)

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
        
        local enemy_list = nil
        enemy_list = player:get_field():find_nearest_characters(user, enemy_filter)

        if enemy_list[1] then 
            tile1 = enemy_list[1]:get_current_tile()
        else
            tile1 = tile_list[math.random(1, #tile_list)]
        end

        tile2 = tile_list[math.random(1, #tile_list)]

        spell.update_func = function(self)
            if counter1 > 0 then 
                tile1:highlight(Highlight.Flash)
            elseif counter1 == 0 then 
                create_rock(user, tile1)
            end

            if counter2 < 14 then 
                tile2:highlight(Highlight.Flash)
            end

            if counter2 == 0 then 
                create_rock(user, tile2)
                self:delete()
            end
        
            counter1 = counter1 - 1
            counter2 = counter2 - 1

                

        end

        user:get_field():spawn(spell, 1, 1)
        shake()
    end

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    function copy_spell(spell, props, lifetime)
        local newSpell = Battle.Spell.new(spell:get_team())
        newSpell:set_hit_props(props)
        newSpell.lifetime = lifetime
        newSpell.update_func = function(self)
            self.lifetime = self.lifetime-1
            self:get_current_tile():highlight(Highlight.Solid)


            if self.lifetime == 0 then 
                self:delete()
            end
            self:get_current_tile():attack_entities(self)

        end

        newSpell.attack_func = spell.attack_func
        newSpell.collision_func = spell.collision_func

        
        return newSpell
    end

    -- Fire lasts 115f, takes 5f to fade

    function Burning_Breath(user)
        local action = Battle.CardAction.new(user, "PLAYER_BREATH_START")
        action:set_lockout(make_sequence_lockout())
        local field = user:get_field()

        local function create_spell(user, curX, curY, X, Y)
            if user:get_facing() == Direction.Left then 
                X = X * -1
            end

            local tile = user:get_field():tile_at(curX+X, curY+Y)

            -- I'm pretty sure this is an is_edge check
            if tile and (tile:x() > 0 and tile:x() < 7) and (tile:y() < 4 and tile:y() > 0) then 
                local hasHit = false
                local spell = Battle.Spell.new(user:get_team())
                local offsetY = 0
                local duration = 115

                spell:sprite():set_layer(-1)
                spell:set_facing(user:get_facing())
                spell:set_texture(user.fire_texture, false)
                spell:set_offset(0, offsetY)
                spell:get_animation():load(base_animation_path)
                spell:get_animation():set_state("FIRE_LOOP")
                spell:get_animation():set_playback(Playback.Loop)
        
                spell:get_animation():refresh(spell:sprite())
        
                spell:highlight_tile(Highlight.Solid)

                spell:set_hit_props(
                    HitProps.new(
                    user:get_attack_level() * 50,
                    Hit.Impact| Hit.Flinch | Hit.Flash,
                    Element.Fire,
                    user:get_context(),
                    Drag.None
                    )
                )

                
                spell.can_move_to_func = function()
                    return true
                end

                spell.update_func = function(self)
                    duration = duration - 1
                    if duration == 0 then 

                        spell:get_animation():set_state("FIRE_END")
                        spell:get_animation():refresh(spell:sprite())

                        spell:get_animation():on_complete(function()
                            spell:delete()
                        
                        end)

                    end

                    -- This does nothing for now. Check later on when engine animation works correctly to see if this unhighlights a frame before deletion
                    if duration == -4 then 
                        spell:highlight_tile(Highlight.None)
                    end

                    if not hasHit then
                        spell:get_current_tile():attack_entities(self)
                    end

                end


                spell.attack_func = function()
                    Engine.play_audio(user.hit_sfx, AudioPriority.Low)
                end

                spell.collision_func = function()
                    hasHit = true
                end

                user:get_field():spawn(spell, tile)
                return spell
            end
        end

        

        local step = Battle.Step.new()
        local step_first = true
        local duration = 120
        local attacking = false
        local field = user:get_field()
        local tile_filter = function(tile)
            local facing = user:get_facing()
            local user_tile = user:get_current_tile()
            return tile == user_tile:get_tile(facing, 1) or (((tile:x() == user_tile:get_tile(facing, 2):x()) or (tile:x() == user_tile:get_tile(facing, 3):x())) and (math.abs(user_tile:y() - tile:y()) <= 1))
        end

        local tile_list = nil
        local spell_list = {}
        
        step.update_func = function()
            if step_first then 
                user:get_animation():on_complete(function()
                    Engine.play_audio(user.roar_sfx, AudioPriority.Low)
                    user:get_animation():set_state("PLAYER_BREATH_LOOP")
                    user:get_animation():set_playback(Playback.Loop)
                    -- Refresh maybe
                    attacking = true
                    local currentX = user:get_current_tile():x()
                    local currentY = user:get_current_tile():y()
            
                    -- I didn't spawn these
                    spell_list[1] = create_spell(user, currentX, currentY, 1, 0)
                    spell_list[2] = create_spell(user, currentX, currentY, 2, 0)
                    spell_list[3] = create_spell(user, currentX, currentY, 2, 1)
                    spell_list[4] = create_spell(user, currentX, currentY, 2, -1)
                    spell_list[5] = create_spell(user, currentX, currentY, 3, 0)
                    spell_list[6] = create_spell(user, currentX, currentY, 3, 1)
                    spell_list[7] = create_spell(user, currentX, currentY, 3, -1)

                    step_first = false
                end)

                tile_list = user:get_field():find_tiles(tile_filter)

                for i=1, #tile_list
                do
                    tile_list[i]:highlight(Highlight.Flash)
                end
            end

            if attacking then 
                duration = duration - 1 
                if duration == 0 then 
                    step:complete_step()
                end

                if duration % 37 == 0 and duration > 0 then 
                    Engine.play_audio(user.fire_sfx, AudioPriority.Low)
                end
            end

        end

        action.execute_func = function()
            action:add_step(step)

        end

        action.action_end_func = function()
            for i=1, #spell_list
            do
                if spell_list[i] and not spell_list[i]:is_deleted() then 
                    spell_list[i]:delete()

                end
            end
        end
    
        
        return action
    end

    function Lightning_Breath(user)
        local action = Battle.CardAction.new(user, "PLAYER_LIGHTNING_BREATH_START")
        action:set_lockout(make_sequence_lockout())
        local field = user:get_field()
        local horizontal_spells = {}
        local vertical_spells = {}
        

        local startup = 22  

        local step = Battle.Step.new()
        local step_first = true
        local duration = 120
        local attacking = false

        local step2 = Battle.Step.new()
        local step2_first = false

        local function highlight_spell()
            local spell = Battle.Spell.new(user:get_team())
        end

        local function create_vertical(user, tile)
            local hasHit = false -- Unused
            local spell = Battle.Spell.new(user:get_team())
            local offsetY = 0
            local lifetime = 120
            local spell_list = {}

            local spell = graphic_init("spell", 8, -6, "lightning.png", "lightning.animation", -2, "1", user, user:get_facing())

            spell:get_animation():set_playback(Playback.Loop)

         --   spell:highlight_tile(Highlight.Solid)
            local props = HitProps.new(
                user:get_attack_level() * 50,
                Hit.Impact| Hit.Flinch | Hit.Pierce | Hit.Retangible | Hit.Stun,
                Element.Elec, 
                user:get_context(),
                Drag.None
            )
            spell:set_hit_props(props)

            
            spell.can_move_to_func = function()
                return true
            end

            spell.update_func = function(self)
                lifetime = lifetime - 1
                if lifetime == 0 then 
                    spell:delete()
                    
                end


            end


            spell.attack_func = function()
                Engine.play_audio(user.hit_sfx, AudioPriority.Low)
            end

            spell.collision_func = function()
                hasHit = true
            end

            local field = user:get_field()
            field:spawn(spell, tile)
            spell_list[1] = spell

            local spell_count = 1

            for i=1, field:height()
            do
                local target_tile = field:tile_at(tile:x(), i)
                if target_tile and not target_tile:is_edge() and i ~= tile:y() then 
                    local copy = copy_spell(spell, props, 120)
                    field:spawn(copy, target_tile)
                    spell_list[spell_count+1] = copy
                    spell_count = spell_count + 1
                end


            end
            
            return spell_list

        end

        local function create_horizontal(user, tile)
            local hasHit = false
            local spell = Battle.Spell.new(user:get_team())
            local offsetY = 0
            local lifetime = 120

            local spell = graphic_init("spell", 174, -8, "lightning.png", "lightning.animation", 2, "0", user, user:get_facing())

            spell:get_animation():set_playback(Playback.Loop)
    
            local props = HitProps.new(
                user:get_attack_level() * 50,
                Hit.Impact| Hit.Flinch | Hit.Pierce | Hit.Retangible | Hit.Stun,
                Element.Elec, -- Maybe elec
                user:get_context(),
                Drag.None
                )

            spell:set_hit_props(props)

            
            spell.can_move_to_func = function()
                return true
            end

            spell.update_func = function(self)
                lifetime = lifetime - 1
                
                self:get_current_tile():highlight(Highlight.Solid)
                if lifetime % 20 == 0 then 
                    Engine.play_audio(user.lightning_sfx2, AudioPriority.Low)
                end
                

                if not hasHit then
                    self:get_current_tile():attack_entities(self)
                end


                if lifetime == 0 then 
                    spell:delete()

                end
            end


            spell.attack_func = function()
                Engine.play_audio(user.hit_sfx, AudioPriority.Low)
            end

            spell.collision_func = function()
                hasHit = true
            end

            local field = user:get_field()
            field:spawn(spell, tile)
            local spell_list = {spell}

            for i=1, field:width()
            do
                local target_tile = tile:get_tile(user:get_facing(), i)
                if target_tile and not target_tile:is_edge() then 
                    local copy = copy_spell(spell, props, 120)
                    field:spawn(copy, target_tile)
                    spell_list[i+1] = copy
                else
                    break
                end


            end
        --    local copy1 = copy_spell(spell, props, 120)
          --  local copy2 = copy_spell(spell, props, 120)
            --local sharebox1 = copy_spell(spell)

        --    local sharebox2 = Battle.SharedHitbox.new(spell, 2)
          --  sharebox2:set_hit_props(spell:copy_hit_props())
            --local sharebox3 = Battle.SharedHitbox.new(spell, 2)
            --sharebox3:set_hit_props(spell:copy_hit_props())


           -- field:spawn(sharebox2, tile:get_tile(user:get_facing(), 2))
            --field:spawn(sharebox3, tile)

            return spell_list
        end


        step.update_func = function()
            if step_first then 
                user:get_animation():set_state("PLAYER_LIGHTNING_BREATH_START")
                user:get_animation():set_playback(Playback.Loop)

                user:get_animation():refresh(user:sprite())
                step_first = false

                
                
            end

            for i=1, field:width()
            do
                local target_tile = user:get_current_tile():get_tile(user:get_facing(), i)
                if target_tile and not target_tile:is_edge() then 
                    target_tile:highlight(Highlight.Flash)
                else
                    break
                end


            end

            local tile = user:get_tile(user:get_facing(), 1)
            for i=1, field:height()
            do
                local target_tile = field:tile_at(tile:x(), i)
                if target_tile and not target_tile:is_edge() and i ~= tile:y() then 
                    target_tile:highlight(Highlight.Flash)
                end

            end

            startup = startup - 1

            if startup == 1 then 
                Engine.play_audio(user.lightning_sfx, AudioPriority.Low)
            end

            if startup == 0 then
                Engine.play_audio(user.roar_sfx, AudioPriority.Low)
                horizontal_spells = create_horizontal(user, user:get_current_tile():get_tile(user:get_facing(), 1))
                vertical_spells = create_vertical(user, user:get_current_tile():get_tile(user:get_facing(), 1))

                user:get_animation():set_state("PLAYER_LIGHTNING_BREATH_LOOP")
                user:get_animation():set_playback(Playback.Loop)
                action:add_step(step2)

                step:complete_step()
            end
        end

        step2.update_func = function()
            duration = duration - 1
            if step2_first then 

                step2_first = false
            end
            
            
                if duration == 0 then 
                    step2:complete_step()
                end

--                if duration % 37 == 0 then 
               --     Engine.play_audio(user.fire_sfx, AudioPriority.Low)
 --               end

        end

        action.execute_func = function()

            action:add_step(step)
        end

        action.action_end_func = function()

            for i=1, #horizontal_spells
            do
                local check_spell = horizontal_spells[i]
                if check_spell and not check_spell:is_deleted() then 
                    check_spell:delete() 
                end
            end

            for i=1, #vertical_spells
            do
                local check_spell = vertical_spells[i]
                if check_spell and not check_spell:is_deleted() then 
                    check_spell:delete() 
                end
            end
            
        end

        return action
    end

    player.charged_attack_func = Burning_Breath
    -- Loop for 21


    -- Hits on 27, appears on the top of screen on 5 when at bottom row, flashes for 12-14 before shadow appears?
    function create_rock(user, target_tile)
        local rock = graphic_init("spell", 0, 0, "rock.png", "rock.animation", -2, "0", user, user:get_facing())
        local speed = 12
        local time = 0
        local initial_height = 332
       -- local acceleration = initial_height/(fall_time*fall_time)

        local props = HitProps.new(
                user:get_attack_level() * 25,
                Hit.Impact| Hit.Flinch, -- Maybe breaking
                Element.None, 
                user:get_context(),
                Drag.None
        )

        rock:set_hit_props(props)

        rock.collision_func = function(self)
            local hit_effect = graphic_init("artifact", 0, 0, "hit_effect.png", "hit_effect.animation", -3, "1", user, user:get_facing())
            hit_effect:get_animation():on_complete(function(self)
                hit_effect:delete()
            end)
            user:get_field():spawn(hit_effect, target_tile)
        end

        rock.attack_func = function()
            Engine.play_audio(user.hit_sfx, AudioPriority.Low)

        end

        

        rock:set_elevation(speed*27)
        rock:show_shadow(true)
        rock:set_shadow(1)

        local function rock_break(tile)
            local piece1 = graphic_init("artifact", 0, 0, "rock.png", "rock.animation", -2, "1", user, user:get_facing())
            piece1.time = -6
            piece1.flash_count = 0
            piece1:show_shadow(true)
            piece1:set_shadow(1)
            local piece2 = graphic_init("artifact", 0, 0, "rock.png", "rock.animation", -2, "1", user, user:get_facing())
            piece2.time = -8
            piece2.flash_count = 0
            piece2:show_shadow(true)
            piece2:set_shadow(1)


            piece1.update_func = function(self)
                local time = self.time
                if self:get_offset().y <= 0 then 

                    self:set_offset(self:get_offset().x + 4, ((time*time)/2 - 20))

                    
                else
                    if time % 4 < 2 then
                        self:hide()
                        if self.flash_count > 3 then 
                            self:delete()
                        end
                    else
                        self:reveal()
                        self.flash_count = self.flash_count + 1
                    end 
                    
                end
                
                self.time = self.time+1

            end

            piece2.update_func = function(self)
                local time = self.time
                if self:get_offset().y <= 0 then 

                    self:set_offset(self:get_offset().x - 2, ((time*time)/3 - 30))

                    
                else
                    if time % 4 < 2 then
                        self:hide()
                        if self.flash_count > 3 then 
                            self:delete()
                        end
                    else
                        self:reveal()
                        self.flash_count = self.flash_count + 1
                    end 
                    
                end

                self.time = self.time+1


            end

            user:get_field():spawn(piece1, tile)
            user:get_field():spawn(piece2, tile)

        end

        rock.update_func = function(self)
            if self:get_elevation() == 0 then 
                self:delete()
                rock_break(self:get_current_tile())
                Engine.play_audio(user.rock_break, AudioPriority.Low)
                self:get_current_tile():attack_entities(self)



                return
            end
           -- rock:set_elevation(initial_height - speed*time)
            self:set_elevation(self:get_elevation() - speed)

            time = time + 1

            

            if time == 20 then 
                speed = speed + 2
            end
            

        end


        user:get_field():spawn(rock, target_tile)
    end

    player.special_attack_func = function(player)
        if player.current_charge == 1 then 
            player.current_charge = 2
            player.charged_attack_func = Lightning_Breath
        else
            player.current_charge = 1
            player.charged_attack_func = Burning_Breath
        end
    end

end


-- Example use: local thing = graphic_init("artifact", 0, -30, "picture.png", "animation.animation", -2, "STATE", user, user:get_facing())
function graphic_init(type, x, y, texture, animation, layer, state, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    graphic:get_animation():load(_folderpath..animation)

    graphic:get_animation():set_state(state)
    graphic:get_animation():refresh(graphic:sprite())

    return graphic
end