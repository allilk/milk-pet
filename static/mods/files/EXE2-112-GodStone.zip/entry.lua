local DAMAGE = 150

local GODSTONE_TEXTURE = Engine.load_texture(_modpath.."godstone.png")
local GODSTONE_ANIMPATH = _modpath.."godstone.animation"
local GODSTONE_AUDIO_SWING = Engine.load_audio(_modpath.."godstone-swing.ogg")
local STONE_TEXTURE = Engine.load_texture(_modpath.."stone.png")
local STONE_ANIMPATH = _modpath.."stone.animation"
local STONE_SHADOW_TEXTURE = Engine.load_texture(_modpath.."stone-shadow.png")
local STONE_SHADOW_ANIMPATH = _modpath.."stone-shadow.animation"
local STONES_AUDIO_FALL = Engine.load_audio(_modpath.."exe2-knightman-fall.ogg")
local STONES_AUDIO_BREAK = Engine.load_audio(_modpath.."exe2-stones-break.ogg")
local STONE_PIECE_1_TEXTURE = Engine.load_texture(_modpath.."stonecube_piece_1.png")
local STONE_PIECE_1_ANIMPATH = _modpath.."stonecube_piece_1.animation"
local STONE_PIECE_2_TEXTURE = Engine.load_texture(_modpath.."stonecube_piece_2.png")
local STONE_PIECE_2_ANIMPATH = _modpath.."stonecube_piece_2.animation"
local AREASTEAL_AUDIO = Engine.load_audio(_modpath.."exe2-areasteal.ogg")
local STONECUBE_AUDIO = Engine.load_audio(_modpath.."exe2-stonecube.ogg")

local SMOKE_TEXTURE = Engine.load_texture(_modpath.."smoke.png")
local SMOKE_ANIMPATH = _modpath.."smoke.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath.."guard_hit.png")
local HIT_ANIMPATH = _modpath.."guard_hit.animation"
local HIT_AUDIO = Engine.load_audio(_modpath.."exe2-tink.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-112-GodStone")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"E","I","L","Q","U"})

    local props = package:get_card_props()
    props.shortname = "GodStone"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Summons     a God Stone!"
    props.long_description = "Summon a God Stone from the hole in front of you!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()
        local spawn_tile = user:get_tile(direction, 1)
        local tiles_are_holes = false
        if spawn_tile:get_tile(Direction.Up, 1):is_hole() and spawn_tile:get_tile(Direction.Down, 1):is_hole() then
            tiles_are_holes = true
        end

        local tile_array = {}
        local query = function(ent)
			if not user:is_team(ent:get_team()) then
				return true
			end
		end
		for i = 1, 6, 1 do
			for j = 1, 3, 1 do
				local tile = field:tile_at(i, j)
                if #tile:find_characters(query) > 0 then
					table.insert(tile_array, tile)
				end
			end
		end

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_2 = true
        local do_once_3 = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
		    	ref.navi:sprite():set_texture(GODSTONE_TEXTURE, true)
		    	ref.navi:sprite():set_layer(-3)
                ref.navi:set_offset(0.0, -356.0)

                local anim = ref.navi:get_animation()
                anim:load(GODSTONE_ANIMPATH)
                anim:set_state("DELAY1")
                anim:set_playback(Playback.Loop)
		    	anim:refresh(ref.navi:sprite())
		    	anim:on_complete(function()
                    print("Sphere spawned")
                    Engine.play_audio(AREASTEAL_AUDIO, AudioPriority.High)
		    		anim:set_state("SPHERE")
		    		anim:refresh(ref.navi:sprite())
		    	end)
                field:spawn(ref.navi, spawn_tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "SPHERE" then
                if ref.navi:get_offset().y >= -13 then
                    if do_once_2 then
                        do_once_2 = false
                        ref.navi:set_offset(0.0, 0.0)
                        if spawn_tile:is_hole() then
                            print("Spawn tile IS a hole!")
                            print("GodStone spawned")
		    		        anim:set_state("GODSTONE")
		    		        anim:refresh(ref.navi:sprite())
                        else
                            print("Spawn tile is NOT a hole!")
                            Engine.play_audio(HIT_AUDIO, AudioPriority.Highest)
                            create_effect(HIT_TEXTURE, HIT_ANIMPATH, "0", 0, 0, field, spawn_tile)
                            anim:set_state("DELAY2")
		    		        anim:refresh(ref.navi:sprite())
                            anim:on_complete(function()
                                ref.navi:erase()
                                step1:complete_step()
                            end)
                        end
                    end
                else
                    ref.navi:set_offset(0.0, ref.navi:get_offset().y + 13.0)
                end
            end
            if anim:get_state() == "GODSTONE" then
                if do_once_3 then
                    do_once_3 = false
                    anim:on_frame(1, function()
                        Engine.play_audio(STONECUBE_AUDIO, AudioPriority.Highest)
                    end)
                    anim:on_frame(21, function()
                        stones_fall(tiles_are_holes, ref.navi, field, user, props, team, direction)
                    end)
                    anim:on_frame(26, function()
                        stones_fall(tiles_are_holes, ref.navi, field, user, props, team, direction)
                    end)
                    anim:on_frame(31, function()
                        stones_fall(tiles_are_holes, ref.navi, field, user, props, team, direction)
                    end)
		    	    anim:on_complete(function()
                        anim:set_state("DELAY2")
                        anim:refresh(ref.navi:sprite())
                        anim:on_complete(function()
                            ref.navi:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function stones_fall(hole_check, navi, field, user, props, team, direction)
    if not hole_check then
        Engine.play_audio(STONES_AUDIO_FALL, AudioPriority.Highest)
        navi:shake_camera(15, 0.5)

        local tile1_X = nil
        local tile1_Y = nil
        local tile2_X = nil
        local tile2_Y = nil
        local tile3_X = nil
        local tile3_Y = nil
        local tile4_X = nil
        local tile4_Y = nil
        local tile5_X = nil
        local tile5_Y = nil
        local tiles_found = false

        local stones_number = math.random(3,5)
        local tile_number1
        repeat
            tile1_X = math.random(1, 6)
            tile1_Y = math.random(1, 3)
        until field:tile_at(tile1_X, tile1_Y):get_team() ~= team
        tile_number1 = field:tile_at(tile1_X, tile1_Y)
        if tile_number1 then
            local tile_number2
            repeat
                tile2_X = math.random(1, 6)
                tile2_Y = math.random(1, 3)
            until field:tile_at(tile2_X, tile2_Y):get_team() ~= team and field:tile_at(tile2_X, tile2_Y) ~= tile_number1
            tile_number2 = field:tile_at(tile2_X, tile2_Y)
            if tile_number2 then
                local tile_number3
                repeat
                    tile3_X = math.random(1, 6)
                    tile3_Y = math.random(1, 3)
                until field:tile_at(tile3_X, tile3_Y):get_team() ~= team and field:tile_at(tile3_X, tile3_Y) ~= tile_number1 and field:tile_at(tile3_X, tile3_Y) ~= tile_number2
                tile_number3 = field:tile_at(tile3_X, tile3_Y)
                if tile_number3 then
                    if stones_number == 4 or stones_number == 5 then
                        local tile_number4
                        repeat
                            tile4_X = math.random(1, 6)
                            tile4_Y = math.random(1, 3)
                        until field:tile_at(tile4_X, tile4_Y):get_team() ~= team and field:tile_at(tile4_X, tile4_Y) ~= tile_number1 and field:tile_at(tile4_X, tile4_Y) ~= tile_number2 and field:tile_at(tile4_X, tile4_Y) ~= tile_number3
                        tile_number4 = field:tile_at(tile4_X, tile4_Y)
                        if tile_number4 then
                            if stones_number == 5 then
                                local tile_number5
                                repeat
                                    tile5_X = math.random(1, 6)
                                    tile5_Y = math.random(1, 3)
                                until field:tile_at(tile5_X, tile5_Y):get_team() ~= team and field:tile_at(tile5_X, tile5_Y) ~= tile_number1 and field:tile_at(tile5_X, tile5_Y) ~= tile_number2 and field:tile_at(tile5_X, tile5_Y) ~= tile_number3 and field:tile_at(tile5_X, tile5_Y) ~= tile_number4
                                tile_number5 = field:tile_at(tile5_X, tile5_Y)
                                if tile_number5 then
                                    tiles_found = true
                                end
                            else
                                tiles_found = true
                            end
                        end
                    else
                        tiles_found = true
                    end
                end
            end
        end
        if tiles_found then
            create_stone(user, props, team, direction, field, field:tile_at(tile1_X, tile1_Y))
            create_stone(user, props, team, direction, field, field:tile_at(tile2_X, tile2_Y))
            create_stone(user, props, team, direction, field, field:tile_at(tile3_X, tile3_Y))
            if     stones_number == 4 then
                create_stone(user, props, team, direction, field, field:tile_at(tile4_X, tile4_Y))
            elseif stones_number == 5 then
                create_stone(user, props, team, direction, field, field:tile_at(tile4_X, tile4_Y))
                create_stone(user, props, team, direction, field, field:tile_at(tile5_X, tile5_Y))
            end
        end
    else
        Engine.play_audio(GODSTONE_AUDIO_SWING, AudioPriority.High)
    end
end

function create_stone(owner, props, team, direction, field, tile)
    local shadow = Battle.Artifact.new()
    shadow:set_facing(Direction.Right)
    shadow:set_texture(STONE_SHADOW_TEXTURE, true)
    shadow:set_offset(0, 0)
    local shadow_sprite = shadow:sprite()
    shadow_sprite:set_layer(99)
    local shadow_anim = shadow:get_animation()
	shadow_anim:load(STONE_SHADOW_ANIMPATH)
	shadow_anim:set_state("0")
	shadow_anim:refresh(shadow_sprite)
    field:spawn(shadow, tile)

    local stone = Battle.Artifact.new()
    stone:set_texture(STONE_TEXTURE, true)
    stone:set_offset(0.0, -356.0)
    local stone_sprite = stone:sprite()
    stone_sprite:set_layer(-99)
    local stone_anim = stone:get_animation()
    stone_anim:load(STONE_ANIMPATH)
    stone_anim:set_state("0")
	stone_anim:refresh(stone_sprite)
    field:spawn(stone, tile)

    local stonecube_piece_1 = Battle.Artifact.new()
    stonecube_piece_1:set_facing(Direction.Right)
    stonecube_piece_1:set_texture(STONE_PIECE_1_TEXTURE, true)
    local piece_1_sprite = stonecube_piece_1:sprite()
    piece_1_sprite:set_layer(-9)
    local piece_1_anim = stonecube_piece_1:get_animation()
	piece_1_anim:load(STONE_PIECE_1_ANIMPATH)
	piece_1_anim:set_state("0")
	piece_1_anim:refresh(piece_1_sprite)
    piece_1_anim:on_frame(18, function()
        create_effect(SMOKE_TEXTURE, SMOKE_ANIMPATH, "0", 32, 36, field, stonecube_piece_1:get_current_tile())
    end)
    piece_1_anim:on_complete(function()
        stonecube_piece_1:erase()
    end)

    local stonecube_piece_2 = Battle.Artifact.new()
    stonecube_piece_2:set_facing(Direction.Right)
    stonecube_piece_2:set_texture(STONE_PIECE_2_TEXTURE, true)
    local piece_2_sprite = stonecube_piece_2:sprite()
    piece_2_sprite:set_layer(-9)
    local piece_2_anim = stonecube_piece_2:get_animation()
	piece_2_anim:load(STONE_PIECE_2_ANIMPATH)
	piece_2_anim:set_state("0")
	piece_2_anim:refresh(piece_2_sprite)
    piece_2_anim:on_frame(21, function()
        create_effect(SMOKE_TEXTURE, SMOKE_ANIMPATH, "0", -36, 73, field, stonecube_piece_2:get_current_tile())
    end)
    piece_2_anim:on_complete(function()
        stonecube_piece_2:erase()
    end)

    local query = function(ent)
        if not owner:is_team(ent:get_team()) then
            return true
        end
    end

    local do_once = true

    stone.update_func = function(self, dt)
        --self:get_current_tile():attack_entities(self)
        if stone:get_offset().y >= -11 then
            if do_once then
                do_once = false
                stone:set_offset(0.0, 0.0)
                if not tile:is_hole() then
                    Engine.play_audio(STONES_AUDIO_BREAK, AudioPriority.High)
                    create_attack(owner, props, team, direction, field, tile)
                    create_effect(SMOKE_TEXTURE, SMOKE_ANIMPATH, "1", 0, -7, field, self:get_current_tile())
                    field:spawn(stonecube_piece_1, self:get_current_tile())
                    field:spawn(stonecube_piece_2, self:get_current_tile())
                    shadow:erase()
                    stone:erase()
                elseif #tile:find_characters(query) > 0 then
                    Engine.play_audio(STONES_AUDIO_BREAK, AudioPriority.High)
                    create_attack(owner, props, team, direction, field, tile)
                    create_effect(SMOKE_TEXTURE, SMOKE_ANIMPATH, "1", 0, -7, field, self:get_current_tile())
                    field:spawn(stonecube_piece_1, self:get_current_tile())
                    field:spawn(stonecube_piece_2, self:get_current_tile())
                    shadow:erase()
                    stone:erase()
                else
                    shadow:erase()
                    stone:erase()
                end
            end
        else
            stone:set_offset(0.0, stone:get_offset().y + 11.0)
        end
    end

	stone.collision_func = function(self, other)
	end

	stone.can_move_to_func = function(self, other)
		return true
	end

	stone.battle_end_func = function(self)
		self:delete()
	end

    stone.delete_func = function(self)
		self:erase()
	end

    field:spawn(stone, tile)

    print("Attack tile: ("..tile:x()..";"..tile:y()..")")
end

function create_attack(owner, props, team, direction, field, tile)
    local spell = Battle.Spell.new(team)
    spell:get_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
    end
    spell.can_move_to_func = function(tile)
		return true
	end
    spell.battle_end_func = function(self)
		self:erase()
	end
    spell.delete_func = function(self)
		self:erase()
    end
     
    field:spawn(spell, tile)
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end