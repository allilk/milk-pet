nonce = function() end
 
local Tickaudio = Engine.load_audio(_modpath.."timebomb.ogg") --notes to self: Timebomb has 50 HP.
local Zeroaudio = Engine.load_audio(_modpath.."timezero.ogg")
local Bombaudio = Engine.load_audio(_modpath.."Bomb HQ.ogg")
local Bombtexture = Engine.load_texture(_modpath.."timebombtexture.png")
local Explodetexture = Engine.load_texture(_modpath.."explosiontexture.png")

function package_init(package) 
    package:declare_package_id("hoov.cards.timebomb2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'D','H','Z'})

    local props = package:get_card_props()
    props.shortname = "TimeBom2"
    props.damage = 140
    props.time_freeze = true
    props.element = Element.Summon
    props.description = "Explode 3 seconds later"
	props.can_boost = true
    props.limit = 4
end

function get_xpos(user, starty, field) --help gets X co-ords for bomb placement
    --local tile = tile:get_tile()
    local tile = field:tile_at(1, starty)
    if user:get_facing() == Direction.Left then
        tile = field:tile_at(6, starty)
    end
    local xpos = nil
    while tile:get_team() == user:get_team() do
        xpos = tile:get_tile(user:get_facing(), 1):x()
        tile = tile:get_tile(user:get_facing(), 1)
    end
    return xpos
end

function shuffle(tbl) --shuffle tables. very useful code
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

--explosion generaton code
function explosion_spots(user, field, props, list)
    local randblast_handler = Battle.Component.new(user, Lifetimes.Local)
    user:register_component(randblast_handler)
    for xpos = 1, 6, 1 do
        for ypos = 1, 3, 1 do
            local tile = field:tile_at(xpos, ypos)
            if tile:get_team() ~= user:get_team() and not tile:is_edge() then
            
                table.insert(list, tile)
                local spell = create_attack(user, props) --swap this out with something that adds it to a list later
                field:spawn(spell, tile)
                --print("Not your tile!")
            
            else
                --print("Your tile!")
            end
        end
    end
    shuffle(list)
    local tilenum = 1
    local cooldown = 0
    user:shake_camera(10, 0.5)
    randblast_handler.update_func = function (dt) --this is where the random explosion magic happens
        if tilenum <= #list and cooldown % 3 == 0 then
            --print("bang")
            local currenttile = list[tilenum]
            create_explosion(user, currenttile)
            tilenum = tilenum + 1
            cooldown = 0

        end

        if tilenum >= #list then
            randblast_handler:eject()
            --print("explosions ended")
        end
        cooldown = cooldown + 1

    end
end

function card_create_action(actor, props) --places bomb and handles countdown
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function (self, user)
        local field = user:get_field()
		--local tile = user:get_tile()
        local tile_list = {}
        local boomtime = false
        local bombtimer = Battle.Component.new(user, Lifetimes.Battlestep) --Battlestep
        local bomb = Battle.Obstacle.new(Team.Other)
        bomb:set_texture(Bombtexture, true)
        bomb:set_facing(user:get_facing())
        bomb:never_flip(true)
        local anim = bomb:get_animation()
        anim:load(_modpath.."timebomb.animation")
        anim:set_state("SPAWN")
		anim:refresh(bomb:sprite())
		anim:on_complete(function()
            anim:set_state("COUNT3")
            print("three...")
            --Engine.play_audio(Tickaudio, AudioPriority.High) anim:set_playback(Playback.Loop)
            
            boomtime = true
        end)
        bomb:set_health(50)
        bomb:register_component(bombtimer)
        local twocount = true
        local onecount = true
        local zerocount = true
        --local start1 = field:tile_at
        local tile1 = field:tile_at(get_xpos(user, 1, field), 1)
        local tile2 = field:tile_at(get_xpos(user, 2, field), 2)
        local tile3 = field:tile_at(get_xpos(user, 3, field), 3)
        local spawn_list = {
            tile1,
            tile2,
            tile3,
        }
        local randtile = spawn_list[math.random(1, 3)]
        --randtile is for random bomb placement
        local query = function(ent)
            return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
        end
        if #randtile:find_entities(query) == 0 and not randtile:is_edge() and randtile:is_walkable() then
            user:get_field():spawn(bomb, randtile)
            print("Random tile!")
        elseif #tile1:find_entities(query) == 0 and not tile1:is_edge() and tile1:is_walkable() then
            user:get_field():spawn(bomb, tile1)
            print("Tile1")
        elseif #tile2:find_entities(query) == 0 and not tile2:is_edge() and tile2:is_walkable() then
            user:get_field():spawn(bomb, tile2)
            print("Tile2")
        elseif #tile3:find_entities(query) == 0 and not tile3:is_edge() and tile3:is_walkable() then
            user:get_field():spawn(bomb, tile3)
            print("Tile3")
        else
            print ("No valid space")
        end
        local bombcounter = 0 --might need to make it -43
        
        bombtimer.update_func = function() --Controls the wave's progress   
            if boomtime == true then
                bombcounter = bombcounter + 1
                --print(bombcounter)
            end
        end

        bomb.update_func = function(self, dt)
            if boomtime == true then
                
                --anim:on_frame(2, function () ok so 100's way too long
                if bombcounter == 60 then
                    if twocount then
                    anim:set_state("COUNT2")
                    print("two...")
                    Engine.play_audio(Tickaudio, AudioPriority.High)
                    twocount = false
                    end
                end
                --end)
                --anim:on_frame(3, function ()
                if bombcounter  == 120 then
                    if onecount then
                    anim:set_state("COUNT1")
                    print("one...")
                    Engine.play_audio(Tickaudio, AudioPriority.High)
                    onecount = false
                    end
                end
                --end)
                --anim:on_frame(4, function ()
                if bombcounter == 180 then
                    if zerocount then
                    anim:set_state("COUNT0")
                    print("Boom!")
                    Engine.play_audio(Zeroaudio, AudioPriority.High)
                    zerocount = false
                    end
                end
                --end)
                --anim:on_frame(5, function ()
                if bombcounter == 210 then
                    print("*explosion sounds*")
                    explosion_spots(user, field, props, tile_list)
                    Engine.play_audio(Bombaudio, AudioPriority.High)
                    --have the create explosion code here
                    --bombtimer:eject()
                    bomb.delete_func(bomb)
                end
                --end)

            end
            if self:get_health() <= 0 then
                bomb.delete_func(bomb)
            end
        end
        bomb.delete_func = function(self)
            bombtimer:eject()
            local tile = self:get_current_tile()
            if tile and not tile:is_edge() then
                create_explosion(self, tile)
            end
            bomb:erase()
        end
    end
    

    return action

end

--Create_attack type stuff here
function create_attack(user, props) --Attack Properties
    local spell = Battle.Spell.new(user:get_team())

    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )

    local query = function(ent)
        if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
            return true
        end
    end
    local runonce = true
    spell.update_func = function(self, dt)
        if runonce then
            self:get_current_tile():attack_entities(self)
            runonce = false
        else
            spell:erase()
        end
    end

    spell.collision_func = function(self, other)
    end
  spell.attack_func = function(self, other) 
      --Engine.play_audio(HITAUDIO, AudioPriority.Highest)
  end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    --Engine.play_audio(AUDIO, AudioPriority.Low)
    return spell
end

--make the explosion fx
function create_explosion (user, tile)
    local fx = Battle.Artifact.new()
    fx:set_texture(Explodetexture, true)
    fx:get_animation():load(_modpath.."explosion.animation")
    fx:get_animation():set_state("DEFAULT")
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_height(-16.0)
    local field = user:get_field()
    --local tile = user:get_current_tile()
    field:spawn(fx, tile)
end