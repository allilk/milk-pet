local doubleneedle = include("doubleneedle/doubleneedle.lua")

local DAMAGE = 50

doubleneedle.shots_count = 3
doubleneedle.needle_type = "1"

doubleneedle.codes = {"C","I","M","T","V"}
doubleneedle.shortname = "TriplNdl"
doubleneedle.damage = DAMAGE
doubleneedle.time_freeze = false
doubleneedle.element = Element.None
doubleneedle.description = "3 volleys of needles!"
doubleneedle.long_description = "Launch 3 needles in a row!"
doubleneedle.can_boost = true
doubleneedle.card_class = CardClass.Standard
doubleneedle.limit = 5

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-052-TripleNeedle")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(doubleneedle.codes)

    local props = package:get_card_props()
    props.shortname = doubleneedle.shortname
    props.damage = doubleneedle.damage
    props.time_freeze = doubleneedle.time_freeze
    props.element = doubleneedle.element
    props.description = doubleneedle.description
    props.long_description = doubleneedle.long_description
    props.can_boost = doubleneedle.can_boost
	props.card_class = doubleneedle.card_class
	props.limit = doubleneedle.limit
end

card_create_action = doubleneedle.card_create_action