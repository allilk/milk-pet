local DAMAGE = 50
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."buster.png")
local BUSTER_ANIMPATH = _folderpath.."buster.animation"
local NEEDLE_TEXTURE = Engine.load_texture(_folderpath.."needle.png")
local NEEDLE_ANIMPATH = _folderpath.."needle.animation"

local AUDIO_SHOOT = Engine.load_audio(_folderpath.."shoot.ogg")

local triplearrow = {
    shots_count = 2,
    needle_type = "1",

    codes = {"A","C","F","I","J"},
    shortname = "DoublNdl",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.None,
    description = "2 volleys of needles!",
    long_description = "Launch 2 needles in a row!",
    can_boost = true,
    card_class = CardClass.Standard,
    limit = 5
}

triplearrow.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    action.hits = triplearrow.shots_count

    local frame1 = {1, 0.033}
    local frame2 = {1, 0.305}
    local original_offset = actor:get_offset()
    action.frames = {frame1,frame1,frame1,frame2}

    action.before_exec = function(action)
        local frame3 = {1, 0.017}
        local frame4 = {1, 0.033}
        local frame5 = {1, 0.22}
        local frame6 = {1, 0.067}
        for i = 1, action.hits do
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame5)
        end
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame4)
        table.insert(action.frames,frame4)
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    action.before_exec(action)

    action.execute_func = function(self, user)
        local field = user:get_field()
        local team = user:get_team()
        local facing = user:get_facing()

        local attacking = false

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-2)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())
        
        self:add_anim_action(2, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(5, function()
            buster_anim:set_state("1")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Loop)
        end)

        self:add_anim_action(6, function()
            actor:toggle_counter(false)
        end)

        for i = 0, action.hits, 1 do
            self:add_anim_action(5+(i*6),function()
                if attacking then
                    --print("01")
                    actor:set_offset(original_offset.x, original_offset.y)
                    Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                    create_needle(user, props, team, facing, field, user:get_tile(facing, 1))
                end
            end)
            self:add_anim_action((5+(i*6))+1,function()
                if attacking then
                    --print(actor:get_offset().x)
                    --print("-2")
                    if facing == Direction.Right then
                        actor:set_offset(original_offset.x - 2*2, original_offset.y)
                    else
                        actor:set_offset(original_offset.x + 2*2, original_offset.y)
                    end
                end
            end)
            self:add_anim_action((5+(i*6))+2,function()
                if attacking then
                    --print(actor:get_offset().x)
                    --print("-1")
                    if facing == Direction.Right then
                        actor:set_offset(original_offset.x - 1*2, original_offset.y)
                    else
                        actor:set_offset(original_offset.x + 1*2, original_offset.y)
                    end
                end
            end)
            self:add_anim_action((5+(i*6))+3,function()
                if attacking then
                    --print(actor:get_offset().x)
                    --print("-2")
                    if facing == Direction.Right then
                        actor:set_offset(original_offset.x - 2*2, original_offset.y)
                    else
                        actor:set_offset(original_offset.x + 2*2, original_offset.y)
                    end
                end
            end)
            self:add_anim_action((5+(i*6))+4,function() --5
                if attacking then
                    --print(actor:get_offset().x)
                    --print("-1")
                    if facing == Direction.Right then
                        actor:set_offset(original_offset.x - 1*2, original_offset.y)
                    else
                        actor:set_offset(original_offset.x + 1*2, original_offset.y)
                    end
                end
            end)
            self:add_anim_action((5+(i*6))+5,function() --7
                if attacking then
                    --print(actor:get_offset().x)
                    --print("02")
                    actor:set_offset(original_offset.x, original_offset.y)
                end
            end)
        end

        self:add_anim_action(#action.frames-5,function()
            --print("03")
            actor:set_offset(original_offset.x, original_offset.y)
            attacking = false
            buster_anim:set_state("2")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Once)
        end)
        
	end
    action.action_end_func = function()
        actor:toggle_counter(false)
		actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function create_needle(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:highlight_tile(Highlight.Solid)
        spell:set_height((user:get_height()/2)+20)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact, 
                props.element, 
                user:get_context(), 
                Drag.None
            )
        )

        local sprite = spell:sprite()
        sprite:set_texture(NEEDLE_TEXTURE)
        sprite:set_layer(2)

        local anim = spell:get_animation()
        anim:load(NEEDLE_ANIMPATH)
        anim:set_state(triplearrow.needle_type)
        anim:refresh(sprite)
        anim:on_complete(function()
            tile = tile:get_tile(facing, 1)
            spawn_next()
            spell:erase()
        end, true)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
            end
        end

        spell.collision_func = function(self, other)
            self:erase()
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

return triplearrow