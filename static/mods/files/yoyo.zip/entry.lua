local debug = true
function debug_print(text)
    if debug then
        print("[yoyo] " .. text)
    end
end

function nonce() end

local buster_texture = Engine.load_texture(_modpath .. "buster.png")
local yoyo_texture = Engine.load_texture(_modpath .. "yoyo.png")

local buster_animation_path = _modpath .. "buster.anim"
local yoyo_animation_path = _modpath .. "yoyo.anim"

local yoyo_sfx = Engine.load_audio(_modpath .. "yoyo_sfx.ogg")
local hit_sfx = Engine.load_audio(_modpath .. "hit_sfx.ogg")

--variables that change for each version of the card
local details = {
    name="Yoyo1",
    codes={"Y","S", "T"},
    damage=50,
    duration=1.000,
    animation="DEFAULT"
}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = details.name
    props.damage = details.damage
    props.time_freeze = false
    props.element = Element.None
    props.description = "Attack 3 sqrs ahead!"

    package:declare_package_id("com.jamesking.card."..props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview_"..props.shortname..".png"))
    package:set_codes(details.codes)
end

function card_create_action(user,props)
    debug_print("in create_card_action()!")

    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    --special properties
    action.animation = details.animation

	action:set_lockout(make_async_lockout(details.duration))
	local ATTACK = {1 ,details.duration}
	local POST_ATTACK = {1, 0.1667} 
	local FRAMES = make_frame_data({ATTACK,POST_ATTACK})
	action:override_animation_frames(FRAMES)

    action.execute_func = function(self, user)
        local buster_attachment = self:add_attachment("BUSTER")
        local buster_sprite = buster_attachment:sprite()
        buster_sprite:set_texture(buster_texture)
        buster_sprite:set_layer(-2)

        local buster_animation = buster_attachment:get_animation()
        buster_animation:load(buster_animation_path)
        buster_animation:set_state(action.animation)

		self:add_anim_action(1,function()
			action.yoyo_id = spawn_yoyo(
                user, 
                user:get_team(), 
                user:get_field(), 
                user:get_tile(user:get_facing(), 1), 
                user:get_facing(), details.damage, 
                yoyo_texture, 
                yoyo_sfx, 
                frames(7), 
                3
            )
		end)
    end

    action.animation_end_func = function(self)
        print("animation end called")
        local yoyo = user:get_field():get_entity(action.yoyo_id)

        if yoyo ~= nil then
            yoyo:delete()
        end
    end

    return action
end

function hit_func(self, entity)
    Engine.play_audio(hit_sfx, AudioPriority.Highest)
end

function spawn_hitbox(owner, team, field, tile, hitbox_props)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(hitbox_props)
    spell.update_func = function()
        tile:attack_entities(spell)
        spell:erase()
    end
    spell.attack_func = hit_func
    field:spawn(spell, tile)
end

function spawn_yoyo(owner, team, field, tile, direction, damage, texture, sfx, speed, hits)
    local spawn_next
    spawn_next = function()
        Engine.play_audio(sfx, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell.max_move_count = 3
        spell.move_count = spell.max_move_count
        spell.waiting = false
        spell.returning = false
        spell.hits = hits
        spell:set_facing(direction)
        spell:set_move_direction(direction)
        spell:highlight_tile(Highlight.None)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact|Hit.Flinch, Element.None, owner:get_context() , Drag.None))

        local sprite = spell:sprite()
        sprite:set_texture(texture)

        local animation = spell:get_animation()
        animation:load(yoyo_animation_path)
        animation:set_state("DEFAULT")
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)

        spell.can_move_to_func = function(tile) 
            return true
        end

        spell.attack_func = hit_func

        spell.delete_func = function(self) 
            local fx = Battle.Explosion.new(1, 1.0)
            self:get_field():spawn(fx, self:get_current_tile())
            self:erase()
        end

        spell.update_func = function()
            if not spell.waiting then
                -- yoyo hits 3 times when on the target tile where it waits
                -- otherwise attack the tile it is on
                spell:get_current_tile():attack_entities(spell)
            end

            if not spell:is_sliding() then
                spell.move_count = spell.move_count - 1

                if spell.move_count == 0 then 
                    if spell.returning then
                        spell:erase()
                    else
                        if not spell.waiting then
                            spell.waiting = true 

                            animation:on_complete(
                                function()
                                    spawn_hitbox(owner, team, field, spell:get_current_tile(), spell:copy_hit_props())
                                    spell.hits = spell.hits - 1

                                    if spell.hits == 0 then
                                        spell.returning = true
                                        spell.waiting = false
                                        spell.move_count = spell.max_move_count
                                        spell:set_move_direction(spell:get_facing_away())
                                    end
                                end
                            )

                            return
                        end
                    end
                end

                if not spell.waiting then
                    spell:slide(
                        spell:get_tile(spell:get_move_direction(), 1), 
                        speed, 
                        frames(0), 
                        ActionOrder.Immediate, 
                        nonce
                    )
                end
            end
        end

        field:spawn(spell, tile)

        spell:slide(spell:get_tile(spell:get_move_direction(), 1), speed, frames(0), ActionOrder.Immediate, nonce)

        return spell:get_id()
    end

    return spawn_next()
end
