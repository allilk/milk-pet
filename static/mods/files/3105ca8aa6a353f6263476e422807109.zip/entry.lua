local bomb = include('bomb/bomb.lua')
 
bomb.name="Howitzer"
bomb.damage=200
bomb.element=Element.Break
bomb.description = "Breaks panels,Depth=3"
bomb.codes = {"A","C","G","H","O"}

function package_init(package)
    package:declare_package_id("rune.legacy.howitzer")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"A","C","G","H","O"})
 
    local props = package:get_card_props()
    props.shortname = "Howitzer"
    props.damage = 200
    props.time_freeze = false
    props.element = Element.Break
    props.secondary_element = Element.None
    props.description = "Breaks panels,Depth=3"
   end

   card_create_action = bomb.card_create_action
