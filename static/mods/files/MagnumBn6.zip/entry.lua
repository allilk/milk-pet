nonce = function() end

function package_init(package)
	package:declare_package_id("com.EXE6.Card136-Magnum")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'F', 'L', 'W' })

	local props = package:get_card_props()
	props.shortname = "Magnum"
	props.damage = 150
	props.time_freeze = true
	props.element = Element.Cursor
	props.description = "Cursor destroys panels!"
	props.card_class = CardClass.Standard
	props.limit = 3
	props.long_description = "Cursor destroys panels!"
end

function card_create_action(player, props)
	local finish_delay = 60
	local gun_audio = Engine.load_audio(_folderpath .. "heatShotImpact.ogg")
	local move_audio = Engine.load_audio(_folderpath .. "move.ogg")
	local action = Battle.CardAction.new(player, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	local tile_array = {}
	action.execute_func = function(self, user)
		local step1 = Battle.Step.new()
		local step2 = Battle.Step.new()
		local do_once = true
		local ref = self
		local field = user:get_field()
		local frame_count = 288
		local cursors = {}
		local cursor_move_delay = 12
		local start_positions = {}
		local stuntDouble = self:get_actor()
		local scanCount = 1
		start_positions.horizontal = get_start_column(user)
		start_positions.vertical = get_start_row(user)
		--self:get_actor():hide()
		step1.update_func = function(self, dt)
			if do_once then
				local cursor1 = create_cursor(start_positions.horizontal, 1, field, user)
				local cursor2 = create_cursor(start_positions.horizontal, 2, field, user)
				local cursor3 = create_cursor(start_positions.horizontal, 3, field, user)
				table.insert(cursors, cursor1)
				table.insert(cursors, cursor2)
				table.insert(cursors, cursor3)
				do_once = false
				Engine.play_audio(move_audio, AudioPriority.High)
			end
			if user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot) or frame_count <= 0 then
				self:complete_step()
			else

				cursor_move_delay = cursor_move_delay - 1
				if cursor_move_delay <= 0 then
					Engine.play_audio(move_audio, AudioPriority.High)
					move_cursors_next(cursors, start_positions, field, user:get_facing())
					cursor_move_delay = 12
					scanCount = scanCount + 1
				end
			end
			frame_count = frame_count - 1
		end
		step2.update_func = function(self, dt)
			finish_delay = finish_delay - 1
			if finish_delay == 40 then
				stuntDouble:get_animation():set_state("PLAYER_SWORD")
				stuntDouble:get_animation():on_frame(2, function()
					local hilt = action:add_attachment("HILT")
					local hilt_sprite = hilt:sprite()
					hilt_sprite:set_texture(stuntDouble:get_texture())
					hilt_sprite:set_layer(-2)
					hilt_sprite:enable_parent_shader(true)
					local hilt_anim = hilt:get_animation()
					hilt_anim:copy_from(stuntDouble:get_animation())
					hilt_anim:set_state("HAND")
					hilt_anim:refresh(hilt_sprite)
				end)
				stuntDouble:get_animation():on_frame(3, function()
					for index, cursor in ipairs(cursors) do
						local attack = create_attack(user, props)
						cursor:erase()
						Engine.play_audio(gun_audio, AudioPriority.Highest)
						field:spawn(attack, cursor:get_tile())
					end
				end)
			elseif finish_delay == 0 then
				stuntDouble:erase()
				self:complete_step()
			end
		end
		self:add_step(step1)
		self:add_step(step2)
	end
	return action
end

function create_cursor(x, y, field, user)
	local cursor_artifact = Battle.Artifact.new()
	cursor_artifact:set_texture(Engine.load_texture(_modpath .. "cursor.png"))
	cursor_artifact:sprite():set_layer(-5)
	cursor_artifact:get_animation():load(_modpath .. "cursor.animation")
	cursor_artifact:get_animation():set_state("SEARCH")
	cursor_artifact:set_float_shoe(true)
	cursor_artifact:set_air_shoe(true)
	cursor_artifact:get_animation():refresh(cursor_artifact:sprite())
	cursor_artifact.direction = (user:get_facing())
	cursor_artifact.can_move_to_func = function(tile) return true end
	cursor_artifact.initial_y = y;
	field:spawn(cursor_artifact, field:tile_at(x, y))
	return cursor_artifact
end

function move_cursors_next(cursors, start_positions, field, facing)
	for index, cursor in ipairs(cursors) do
		local next_tile = cursor:get_tile(cursor.direction, 1)
		if (next_tile:is_edge()) then
			if (is_dir_horizontal(cursor.direction)) then
				--wrap around to horizontal, Y = 1, x depends
				next_tile = field:tile_at(start_positions.vertical + cursor.initial_y - 1, 1)
				cursor.direction = Direction.Down
			else
				next_tile = field:tile_at(start_positions.horizontal, cursor.initial_y)
				cursor.direction = facing
			end
		end
		cursor:get_animation():set_state("SEARCH")
		cursor:teleport(next_tile, ActionOrder.Immediate, nil)
	end
end

function tile_occupied(tile)
	local query = function(char) return true end
	return #tile:find_characters(query) > 0 or #tile:find_obstacles(query) > 0
end

function is_dir_horizontal(direction)
	return direction == Direction.Left or direction == Direction.Right
end

function get_start_column(user)
	local facing = user:get_facing()
	local field = user:get_field()

	local check_row = 2
	local end_col = 6
	local increment = 1
	if facing == Direction.Left then
		check_row = 5
		end_col = 1
		increment = -1
	end

	for x = check_row, end_col, increment do
		if (not column_controlled_by_team(field, user:get_team(), x)) then
			return x
		end
	end
	return end_col
end

function get_start_row(user)
	if (user:get_facing() == Direction.Right) then
		return 4
	else
		return 1
	end
end

-- return true if team controls all tiles in a column
function column_controlled_by_team(field, team, x)
	for y = 1, 3, 1 do
		if (field:tile_at(x, y):get_team() ~= team) then
			return false
		end
	end
	return true
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell:set_texture(Engine.load_texture(_modpath .. "blast.png"))
	spell:sprite():set_layer(-5)
	local anim = spell:get_animation()
	anim:load(_modpath .. "blast.animation")
	anim:set_state("Fast")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:erase()
	end)
	local do_once = true
	local attacked = false
	spell.update_func = function(self, dt)
		if (do_once) then
			local tile = self:get_tile()
			if tile and tile:is_walkable() then

				if (tile_occupied(tile)) then
					tile:set_state(TileState.Cracked)
				else
					tile:set_state(TileState.Broken)
				end
			end
			do_once = false
		elseif not attacked then
			self:get_tile():attack_entities(self)
			attacked = true
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	return spell
end
