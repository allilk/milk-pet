local DAMAGE = 30
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE6_50.wav")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE6_131.wav")
 
local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."spread_buster.png")
local BUSTER_ANIMPATH = _folderpath.."spread_buster.animation"
local BURST_TEXTURE = Engine.load_texture(_folderpath.."spread_impact.png")
local BURST_ANIMPATH = _folderpath.."spread_impact.animation"
local BURST_AUDIO = Engine.load_audio(_folderpath.."EXE6_282.wav")

local spreadgun = {
    codes = {"L","M","N","*"},
	shortname = "SprdGun1",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Spreads to 1 sqr around!",
	long_description = "When hits, spreads to 1 square around!",
	can_boost = true,
	card_class = CardClass.Standard,
	memory = 10,
	limit = 5
}

spreadgun.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.0170}
	local frame2 = {2, 0.0170}
	local frame3 = {2, 0.0170}
	local frame4 = {2, 0.0170}
	local frame5 = {3, 0.0170}
	local frame6 = {3, 0.0330}
	local frame7 = {4, 0.0840}
	local frame8 = {4, 0.1690}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8})
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-3)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
		
		self:add_anim_action(2, function()
            Engine.play_audio(BURST_AUDIO, AudioPriority.Highest)
			actor:toggle_counter(true)
			local tile = user:get_tile(facing, 1)
			create_attack(user, props, team, facing, field, tile)
        end)
		self:add_anim_action(8, function()
			actor:toggle_counter(false)
        end)
	end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
	end
    return action
end

function create_attack2(user, props, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
    	print("Spread on tile ("..tile:x()..";"..tile:y()..")")
    	local spell = Battle.Spell.new(team)
    	spell:set_facing(facing)
    	spell:set_hit_props(
    	    HitProps.new(
    	        props.damage, 
    	        Hit.Impact | Hit.Flash | Hit.Flinch, 
    	        props.element,
    	        user:get_context(), 
    	        Drag.None
    	    )
    	)
		local anim = spell:get_animation()
		anim:load(_folderpath.."attack.animation")
		anim:set_state("0")
		anim:on_complete(function()
			spell:delete()
		end, true)
    	spell.update_func = function(self, dt)
    	    self:get_current_tile():attack_entities(self)
    	end
		spell.attack_func = function(self, ent)
			if Battle.Obstacle.from(ent) == nil then
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
				end
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.High)
			end
		end
		spell.battle_end_func = function(self)
			spell:delete()
		end
		spell.delete_func = function(self)
			spell:erase()
		end
		spell.can_move_to_func = function(self, other)
			return true
		end
		create_effect(Direction.Right, BURST_TEXTURE, BURST_ANIMPATH, "0", 0.0, -16.0*2, -99, field, tile)
		field:spawn(spell, tile)
	end
    spawn()
end

function create_attack(user, props, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end
		print("Spread Gun attack spawned at tile ("..tile:x()..";"..tile:y()..")")
		local spell = Battle.Spell.new(team)
		spell.slide_started = false
		--[[local sprite = spell:sprite()
    	sprite:set_texture(Engine.load_texture(_folderpath.."testdot.png"), true)
		sprite:set_layer(-3)
    	local anim = spell:get_animation()
		anim:load(_folderpath.."testdot.animation")
		anim:set_state("0")]]
		spell.update_func = function(self, dt) 
    	    self:get_current_tile():attack_entities(self)
    	    if self:is_sliding() == false then
    	        if self:get_current_tile():is_edge() and self.slide_started then 
    	            self:delete()
    	        end 

    	        local dest = self:get_tile(facing, 1)
    	        local ref = self
    	        self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
    	            function()
    	                ref.slide_started = true 
    	            end
    	        )
    	    end
    	end
		spell.collision_func = function(self, ent)
			print("Spread Gun attack collided tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
			create_attack2(user, props, team, facing, field, ent:get_current_tile())																		--cur tile
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(facing, 1))													--forward
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Up, 1))												--up
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.Down, 1))											--down
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.reverse(facing), 1))									--back
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(facing, 1):get_tile(Direction.Up, 1))							--up-forward
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(facing, 1):get_tile(Direction.Down, 1))						--down-forward
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.reverse(facing), 1):get_tile(Direction.Up, 1))		--up-back
			create_attack2(user, props, team, facing, field, ent:get_current_tile():get_tile(Direction.reverse(facing), 1):get_tile(Direction.Down, 1))		--down-back
			self:delete()
		end
    	spell.attack_func = function(self, other)
    	end
		spell.battle_end_func = function(self)
			self:delete()
		end
    	spell.delete_func = function(self)
			self:erase()
    	end
    	spell.can_move_to_func = function(tile)
    	    return true
    	end
		field:spawn(spell, tile)
	end
    spawn()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return spreadgun