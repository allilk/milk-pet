local DAMAGE = 30

local TEXTURE_VIDEOMAN = Engine.load_texture(_modpath.."videoman.png")
local TEXTURE_WINDCUTTER = Engine.load_texture(_modpath.."windcutter.png")
local ANIMPATH_VIDEOMAN = _modpath.."videoman.animation"
local ANIMPATH_WINDCUTTER = _modpath.."windcutter.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_WINDCUTTER = Engine.load_audio(_modpath.."windcutter.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-268-VideoManDS")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"V"})

    local props = package:get_card_props()
    props.shortname = "VideMnDS"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Attack tape slam 2.5 in"
    props.long_description = "Tape core in 2 squares forward! Rolling tape attack"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    local dark_hole_query = function(hole)
        return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
    end
    local field = actor:get_field()
    local dark_hole_list = field:find_obstacles(dark_hole_query)
    local boost = 5 * (math.min(10, #dark_hole_list))
    props.damage = props.damage + boost
    action:set_metadata(props)
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local x = self_tile:x()
        local y = self_tile:y()

		local step1 = Battle.Step.new()

        self.videoman = nil
        self.tile     = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.videoman = Battle.Artifact.new()
                ref.videoman:set_facing(direction)
		    	ref.videoman:set_texture(TEXTURE_VIDEOMAN, true)
		    	ref.videoman:sprite():set_layer(-1)

                video_anim = ref.videoman:get_animation()
                video_anim:load(ANIMPATH_VIDEOMAN)
                video_anim:set_state("SPAWN")
		    	video_anim:refresh(ref.videoman:sprite())
                video_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
		    	video_anim:on_complete(function()
		    		video_anim:set_state("ATTACK")
		    		video_anim:refresh(ref.videoman:sprite())
		    	end)
                field:spawn(ref.videoman, ref.tile)
            end
            local anim = ref.videoman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local doublecutter = false
                    anim:on_frame(3, function()
                        print("VideoMan: WindCutter!")
                        local cutterdist1 = nil
                        local cutterdist2 = nil
				        local cutter1_1 = create_attack(team, direction, user, props)
                        local cutter1_2 = create_attack(team, direction, user, props)
                        local cutter1_3 = create_attack(team, direction, user, props)
                        local cutter1_4 = create_attack(team, direction, user, props)
                        local cutter2_1 = create_attack(team, direction, user, props)
                        local cutter2_2 = create_attack(team, direction, user, props)
                        local cutter2_3 = create_attack(team, direction, user, props)
                        local cutter2_4 = create_attack(team, direction, user, props)
                        local cutter3_1 = create_attack(team, direction, user, props)
                        local cutter3_2 = create_attack(team, direction, user, props)
                        local cutter3_3 = create_attack(team, direction, user, props)
                        local cutter3_4 = create_attack(team, direction, user, props)
                        if direction == Direction.Right then
                            cutterdist1 = x + 2
                            cutterdist2 = x + 3
                        elseif direction == Direction.Left then
                            cutterdist1 = x - 2
                            cutterdist2 = x - 3
                        end
                        if y == 1 then
                            doublecutter = true
                        elseif y == 2 then
                            doublecutter = true
                            Engine.play_audio(AUDIO_WINDCUTTER, AudioPriority.Highest)
				            local fx1 = Battle.Artifact.new()
				            fx1:set_facing(direction)
				            local fx1_anim = fx1:get_animation()
				            fx1:set_texture(TEXTURE_WINDCUTTER, true)
				            fx1_anim:load(ANIMPATH_WINDCUTTER)
				            fx1_anim:set_state("ATTACK")
                            fx1_anim:on_frame(5, function()
                                field:spawn(cutter1_1, cutterdist1, 2)
				                field:spawn(cutter1_2, cutterdist1, 1)
				                field:spawn(cutter1_3, cutterdist2, 1)
                                field:spawn(cutter1_4, cutterdist2, 2)
                            end)
                            fx1_anim:on_frame(10, function()
                                cutter1_1:erase()
                                cutter1_2:erase()
                                cutter1_3:erase()
                                cutter1_4:erase()
                                field:spawn(cutter2_1, cutterdist1, 2)
				                field:spawn(cutter2_2, cutterdist1, 1)
				                field:spawn(cutter2_3, cutterdist2, 1)
                                field:spawn(cutter2_4, cutterdist2, 2)
                            end)
                            fx1_anim:on_frame(15, function()
                                cutter2_1:erase()
                                cutter2_2:erase()
                                cutter2_3:erase()
                                cutter2_4:erase()
                                field:spawn(cutter3_1, cutterdist1, 2)
				                field:spawn(cutter3_2, cutterdist1, 1)
				                field:spawn(cutter3_3, cutterdist2, 1)
                                field:spawn(cutter3_4, cutterdist2, 2)
                            end)
				            fx1_anim:on_complete(function()
                                cutter3_1:erase()
                                cutter3_2:erase()
                                cutter3_3:erase()
                                cutter3_4:erase()
				    	        fx1:erase()
				    	    end)
				            field:spawn(fx1, cutterdist1, 2)
                        else
                            Engine.play_audio(AUDIO_WINDCUTTER, AudioPriority.Highest)
				            local fx1 = Battle.Artifact.new()
				            fx1:set_facing(direction)
				            local fx1_anim = fx1:get_animation()
				            fx1:set_texture(TEXTURE_WINDCUTTER, true)
				            fx1_anim:load(ANIMPATH_WINDCUTTER)
				            fx1_anim:set_state("ATTACK")
				            fx1_anim:on_frame(5, function()
                                field:spawn(cutter1_1, cutterdist1, 3)
				                field:spawn(cutter1_2, cutterdist1, 2)
				                field:spawn(cutter1_3, cutterdist2, 2)
                                field:spawn(cutter1_4, cutterdist2, 3)
                            end)
                            fx1_anim:on_frame(10, function()
                                cutter1_1:erase()
                                cutter1_2:erase()
                                cutter1_3:erase()
                                cutter1_4:erase()
                                field:spawn(cutter1_1, cutterdist1, 3)
				                field:spawn(cutter1_2, cutterdist1, 2)
				                field:spawn(cutter1_3, cutterdist2, 2)
                                field:spawn(cutter1_4, cutterdist2, 3)
                            end)
                            fx1_anim:on_frame(15, function()
                                cutter2_1:erase()
                                cutter2_2:erase()
                                cutter2_3:erase()
                                cutter2_4:erase()
                                field:spawn(cutter3_1, cutterdist1, 3)
				                field:spawn(cutter3_2, cutterdist1, 2)
				                field:spawn(cutter3_3, cutterdist2, 2)
                                field:spawn(cutter3_4, cutterdist2, 3)
                            end)
				            fx1_anim:on_complete(function()
                                cutter3_1:erase()
                                cutter3_2:erase()
                                cutter3_3:erase()
                                cutter3_4:erase()
				    	        fx1:erase()
				    	    end)
				            field:spawn(fx1, cutterdist1, 3)
                        end
			        end)
                    anim:on_frame(12, function()
                        if doublecutter == true then
                            local cutterdist1 = nil
                            local cutterdist2 = nil
				            local cutter1_1 = create_attack(team, direction, user, props)
                            local cutter1_2 = create_attack(team, direction, user, props)
                            local cutter1_3 = create_attack(team, direction, user, props)
                            local cutter1_4 = create_attack(team, direction, user, props)
                            local cutter2_1 = create_attack(team, direction, user, props)
                            local cutter2_2 = create_attack(team, direction, user, props)
                            local cutter2_3 = create_attack(team, direction, user, props)
                            local cutter2_4 = create_attack(team, direction, user, props)
                            local cutter3_1 = create_attack(team, direction, user, props)
                            local cutter3_2 = create_attack(team, direction, user, props)
                            local cutter3_3 = create_attack(team, direction, user, props)
                            local cutter3_4 = create_attack(team, direction, user, props)
                            if direction == Direction.Right then
                                cutterdist1 = x + 2
                                cutterdist2 = x + 3
                            elseif direction == Direction.Left then
                                cutterdist1 = x - 2
                                cutterdist2 = x - 3
                            end
                            if y == 1 then
                                Engine.play_audio(AUDIO_WINDCUTTER, AudioPriority.Highest)
				                local fx2 = Battle.Artifact.new()
				                fx2:set_facing(direction)
				                local fx2_anim = fx2:get_animation()
				                fx2:set_texture(TEXTURE_WINDCUTTER, true)
				                fx2_anim:load(ANIMPATH_WINDCUTTER)
				                fx2_anim:set_state("ATTACK")
				                fx2_anim:on_frame(5, function()
                                    field:spawn(cutter1_1, cutterdist1, 2)
				                    field:spawn(cutter1_2, cutterdist1, 1)
				                    field:spawn(cutter1_3, cutterdist2, 1)
                                    field:spawn(cutter1_4, cutterdist2, 2)
                                end)
                                fx2_anim:on_frame(10, function()
                                    cutter1_1:erase()
                                    cutter1_2:erase()
                                    cutter1_3:erase()
                                    cutter1_4:erase()
                                    field:spawn(cutter2_1, cutterdist1, 2)
				                    field:spawn(cutter2_2, cutterdist1, 1)
				                    field:spawn(cutter2_3, cutterdist2, 1)
                                    field:spawn(cutter2_4, cutterdist2, 2)
                                end)
                                fx2_anim:on_frame(15, function()
                                    cutter2_1:erase()
                                    cutter2_2:erase()
                                    cutter2_3:erase()
                                    cutter2_4:erase()
                                    field:spawn(cutter3_1, cutterdist1, 2)
				                    field:spawn(cutter3_2, cutterdist1, 1)
				                    field:spawn(cutter3_3, cutterdist2, 1)
                                    field:spawn(cutter3_4, cutterdist2, 2)
                                end)
                                fx2_anim:on_complete(function()
                                    cutter3_1:erase()
                                    cutter3_2:erase()
                                    cutter3_3:erase()
                                    cutter3_4:erase()
                                    fx2:erase()
                                end)
				                field:spawn(fx2, cutterdist1, 2)
                            elseif y == 1 or y == 2 then
                                Engine.play_audio(AUDIO_WINDCUTTER, AudioPriority.Highest)
				                local fx2 = Battle.Artifact.new()
				                fx2:set_facing(direction)
				                local fx2_anim = fx2:get_animation()
				                fx2:set_texture(TEXTURE_WINDCUTTER, true)
				                fx2_anim:load(ANIMPATH_WINDCUTTER)
				                fx2_anim:set_state("ATTACK")
				                fx2_anim:on_frame(5, function()
                                    field:spawn(cutter1_1, cutterdist1, 3)
				                    field:spawn(cutter1_2, cutterdist1, 2)
				                    field:spawn(cutter1_3, cutterdist2, 2)
                                    field:spawn(cutter1_4, cutterdist2, 3)
                                end)
                                fx2_anim:on_frame(10, function()
                                    cutter1_1:erase()
                                    cutter1_2:erase()
                                    cutter1_3:erase()
                                    cutter1_4:erase()
                                    field:spawn(cutter2_1, cutterdist1, 3)
				                    field:spawn(cutter2_2, cutterdist1, 2)
				                    field:spawn(cutter2_3, cutterdist2, 2)
                                    field:spawn(cutter2_4, cutterdist2, 3)
                                end)
                                fx2_anim:on_frame(15, function()
                                    cutter2_1:erase()
                                    cutter2_2:erase()
                                    cutter2_3:erase()
                                    cutter2_4:erase()
                                    field:spawn(cutter3_1, cutterdist1, 3)
				                    field:spawn(cutter3_2, cutterdist1, 2)
				                    field:spawn(cutter3_3, cutterdist2, 2)
                                    field:spawn(cutter3_4, cutterdist2, 3)
                                end)
                                fx2_anim:on_complete(function()
                                    cutter3_1:erase()
                                    cutter3_2:erase()
                                    cutter3_3:erase()
                                    cutter3_4:erase()
                                    fx2:erase()
                                end)
				                field:spawn(fx2, cutterdist1, 3)
                            end
                        end
                    end)
                    anim:on_complete(function()
                        ref.videoman:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
	action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_attack(team, direction, user, props)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
	spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end

	return spell
end