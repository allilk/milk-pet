nonce = function() end

local DAMAGE = 70
local TRNARROW_TEXTURE = Engine.load_texture(_modpath .. "trnarrow.png")
local TRNARROW_ANIM = _modpath .. "trnarrow.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM = _modpath .. "effect.animation"
local AUDIO = Engine.load_audio(_modpath .. "TrnArrow.ogg")
local HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")


function package_init(package)
	package:declare_package_id("com.louise.card.drktrarw")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ "P" })

	local props = package:get_card_props()
	props.shortname = "DrkTrArw"
	props.damage = DAMAGE
	props.time_freeze = false
	props.element = Element.Aqua
	props.description = "HITS ENMY WITH MANY ARROW"
	props.long_description = "HITS ENMY WITH MANY ARROW"
	props.card_class = CardClass.Dark
end

local frame1 = { 1, 0.646 }
local frame_data = make_frame_data({
	frame1
})

---@param actor Entity
---@param props any
---@return unknown
function card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TRNARROW_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TRNARROW_ANIM)
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(3, function()
			-- create train arrows
			-- get endpoint
			Engine.play_audio(AUDIO, AudioPriority.High)
			local tile = get_first_enemy_tile(user, user:get_tile(user:get_facing(), 1))
			local delay = 0
			while tile ~= user:get_tile() do
				delay = delay + 4
				spawn_arrow(user, tile, DAMAGE, delay, user:get_facing())
				tile = tile:get_tile(user:get_facing_away(), 1)
			end
			spawn_arrow(user, tile, DAMAGE, delay, user:get_facing(), true)
		end)
	end

	return action
end

--filter function to only consider characters or obstacles
function filter(ent)
	if ent:get_health() <= 0 then return false end
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end
end

function tiletostring(tile)
	return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
	local fx = Battle.Artifact.new()
	fx:set_texture(hit_texture, true)
	local fx_sprite = fx:sprite()
	fx_sprite:set_layer(-3)
	local fx_anim = fx:get_animation()
	fx_anim:load(hit_anim_path)
	fx_anim:set_state(hit_anim_state)
	fx_anim:refresh(fx_sprite)
	fx_anim:on_complete(function()
		fx:erase()
	end)
	field:spawn(fx, tile)
	return fx
end

--get first enemy in line of sight, or end row
function get_first_enemy_tile(user, tile)

	if (tile:is_edge()) then
		return nil
	else
		if (#tile:find_entities(filter) >= 1) then
			-- tile occupied, return the last tile.
			return tile:get_tile(user:get_facing_away(), 1)
		else
			local next_tile = tile:get_tile(user:get_facing(), 1)
			if (next_tile:is_edge() or next_tile == nil) then
				return tile
			end
			return get_first_enemy_tile(user, next_tile)
		end
	end

end

--filter function to only consider characters or obstacles
function filter(ent)
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end
end

function spawn_arrow(user, tile, damage, delay, direction, last)
	-- Creates a new spell that belongs to the user's team.
	local spell = Battle.Spell.new(user:get_team())
	local speed = 7

	spell:set_height(54);
	spell:set_facing(user:get_facing())

	if (last) then
		spell:hide()
	end

	--Set the hit properties of this spell.
	spell:set_hit_props(
		HitProps.new(
			damage,
			Hit.Impact | Hit.Flinch,
			Element.Aqua,
			user:get_context(),
			Drag.new(direction, 1)
		)
	)
	-- Setup sprite of the spell
	local sprite = spell:sprite()
	sprite:set_texture(TRNARROW_TEXTURE)
	sprite:set_layer(-1)
	-- Setup animation of the spell
	local anim = spell:get_animation()
	anim:load(TRNARROW_ANIM)
	anim:set_state("ARROW")
	anim:refresh(sprite)
	spell.delay = delay


	spell.update_func = function(self, dt)
		--- Gets the next tile in the specified direction.
		--- If that tile is out of bounds, it returns nil
		if (spell.delay > 0) then
			spell.delay = spell.delay - 1
			return
		end
		spell:reveal()
		local tile = spell:get_tile(direction, 1)
		if (tile == nil) then
			-- Spell will be erased once it reaches the end of the field.
			spell:erase()
			return
		end
		--- Makes the spell slide to the next tile over a certain number of frames.
		spell:slide(tile, frames(speed), frames(0), ActionOrder.Voluntary, nil)
		--- Attacks the entities this spell collides with.
		self:get_current_tile():attack_entities(self)
	end

	spell.attack_func = function(self, other)
		-- Erases the spell once it hits something
		create_basic_effect(spell:get_field(), spell:get_current_tile(), HIT_TEXTURE, HIT_ANIM, "AQUA", HIT_SOUND)
		spell:erase()
	end

	spell.delete_func = function(self)
		spell:erase()
	end
	spell.battle_end_func = function(self)
		spell:erase()
	end

	--- Function that decides whether or not this spell is allowed
	--- to move to a certain tile. This is automatically called for
	--- functions such as slide and teleport.
	--- In this case since it always returns true, it can move over
	--- any tile.
	spell.can_move_to_func = function(tile)
		return true
	end
	user:get_field():spawn(spell, tile)
	return spell
end
