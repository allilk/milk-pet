nonce = function() end
 
local AUDIO1 = Engine.load_audio(_modpath.."shine.ogg")
 
function package_init(package)
    package:declare_package_id("rune.legacy.airshoes")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"H","I","N","U","Y","*"})
 
    local props = package:get_card_props()
    props.shortname = "AirShoes"
    props.damage = 0-0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Can stand on empty squares"
   
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        actor:set_air_shoe(true)
        actor:set_color(Color.new(16,255,49,225))
        actor:set_color(Color.new(80,255,80,225))
        actor:set_color(Color.new(16,255,49,225))
        Engine.play_audio(AUDIO1, AudioPriority.Low)    
    end


    return action
end
