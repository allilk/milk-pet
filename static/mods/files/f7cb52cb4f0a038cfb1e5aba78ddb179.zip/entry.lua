local SHOT_TEXTURE = Engine.load_texture(_modpath .. "3waytexture.png")
local SHOT_ANIM = _modpath .. "3wayshot.animation"
local SHOOT_AUDIO = Engine.load_audio(_modpath.."Sample-0.ogg")
local HIT_AUDIO = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("hoov.cards.3Way")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'B','N','T', '*'})

    local props = package:get_card_props()
    props.shortname = "3-Way"
    props.damage = 60
    props.time_freeze = false
    props.element = Element.None
    props.description = "Shoots in three dir."
	props.can_boost = true
    props.limit = 4
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())
    action.execute_func = function (self, user)
        local actor = self:get_actor()
        local coredirection = user:get_facing()
        local tile = user:get_tile(user:get_facing(), 1)
        local direction1 = Direction.join(user:get_facing(), Direction.Up)
        local direction2 = user:get_facing()
        local direction3 = Direction.join(user:get_facing(), Direction.Down)
        local buster = action:add_attachment("Buster")
        buster:sprite():set_texture(actor:get_texture(), true)
        buster:sprite():set_layer(-1)
        buster:sprite():enable_parent_shader(true)
      
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(actor:get_animation())
        buster_anim:set_state("BUSTER")
        local shot1 = create_shot(user, user:get_tile(direction1, 1), 8, direction1, props)
        local shot2 = create_shot(user, user:get_tile(direction2, 1), 8, direction2, props)
        local shot3 = create_shot(user, user:get_tile(direction3, 1), 8, direction3, props)
        actor:get_animation():on_frame(1, function()
            actor:get_field():spawn(shot1, tile)
            actor:get_field():spawn(shot2, tile)
            actor:get_field():spawn(shot3, tile)
            Engine.play_audio(SHOOT_AUDIO, AudioPriority.Low)
        end, false)
        


    end
    return action
end

function create_shot(user, tile, speed, direction, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(SHOT_TEXTURE)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(SHOT_ANIM)
    if direction == Direction.join(user:get_facing(), Direction.Up) then
        anim:set_state("UP")
        print("Upshot")
    elseif direction == Direction.join(user:get_facing(), Direction.Down) then
        anim:set_state("DOWN")
        print("Downshot")
    elseif direction == user:get_facing() then
        anim:set_state("STRAIGHT")
        print("Straightshot")
    end
    anim:set_playback(Playback.Loop)
    anim:refresh(sprite)

    spell.update_func = function(self, dt)
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(direction, 1)
        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            --print("erased")
            spell:erase()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        spell:slide(tile, frames(speed), frames(0), ActionOrder.Voluntary, nil)
        --- Attacks the entities this spell collides with.
        self:get_current_tile():attack_entities(self)
        spell:highlight_tile(Highlight.Solid)
    end
    spell.collision_func = function(self, other)
        --a
        spell:erase()
        
    end
    spell.attack_func = function(self, other)
        -- Erases the spell once it hits something
        local fx = Battle.Artifact.new()
		fx:set_texture(SHOT_TEXTURE, true)
		fx:get_animation():load(SHOT_ANIM)
		fx:get_animation():set_state("IMPACT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
        local tile = self:get_current_tile()
        spell:get_field():spawn(fx, tile)
        --print("erased")
        Engine.play_audio(HIT_AUDIO, AudioPriority.Low)
        spell:erase()
        
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end