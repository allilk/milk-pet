local bombtexture = Engine.load_texture(_modpath .. "blackbombtexture.png")
local bombanim = _modpath .. "blackbomb.animation"
local explodetexture = Engine.load_texture(_modpath .. "explosiontexture.png") 
local explodeanim = _modpath .. "explosion.animation"
local explodeaudio = Engine.load_audio(_modpath .. "Bomb HQ.ogg")
local thudaudio = Engine.load_audio(_modpath .. "ItemThud_HQ.ogg")
local tossaudio = Engine.load_audio(_modpath .. "toss_item.ogg")

function package_init(package) 
    package:declare_package_id("hoov.cards.blackbomb")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'B','F','O'})

    local props = package:get_card_props()
    props.shortname = "BlkBomb"
    props.damage = 250
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Thrw shel 3sqr fwd. Fire attk"
	props.can_boost = true
    props.limit = 3
end

function shuffle(tbl) --shuffle tables. very useful code
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function explosion_spots(user, field, props, list, targtile)
    local randblast_handler = Battle.Component.new(user, Lifetimes.Local)
    user:register_component(randblast_handler)
    local targteam
    if targtile:get_team() == Team.Red then
        targteam = Team.Blue
        print("teamblue")
    elseif targtile:get_team() == Team.Blue then
        targteam = Team.Red
        print("teamred")
    end
    --local testnum = 1
    for xpos = 1, 6, 1 do
        for ypos = 1, 3, 1 do
            local tile = field:tile_at(xpos, ypos)
            if tile:get_team() == targtile:get_team() and not tile:is_edge() then
            
                table.insert(list, tile)
                local spell = create_attack(user, props, props.damage, targteam, props.element, Hit.Impact | Hit.Flinch | Hit.Flash) --swap this out with something that adds it to a list later
                field:spawn(spell, tile)
                --print(testnum)
                --testnum = testnum + 1 -- if testnum isn't 9 we have a problem
            
            else
                --print("Your tile!")
            end
        end
    end
    shuffle(list)
    local tilenum = 1
    local cooldown = 0
    user:shake_camera(10, 0.5)
    randblast_handler.update_func = function (dt) --this is where the random explosion magic happens
        if tilenum <= #list and cooldown % 3 == 0 then
            --print("bang")
            local currenttile = list[tilenum]
            create_explosion(user, currenttile)
            tilenum = tilenum + 1
            cooldown = 0

        end

        if tilenum >= #list then
            randblast_handler:eject()
            --print("explosions ended")
        end
        cooldown = cooldown + 1

    end
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        {1, 0.064}, {2, 0.064}, {3, 0.064}, {4, 0.064}, {5, 0.064}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        -- local props = self:copy_metadata()
        local field = user:get_field()
		--local tile = user:get_tile()
        local tile_list = {}
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(bombtexture)
        attachment_sprite:set_layer(-2)
        -- attachment_sprite:enable_parent_shader(true)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(bombanim)
        attachment_animation:set_state("DEFAULT")
        local query = function(ent)
            return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
        end
        local blkbomb = Battle.Obstacle.new(Team.Other)
        blkbomb:set_texture(bombtexture, true)
        blkbomb:set_facing(user:get_facing())
        blkbomb:never_flip(true)
        local anim = blkbomb:get_animation()
        anim:load(bombanim)
        anim:set_state("DEFAULT")
        anim:set_playback(Playback.Loop)
        blkbomb:set_health(100)
        blkbomb.can_move_to_func = function(tile)
			if not tile then
				return false
			end
			if not tile:is_walkable() or tile:is_edge() or #tile:find_entities(query) > 0 then
				return false
			end
			return true
		end
        blkbomb:set_shadow(Shadow.Small)
        blkbomb:show_shadow(true)
        local mytile
        local ignited = false
        blkbomb.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
        blkbomb.defense_rule.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.element == Element.Fire then
                ignited = true
                blkbomb:set_health(0)
                --ignited n updatefunc handles the bomb explosion for now on
            end
        end
        blkbomb:add_defense_rule(blkbomb.defense_rule)
        blkbomb.update_func = function(self, dt) --might need to move defense_rule junk here, need to test
            if self:get_current_tile() ~= nil then
                 mytile = self:get_current_tile()
            end
            if ignited then
                Engine.play_audio(explodeaudio, AudioPriority.High)
                explosion_spots(user, field, props, tile_list, mytile)
                print("blackbomb dentonated!")
                blkbomb:remove_defense_rule(blkbomb.defense_rule)
                blkbomb.delete_func(blkbomb)
            end
            if self:get_health() <= 0 then
                blkbomb.delete_func(blkbomb)
            end
            --Engine.play_audio(tossaudio, AudioPriority.High)--REMOVE WHEN DONE PLEASE
        end
        blkbomb.delete_func = function(self)
            
            local tile = self:get_current_tile()
            if tile and not tile:is_edge() then
                create_explosion(self, tile)
            end
            
            blkbomb:erase()
        end
        
        --throwing stuff
        self:add_anim_action(3, function()
            attachment_sprite:hide()
            -- self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local facing = user:get_facing()
            local target_tile = user:get_tile(facing, tiles_ahead)
            if not target_tile then return end
            action.on_landing = function()
                if target_tile:is_walkable() then
                    if #target_tile:find_entities(query) == 0 then --not working right for some reason
                        user:get_field():spawn(blkbomb, target_tile)
                        Engine.play_audio(thudaudio, AudioPriority.Highest)
                        print("blackbomb made")
                    else
                        print("element getting time") --BIG CREDIT to Alrysc for helping me getting this part of the code working. Ya we're a big help, man.
                        local tester = Battle.Spell.new(user:get_team())
                        local getelement
                        tester:set_hit_props(
                        HitProps.new(
                            0,
                            Hit.None,
                            Element.None,
                            user:get_context(),
                            Drag.None
                            )
                        )
                        tester.attack_func = function (self, other)
                            getelement = other:get_element()
                            print(getelement)
                            print("element got!")
                            --tester:erase()
                            if getelement == 0 then--Element.Fire = 0
                                Engine.play_audio(explodeaudio, AudioPriority.High)
                                explosion_spots(user, field, props, tile_list, target_tile)
                                print("Ignited!")
                                else
                                local spell = create_attack(user, props, 100, user:get_team(), Element.None, Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking)
                                user:get_field():spawn(spell, target_tile)
                                print("wiff")
                                --print(getelement)
                                end
                        end
                        local runonce = true
                        tester.update_func = function(self, dt)
                            if runonce then
                                tester:get_current_tile():attack_entities(tester)
                                runonce = false
                            else
                                tester:erase()
                            end
                        end

                        
                        
                        user:get_field():spawn(tester, target_tile)
                        --tester:get_current_tile():attack_entities(tester) ---not
                        


                    end
                   
                end
            end
            toss_spell(user, toss_height, attachment_texture,
                       attachment_animation_path, target_tile, frames_in_air,
                       action.on_landing)
        end)

        Engine.play_audio(tossaudio, AudioPriority.Highest)
    end

    return action
end

function toss_spell(tosser, toss_height, texture, animation_path, target_tile,
    frames_in_air, arrival_callback)
local starting_height = -110
local start_tile = tosser:get_current_tile()
local field = tosser:get_field()
local spell = Battle.Spell.new(tosser:get_team())
local spell_animation = spell:get_animation()
spell_animation:load(bombanim)
spell_animation:set_state("DEFAULT")
if tosser:get_height() > 1 then
    starting_height = -(tosser:get_height() + 40)
end
spell:set_shadow(Shadow.Small)
spell:show_shadow(true)

spell.jump_started = false
spell.starting_y_offset = starting_height
spell.starting_x_offset = 10
if tosser:get_facing() == Direction.Left then
    spell.starting_x_offset = -10
end
spell.y_offset = spell.starting_y_offset
spell.x_offset = spell.starting_x_offset
local sprite = spell:sprite()
sprite:set_texture(bombtexture)
spell:never_flip(true)
spell:set_offset(spell.x_offset, spell.y_offset)

spell.update_func = function(self)
if not spell.jump_started then
self:jump(target_tile, toss_height, frames(frames_in_air),
      frames(frames_in_air), ActionOrder.Voluntary)
self.jump_started = true
end
    if self.y_offset < 0 then
        self.y_offset = self.y_offset +
                math.abs(self.starting_y_offset / frames_in_air)
        self.x_offset = self.x_offset - self.starting_x_offset / frames_in_air
        self:set_elevation(-self.y_offset)
        self:set_offset(self.x_offset, 0)
        --self:set_offset(self.x_offset, self.y_offset)
    else
        arrival_callback()
        self:delete()
    end
end
spell.can_move_to_func = function(tile) return true end
field:spawn(spell, start_tile)
end

function create_attack(user, props, attack, team, element, hitprops) --Attack Properties
    local spell = Battle.Spell.new(team)

    spell:set_hit_props(
        HitProps.new(
            attack,
            hitprops,
            element,
            user:get_context(),
            Drag.None
        )
    )

    local query = function(ent)
        if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
            return true
        end
    end
    local runonce = true
    spell.update_func = function(self, dt)
        if runonce then
            self:get_current_tile():attack_entities(self)
            runonce = false
        else
            spell:erase()
        end
    end

    spell.collision_func = function(self, other)
    end
  spell.attack_func = function(self, other) 
      --Engine.play_audio(HITAUDIO, AudioPriority.Highest)
  end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    --Engine.play_audio(AUDIO, AudioPriority.Low)
    return spell
end

--make the explosion fx
function create_explosion (user, tile)
    local fx = Battle.Artifact.new()
    fx:set_texture(explodetexture, true)
    fx:get_animation():load(explodeanim)
    fx:get_animation():set_state("DEFAULT")
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_height(-16.0)
    local field = user:get_field()
    --local tile = user:get_current_tile()
    field:spawn(fx, tile)
end