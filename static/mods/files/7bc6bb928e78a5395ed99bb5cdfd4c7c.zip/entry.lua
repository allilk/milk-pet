function package_init(block)
    block:declare_package_id("com.Dawn.NCP.WeakSave")
    block:set_name("WeakSave")
    block:as_program()
    block:set_description("Desperation breeds innovation.")
    block:set_color(Blocks.Green)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 1, 0,
        0, 1, 1, 1, 0,
        0, 1, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    local PlotArmor = Battle.DefenseRule.new(422,DefenseOrder.CollisionOnly)
    local element_hit = false
    --Create a table of list of lists, showing us the weaknesses to check.
    local element_weakness_table = {
        {Element.Fire, Element.Aqua},
        {Element.Aqua, Element.Elec},
        {Element.Elec, Element.Wood},
        {Element.Wood, Element.Fire},
        {Element.Wind, Element.Sword},
        {Element.Sword, Element.Break},
        {Element.Break, Element.Cursor},
        {Element.Cursor, Element.Wind}
    }
    PlotArmor.filter_statuses_func = function(statuses)
        --Get the incoming element.
        local element = statuses.element
        --If the element is ALREADY none, don't change anything.
        if element == Element.None then return statuses end
        --Get the defender's element. We can't avoid relying no the modify scope here, unfortunately.
        local user_element = player:get_element()
        --Loop over that list, and compare the user's element to the incoming attack element.
        --If the entries match appropriately - entry 1 is the defender, entry 2 is the attacker, thus a weakness was targeted?
        --Then we signal an elemental hit was made.
		for i = 1, #element_weakness_table, 1 do
			if element_weakness_table[i][1] == user_element and element_weakness_table[i][2] == element then element_hit = true break end
		end
        --If an elemental hit was amde, we turn the element to None so that we don't get beat up too bad.
        --Below, we'll remove this rule so it only happens once.
        if element_hit then statuses.element = Element.None end
        return statuses
    end
    local RemoveArmor = Battle.Component.new(player, Lifetimes.Scene)
    --We'll be resetting the color and color mode when we eject the component. Grab them.
    RemoveArmor.original_color = player:get_color()
    RemoveArmor.original_mode = player:sprite():get_color_mode()
    --Assign the owner so we aren't reliant on the modify scope, but so that the component relies on itself.
    RemoveArmor.owner = player
    --Create a component to handle the color.
    local ColorArmor = Battle.Component.new(player, Lifetimes.Battlestep)
    --Create every color we'll need in advance.
    ColorArmor.colors = {
        Color.new(100, 100, 100, 255),
        Color.new(125, 125, 125, 255),
        Color.new(150, 150, 150, 255),
        Color.new(175, 175, 175, 255),
        Color.new(200, 200, 200, 255)
    }
    ColorArmor.color_cycle = 12
    ColorArmor.color_cycle_max = 12
    ColorArmor.owner = player
    ColorArmor.color_index = 1
    ColorArmor.increment = 1
    ColorArmor.do_once = true
    player:sprite():set_color_mode(ColorMode.Additive)
    ColorArmor.update_func = function(self, dt)
        if element_hit then self:eject() return end
        --Set the owner's sprite's color mode. This is necessary to get the glow effect as desired.
        self.color_cycle = self.color_cycle - 1
        if self.color_cycle <= 0 then
            --Set the player's new color. It's really just an alpha change.
            self.owner:set_color(self.colors[self.color_index])
            --Reset the color cycle counter.
            self.color_cycle = self.color_cycle_max
            --If incrementing the color index would put it over the length of the color list,
            if self.color_index + self.increment > #self.colors then
                --Change it to decrementing.
                self.increment = -1
            elseif self.color_index + self.increment <= 0 then
                --If decrementing the color index would put it at or below zero,
                --Then change it to incrementing.
                self.increment = 1
            end
            self.color_index = self.color_index + self.increment
        end
    end
    RemoveArmor.update_func = function(self, dt)
        --When the defense rule dictates a hit, 
        if element_hit then
            --reset the colors,
            self.owner:sprite():set_color_mode(self.original_mode)
            self.owner:set_color(self.original_color)
            --remove the defense rule, 
            self.owner:remove_defense_rule(PlotArmor)
            --and eject this component.
            self:eject()
        end
    end
    player:add_defense_rule(PlotArmor)
    player:register_component(RemoveArmor)
    player:register_component(ColorArmor)
end