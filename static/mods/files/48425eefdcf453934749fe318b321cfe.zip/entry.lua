function package_init(block)
    block:declare_package_id("com.stockCustomization.ElecBody")
    block:set_name("ElecBody")
    block:as_program()
    block:set_description("Is this a...style change?")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 1, 1, 1, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_element(Element.Elec)
end