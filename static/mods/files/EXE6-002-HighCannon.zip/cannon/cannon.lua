local DAMAGE = 40
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE6_50.wav")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE6_131.wav")

local CANNON_ANIMPATH = _folderpath.."cannon.animation"
local CANNON_AUDIO = Engine.load_audio(_folderpath.."EXE6_278.wav")
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"

local cannon = {
	type = 1,

    codes = {"A","B","C","*"},
	shortname = "Cannon",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Cannon attack to 1 enemy",
	long_description = "A Cannon attacks 1 enemy in front of you",
	can_boost = true,
	card_class = CardClass.Standard,
	memory = 6,
	limit = 5
}

cannon.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.0500}
	local frame2 = {1, 0.0170}
	local frame3 = {1, 0.0830}
	local frame4 = {2, 0.0170}
	local frame5 = {2, 0.0170}
	local frame6 = {3, 0.0170}
	local frame7 = {3, 0.0330}
	local frame8 = {3, 0.0330}
	local frame9 = {3, 0.0330}
	local frame10 = {3, 0.0330}
	local frame11 = {3, 0.0330}
	local frame12 = {3, 0.0330}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10, frame11, frame12})
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local facing = user:get_facing()
		local field = user:get_field()
		local team = user:get_team()

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_folderpath.."cannon"..cannon.type..".png"), true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(CANNON_ANIMPATH)
		buster_anim:set_state("0")

		self:add_anim_action(2, function()
			actor:toggle_counter(true)
		end)
		self:add_anim_action(4, function()
			Engine.play_audio(CANNON_AUDIO, AudioPriority.Highest)
			if facing == Direction.Right then
				actor:set_offset(original_offset.x - 4.0*2, original_offset.y)
			else
				actor:set_offset(original_offset.x + 4.0*2, original_offset.y)
			end
		end)
		self:add_anim_action(5, function()
			if facing == Direction.Right then
				actor:set_offset(original_offset.x - 5.0*2, original_offset.y)
			else
				actor:set_offset(original_offset.x + 5.0*2, original_offset.y)
			end
		end)
		self:add_anim_action(6, function()
			if facing == Direction.Right then
				actor:set_offset(original_offset.x - 6.0*2, original_offset.y)
			else
				actor:set_offset(original_offset.x + 6.0*2, original_offset.y)
			end
			local tile = user:get_tile(facing, 1)
			create_attack(user, props, team, facing, field, tile)
		end)
		self:add_anim_action(7, function()
			actor:toggle_counter(false)
			if facing == Direction.Right then
				actor:set_offset(original_offset.x - 8.0*2, original_offset.y)
			else
				actor:set_offset(original_offset.x + 8.0*2, original_offset.y)
			end
		end)
	end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_attack(user, props, team, facing, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
	spell.slide_started = false
    --[[local sprite = spell:sprite()
    sprite:set_texture(Engine.load_texture(_folderpath.."testdot.png"), true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
	anim:load(_folderpath.."testdot.animation")
	anim:set_state("0")]]
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, ent)
        local rndm1 = math.random(-7,7)
        local rndm2 = math.random(-30,-15)
		print("Cannon attacked tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
		create_effect(Direction.Right, BOOM_TEXTURE, BOOM_ANIMPATH, "0", rndm1 * 2, rndm2 * 2, -999999, field, ent:get_current_tile())
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
		end
	end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	field:spawn(spell, tile)
    print("Cannon attack spawned at tile ("..tile:x()..";"..tile:y()..")")
	return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return cannon