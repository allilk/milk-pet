local function get_character_id(folder)
    return "com.Dawn.Co-OpUsage.Alpha." .. folder
end

local function define_character(folder)
    Engine.define_character(get_character_id(folder), _modpath..folder)
end

local modify, spawn_enemy, spawn_encounter

function package_init(block)
    define_character("alpha")

    block:declare_package_id("com.Dawn.SummonAlphaCo-Op")
    block:set_name("Alpha")
    block:set_description("Spawns Alpha...!")
    block:set_color(Blocks.Red)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function spawn_enemy(player, folder, rank, x, y)
    local field = player:get_field()
    local team = player:get_team()

    if player:get_facing() == Direction.Left then
        print("[Encounter NCP] need to flip enemy spawn")
        x = field:width() - x + 1
    end

    local tile = field:tile_at(x, y)
    local enemy = Battle.Character.from_package(get_character_id(folder), team, rank)
    field:spawn(enemy, tile)
end

function spawn_encounter(player)
    spawn_enemy(player, "alpha", Rank.SP, 2, 2)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)
    local cooldown = 1
    component.update_func = function()
        if cooldown == 1 then spawn_encounter(player) end
        if cooldown <= 0 then
            local field = player:get_field()
            
			Engine.stream_music(_modpath.."music.mid")
            component:eject()
        else
            cooldown = cooldown - 1
        end
    end
    player:register_component(component)
end
