local query = function(o)
    return Battle.Obstacle.from(o) ~= nil
end

local function end_alpha_arm(alpha)
    alpha.cooldown = 120
    alpha.is_acting = false
    alpha.goop_health = 40
    alpha.anim_once = true
    alpha.sigma_index = 1
    alpha.omega_attack = false
    alpha.is_vulnerable = false
    alpha.pattern_index = alpha.pattern_index + 1
    if alpha.pattern_index > #alpha.pattern then alpha.pattern_index = 1 end
    alpha.alpha_arm_index = alpha.alpha_arm_index + 1
    if alpha.alpha_arm_index > #alpha.alpha_arm_type then alpha.alpha_arm_index = 1 end
    alpha.upper_arm:reveal()
    alpha.lower_arm:reveal()
    alpha.upper_arm:toggle_hitbox(true)
    alpha.lower_arm:toggle_hitbox(true)
end

local function drop_trace_fx(target_artifact, lifetime_ms, desired_color)
    --drop an afterimage artifact mimicking the appearance of an existing spell/artifact/character and fade it out over it's lifetime_ms
    local fx = Battle.Spell.new(target_artifact:get_team())
    local anim = target_artifact:get_animation()
    local field = target_artifact:get_field()
    local offset = target_artifact:get_offset()
    local texture = target_artifact:get_texture()
    local elevation = target_artifact:get_elevation()
    fx:set_facing(target_artifact:get_facing())
    fx:set_texture(texture, true)
    fx:get_animation():copy_from(anim)
    fx:get_animation():set_state(anim:get_state())
    fx:set_offset(offset.x,offset.y)
    fx:set_elevation(elevation)
    fx:get_animation():refresh(fx:sprite())
    fx.starting_lifetime_ms = lifetime_ms
    fx.lifetime_ms = lifetime_ms
    fx.update_func = function(self, dt)
        self.lifetime_ms = math.max(0, self.lifetime_ms-math.floor(dt*1000))
        local alpha = math.floor((fx.lifetime_ms/fx.starting_lifetime_ms)*255)
        self:sprite():set_color_mode(ColorMode.Multiply)
        self:set_color(Color.new(desired_color[1], desired_color[2], desired_color[3], alpha))
        if self.lifetime_ms == 0 then 
            self:erase()
        end
    end

    local tile = target_artifact:get_current_tile()
    field:spawn(fx, tile:x(), tile:y())
    return fx
end

local function create_claw_defense(spell)
    local defense = Battle.DefenseRule.new(2, DefenseOrder.Always)
    defense.texture = Engine.load_texture(_modpath.."guard_hit.png")
    defense.animation = _modpath.."guard_hit.animation"
    defense.audio = Engine.load_audio(_modpath.."sounds/tink.ogg")
    defense.can_block_func = function(judge, attacker, defender)
        judge:block_damage()
        judge:block_impact()
        local artifact = Battle.Spell.new(spell:get_team())
        artifact:set_texture(defense.texture)
        local anim = artifact:get_animation()
        anim:load(defense.animation)
        anim:set_state("DEFAULT")
        anim:refresh(artifact:sprite())
        anim:on_complete(function()
            artifact:erase()
        end)
        defender:get_field():spawn(artifact, defender:get_tile())
        Engine.play_audio(defense.audio, AudioPriority.High)
    end
    return defense
end

local function find_best_target(alpha)
    local target = alpha:get_target()
    local field = alpha:get_field()
    local query = function(c)
        return c:get_team() ~= alpha:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 0
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target and not possible_target:is_deleted() and possible_target:get_health() >= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

local function create_mob_move(texture, state)
    local artifact = Battle.Spell.new(Team.Blue)
    artifact:set_texture(texture)
    local anim = artifact:get_animation()
    anim:load(_modpath.."mob_move.animation")
    anim:set_state(state) --Set the state
    anim:refresh(artifact:sprite())
    anim:on_complete(function()
        artifact:erase() --Delete the artifact when the animation completes
    end)
    return artifact
end

local function create_red_eye_arrow(alpha, props, state, direction)
    local spell = Battle.Spell.new(alpha:get_team())
    local texture = Engine.load_texture(_modpath.."red_eyes_delete_projectile.png")
    local animation = _modpath.."red_eyes_delete_projectile.animation"
    spell:set_hit_props(props)
    spell:set_texture(texture)
    spell:set_facing(alpha:get_facing())
    local anim = spell:get_animation()
    anim:load(animation)
    anim:set_state(state)
    spell:sprite():set_layer(-2) --set_layer determines the order sprites visually draw in.
    anim:refresh(spell:sprite())
    spell.slide_started = false
    spell.update_func = function(self, dt)
        if self:is_deleted() then return end
        local tile = self:get_tile()
        if tile:is_edge() and self.slide_started then self:delete() end
        tile:attack_entities(self)
        local dest = self:get_tile(direction, 1)
        local ref = self
        if dest and #dest:find_entities(query) > 0 then self:delete() end
        self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, function()
            ref.slide_started = true
            tile:attack_entities(self)
        end)
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

local function create_sigma_taser(alpha)
    local spell = Battle.Spell.new(alpha:get_team())
    spell:set_texture(Engine.load_texture(_modpath.."alpha taser.png"))
    spell:set_facing(alpha:get_facing())
    spell:sprite():set_layer(-4)
    local damage = 60
    if alpha:get_rank() == Rank.SP then damage = 200 end
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            alpha:get_context(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."alpha taser.animation")
    anim:set_state(alpha.sigma_state[alpha.sigma_index])
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        anim:set_state(alpha.sigma_state[alpha.sigma_index])
        anim:refresh(spell:sprite())
        alpha.sigma_index = alpha.sigma_index + 1
        alpha.sigma_count = alpha.sigma_count + 1
        if alpha.sigma_index > #alpha.sigma_state then alpha.sigma_index = 1 end
        spell.anim_once = true
    end)
    local field = alpha:get_field()
    local facing = alpha:get_facing()
    local center_tile = alpha:get_tile(facing, 2)
    local upper_tile = center_tile:get_tile(Direction.Up, 1)
    local lower_tile = center_tile:get_tile(Direction.Down, 1)
    local center_table = {center_tile}
    local up_down_table = {center_tile}
    for x = 1, 6, 1 do
        local prospective_addition = upper_tile:get_tile(facing, x)
        if prospective_addition and not prospective_addition:is_edge() then table.insert(up_down_table, prospective_addition) end
        prospective_addition = lower_tile:get_tile(facing, x)
        if prospective_addition and not prospective_addition:is_edge() then table.insert(up_down_table, prospective_addition) end
        prospective_addition = center_tile:get_tile(facing, x)
        if prospective_addition and not prospective_addition:is_edge() then table.insert(center_table, prospective_addition) end
    end
    local tile_array = {center_table, up_down_table}
    spell.on_spawn_func = function(self)
        for i = 1, #tile_array[alpha.sigma_index], 1 do
            local check_tile = tile_array[alpha.sigma_index][i]
            if check_tile and not check_tile:is_edge() then
                local hitbox = Battle.Spell.new(self:get_team())
                hitbox:set_hit_props(self:copy_hit_props())
                hitbox.update_func = function(self, dt)
                    self:get_tile():attack_entities(self)
                    self:erase()
                end
                field:spawn(hitbox, check_tile)
            end
        end
    end
    spell.can_move_to_func = function(tile) return true end
    spell.anim_once = false
    spell.update_func = function(self, dt)
        if self.anim_once then
            self.anim_once = false
            Engine.play_audio(AudioType.Thunder, AudioPriority.Highest)
            anim:on_complete(function()
                alpha.sigma_count = alpha.sigma_count + 1
                if alpha.sigma_count >= 16 then
                    alpha.is_acting = false
                    self:erase()
                else
                    local tile = self:get_tile()
                    for i = 1, #tile_array[alpha.sigma_index], 1 do
                        local hitbox = Battle.Spell.new(self:get_team())
                        hitbox:set_hit_props(self:copy_hit_props())
                        hitbox.update_func = function(self, dt)
                            self:get_tile():attack_entities(self)
                            self:erase()
                        end
                        field:spawn(hitbox, tile_array[alpha.sigma_index][i])
                    end
                    anim:set_state(alpha.sigma_state[alpha.sigma_index])
                    anim:refresh(spell:sprite())
                    alpha.sigma_index = alpha.sigma_index + 1
                    if alpha.sigma_index > #alpha.sigma_state then alpha.sigma_index = 1 end
                    spell.anim_once = true
                end
            end)
        end
    end
    return spell
end

local function create_omega_rocket(alpha)
    local spell = Battle.Spell.new(alpha:get_team())
    spell:set_texture(Engine.load_texture(_modpath.."alpha rocket.png"))
    spell:set_facing(alpha:get_facing())
    spell:sprite():set_layer(-4)
    local damage = 100
    if alpha:get_rank() == Rank.SP then damage = 300 end
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            alpha:get_context(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."alpha rocket.animation")
    anim:set_state("IDLE")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        anim:set_state("TAKEOFF")
        anim:refresh(spell:sprite())
    end)
    spell.slide_started = false
    spell.has_exploded = false
    spell.can_move_to_func = function(tile) return true end
    local TEXTURE_FLASHLIGHT = Engine.load_texture(_modpath.."flashlight.png")
    local ANIMPATH_FLASHLIGHT = _modpath.."flashlight.animation"
    local field = alpha:get_field()
    local explosion = Engine.load_texture(_modpath.."rocket explosion.png")
    local function run_explosion(hitter, array)
        Engine.play_audio(AudioType.Explode, AudioPriority.High)
        local flashlight = Battle.Spell.new(spell:get_team())
        flashlight:set_facing(Direction.Right)
        local flashlight_anim = flashlight:get_animation()
        flashlight:set_texture(TEXTURE_FLASHLIGHT, true)
        flashlight:sprite():set_layer(10)
        flashlight_anim:load(ANIMPATH_FLASHLIGHT)
        flashlight_anim:set_state("DEFAULT")
        flashlight_anim:refresh(flashlight:sprite())
        flashlight_anim:on_complete(function()
            flashlight:erase()
        end)
        for i = 1, #array, 1 do
            local attack = Battle.Spell.new(hitter:get_team())
            attack:set_hit_props(hitter:copy_hit_props())
            attack:set_texture(explosion)
            attack:sprite():set_layer(-2)
            local anim2 = attack:get_animation()
            anim2:load(_modpath.."rocket explosion.animation")
            anim2:set_state("0")
            anim2:refresh(attack:sprite())
            anim2:on_complete(function()
                attack:erase()
            end)
            attack.update_func = function(self, dt)
                self:get_tile():attack_entities(self)
            end
            field:spawn(attack, array[i])
        end
        field:spawn(flashlight, 1, 1)
        hitter:shake_camera(15, 1.0)
    end
    spell.collision_func = function(self, other)
    end
    spell.back_boom_array = {field:tile_at(1, 1), field:tile_at(1, 2), field:tile_at(1, 3), field:tile_at(2, 1), field:tile_at(2, 2), field:tile_at(2, 3)}
    spell.delete_func = function(self)
        if not self.has_exploded then
            run_explosion(self, self.back_boom_array)
            self.has_exploded = true
            alpha.is_acting = false
            self:erase()
        end
    end
    local direction = spell:get_facing()
    spell.update_func = function(self, dt)
        if anim:get_state() ~= "TAKEOFF" then return end
        if self:is_deleted() then return end
        local tile = self:get_tile()
        local dest = self:get_tile(direction, 1)
        tile:attack_entities(self)
        if dest and not dest:is_edge() then
            dest:attack_entities(self)
        end
        if not self:is_sliding() then
            if tile:is_edge() and self.slide_started then self:delete() end
            local ref = self
            self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true
            end)
        end
    end
    return spell
end

local function take_alpha_arm_action(alpha, current_arm)
    alpha.is_acting = true
    alpha.is_vulnerable = false
    local field = alpha:get_field()
    if current_arm == "SIGMA" then
        local spell = create_sigma_taser(alpha)
        field:spawn(spell, alpha:get_tile(alpha:get_facing(), 2))
        return spell
    elseif current_arm == "OMEGA" then
        local spell = create_omega_rocket(alpha)
        field:spawn(spell, alpha:get_tile(alpha:get_facing(), 1))
        return spell
    else
        alpha.is_acting = false
    end
end

local function take_red_eye_action(alpha, state)
    alpha.is_acting = true --Set to acting so we don't spam lasers.
    local field = alpha:get_field()
    local first_tile = alpha:get_tile(alpha:get_facing(), 2)
    local tile_array = {first_tile, first_tile:get_tile(Direction.Up, 1), first_tile:get_tile(alpha:get_facing(), 1), first_tile:get_tile(Direction.Down, 1)}
    local texture = Engine.load_texture(_modpath.."red_eyes_delete.png")
    local artifact = Battle.Spell.new(alpha:get_team())
    artifact:set_texture(texture)
    artifact:sprite():set_layer(-4)
    local anim = artifact:get_animation()
    anim:load(_modpath.."red_eyes_delete.animation")
    anim:set_state(state) --Set the state
    anim:refresh(artifact:sprite())
    local damage = 80
    if alpha:get_rank() == Rank.SP then damage = 200 end
    local props = HitProps.new(
        damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None,
        alpha:get_context(),
        Drag.None
    )
    anim:on_complete(function()
        local state = anim:get_state()
        if state == "ATTACK_CHARGE" then
            anim:set_state("ATTACK_FIRE")
            Engine.play_audio(Engine.load_audio(_modpath.."sounds/red eye laser.ogg"), AudioPriority.High)
            anim:on_complete(function()
                anim:set_state("ATTACK_LAND")
                local hitbox = Battle.Spell.new(alpha:get_team())
                hitbox:set_hit_props(props)
                hitbox.update_func = function(self, dt)
                    self:get_tile():attack_entities(self)
                    self:erase()
                end
                field:spawn(hitbox, tile_array[2])
                anim:on_complete(function()
                    anim:set_state("ATTACK_DISSIPATE")
                    anim:on_complete(function()
                        artifact:delete()
                        alpha.is_acting = false
                        alpha.cooldown = 40
                    end)
                end)
                --If the landing tile of Red Eye Delete isn't broken, Crack/Break the tiles.
                --Do this by scanning the compiled tiles above for Cracked state and breaking them if Cracked.
                --If NOT Cracked, then Crack them.
                if tile_array[1]:get_state() ~= TileState.Broken then
                    Engine.play_audio(Engine.load_audio(_modpath.."sounds/crack.ogg"), AudioPriority.High)
                    alpha:shake_camera(8, 1.0)
                    for i = 1, #tile_array, 1 do
                        if tile_array[i]:get_state() == TileState.Cracked then
                            tile_array[i]:set_state(TileState.Broken)
                        else
                            tile_array[i]:set_state(TileState.Cracked)
                        end
                    end
                    local up = create_red_eye_arrow(alpha, props, "UP", Direction.Up)
                    local forward = create_red_eye_arrow(alpha, props, "FORWARD", alpha:get_facing())
                    local down = create_red_eye_arrow(alpha, props, "DOWN", Direction.Down)
                    local check_up = tile_array[2]
                    if check_up and not check_up:is_edge() then
                        field:spawn(up, check_up)
                    end
                    field:spawn(forward, tile_array[3])
                    local check_down = tile_array[4]
                    if check_down and not check_down:is_edge() then
                        print("spawning down")
                        field:spawn(down, check_down)
                    end
                end
            end)
        end
    end)
    Engine.play_audio(Engine.load_audio(_modpath.."sounds/red eye charging.ogg"), AudioPriority.High)
    field:spawn(artifact, alpha:get_tile())
end

local function create_reverse_vulcan_shot(alpha, texture, props)
    local shot = Battle.Spell.new(alpha:get_team())
    shot:highlight_tile(Highlight.Solid)
    shot:set_hit_props(props)
    shot:set_facing(alpha:get_facing())
    shot:sprite():set_layer(-4)
    shot:set_texture(texture)
    local anim = shot:get_animation()
    anim:load(_modpath.."vulcan_fx.animation")
    anim:set_state("TILE_BURST")
    anim:refresh(shot:sprite())
    anim:on_complete(function()
        alpha.vulcan_shots = alpha.vulcan_shots + 1
        alpha.is_acting = false
    end)
    shot.delay = 15
    shot.update_func = function(self, dt)
        if self.delay <= 0 then
            local tile = self:get_tile()
            if tile:is_walkable() then
                tile:attack_entities(self)
            end
            self:erase()
        else
            self.delay = self.delay - 1
        end
    end
    shot.can_move_to_func = function(tile)
        return true
    end
    return shot
end

local function create_reverse_vulcan_flare(alpha, texture)
    local artifact = Battle.Spell.new(Team.Blue)
    artifact:set_texture(texture)
    artifact:sprite():set_layer(-4)
    local anim2 = artifact:get_animation()
    anim2:load(_modpath.."vulcan_fx.animation")
    anim2:set_state("CANNON_BURST")
    anim2:refresh(artifact:sprite())
    anim2:set_playback(Playback.Loop)
    artifact.update_func = function(self, dt)
        if alpha.vulcan_shots >= 16 then
            alpha.anim_once = true
            self:erase()
        end
    end
    return artifact
end

local function take_reverse_vulcan_action(alpha)
    alpha.is_acting = true --Set Alpha to be acting so we don't spam shots. Well, any more than we should.
    local texture = alpha.vulcan_texture
    local damage = 20
    if alpha:get_rank() == Rank.SP then damage = 50 end
    local props = HitProps.new(
        damage,
        Hit.Impact,
        Element.None,
        alpha:get_context(),
        Drag.None
    )
    local shot = create_reverse_vulcan_shot(alpha, texture, props)
    local target = find_best_target(alpha)
    local field = alpha:get_field()
    if target and not target:is_deleted() then
        field:spawn(shot, target:get_tile())
        Engine.play_audio(Engine.load_audio(_modpath.."sounds/gun.ogg"), AudioPriority.Highest)
    else
        alpha.is_acting = false
    end
end

local function create_devil_hand(alpha, props, texture_part, is_omega)
    local spell = Battle.Obstacle.new(alpha:get_team()) --Create the spell.
    local arm = alpha.upper_arm
    local field = alpha:get_field()
    local sound = "sounds/devil arm 1.ogg"
    local direction = Direction.Down
    local target_anim = _modpath.."arm_upper.animation"
    if texture_part == "arm_lower" then
        sound = "sounds/devil arm 2.ogg"
        direction = alpha:get_facing()
        arm = alpha.lower_arm
        target_anim = _modpath.."arm_lower.animation"
    else
        spell:set_offset(0.0, -40.0)
    end
    local state = "ATTACK"
    if is_omega then state = "ATTACK_OMEGA" end
    spell:set_health(99999)
    spell:set_hit_props(props)
    local virus_def = Battle.DefenseVirusBody.new()
    spell:add_defense_rule(virus_def)
    spell.spell_defense = create_claw_defense(spell)
    spell:add_defense_rule(spell.spell_defense)
    spell:set_facing(alpha:get_facing()) --Make sure it's going to face the right way. It's going to be on the "enemy" side compared to the virus.
    spell:set_texture(arm:get_texture()) --Copying the texture of the arm.
    spell:sprite():set_layer(-4) --Needs to spawn "over" the player it's attacking.
    local spell_animation = spell:get_animation()
    spell_animation:load(target_anim)
    spell_animation:set_state(state) --Set the state to attack instead of idle.
    spell_animation:refresh(spell:sprite()) 
    spell.slide_started = false
    spell.cooldown = 20 --Wait for 20 frames before moving to attack.
    spell.spawned_other_claw = false
    spell.play_sound = true
    local negative_tile_array = {TileState.Poison, TileState.Ice, TileState.Cracked, TileState.Lava}
    local rng = math.random(1, #negative_tile_array)
    spell.obstacle_hit = false
    spell.update_func = function(self, dt)
        if self:is_deleted() then return end
        if self.cooldown <= 0 then
            if self.play_sound then
                Engine.play_audio(Engine.load_audio(_modpath..sound), AudioPriority.High)
                self.play_sound = false
            end
            local tile = self:get_tile()
            if texture_part == "arm_upper" and tile:y() == 2 then alpha.is_acting = false end
            if is_omega and texture_part == "arm_upper" and not tile:is_edge() and self:is_team(tile:get_tile(self:get_facing_away(), 1):get_team()) then
                tile:set_team(self:get_team(), false)
            elseif is_omega and texture_part == "arm_lower" and not self:is_team(tile:get_team()) then
                tile:set_state(negative_tile_array[rng])
            end
            if not self:is_sliding() then
                if tile:is_edge() and self.slide_started then self:delete() end
                local dest = self:get_tile(direction, 1)
                local ref = self
                if dest and #dest:find_entities(query) > 0 then
                    self.obstacle_hit = true
                    self:delete()
                end
                self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true
                    if texture_part == "arm_upper" then
                        drop_trace_fx(self, 240, {0, 50, 150})
                    else
                        drop_trace_fx(self, 120, {100, 100, 100})
                    end
                    tile:attack_entities(self)
                end)
            end
        else
            self.cooldown = self.cooldown - 1
        end
    end
    spell.collision_func = function(self, other)
        local check = Battle.Obstacle.from(other)
        if check ~= nil then self:delete() end
    end
    spell.delete_func = function(self)
        if not arm:is_deleted() then
            if texture_part == "arm_lower" or self.obstacle_hit then
                alpha.upper_arm:reveal()
                alpha.upper_arm:toggle_hitbox(true)
                alpha.upper_arm:share_tile(false)
                alpha.lower_arm:reveal()
                alpha.lower_arm:toggle_hitbox(true)
                alpha.lower_arm:share_tile(false)
                alpha.is_acting = false
            end
            self:erase()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end

    return spell
end

local function take_devil_hand_action(alpha, texture_part, is_omega)
    alpha.is_acting = true --Set alpha to acting so we don't spam claws.

    local field = alpha:get_field() --Get the field so we can spawn the spell.
    local mob_move_texture = Engine.load_texture(_modpath.."mob_move.png")
    local mob_move = create_mob_move(mob_move_texture, "2") --Create an artifact to visually warp the claw.
    local damage = 50
    if alpha:get_rank() == Rank.SP then damage = 100 end
    local props = HitProps.new(
        damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None,
        alpha:get_context(),
        Drag.None
    )

    local spell = create_devil_hand(alpha, props, texture_part, is_omega)
    local target = find_best_target(alpha) --Get the player to attack them.
    if target and not target:is_deleted() then
        local target_tile = target:get_tile() --Get their tile.
        local desired_tile = nil
        if texture_part == "arm_upper" then
            alpha.upper_arm:hide() --Hide the upper arm. We're going to be spawning a spell that looks like it.
            alpha.upper_arm:toggle_hitbox(false)
            alpha.upper_arm:share_tile(true)
            if is_omega then
                desired_tile = field:tile_at(3, 0) --Hover over the player's third column
            else
                desired_tile = field:tile_at(target_tile:x(), 0) --Hover on the edge tile above them.
            end
            field:spawn(mob_move, alpha.upper_arm:get_tile()) --Spawn the artifact as we hide the arm so it looks good.
        elseif texture_part == "arm_lower" then
            alpha.lower_arm:hide() --Hide the upper arm. We're going to be spawning a spell that looks like it.
            alpha.lower_arm:toggle_hitbox(false)
            alpha.lower_arm:share_tile(true)
            local goal_x = 4
            if alpha:get_team() == Team.Red then goal_x = 3 end
            desired_tile = field:tile_at(goal_x, target_tile:y())
            field:spawn(mob_move, alpha.lower_arm:get_tile()) --Spawn the artifact as we hide the arm so it looks good.
        end
        local other_query = function(o)
            return Battle.Obstacle.from(o) ~= nil
        end
        local list = desired_tile:find_entities(other_query)
        if desired_tile and #list == 0 then
            field:spawn(spell, desired_tile)
        else
            alpha.is_acting = false
        end
    else
        alpha.is_acting = false
    end
end

function package_init(self)
    self.is_acting = false
    self.vulcan_shots = 0
    self.anim_once = true
    self:set_name("Alpha")
    self.health = 2000
    if self:get_rank() == Rank.SP then self.health = 3000 end
    self:set_health(self.health)
    self:set_texture(Engine.load_texture(_modpath.."alpha_core.png"))
    
    self:set_float_shoe(true)

    self.core_anim = self:get_animation()
    self.core_anim:load(_modpath.."alpha_core.animation")
    self.core_anim:set_state("CORE")
    self.core_anim:set_playback(Playback.Loop)
    self.core_anim:refresh(self:sprite())
    
    local armor = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    armor:set_texture(self:get_texture()) --Just set their texture...
    self.armor_anim = Engine.Animation.new(_modpath.."alpha_core.animation") --And they have no get_animation, so we create one...
    armor:set_layer(-3) --Set their layer, they're already a sprite...
    self.armor_anim:copy_from(self:get_animation()) --Load or copy the animation and do the normal stuff...
    self.armor_anim:set_state("ARMOR_IDLE")
    self.armor_anim:refresh(armor)
    self.armor_anim:set_playback(Playback.Loop)

    local pool = self:create_node() --Need one for the pool too.
    pool:set_texture(Engine.load_texture(_modpath.."pool.png"))
    self.pool_anim = Engine.Animation.new(_modpath.."pool.animation")
    self.pool_anim:set_state("0")
    self.pool_anim:refresh(pool)
    self.pool_anim:set_playback(Playback.Loop)
    pool:set_layer(3)

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.armor_anim:update(dt, armor)
        ref.pool_anim:update(dt, pool)
    end

    self:register_component(self.animate_component)

    self.def = Battle.DefenseVirusBody.new() -- lua owns this, so we need to keep it alive
    self:add_defense_rule(self.def)
    self.goop_defense = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
    self.goop_health = 40
    self.previous_goop_health = 40
    self.regen_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.regen_component.cooldown = 0
    self.regen_component.cooldown_max = 240
    self.regen_component.update_func = function(self, dt)
        if self.cooldown < 0 then
            ref.goop_health = math.min(40, ref.goop_health + 20)
            self.cooldown = self.cooldown_max
        else
            self.cooldown = self.cooldown - 1
        end
    end
    local state_table = {
        "COIL_SPAWN", 
        "COIL_ATTACK",
        "COIL_RETREAT",
        "ROCKET_SPAWN",
        "VULCAN_IDLE",
        "VULCAN_ATTACK"
      }
      
    local check_state = "COIL_SPAWN" -- try replacing with one of the above
    
    local function is_any(item, set)
        for k,v in pairs(set) do
            if item == v then return true end
        end
    
        return false
    end
    self.goop_animation = Battle.Component.new(self, Lifetimes.Battlestep)
    self.goop_animation.update_func = function(self, dt)
        local check_state = ref.core_anim:get_state()
        if not ref.sigma_attack and not ref.omega_attack and not is_any(check_state, state_table) then
            if ref.goop_health ~= ref.previous_goop_health then
                if ref.goop_health <= 0 and check_state ~= "CORE_VULNERABLE_2" then
                    ref.core_anim:set_state("CORE_DAMAGE_2")
                    ref.core_anim:on_frame(3, function()
                        ref.is_vulnerable = true
                    end)
                    ref.core_anim:on_complete(function()
                        ref:set_float_shoe(false)
                        ref.core_anim:set_state("CORE_VULNERABLE_2")
                        ref.core_anim:set_playback(Playback.Loop)
                    end)
                elseif ref.goop_health == 20 and check_state ~= "CORE_VULNERABLE" then
                    ref.core_anim:set_state("CORE_DAMAGE")
                    ref:set_float_shoe(true)
                    ref.core_anim:on_frame(2, function()
                        ref.is_vulnerable = false
                    end)
                    ref.core_anim:on_complete(function()
                        ref.core_anim:set_state("CORE_VULNERABLE")
                        ref.core_anim:set_playback(Playback.Loop)
                    end)
                elseif ref.goop_health == 40 and check_state ~= "CORE" then
                    ref.core_anim:set_state("CORE_DAMAGE")
                    ref:set_float_shoe(true)
                    ref.core_anim:set_playback(Playback.Reverse)
                    ref.core_anim:on_frame(2, function()
                        ref.is_vulnerable = false
                    end)
                    ref.core_anim:on_complete(function()
                        ref.core_anim:set_state("CORE")
                        ref.core_anim:set_playback(Playback.Loop)
                    end)
                end
            end
        end
        ref.previous_goop_health = ref.goop_health
    end
    self:register_component(self.goop_animation)
    self:register_component(self.regen_component)
    self.is_vulnerable = false
    self.goop_defense.can_block_func = function(judge, attacker, defender)
        if not ref.is_vulnerable then
            judge:block_damage()
            local props = attacker:copy_hit_props()
            props.damage = math.min(20, props.damage)
            attacker:set_hit_props(props)
            if ref.goop_health > 20 then
                ref.goop_health = math.max(20, ref.goop_health - props.damage)
            else
                ref.goop_health = math.max(0, ref.goop_health - props.damage)
            end
        end
    end
    self:add_defense_rule(self.goop_defense)
    self.upper_arm = Battle.Obstacle.new(self:get_team())
    self.upper_arm:set_texture(Engine.load_texture(_modpath.."arm_upper.png"))
    self.upper_arm:set_health(99999)
    self.upper_arm_anim = self.upper_arm:get_animation()
    self.upper_arm_anim:load(_modpath.."arm_upper.animation")
    self.upper_arm_anim:set_state("IDLE")
    self.upper_arm_anim:refresh(self.upper_arm:sprite())
    self.upper_arm_anim:set_playback(Playback.Loop)
    self.upper_arm:sprite():set_layer(4)
    self.lower_arm = Battle.Obstacle.new(self:get_team())
    self.lower_arm:set_health(99999)
    self.lower_arm:set_texture(Engine.load_texture(_modpath.."arm_lower.png"))
    self.lower_arm_anim = self.lower_arm:get_animation()
    self.lower_arm_anim:load(_modpath.."arm_lower.animation")
    self.lower_arm_anim:set_state("IDLE")
    self.lower_arm_anim:refresh(self.lower_arm:sprite())
    self.lower_arm_anim:set_playback(Playback.Loop)
    self.lower_arm:sprite():set_layer(-4)
    
    local reverse_vulcan_spawn_sound = Engine.load_audio(_modpath.."sounds/reverse vulcan spawn.ogg")
    self.flare = nil
    self.vulcan_texture = Engine.load_texture(_modpath.."vulcan_fx.png")
    self.flare_cooldown = 8

    local field = nil
    self.battle_start_func = function()
        local friends_list = field:find_characters(function(ent)
            return ent and self:is_team(ent:get_team())
        end)
        -- local fix_tile_component = Battle.Component.new()
        for x = 1, 6, 1 do
            for y = 1, 3, 1 do
                local tile = field:tile_at(x, y)
                if tile:get_team() == self:get_team() then
                    for c = 1, #friends_list, 1 do
                        field:tile_at(x, y):reserve_entity_by_id(tonumber(friends_list[c]:get_id()))
                    end
                end
            end
        end
    end
    self.on_spawn_func = function()
        field = self:get_field()
        self.upper_arm:add_defense_rule(create_claw_defense(self.upper_arm))
        self.upper_arm:set_team(self:get_team())
        self.upper_arm:set_facing(self:get_facing())
        field:spawn(self.upper_arm, self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1))
        self.lower_arm:add_defense_rule(create_claw_defense(self.lower_arm))
        self.lower_arm:set_team(self:get_team())
        self.lower_arm:set_facing(self:get_facing())
        field:spawn(self.lower_arm, self:get_tile(self:get_facing_away(), 1))
    end
    self.can_move_to_func = function(tile)
        return false
    end
    self.cooldown = 150
    self.vulcan_attack = false
    self.omega_attack = false
    self.sigma_attack = false
    self.sigma_count = 0
    self.alpha_arm = nil
    self.alpha_arm_type = {"SIGMA", "OMEGA"}
    self.alpha_arm_index = 1
    self.sigma_state = {"SINGLE_ROW", "DOUBLE_ROW"}
    self.sigma_index = 1
    self.pattern = {
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "REVERSE VULCAN",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "RED EYE DELETE"
    }
    self.low_health_pattern = {
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "ALPHA ARM",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "RED EYE DELETE"
    }
    self.omega_pattern = {
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "REVERSE VULCAN",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "RED EYE DELETE",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "GOD HAND", "GOD HAND"
    }
    self.low_health_pattern_omega = {
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "ALPHA ARM",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "RED EYE DELETE",
        "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "DEVIL HAND", "GOD HAND", "GOD HAND"
    }
    self.pattern_index = 1
    self.devil_hand_list = {"arm_upper", "arm_lower"}
    self.devil_hand_index = 1
    local has_changed_armor = false
    local activity = self.pattern[self.pattern_index]
    local rank = self:get_rank()
    self.update_func = function(self, dt)
        if self:is_deleted() then
            self.upper_arm:delete()
            self.lower_arm:delete()
            return
        end
        if self.cooldown <= 0 then
            if not self.is_acting then
                if not has_changed_armor and self:get_health() <= math.floor(self.health/2) and self.armor_anim:get_state() == "ARMOR_IDLE" then
                    self.armor_anim:set_state("ARMOR_IDLE_FAST")
                    self.armor_anim:set_playback(Playback.Loop)
                end
                if rank == Rank.SP then
                    activity = self.omega_pattern[self.pattern_index]
                else
                    activity = self.pattern[self.pattern_index]
                end
                if self:get_health() <= math.floor(self.health/2) then
                    if rank == Rank.SP then
                        activity = self.low_health_pattern_omega[self.pattern_index]
                    else
                        activity = self.low_health_pattern[self.pattern_index]
                    end
                end
                if self.vulcan_attack then activity = "REVERSE VULCAN" end
                if activity == "DEVIL HAND" then
                    take_devil_hand_action(self, self.devil_hand_list[self.devil_hand_index], false)
                    self.pattern_index = self.pattern_index + 1
                    self.devil_hand_index = self.devil_hand_index + 1
                    if self.devil_hand_index > #self.devil_hand_list then self.devil_hand_index = 1 end
                    self.cooldown = 40
                elseif activity == "GOD HAND" then
                    take_devil_hand_action(self, self.devil_hand_list[self.devil_hand_index], true)
                    self.pattern_index = self.pattern_index + 1
                    self.devil_hand_index = self.devil_hand_index + 1
                    if self.devil_hand_index > #self.devil_hand_list then self.devil_hand_index = 1 end
                    self.cooldown = 40
                elseif activity == "REVERSE VULCAN" then
                    if self.vulcan_attack and self.vulcan_shots < 16 then
                        take_reverse_vulcan_action(self)
                        self.cooldown = 13
                    end
                    if self.anim_once and self.vulcan_shots < 16 then
                        print("hi hi")
                        self.anim_once = false
                        self.armor_anim:set_state("VULCAN_REVEAL")
                        Engine.play_audio(reverse_vulcan_spawn_sound, AudioPriority.High)
                        self.armor_anim:on_complete(function()
                            self.armor_anim:set_state("VULCAN PAUSE")
                            self.armor_anim:on_complete(function()
                                self.armor_anim:set_state("VULCAN_SHOOT")
                                self.armor_anim:set_playback(Playback.Loop)
                                self.vulcan_attack = true
                                self.flare = create_reverse_vulcan_flare(self, self.vulcan_texture)
                                field:spawn(self.flare, self:get_tile())
                            end)
                        end)
                    elseif self.anim_once and self.vulcan_shots >= 16 then
                        print("hi hi hi")
                        self.anim_once = false
                        self.armor_anim:set_state("VULCAN_REVEAL")
                        self.armor_anim:set_playback(Playback.Reverse)
                        self.armor_anim:on_complete(function()
                            if self:get_health() <= math.floor(self.health/2) then
                                self.armor_anim:set_state("ARMOR_IDLE_FAST")
                            else
                                self.armor_anim:set_state("ARMOR_IDLE")
                            end
                            self.armor_anim:set_playback(Playback.Loop)
                            self.pattern_index = self.pattern_index + 1
                            self.vulcan_attack = false
                            self.vulcan_shots = 0
                            self.anim_once = true
                            self.cooldown = 23
                        end)
                    end
                elseif activity == "RED EYE DELETE" then
                    take_red_eye_action(self, "ATTACK_CHARGE")
                    self.pattern_index = self.pattern_index + 1
                elseif activity == "ALPHA ARM" then
                    if self.sigma_attack and self.sigma_count < 16 then
                        self.alpha_arm = take_alpha_arm_action(self, self.alpha_arm_type[self.alpha_arm_index])
                    end
                    if self.sigma_count >= 16 then
                        self.sigma_count = 0
                        self.sigma_attack = false
                        if self.alpha_arm ~= nil then
                            self.alpha_arm:delete()
                            self.alpha_arm = nil
                        end
                        self.core_anim:set_state("COIL_RETREAT")
                        self.core_anim:on_complete(function()
                            self.core_anim:set_state("CORE")
                            self.core_anim:set_playback(Playback.Loop)
                            end_alpha_arm(self)
                        end)
                    end
                    if self.anim_once then
                        self.upper_arm:hide()
                        self.lower_arm:hide()
                        self.upper_arm:toggle_hitbox(false)
                        self.lower_arm:toggle_hitbox(false)
                        self.anim_once = false
                        if self.alpha_arm_type[self.alpha_arm_index] == "SIGMA" then
                            self.core_anim:set_state("COIL_SPAWN")
                            self.core_anim:on_complete(function()
                                self.core_anim:set_state("COIL_ATTACK")
                                self.core_anim:set_playback(Playback.Loop)
                                self.sigma_attack = true
                            end)
                        elseif self.alpha_arm_type[self.alpha_arm_index] == "OMEGA" then
                            self.omega_attack = true
                            Engine.play_audio(reverse_vulcan_spawn_sound, AudioPriority.High)
                            self.core_anim:set_state("ROCKET_SPAWN")
                            self.core_anim:on_frame(5, function()
                                take_alpha_arm_action(self, self.alpha_arm_type[self.alpha_arm_index])
                            end)
                            self.core_anim:on_complete(function()
                                self.core_anim:set_state("CORE")
                                self.core_anim:set_playback(Playback.Loop)
                                end_alpha_arm(self)
                            end)
                        end
                    end
                end
                if self.pattern_index > #self.pattern then self.pattern_index = 1 end
                keep_omega = false
            end
        else
            self.cooldown = self.cooldown - 1
        end
    end
end