local DAMAGE = 240

local TEXTURE_GIGANTHOOK = Engine.load_texture(_modpath.."giganthook.png")
local ANIMPATH_GIGANTHOOK = _modpath.."giganthook.animation"
local AUDIO_HOOK = Engine.load_audio(_modpath.."hook.ogg")

local TEXTURE_FLASH = Engine.load_texture(_modpath.."flash.png")
local ANIMPATH_FLASH = _modpath.."flash.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-292-GigantHook")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G"})

    local props = package:get_card_props()
    props.shortname = "GgntHook"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Break
    props.description = "Hook atk 2sq wide!"
    props.long_description = "2 fists 2 squares wide, 2 hooks!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local spawn_tile = nil
        local hit_tile_1 = nil
        local hit_tile_2 = nil
        local hit_tile_3 = nil
        local hit_tile_4 = nil
        local hit_tile_5 = nil
        local hit_tile_6 = nil
        local hit_tile_7 = nil
        local hit_tile_8 = nil
        local hit_tile_9 = nil

        if direction == Direction.Right then
            spawn_tile = field:tile_at(2,2)
            hit_tile_4 = field:tile_at(4,2)
            hit_tile_5 = field:tile_at(5,2)
            hit_tile_6 = field:tile_at(6,2)
        else
            spawn_tile = field:tile_at(5,2)
            hit_tile_4 = field:tile_at(3,2)
            hit_tile_5 = field:tile_at(2,2)
            hit_tile_6 = field:tile_at(1,2)
        end

        local hit_tile_1 = hit_tile_4:get_tile(Direction.Up, 1)
        local hit_tile_2 = hit_tile_5:get_tile(Direction.Up, 1)
        local hit_tile_3 = hit_tile_6:get_tile(Direction.Up, 1)
        local hit_tile_7 = hit_tile_4:get_tile(Direction.Down, 1)
        local hit_tile_8 = hit_tile_5:get_tile(Direction.Down, 1)
        local hit_tile_9 = hit_tile_6:get_tile(Direction.Down, 1)

		local step1 = Battle.Step.new()

        self.giganthook = nil
        self.tile       = user:get_current_tile()

        local ref = self
        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.giganthook = Battle.Artifact.new()
                ref.giganthook:set_facing(direction)
                ref.giganthook:sprite():set_layer(-3)
		    	ref.giganthook:set_texture(TEXTURE_GIGANTHOOK, true)

                local hitbox_1_1 = create_attack(user, team, props, field)
                local hitbox_1_2 = create_attack(user, team, props, field)
                local hitbox_2_1 = create_attack(user, team, props, field)
                local hitbox_2_2 = create_attack(user, team, props, field)
                local hitbox_3_1 = create_attack(user, team, props, field)
                local hitbox_3_2 = create_attack(user, team, props, field)
                local hitbox_4_1 = create_attack(user, team, props, field)
                local hitbox_4_2 = create_attack(user, team, props, field)
                local hitbox_5_1 = create_attack(user, team, props, field)
                local hitbox_5_2 = create_attack(user, team, props, field)
                local hitbox_6_1 = create_attack(user, team, props, field)
                local hitbox_6_2 = create_attack(user, team, props, field)

                gigant_anim = ref.giganthook:get_animation()
                gigant_anim:load(ANIMPATH_GIGANTHOOK)
                gigant_anim:set_state("0")
		    	gigant_anim:refresh(ref.giganthook:sprite())
                gigant_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_HOOK, AudioPriority.Highest)
                end)
                gigant_anim:on_frame(3, function()
                    field:spawn(hitbox_1_1, hit_tile_7)
                    field:spawn(hitbox_1_2, hit_tile_8)
                end)
                gigant_anim:on_frame(5, function()
                    hitbox_1_1:erase()
                    hitbox_1_2:erase()
                    field:spawn(hitbox_2_1, hit_tile_4)
                    field:spawn(hitbox_2_2, hit_tile_5)
                end)
                gigant_anim:on_frame(7, function()
                    hitbox_2_1:erase()
                    hitbox_2_2:erase()
                end)
                gigant_anim:on_frame(9, function()
                    field:spawn(hitbox_3_1, hit_tile_1)
                    field:spawn(hitbox_3_2, hit_tile_2)
                end)
                gigant_anim:on_frame(11, function()
                    hitbox_3_1:erase()
                    hitbox_3_2:erase()
                end)
                gigant_anim:on_frame(22, function()
                    Engine.play_audio(AUDIO_HOOK, AudioPriority.Highest)
                end)
                gigant_anim:on_frame(29, function()
                    field:spawn(hitbox_4_1, hit_tile_2)
                    field:spawn(hitbox_4_2, hit_tile_3)
                end)
                gigant_anim:on_frame(31, function()
                    hitbox_4_1:erase()
                    hitbox_4_2:erase()
                end)
                gigant_anim:on_frame(33, function()
                    field:spawn(hitbox_5_1, hit_tile_5)
                    field:spawn(hitbox_5_2, hit_tile_6)
                end)
                gigant_anim:on_frame(35, function()
                    hitbox_5_1:erase()
                    hitbox_5_2:erase()
                    field:spawn(hitbox_6_1, hit_tile_8)
                    field:spawn(hitbox_6_2, hit_tile_9)
                end)
                gigant_anim:on_frame(37, function()
                    hitbox_6_1:erase()
                    hitbox_6_2:erase()
                end)
		    	gigant_anim:on_complete(function()
                    ref.giganthook:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.giganthook, spawn_tile)
            end
        end
        self:add_step(step1)
    end
	return action
end

function create_attack(actor, team, props, field)
    local spell = Battle.Spell.new(team)
    spell:get_facing(Direction.Right)
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact | Hit.Breaking,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("0")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
        spell:shake_camera(11, 0.25)
        create_flashlight(field)
    end
    
    spell.delete_func = function(self)
		self:erase()
    end

    return spell
end

function create_flashlight(field)
    local flashlight = Battle.Artifact.new()
    flashlight:set_facing(Direction.Right)
    flashlight:sprite():set_layer(10)
    flashlight:set_texture(TEXTURE_FLASH, true)
    local flashlight_anim = flashlight:get_animation()
	flashlight_anim:load(ANIMPATH_FLASH)
	flashlight_anim:set_state("0")
	flashlight_anim:refresh(flashlight:sprite())
    flashlight_anim:on_complete(function()
        flashlight:erase()
    end)
    field:spawn(flashlight, 3, 2)
end