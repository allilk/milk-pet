local DarkSword = include("DarkSword/entry.lua")
local DarkCannon = include("DarkCannon/entry.lua")
local function buster_spam_action(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell:set_facing(dark_rock:get_facing())
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            10,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
        if Battle.Character.from(other) ~= nil or Battle.Obstacle.from(other) ~= nil then
		    self:delete()
        end
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function package_init(package) 
    package:declare_package_id("com.Dawn.Dark.Invisible")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'I'})

    local props = package:get_card_props()
    props.shortname = "DrkInvis"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "RELEASE YOUR DARKNESS"
    props.limit = 1
    props.long_description = "DARK CHIP (C) YOU. DARK SOUL YOU WILL BECOME!"
    props.card_class = CardClass.Dark
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")    
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user2)
        StatusGuard = Battle.DefenseRule.new(99559933, DefenseOrder.CollisionOnly)
        StatusGuard.filter_statuses_func = function(statuses)
            statuses.flags = statuses.flags & ~Hit.Freeze
			statuses.flags = statuses.flags & ~Hit.Flash
			statuses.flags = statuses.flags & ~Hit.Flinch
			statuses.flags = statuses.flags & ~Hit.Stun
            statuses.flags = statuses.flags & ~Hit.Blind
            return statuses
        end
        user:add_defense_rule(StatusGuard)
        local EndDarkInvisComponent = Battle.Component.new(user2, Lifetimes.Battlestep)
        local frame1 = {1, 0.05}
        local frame2 = {2, 0.05}
        local frame3 = {3, 0.05}
        local frame4 = {1, 0.05}
        local frame5 = {2, 0.05}
        local frame6 = {3, 0.05}
        local frame7 = {1, 0.05}
        local frame8 = {2, 0.05}
        local frame9 = {3, 0.05}
        local frame10 = {4, 0.1}
        local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
        local AttackPattern = {"BusterSpam", "BusterSpam", "BusterSpam", "BusterSpam", "BusterSpam", "Move", "Move", "Move", "DarkCannon", "DarkSword", "DarkSword", "DarkCannon"}
        EndDarkInvisComponent.shuffled = {}
        for i, v in ipairs(AttackPattern) do
            local pos = math.random(1, #EndDarkInvisComponent.shuffled+1)
            table.insert(EndDarkInvisComponent.shuffled, pos, v)
        end
        EndDarkInvisComponent.StoredActor = self:get_actor()
        EndDarkInvisComponent.CountDown = 0
        EndDarkInvisComponent.RandRoll = 1
        EndDarkInvisComponent.RandRollCountDown = 0
        EndDarkInvisComponent.color = Color.new(190, 150, 220, 255)
        EndDarkInvisComponent.update_func = function(self, dt)
            local owner = self:get_owner()
            EndDarkInvisComponent.CountDown = EndDarkInvisComponent.CountDown + 1
            EndDarkInvisComponent.RandRollCountDown = EndDarkInvisComponent.RandRollCountDown + 1
            if EndDarkInvisComponent.RandRollCountDown % 60 == 0 then
                if EndDarkInvisComponent.shuffled[EndDarkInvisComponent.RandRoll] == "BusterSpam" then
                    local action = Battle.CardAction.new(self.StoredActor, "PLAYER_SHOOTING")
                    action:override_animation_frames(frame_sequence)
                    action:set_lockout(make_animation_lockout())
                    action.execute_func = function(act, user)
                        local buster = act:add_attachment("BUSTER")
                        local sprite = buster:sprite()
                        sprite:set_texture(owner:get_texture())
                        sprite:enable_parent_shader(true)
                        sprite:set_layer(-1)
                        local buster_anim = buster:get_animation()
                        buster_anim:copy_from(owner:get_animation())
                        buster_anim:set_state("BUSTER")
                        buster_anim:refresh(sprite)
                        act:add_anim_action(1, function()
                            local spell = buster_spam_action(owner)
                            owner:get_field():spawn(spell, owner:get_tile(owner:get_facing(), 1))
                        end)
                        act:add_anim_action(4, function()
                            local spell = buster_spam_action(owner)
                            owner:get_field():spawn(spell, owner:get_tile(owner:get_facing(), 1))
                        end)
                        act:add_anim_action(7, function()
                            local spell = buster_spam_action(owner)
                            owner:get_field():spawn(spell, owner:get_tile(owner:get_facing(), 1))
                        end)
                    end
                    self.StoredActor:card_action_event(action, ActionOrder.Involuntary)
                elseif EndDarkInvisComponent.shuffled[EndDarkInvisComponent.RandRoll] == "DarkCannon" then
                    local action = DarkCannon.card_create_action(EndDarkInvisComponent.StoredActor)
                    self.StoredActor:card_action_event(action, ActionOrder.Involuntary)
                elseif EndDarkInvisComponent.shuffled[EndDarkInvisComponent.RandRoll] == "DarkSword" then
                    local action = DarkSword.card_create_action(EndDarkInvisComponent.StoredActor)
                    self.StoredActor:card_action_event(action, ActionOrder.Involuntary)
                end
                EndDarkInvisComponent.RandRoll = EndDarkInvisComponent.RandRoll + 1
                if EndDarkInvisComponent.RandRoll > #EndDarkInvisComponent.shuffled then
                    EndDarkInvisComponent.RandRoll = 1
                end
            end
            if EndDarkInvisComponent.CountDown >= 900 then
                self:eject()
                local anim = owner:get_animation()
                anim:set_state("PLAYER_HIT")
                Engine.play_audio(AudioType.Deform, AudioPriority.High)
                anim:on_complete(function()
                    anim:set_state("PLAYER_IDLE")
                    user:remove_defense_rule(StatusGuard)
                end)
            end
            owner:sprite():set_color_mode(ColorMode.Multiply)
            owner:set_color(self.color)
        end
        user2:register_component(EndDarkInvisComponent)
        Engine.play_audio(Engine.load_audio(_modpath.."sfx.ogg", true), AudioPriority.High)
    end
    return action
end