local DAMAGE = 280

local TEXTURE_JUSTICEONE = Engine.load_texture(_modpath.."justiceone.png")
local ANIMPATH_JUSTICEONE = _modpath.."justiceone.animation"
local AUDIO_METEOR = Engine.load_audio(_modpath.."meteor.ogg")

local TEXTURE_WARP = Engine.load_texture(_modpath.."warp.png")
local ANIMPATH_WARP = _modpath.."warp.animation"
local TEXTURE_BOOM1 = Engine.load_texture(_modpath.."boom1.png")
local ANIMPATH_BOOM1 = _modpath.."boom1.animation"
local TEXTURE_BOOM2 = Engine.load_texture(_modpath.."boom2.png")
local ANIMPATH_BOOM2 = _modpath.."boom2.animation"
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")

local ANIMPATH_ATTACK = _modpath.."attack.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-218-JusticeOne")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"J"})

    local props = package:get_card_props()
    props.shortname = "JustcOne"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Break
    props.description = "Fist atk on center panel!"
    props.long_description = "Justice Fist in the middle square, 5 columns from the left!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local spawn_tile = nil

        if direction == Direction.Right then
            spawn_tile = field:tile_at(2,2)
        else
            spawn_tile = field:tile_at(5,2)
        end

        local hit_tile = spawn_tile:get_tile(direction, 3)

		local step1 = Battle.Step.new()

        self.justiceone = nil
        self.tile       = user:get_current_tile()

        local ref = self
        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.justiceone = Battle.Artifact.new()
                ref.justiceone:set_facing(direction)
                ref.justiceone:sprite():set_layer(-3)
		    	ref.justiceone:set_texture(TEXTURE_JUSTICEONE, true)

                justice_anim = ref.justiceone:get_animation()
                justice_anim:load(ANIMPATH_JUSTICEONE)
                justice_anim:set_state("0")
		    	justice_anim:refresh(ref.justiceone:sprite())
                justice_anim:on_frame(1, function()
                    Engine.play_audio(AUDIO_METEOR, AudioPriority.High)
                end)
		    	justice_anim:on_complete(function()
                    if not hit_tile:is_hole() then
                        print("The target tile ("..hit_tile:x()..","..hit_tile:y()..") is NOT a hole!")
		    		    justice_anim:set_state("1")
                        justice_anim:refresh(ref.justiceone:sprite())
                        ref.justiceone:shake_camera(30, 1)
                    else
                        print("The target tile ("..hit_tile:x()..","..hit_tile:y()..") IS a hole!")
                        create_boom(TEXTURE_WARP, ANIMPATH_WARP, "2", field, hit_tile)
                        ref.justiceone:erase()
                        step1:complete_step()
                    end
		    	end)
                field:spawn(ref.justiceone, spawn_tile)
            end
            local anim = ref.justiceone:get_animation()
            if anim:get_state() == "1" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_frame(1, function()
                        create_boom(TEXTURE_BOOM2, ANIMPATH_BOOM2, "0", field, hit_tile)
                        create_attack(user, team, props, props.damage, Hit.Flinch | Hit.Flash | Hit.Impact | Hit.Breaking, hit_tile, field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.Up, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.Down, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.Left, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.Right, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.UpLeft, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.UpRight, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.DownLeft, 1), field)
                        create_attack(user, team, props, 100, Hit.Flinch | Hit.Flash | Hit.Impact, hit_tile:get_tile(Direction.DownRight, 1), field)
			        end)
                    anim:on_complete(function()
                        ref.justiceone:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
	return action
end

function create_attack(actor, team, props, damage, hits, tile, field)
    local spell = Battle.Spell.new(team)
    spell:get_facing(Direction.Right)
    spell:set_hit_props(
        HitProps.new(
            damage,
            hits,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )
    local boomfx1 = Battle.Artifact.new()
	boomfx1:set_facing(Direction.Right)
    local boom1sprt = boomfx1:sprite()
    boom1sprt:set_texture(TEXTURE_BOOM1, true)
    boom1sprt:set_layer(-5)
	local fx1_anim = boomfx1:get_animation()
	fx1_anim:load(ANIMPATH_BOOM1)
	fx1_anim:set_state("0")
    fx1_anim:on_complete(function()
        boomfx1:erase()
    end)
    field:spawn(boomfx1, tile)

    local boom_anim = spell:get_animation()
    boom_anim:load(ANIMPATH_ATTACK)
    boom_anim:set_state("0")
    boom_anim:on_frame(1, function()
        if not tile:is_cracked() then
            tile:set_state(TileState.Cracked)
        elseif tile:is_cracked() then
            tile:set_state(TileState.Broken)
        end
    end, true)
    boom_anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end
    
    spell.delete_func = function(self)
		self:erase()
    end

    Engine.play_audio(AUDIO_BOOM, AudioPriority.High)

    field:spawn(spell, tile)
    field:spawn(boomfx1, tile)

    return spell
end

function create_boom(texture, animpath, animstate, field, tile)
    local boomfx1 = Battle.Artifact.new()
	boomfx1:set_facing(Direction.Right)
    local boom1sprt = boomfx1:sprite()
    boom1sprt:set_texture(texture, true)
    boom1sprt:set_layer(-5)
	local fx1_anim = boomfx1:get_animation()
	fx1_anim:load(animpath)
	fx1_anim:set_state(animstate)
    fx1_anim:on_complete(function()
        boomfx1:erase()
    end)
    field:spawn(boomfx1, tile)
end