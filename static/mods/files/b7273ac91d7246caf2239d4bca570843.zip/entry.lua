function package_init(package)
    package:declare_package_id("Ratton2.rune.legacy.PVP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"H","I","J"})
 
    local props = package:get_card_props()
    props.shortname = "Ratton2"
    props.damage = 110
    props.time_freeze = false
    props.element = Element.None
    props.secondary_element = Element.Cursor
    props.description = "Missile that can turn once"
end

function card_create_action(actor, props)
    print("creating Rat Bomb!")
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2,
        function()
        end
    )

    self:add_anim_action(3,
        function()
            local rat = create_rat(user, props)
            local tile = user:get_tile(user:get_facing(), 1)
            actor:get_field():spawn(rat, tile)
        end
        )
    end
    return action
end




function create_rat(user, props)
    local spell = Battle.Obstacle.new(user:get_team())
    spell:set_facing(user:get_facing())
    local direction = spell:get_facing()
    local spell_texture = Engine.load_texture(_modpath.."attack.png")
    spell:set_texture(spell_texture, true)
    local spell_anim = spell:get_animation()
    spell_anim:load(_modpath.."attack.animation")
    spell_anim:refresh(spell:sprite())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Impact | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell:set_health(50)
    spell:share_tile(true)
    spell:sprite():set_layer(-2)
    if spell:get_facing() == Direction.Right then 
        spell:set_offset(-15.0, -30.0)
    else 
        spell:set_offset(15.0, -30.0)
    end


    local explosion = Battle.Artifact.new()
    local explosion_texture = Engine.load_texture(_modpath.."boom.png")
    local explosion_anim = _modpath.."boom.animation"

    spell.slide_started = false

    spell.collision_func = function(self, other)
        self:delete()
    end
    local field = user:get_field()
    spell.delete_func = function(self)
        if self:get_tile():is_edge() then
            local fx = Battle.Artifact.new()
            fx:set_texture(Engine.load_texture(_modpath.."mob_move.png"))
            local fx_anim = fx:get_animation()
            fx_anim:load(_modpath.."mob_move.animation")
            fx_anim:set_state("DEFAULT")
            fx_anim:refresh(fx:sprite())
            fx_anim:on_complete(function()
                fx:erase()
            end)
            field:spawn(fx, self:get_tile())
        else
            explosion:set_texture(explosion_texture, true)
            local explosion_animation = explosion:get_animation()
            explosion_animation:load(explosion_anim)
            explosion_animation:set_state("0")
            explosion_animation:refresh(explosion:sprite())
            explosion_animation:on_complete(function()
                explosion:erase()
            end)
            self:get_field():spawn(explosion, self:get_tile())
            Engine.play_audio(Engine.load_audio(_modpath.."explosion.ogg", true), AudioPriority.Low)
        end
        self:erase()
    end
    local same_column_query = function(c)
        return not c:is_deleted() and c:get_team() ~= spell:get_team() and c:get_tile():x() == spell:get_tile():x() and c:get_tile():y() ~= spell:get_tile():y()
    end
    local has_turned = false
    local slide_speed = 16
    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_tile():highlight(Highlight.Solid)
        if self:get_current_tile():is_edge() and self.slide_started and not self:is_deleted() then 
            self:delete()
        end
        if self:is_deleted() then return end
        if self:is_sliding() == false then
            local dest = self:get_tile(direction, 1)
            if #field:find_characters(same_column_query) > 0 and not has_turned then
                local target = field:find_characters(same_column_query)[1]
                if target:get_tile():y() < self:get_tile():y() then
                    direction = Direction.Up
                else
                    direction = Direction.Down
                end
                dest = self:get_tile(direction, 1)
                has_turned = true
            end
            local ref = self
            self:slide(dest, frames(slide_speed), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end