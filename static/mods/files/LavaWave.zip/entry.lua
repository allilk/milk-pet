local guard = include("guard/guard.lua")

guard.name = "LavaWav"
guard.codes = {"F","L","M"}
guard.damage = 100
guard.duration = 0
guard.guard_animation = "GUARD1"
guard.description = "Magma wave forward!"
 
function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = guard.name
    props.damage = guard.damage
    props.time_freeze = false
    props.element = Element.Fire
    props.description = guard.description

    package:declare_package_id("LavaWav.PVP")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(guard.codes)
end

card_create_action = guard.card_create_action




