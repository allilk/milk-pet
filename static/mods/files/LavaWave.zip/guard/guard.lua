local battle_helpers = include("battle_helpers.lua")

local wave_texture = Engine.load_texture(_folderpath .. "shockwave.png")
local wave_sfx = Engine.load_audio(_folderpath .. "shockwave.ogg")
local shield_texture = Engine.load_texture(_folderpath .. "guard_attachment.png")
local sheild_animation_path = _folderpath .. "guard_attachment.animation"
local guard_hit_effect_texture = Engine.load_texture(_folderpath .. "guard_hit.png")
local guard_hit_effect_animation_path = _folderpath .. "guard_hit.animation"
local tink_sfx = Engine.load_audio(_folderpath .. "tink.ogg")
local shield_sfx = Engine.load_audio(_folderpath .. "shield.ogg")

--variables that change for each version of the card
local guard = {
    name="Guard1",
    codes={'A',"D","K","*"},
    damage=50,
    duration=1.024,
    guard_animation = "GUARD1",
    description = "Repels an enemys attack"
}

function guard.card_create_action(user,props)
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    --special properties
    action.guard_animation = guard.guard_animation

	--protoman's counter in BN5 lasts 24 frames (384ms)
	--there are 224ms of the shield fading away where protoman can move
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()

		self:add_anim_action(1,function ()

            actor:toggle_counter(true)
        end)

		self:add_anim_action(2,function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)


            local reflected_damage = props.damage
            local direction = user:get_facing()
            spawn_shockwave(user, user:get_team(),user:get_field(),user:get_tile(direction, 1), direction,reflected_damage, wave_texture,wave_sfx,0.2)
        end)

        self:add_anim_action(3, function()
		end)

        self:add_anim_action(4, function()
			user:toggle_counter(false)
		end)
    end
    return action
end

function spawn_shockwave(owner, team, field, tile, direction,damage, wave_texture, wave_sfx,frame_time)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(wave_sfx, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact|Hit.Flash, Element.Fire, owner:get_context() , Drag.None))

        local sprite = spell:sprite()
        sprite:set_texture(wave_texture)

        local animation = spell:get_animation()
        animation:load(_folderpath .. "shockwave.animation")
        animation:set_state("DEFAULT")
        animation:refresh(sprite)
        animation:on_frame(5, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() 
        spell:get_current_tile():set_state(TileState.Lava)
        end)

    spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

return guard