local DAMAGE = 200

local GEYSER_TEXTURE = Engine.load_texture(_modpath.."geyser.png")
local GEYSER_ANIMPATH = _modpath.."geyser.animation"
local GEYSER_AUDIO = Engine.load_audio(_modpath.."geyser.ogg")
local BUBBLES_TEXTURE = Engine.load_texture(_modpath.."bubbles.png")
local BUBBLES_ANIMPATH = _modpath.."bubbles.animation"
local BUBBLES_AUDIO = Engine.load_audio(_modpath.."bubbles.ogg")
local ATTACHMENT_TEXTURE = Engine.load_texture(_modpath.."attachment.png")
local ATTACHMENT_ANIMPATH = _modpath.."attachment.animation"
local THROW_AUDIO = Engine.load_audio(_modpath.."toss_item.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE5-046-Kanketsusen")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G","M","S"})

    local props = package:get_card_props()
    props.shortname = "Geyser"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Geyser 3 squares ahead!"
    props.long_description = "Water sprays out if you throw it 3 squares in front and it falls into a hole square!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.064},{2,0.064},{3,0.064},{4,0.064},{5,0.064}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        --local props = self:copy_metadata()
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(ATTACHMENT_TEXTURE)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(ATTACHMENT_ANIMPATH)
        attachment_animation:set_state("DEFAULT")

        user:toggle_counter(true)
        self:add_anim_action(3,function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local target_tile = user:get_tile(direction, tiles_ahead)
            if not target_tile then
                return
            end
            action.on_landing = function()
                if target_tile:is_hole() then
                    create_geysey(user, props, team, direction, field, target_tile)
                else
                    create_bubbles(user, props, team, direction, field, target_tile, true)
                end
            end
            toss_spell(user, team, toss_height, target_tile, frames_in_air, action.on_landing, field)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self.action_end_func = function()
            user:toggle_counter(false)
        end

        Engine.play_audio(THROW_AUDIO, AudioPriority.Highest)
    end
    return action
end

function toss_spell(tosser, team, toss_height, target_tile, frames_in_air, arrival_callback, field)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local spell = Battle.Spell.new(team)
    local spell_animation = spell:get_animation()
    spell_animation:load(ATTACHMENT_ANIMPATH)
    spell_animation:set_state("DEFAULT")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(ATTACHMENT_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function create_geysey(owner, props, team, direction, field, tile)
    local geyser = Battle.Spell.new(team)
    geyser:set_facing(direction)
    geyser:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact,
            props.element,
            owner:get_context(),
            Drag.None
        )
    )
    local geyser_sprite = geyser:sprite()
    geyser_sprite:set_texture(GEYSER_TEXTURE)
    geyser_sprite:set_layer(-9)
    local geyser_anim = geyser:get_animation()
    geyser_anim:load(GEYSER_ANIMPATH)
    geyser_anim:set_state("0")
    geyser_anim:refresh(geyser_sprite)
    geyser_anim:on_complete(function() geyser:erase() end)
     
    geyser.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
     
    geyser.can_move_to_func = function(tile)
		return true
	end
     
    --[[geyser.battle_end_func = function(self)
		self:erase()
	end]]
     
    geyser.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
		create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end
     
    geyser.delete_func = function(self)
		self:erase()
    end

    local number1 = nil
    local number2 = nil
    local number3 = nil
    local number4 = nil
    local number5 = nil
    local number6 = nil
    local number7 = nil
    local number8 = nil

    local delay = Battle.Spell.new(team)
    delay:get_facing(direction)
    local delay_anim = delay:get_animation()
    delay_anim:load(_modpath.."attack.animation")
    delay_anim:set_state("0")
    delay_anim:on_frame(1, function()
        Engine.play_audio(GEYSER_AUDIO, AudioPriority.Highest)
        field:spawn(geyser, tile)
    end)
    delay_anim:on_frame(2, function()
        local tile_number
        number1 = math.random(1, 8)
        tile_number = number1
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(3, function()
        local tile_number
        repeat
            number2 = math.random(1, 8)
        until number2 ~= number1
        tile_number = number2
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(4, function()
        local tile_number
        repeat
            number3 = math.random(1, 8)
        until number3 ~= number1 and number3 ~= number2
        tile_number = number3
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(5, function()
        local tile_number
        repeat
            number4 = math.random(1, 8)
        until number4 ~= number1 and number4 ~= number2 and number4 ~= number3
        tile_number = number4
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(6, function()
        local tile_number
        repeat
            number5 = math.random(1, 8)
        until number5 ~= number1 and number5 ~= number2 and number5 ~= number3 and number5 ~= number4
        tile_number = number5
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(7, function()
        local tile_number
        repeat
            number6 = math.random(1, 8)
        until number6 ~= number1 and number6 ~= number2 and number6 ~= number3 and number6 ~= number4 and number6 ~= number5
        tile_number = number6
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(8, function()
        local tile_number
        repeat
            number7 = math.random(1, 8)
        until number7 ~= number1 and number7 ~= number2 and number7 ~= number3 and number7 ~= number4 and number7 ~= number5 and number7 ~= number6
        tile_number = number7
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_frame(9, function()
        local tile_number
        repeat
            number8 = math.random(1, 8)
        until number8 ~= number1 and number8 ~= number2 and number8 ~= number3 and number8 ~= number4 and number8 ~= number5 and number8 ~= number6 and number8 ~= number7
        tile_number = number8
        if tile_number == 1 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Up, 1), false)
        elseif tile_number == 2 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Down, 1), false)
        elseif tile_number == 3 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Left, 1), false)
        elseif tile_number == 4 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.Right, 1), false)
        elseif tile_number == 5 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpLeft, 1), false)
        elseif tile_number == 6 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.UpRight, 1), false)
        elseif tile_number == 7 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownLeft, 1), false)
        elseif tile_number == 8 then
            create_bubbles(owner, props, team, direction, field, tile:get_tile(Direction.DownRight, 1), false)
        end
    end)
    delay_anim:on_complete(function() delay:erase() end)
    delay.update_func = function(self, dt)
    end
    delay.can_move_to_func = function(tile)
		return true
	end
    delay.battle_end_func = function(self)
		self:erase()
	end
    delay.delete_func = function(self)
		self:erase()
    end

    Engine.play_audio(GEYSER_AUDIO, AudioPriority.High)
     
    field:spawn(delay, tile)
end

function create_bubbles(owner, props, team, direction, field, tile, only_one)
    local spawn
    spawn = function()
        if tile:is_edge() or tile == nil then return end

        local bubbles = Battle.Spell.new(team)
        bubbles:set_facing(direction)
        if only_one then
            Engine.play_audio(BUBBLES_AUDIO, AudioPriority.Highest)
            bubbles:set_hit_props(
            HitProps.new(
                10,
                Hit.Flinch | Hit.Flash | Hit.Impact,
                props.element,
                owner:get_context(),
                Drag.None
            )
        )
        else
            bubbles:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Flinch | Hit.Flash | Hit.Impact,
                props.element,
                owner:get_context(),
                Drag.None
            )
        )
        end
        local bubbles_sprite = bubbles:sprite()
        bubbles_sprite:set_texture(BUBBLES_TEXTURE)
        bubbles_sprite:set_layer(-9)
        local bubbles_anim = bubbles:get_animation()
        bubbles_anim:load(BUBBLES_ANIMPATH)
        bubbles_anim:set_state("0")
        bubbles_anim:refresh(bubbles_sprite)
        bubbles_anim:on_complete(function() bubbles:erase() end)

        bubbles.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end
        bubbles.attack_func = function(self, other)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
	    	create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
        end
        bubbles.can_move_to_func = function(tile)
	    	return true
	    end
        bubbles.battle_end_func = function(self)
	    	self:erase()
	    end
        bubbles.delete_func = function(self)
	    	self:erase()
        end

        field:spawn(bubbles, tile)
    end

    spawn()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end