function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.HP300.pink.bn6")
    block:set_name("HP+300")
    block:set_description("MAX HP\n+300!")
    block:set_color(Blocks.Pink)
    block:set_shape({
        0, 0, 0, 0, 0,
        1, 1, 1, 1, 0,
        1, 1, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:mod_max_health(300)
end
