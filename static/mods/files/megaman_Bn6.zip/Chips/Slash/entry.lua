local chip = {}

local function create_slash(user, props)
    local spell = Battle.Spell.new(user:get_team())
	local SLASH_TEXTURE = Engine.load_texture(_folderpath.."visual.png")
	spell:set_facing(user:get_facing())
	spell:set_texture(SLASH_TEXTURE)
	local anim = spell:get_animation()
	anim:load(_folderpath.."visual.animation")
	anim:set_state("DEFAULT")
	anim:refresh(spell:sprite())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			nil,
			Drag.None
		)
	)
	spell.distance = 0
	spell.distance_max = 2
    spell.slide_started = false
    spell.update_func = function(self, dt)
		if self:is_deleted() then return end
		if self.distance >= spell.distance_max then self:delete() return end
        local tile = spell:get_tile()
        local tile_up = tile:get_tile(Direction.Up, 1)
		local tile_down = tile:get_tile(Direction.Down, 1)
        if tile and not tile:is_edge() then tile:attack_entities(self) end
        if tile_up and not tile_up:is_edge() then tile_up:attack_entities(self) end
        if tile_down and not tile_down:is_edge() then tile_down:attack_entities(self) end
        if not self:is_sliding() then
            if tile:is_edge() and self.slide_started then self:delete() return end
            local dest = self:get_tile(spell:get_facing(), 1)
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, function()
                self.slide_started = true
				self.distance = self.distance + 1
            end)
        end
    end
	spell.collision_func = function(self, other)
		self:delete()
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	return spell
end

chip.card_create_action = function(player, props)
    local action = Battle.CardAction.new(player, "PLAYER_SWORD")
    action.execute_func = function(self, user)
        local cross_texture = Engine.load_texture(_modpath.."forms/slash_cross.png")
        self:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(cross_texture)
            hilt_sprite:set_layer(-2)
            hilt_sprite:enable_parent_shader(false)

            local hilt_anim = hilt:get_animation()
            hilt_anim:load(_modpath.."forms/slash_cross.animation")
            hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
        end)
        local field = user:get_field()
		self:add_anim_action(3, function()
			local sword = create_slash(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			field:spawn(sword, tile)
		end)
    end
    return action
end

return chip