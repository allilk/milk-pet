function package_init(package) 
    package:declare_package_id("com.Dawn.navi.MegamanBN6")
    package:set_speed(2.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("BN6 Gregar Megaman!")
	package:set_icon_texture(Engine.load_texture(_modpath.."mega_face.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Megaman")
	player:set_health(1000)
	player:set_element(Element.None)
    player:set_height(48.0)
	player:set_charge_position(1,-14)
    player:set_animation(_modpath.."megaman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_megaman_atlas.png"), false)
    player:store_base_palette(Engine.load_texture(_modpath.."forms/base.palette.png"))
    player:set_palette(player:get_base_palette())

	local slash_claw = include("Chips/Slash/entry.lua")

    player.update_func = function(self, dt)
        -- nothing in particular
    end

    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
    -- player.special_attack_func = create_special_attack

    -- slash form
    local slash = player:create_form()
    slash:set_mugshot_texture_path(_modpath.."forms/slash_entry.png")
    slash.on_activate_func = function(self, player)
        self.overlay = player:create_sync_node("head")

        local sprite = self.overlay:sprite()
        sprite:set_texture(Engine.load_texture(_modpath.."forms/slash_cross.png"), false)
        sprite:set_layer(-1)
        sprite:enable_parent_shader(false)

        self.overlay:get_animation():load(_modpath.."forms/slash_cross.animation")

        player:set_palette(Engine.load_texture(_modpath.."forms/slash.palette.png"))
    end

    slash.on_deactivate_func = function(self)
        player:remove_sync_node(self.overlay)
        player:set_palette(player:get_base_palette())
    end

    slash.charged_attack_func = function()
        local props = Battle.CardProperties.new()
		props.damage = (player:get_attack_level()*20) + 60
		return slash_claw.card_create_action(player, props)
    end

	local charge = player:create_form()
	charge:set_mugshot_texture_path(_modpath.."forms/charge_entry.png")

	charge.on_activate_func = function(self, player)
		self.overlay = player:create_sync_node("head")
		player:set_element(Element.Fire)
        local sprite = self.overlay:sprite()
        sprite:set_texture(Engine.load_texture(_modpath.."forms/charge_cross.png"), false)
        sprite:set_layer(-1)
        sprite:enable_parent_shader(false)

        self.overlay:get_animation():load(_modpath.."forms/charge_cross.animation")
		
        player:set_palette(Engine.load_texture(_modpath.."forms/charge.palette.png"))
	end
	charge.update_func = function(self, dt)
		if player:get_tile() then
			if player:get_tile():get_state() == TileState.Ice then
				player:get_tile():set_state(TileState.Normal)
			end
		end
	end
	
	charge.on_deactivate_func = function(self, player)
        player:remove_sync_node(self.overlay)
        player:set_palette(player:get_base_palette())
		player:set_element(Element.None)
    end
	charge.charged_attack_func = function(player)
		local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
		local frame1 = {1, 0.25}
		local LONG_IDLE = make_frame_data({frame1})
		local pain = ((20 * player:get_attack_level()) + 30)
		local props = HitProps.new(
			pain,
			Hit.Impact | Hit.Flinch, 
			Element.Fire,
			player:get_context(),
			Drag.None
		)
		local spell = create_tackle(player, props)
		action:override_animation_frames(LONG_IDLE)
		action.execute_func = function(self, user)
			player:hide()
			player:toggle_hitbox(false)
			player:share_tile(true)
			player:get_field():spawn(spell, player:get_tile())
		end
		action.action_end_func = function(self)
			player:reveal()
			player:toggle_hitbox(true)
			player:share_tile(false)
		end
		action.can_move_to_func = function(tile)
			if tile then
				if tile:is_walkable() then
					return true
				else
					return false
				end
			end
			return false
		end
		return action
	end
end

function create_tackle(player, props)
	local spell = Battle.Obstacle.new(Team.Other)
	spell:set_facing(player:get_facing())
	spell.slide_started = false
	spell:set_texture(Engine.load_texture(_modpath.."forms/charge_cross.png"), true)
	local direction = spell:get_facing()
	local max_tiles = 3
	local tiles_moved = 0
	spell.attack_func = function(self)
		local tile = self:get_tile()
		local hitbox = Battle.Hitbox.new(Team.Other)
		hitbox:set_hit_props(props)
		player:get_field():spawn(hitbox, tile)
		self:erase()
	end
	
	local anim = spell:get_animation()
	anim:load(_modpath.."forms/charge_cross.animation", true)
	anim:set_state("PLAYER_SPECIAL")
	
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end 
			if tiles_moved >= max_tiles then
				self:delete()
			end
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
			tiles_moved = tiles_moved + 1
        end
    end
	spell.collision_func = function(self, other)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
		print(tile)
        if tile then
			if tile:is_walkable() then
				return true
			else
				return false
			end
		end
		return false
    end

	return spell
end

function create_bubbler(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(props)
	local query = function(ent)
		return Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil
	end
	spell.has_hit = false
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
			if not self.has_hit then
				local dest = self:get_tile(direction, 1)
				local ref = self
				self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
					function()
						ref.slide_started = true 
					end
				)
			end
        end
    end
	spell.collision_func = function(self, other)
		self.has_hit = true
		spell:set_texture(Engine.load_texture(_modpath.."forms/bubbler.png"), true)
		spell:get_animation():load(_modpath.."forms/bubbler.animation")
		spell:get_animation():set_state("DEFAULT")
		spell:sprite():set_layer(-1)
		spell:get_animation():refresh(spell:sprite())
		spell:set_height(-20)
		local tile = spell:get_tile():get_tile(spell:get_facing(), 1)
		if tile and not tile:is_edge() then
			local hitbox = Battle.Hitbox.new(spell:get_team())
			hitbox:set_hit_props(spell:copy_hit_props())
			local fx = Battle.Artifact.new()
			fx:set_texture(Engine.load_texture(_modpath.."forms/bubbler.png"), true)
			local anim = fx:get_animation()
			anim:load(_modpath.."forms/bubbler.animation")
			anim:set_state("DEFAULT")
			fx:sprite():set_layer(-1)
			fx:set_offset(0.0, 20.0)
			anim:refresh(fx:sprite())
			anim:on_complete(function()
				fx:erase()
			end)
			user:get_field():spawn(fx, tile)
			user:get_field():spawn(hitbox, tile)
		end
		spell:get_animation():on_complete(function()
			spell:erase()
		end)
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	-- Engine.play_audio(Engine.load_audio(_modpath.."forms/airshot.ogg", true), AudioPriority.High)
	return spell
end

function create_dust_buddy(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_texture(Engine.load_texture(_modpath.."forms/dust_charge.png"), true)
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	local direction = spell:get_facing()
	local final_x = 6
	if direction == Direction.Left then
		final_x = 1
	end
	
	local query = function(ent)
		return Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil
	end
	local animation = spell:get_animation()
	animation:load(_modpath.."forms/dust_charge.animation")
	animation:set_state("MOVE")
	spell:sprite():set_layer(-2)
	animation:refresh(spell:sprite())
	local do_once = true
	spell.update_func = function(self, dt)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
			if self:get_current_tile():x() == final_x then
				if do_once then
					do_once = false
					animation:set_state("ATTACK")
					animation:on_frame(4, function()
						local hitbox = Battle.Hitbox.new(self:get_team())
						hitbox:set_hit_props(props)
						local tile = self:get_tile()
						user:get_field():spawn(hitbox, tile)
						spell:shake_camera(4.0, 1.0)
						if tile:is_walkable() and tile:get_state() ~= TileState.Metal then
							if tile:get_state() ~= TileState.Cracked or #tile:find_entities(query) > 0 then
								tile:set_state(TileState.Cracked)
							elseif tile:get_state() == TileState.Cracked or #tile:find_entities(query) == 0 then
								tile:set_state(TileState.Broken)
							end
						end
					end)
					animation:on_complete(function()
						spell:erase()
					end)
				end
			else
				if #self:get_current_tile():find_entities(query) == 0 then
					local dest = self:get_tile(direction, 1)
					local ref = self
					self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, 
						function()
							ref.slide_started = true 
						end
					)
				else
					if do_once then
						do_once = false
						animation:set_state("ATTACK")
						animation:on_frame(4, function()
							local hitbox = Battle.Hitbox.new(self:get_team())
							hitbox:set_hit_props(props)
							local tile = self:get_tile()
							user:get_field():spawn(hitbox, tile)
							spell:shake_camera(4.0, 1.0)
							if tile:is_walkable() and tile:get_state() ~= TileState.Metal then
								if tile:get_state() ~= TileState.Cracked or #tile:find_entities(query) > 0 then
									tile:set_state(TileState.Cracked)
								elseif tile:get_state() == TileState.Cracked or #tile:find_entities(query) == 0 then
									tile:set_state(TileState.Broken)
								end
							end
						end)
						animation:on_complete(function()
							spell:erase()
						end)
					end
				end
			end
        end
    end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	-- Engine.play_audio(Engine.load_audio(_modpath.."forms/airshot.ogg", true), AudioPriority.High)
	return spell
end

function create_charged_attack(player)
    print("execute charged attack")
    return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end

function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level() * 1)
end
