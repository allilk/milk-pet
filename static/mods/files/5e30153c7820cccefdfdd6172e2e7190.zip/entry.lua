local DAMAGE = 100

local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"
local HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")
local BUSTER_TEXTURE = Engine.load_texture(_modpath .. "magBolt.png")
local AUDIO_SHOOT = Engine.load_audio(_modpath .. "Magbolt.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.magbolt")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "A", "B", "G", "M", "T" })

    local props = package:get_card_props()
    props.shortname = "MagBolt"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Shocks an enemy ahead."
    props.long_description = "Shocks an enemy ahead."
    props.can_boost = true
    props.card_class = CardClass.Standard
    props.limit = 3
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    local frame1 = { 1, 0.033 }
    local frame2 = { 1, 0.3 }
    action.frames = { frame1, frame1, frame1, frame2, frame1 }
    local frame_data = make_frame_data(action.frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(BUSTER_TEXTURE, true)
        buster:sprite():set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "magbolt.animation")
        buster_anim:set_state("DEFAULT")


        local attacking = false

        self:add_anim_action(1, function()
            user:toggle_counter(true)
            attacking = true
        end)

        local mag_spell = nil

        self:add_anim_action(3, function()
            if attacking then
                Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                magnet_pull(user)
                mag_spell = magnet_dmg(user, props.damage)
            end
        end)
        self:add_anim_action(5, function()
            user:toggle_counter(false)
            attacking = false
            if (not mag_spell:is_deleted()) then
                mag_spell:erase()
            end
        end)

    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

function magnet_pull(user)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())
    local tile = user:get_tile():get_tile(user:get_facing(), 1)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            0,
            Hit.Impact | Hit.Flinch | Hit.Drag,
            Element.None,
            user:get_context(),
            Drag.new(user:get_facing_away(), 6)
        )
    )
    -- no visible sprite for spell
    spell:set_facing(user:get_facing())
    spell.update_func = function(self, dt)
        if (spell:get_current_tile():is_edge()) then
            -- Spell will be erased once it reaches the end of the field.
            spell:erase()
            return
        end
        local next_tile = spell:get_current_tile():get_tile(user:get_facing(), 1)
        spell:teleport(next_tile)
        --- Attacks the entities this spell collides with.
        spell:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other)
        spell:erase()
    end
    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function magnet_dmg(user, damage)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())
    local tile = user:get_tile():get_tile(user:get_facing(), 1)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Stun,
            Element.Elec,
            user:get_context(),
            Drag.new())
    )
    -- no visible sprite for spell
    spell:set_facing(user:get_facing())
    spell.update_func = function(self, dt)
        spell:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other)
        create_hit_effect(spell:get_field(), spell:get_current_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "ELEC", HIT_SOUND)
        spell:erase()
    end
    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

--- create hit effect.
---@param field any #A field to spawn the effect on
---@param tile Tile tile to spawn effect on
---@param hit_texture any Texture hit effect. (Engine.load_texture)
---@param hit_anim_path any The animation file path
---@param hit_anim_state any The hit animation to play
---@param sfx any Audio # Audio object to play
---@return any returns the hit fx
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    -- Create artifact, artifacts do not have hitboxes and are used mostly for special effects
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    -- This will randomize the position of the effect a bit.
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end
