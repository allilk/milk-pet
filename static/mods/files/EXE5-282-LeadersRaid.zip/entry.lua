local DAMAGE = 200

local TWINLEADERS_TEXTURE = Engine.load_texture(_modpath.."twinleaders.png")
local TWINLEADERS_ANIMPATH = _modpath.."twinleaders.animation"
local SWORD_SLASH_TEXTURE = Engine.load_texture(_modpath.."sword_slash.png")
local SWORD_SLASH_ANIMPATH = _modpath.."sword_slash.animation"
local SWORD_SLASH_AUDIO = Engine.load_audio(_modpath.."sword_slash.ogg")
local SCREENDIVIDE_TEXTURE = Engine.load_texture(_modpath.."screendivide.png")
local SCREENDIVIDE_ANIMPATH = _modpath.."screendivide.animation"
local SCREENDIVIDE_AUDIO = Engine.load_audio(_modpath.."screendivide.ogg")
local AUDIO_SPAWN = Engine.load_audio(_modpath.."exe5-spawn.ogg")
local AUDIO_CHARGESHOT_CHARGING = Engine.load_audio(_modpath.."chargeshot-charging.ogg")
local AUDIO_CHARGESHOT_CHARGED = Engine.load_audio(_modpath.."chargeshot-charged.ogg")

local FLASH_TEXTURE = Engine.load_texture(_modpath.."flash.png")
local FLASH_ANIMPATH = _modpath.."flash.animation"

local AUDIO_DAMAGE1 = Engine.load_audio(_modpath.."hitsound1.ogg")
local AUDIO_DAMAGE2 = Engine.load_audio(_modpath.."hitsound2.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE5-282-LeadersRaid")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"L"})

    local props = package:get_card_props()
    props.shortname = "LeadRaid"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Blues & Colonel together!"
    props.long_description = "Leaders Blues and Colonel together!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 29
        local voiceline_number_B = math.random(17,28)
        local voiceline_number_C = math.random(18,29)

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        
        local self_tile = user:get_current_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local tile = nil
        local tile_notrg = nil
        local tile_notrg_Y1 = nil
        local tile_notrg_Y3 = nil
		if team == Team.Red then
			if direction == Direction.Right then
				tile = field:tile_at(1, Y)
                tile_notrg = field:tile_at(6, Y)
                tile_notrg_Y1 = field:tile_at(6, 1)
                tile_notrg_Y3 = field:tile_at(6, 3)
			else
				tile = field:tile_at(6, Y)
                tile_notrg = field:tile_at(1, Y)
                tile_notrg_Y1 = field:tile_at(1, 1)
                tile_notrg_Y3 = field:tile_at(1, 3)
			end
		else
			if direction == Direction.Left then
				tile = field:tile_at(6, Y)
                tile_notrg = field:tile_at(1, Y)
                tile_notrg_Y1 = field:tile_at(1, 1)
                tile_notrg_Y3 = field:tile_at(1, 3)
			else
				tile = field:tile_at(1, Y)
                tile_notrg = field:tile_at(6, Y)
                tile_notrg_Y1 = field:tile_at(6, 1)
                tile_notrg_Y3 = field:tile_at(6, 3)
			end
		end

		local tile_array = {}
		local tile_array_Y1 = {}
		local tile_array_Y2 = {}
		local tile_array_Y3 = {}
		local count = 1
		local max = 6
		local tile_front = nil
		local tile_front_Y1 = nil
		local tile_front_Y2 = nil
		local tile_front_Y3 = nil
		local check_front = false
		local check_front_Y1 = false
		local check_front_Y2 = false
		local check_front_Y3 = false
        local targeted = false
        local targeted_Y1 = false
        local targeted_Y2 = false
        local targeted_Y3 = false

        local check = function(ent)
            if not user:is_team(ent:get_team()) then
				return true
			end
        end
        local checkOBS = function(ent)
            return true
        end
        
        local cycle0_end = true
        local cycle1_end = false
        local cycle2_end = false
        local cycle3_end = false
		
        if cycle0_end then
		    for i = 1, 6, 1 do
                if i < 6 then
                    tile_front = tile:get_tile(direction, i)
                
		    	    check_front = tile_front and #tile_front:find_characters(check) > 0 and not tile_front:is_edge() and tile_front ~= nil

                    if check_front then
                        print("TARGET USER-Y: ("..tile_front:x()..";"..tile_front:y()..")")
                        targeted = true
                        table.insert(tile_array, tile_front)
                        cycle0_end = false
                        cycle1_end = true
		    	    	break
		    	    end
                else
                    cycle0_end = false
                    cycle1_end = true
                    break
                end
		    end
        end

        if cycle1_end then
		    for i = 1, 6, 1 do
                if i < 6 then
                    local tilef = field:tile_at(X, 1)
		    	    tile_front_Y1 = tilef:get_tile(direction, i)
                
		    	    check_front_Y1 = tile_front_Y1 and #tile_front_Y1:find_characters(check) > 0 and not tile_front_Y1:is_edge() and tile_front_Y1 ~= nil

                    if check_front_Y1 then
                        print("TARGET Y1: ("..tile_front_Y1:x()..";"..tile_front_Y1:y()..")")
                        targeted_Y1 = true
                        table.insert(tile_array_Y1, tile_front_Y1)
                        cycle1_end = false
                        cycle2_end = true
		    	    	break
		    	    end
                else
                    cycle1_end = false
                    cycle2_end = true
                    break
                end
		    end
        end
        
        if cycle2_end then
		    for i = 1, 6, 1 do
                if i < 6 then
                    local tilef = field:tile_at(X, 2)
		    	    tile_front_Y2 = tilef:get_tile(direction, i)
                
		    	    check_front_Y2 = tile_front_Y2 and #tile_front_Y2:find_characters(check) > 0 and not tile_front_Y2:is_edge() and tile_front_Y2 ~= nil

                    if check_front_Y2 then
                        print("TARGET Y2: ("..tile_front_Y2:x()..";"..tile_front_Y2:y()..")")
                        targeted_Y2 = true
                        table.insert(tile_array_Y2, tile_front_Y2)
                        cycle2_end = false
                        cycle3_end = true
		    	    	break
		    	    end
                else
                    cycle2_end = false
                    cycle3_end = true
                    break
                end
		    end
        end
        
        if cycle3_end then
		    for i = 1, 6, 1 do
                if i < 6 then
                    local tilef = field:tile_at(X, 3)
		    	    tile_front_Y3 = tilef:get_tile(direction, i)
                
		    	    check_front_Y3 = tile_front_Y3 and #tile_front_Y3:find_characters(check) > 0 and not tile_front_Y3:is_edge() and tile_front_Y3 ~= nil

                    if check_front_Y3 then
                        print("TARGET Y3: ("..tile_front_Y3:x()..";"..tile_front_Y3:y()..")")
                        targeted_Y3 = true
                        table.insert(tile_array_Y3, tile_front_Y3)
                        cycle3_end = false
		    	    	break
		    	    end
                else
                    cycle3_end = false
                    break
                end
		    end
        end

        self.twinleaders = nil
        self.blues       = nil
        self.tile        = user:get_current_tile()

        local ref = self

		local step1 = Battle.Step.new()

        local do_once = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                --print("READING")
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    --print("VOICE")
                    VOICEACTING = true
                end
            end

            if do_once then
                do_once = false
                ref.blues = Battle.Artifact.new()
                ref.blues:set_facing(direction)
                local blues_sprite = ref.blues:sprite()
		    	blues_sprite:set_texture(TWINLEADERS_TEXTURE, true)
		    	blues_sprite:set_layer(-10)
                local blues_anim = ref.blues:get_animation()
                blues_anim:load(TWINLEADERS_ANIMPATH)
                blues_anim:set_state("BLUES")
		    	blues_anim:refresh(blues_sprite)
                blues_anim:on_frame(1, function()
					print("Blues teleported to tile ("..ref.blues:get_tile():x()..";"..ref.blues:get_tile():y()..")")
                end)
                blues_anim:on_frame(4, function()
                    if VOICEACTING and not ref.tile:is_hole() then
                        Engine.play_audio(Engine.load_audio(_modpath.."voices/B"..voiceline_number_B..".ogg"), AudioPriority.High)
                    end
                end)
                blues_anim:on_frame(5, function()
                    Engine.play_audio(SWORD_SLASH_AUDIO, AudioPriority.High)
                    create_widesword(field, team, direction, user, props, ref.blues:get_tile(direction, 1))
                end)
                blues_anim:on_complete(function() ref.blues:erase() end)
                
                ref.twinleaders = Battle.Artifact.new()
                ref.twinleaders:set_facing(direction)
                local leaders_sprite = ref.twinleaders:sprite()
		    	leaders_sprite:set_texture(TWINLEADERS_TEXTURE, true)
		    	leaders_sprite:set_layer(-9)
                local leaders_anim = ref.twinleaders:get_animation()
                leaders_anim:load(TWINLEADERS_ANIMPATH)
                if not ref.tile:is_hole() then
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") is NOT a hole!")
                    leaders_anim:set_state("TWINLEADERS")
		    	    leaders_anim:refresh(leaders_sprite)
				else
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") IS a hole!")
                    leaders_anim:set_state("TWINLEADERS_HOLE")
		    	    leaders_anim:refresh(leaders_sprite)
				end
                leaders_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                    if VOICEACTING and not ref.tile:is_hole() then
                        print("Blues & Colonel: Let's go!")
                        Engine.play_audio(Engine.load_audio(_modpath.."voices/B0.ogg"), AudioPriority.High)
                        Engine.play_audio(Engine.load_audio(_modpath.."voices/C0.ogg"), AudioPriority.High)
                    end
                end)
                leaders_anim:on_frame(5, function()
                    if not ref.tile:is_hole() then
                        Engine.play_audio(AUDIO_CHARGESHOT_CHARGING, AudioPriority.High)
                    end
                end)
                leaders_anim:on_frame(16, function()
                    if not ref.tile:is_hole() then
                        Engine.play_audio(AUDIO_CHARGESHOT_CHARGED, AudioPriority.High)
                    end
                end)
                leaders_anim:on_frame(38, function()
                    if VOICEACTING then
                        Engine.play_audio(Engine.load_audio(_modpath.."voices/C"..voiceline_number_C..".ogg"), AudioPriority.High)
                    end
                    if     Y==1 then
                        if targeted_Y1 or targeted_Y2 then
                            local x1 = nil
                            local x2 = nil
                            if targeted_Y1 then
                                x1 = tile_array_Y1[1]:x()
                            else
                                if     direction == Direction.Right then
                                    x1 = 7
                                elseif direction == Direction.Left then
                                    x1 = 0
                                end
                            end
                            if targeted_Y2 then
                                x2 = tile_array_Y2[1]:x()
                            else
                                if     direction == Direction.Right then
                                    x2 = 7
                                elseif direction == Direction.Left then
                                    x2 = 0
                                end
                            end
                            local minX = math.min(x1, x2)
                            print("minX: "..minX)
                            local attack_tile = field:tile_at(minX, Y)
                            local ready = false
                            local spawnt = {}
                            local tfr = nil
                            local check = false
                            for i = 1, 6, 1 do

                                tfr = attack_tile:get_tile(Direction.reverse(direction), i)

                                check = tfr and #tfr:find_obstacles(checkOBS) <= 0 and not tfr:is_edge() and not tfr:is_hole() and tfr ~= nil
                            
                                if check then
                                    print("TILE: ("..tfr:x()..";"..tfr:y()..")")
                                    table.insert(spawnt, tfr)
                                    ready = true
                                    break
                                end
                            end
                            if ready then
                                field:spawn(ref.blues, spawnt[1])
                            end
                        else
                            local ready = false
                            local spawnt = {}
                            local tfr = nil
                            local check = false
                            for i = 1, 6, 1 do

                                tfr = tile_notrg_Y3:get_tile(Direction.reverse(direction), i)

                                check = tfr and #tfr:find_obstacles(checkOBS) <= 0 and not tfr:is_edge() and not tfr:is_hole() and tfr ~= nil
                            
                                if check then
                                    print("TILE: ("..tfr:x()..";"..tfr:y()..")")
                                    table.insert(spawnt, tfr)
                                    ready = true
                                    break
                                end
                            end
                            if ready then
                                field:spawn(ref.blues, spawnt[1])
                            end
                        end
                    elseif Y==2 then
                        local x1 = nil
                        local x2 = nil
                        local x3 = nil
                        if targeted_Y1 then
                            x1 = tile_array_Y1[1]:x()
                        else
                            if     direction == Direction.Right then
                                x1 = 7
                            elseif direction == Direction.Left then
                                x1 = 0
                            end
                        end
                        if targeted_Y2 then
                            x2 = tile_array_Y2[1]:x()
                        else
                            if     direction == Direction.Right then
                                x2 = 7
                            elseif direction == Direction.Left then
                                x2 = 0
                            end
                        end
                        if targeted_Y3 then
                            x3 = tile_array_Y3[1]:x()
                        else
                            if     direction == Direction.Right then
                                x3 = 7
                            elseif direction == Direction.Left then
                                x3 = 0
                            end
                        end
                        local minX = math.min(x1, x2, x3)
                        print("minX: "..minX)
                        local attack_tile = field:tile_at(minX, Y)
                        local ready = false
                        local spawnt = {}
                        local tfr = nil
                        local check = false
                        for i = 1, 6, 1 do
                            
                            tfr = attack_tile:get_tile(Direction.reverse(direction), i)
                            
                            check = tfr and #tfr:find_obstacles(checkOBS) <= 0 and not tfr:is_edge() and not tfr:is_hole() and tfr ~= nil
                            
                            if check then
                                print("TILE: ("..tfr:x()..";"..tfr:y()..")")
                                table.insert(spawnt, tfr)
                                ready = true
                                break
                            end
                        end
                        if ready then
                            field:spawn(ref.blues, spawnt[1])
                        end
                    elseif Y==3 then
                        if targeted_Y2 or targeted_Y3 then
                            local x2 = nil
                            local x3 = nil
                            if targeted_Y2 then
                                x2 = tile_array_Y2[1]:x()
                            else
                                if     direction == Direction.Right then
                                    x2 = 7
                                elseif direction == Direction.Left then
                                    x2 = 0
                                end
                            end
                            if targeted_Y3 then
                                x3 = tile_array_Y3[1]:x()
                            else
                                if     direction == Direction.Right then
                                    x3 = 7
                                elseif direction == Direction.Left then
                                    x3 = 0
                                end
                            end
                            local minX = math.min(x2, x3)
                            print("minX: "..minX)
                            local attack_tile = field:tile_at(minX, Y)
                            local ready = false
                            local spawnt = {}
                            local tfr = nil
                            local check = false
                            for i = 1, 6, 1 do

                                tfr = attack_tile:get_tile(Direction.reverse(direction), i)

                                check = tfr and #tfr:find_obstacles(checkOBS) <= 0 and not tfr:is_edge() and not tfr:is_hole() and tfr ~= nil
                            
                                if check then
                                    print("TILE: ("..tfr:x()..";"..tfr:y()..")")
                                    table.insert(spawnt, tfr)
                                    ready = true
                                    break
                                end
                            end
                            if ready then
                                field:spawn(ref.blues, spawnt[1])
                            end
                        else
                            local ready = false
                            local spawnt = {}
                            local tfr = nil
                            local check = false
                            for i = 1, 6, 1 do

                                tfr = tile_notrg_Y1:get_tile(Direction.reverse(direction), i)

                                check = tfr and #tfr:find_obstacles(checkOBS) <= 0 and not tfr:is_edge() and not tfr:is_hole() and tfr ~= nil
                            
                                if check then
                                    print("TILE: ("..tfr:x()..";"..tfr:y()..")")
                                    table.insert(spawnt, tfr)
                                    ready = true
                                    break
                                end
                            end
                            if ready then
                                field:spawn(ref.blues, spawnt[1])
                            end
                        end
                    end
                end)
                leaders_anim:on_frame(40, function()
                    Engine.play_audio(SCREENDIVIDE_AUDIO, AudioPriority.High)
                    create_effect(FLASH_TEXTURE, FLASH_ANIMPATH, "0", 0, 0, 9999, field, field:tile_at(0,0))
                    if targeted then
                        print("target ON")
                        if     Y==1 then
                            create_screendivide(field, team, direction, user, props, tile_array_Y1[1])
                        elseif Y==2 then
                            create_screendivide(field, team, direction, user, props, tile_array_Y2[1])
                        elseif Y==3 then
                            create_screendivide(field, team, direction, user, props, tile_array_Y3[1])
                        end
                    else
                        print("target OFF")
                        create_screendivide(field, team, direction, user, props, tile_notrg)
                    end
                end)
                leaders_anim:on_frame(45, function()
                    create_effect(FLASH_TEXTURE, FLASH_ANIMPATH, "0", 0, 0, 9999, field, field:tile_at(0,0))
                end)
                leaders_anim:on_frame(47, function()
                    create_effect(FLASH_TEXTURE, FLASH_ANIMPATH, "0", 0, 0, 9999, field, field:tile_at(0,0))
                end)
                leaders_anim:on_frame(48, function()
                    create_effect(FLASH_TEXTURE, FLASH_ANIMPATH, "0", 0, 0, 9999, field, field:tile_at(0,0))
                end)
		    	leaders_anim:on_complete(function()
		    		ref.twinleaders:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.twinleaders, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_screendivide(field, team, direction, user, props, tile)
    local fx = Battle.Artifact.new()
    fx:set_facing(direction)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-9)
    fx_sprite:set_texture(SCREENDIVIDE_TEXTURE, true)
    local fx_anim = fx:get_animation()
    fx_anim:load(SCREENDIVIDE_ANIMPATH)
    fx_anim:set_state("0")
    fx_anim:refresh(fx_sprite)
    fx_anim:on_frame(1, function()
        fx:shake_camera(25, 0.5)
        print("ScreenDivide attack tile: ("..tile:x()..";"..tile:y()..")")
        print("ScreenDivide attack tile: ("..tile:get_tile(Direction.UpLeft, 1):x()..";"..tile:get_tile(Direction.UpLeft, 1):y()..")")
        print("ScreenDivide attack tile: ("..tile:get_tile(Direction.UpRight, 1):x()..";"..tile:get_tile(Direction.UpRight, 1):y()..")")
        print("ScreenDivide attack tile: ("..tile:get_tile(Direction.DownLeft, 1):x()..";"..tile:get_tile(Direction.DownLeft, 1):y()..")")
        print("ScreenDivide attack tile: ("..tile:get_tile(Direction.DownRight, 1):x()..";"..tile:get_tile(Direction.DownRight, 1):y()..")")
        create_attack(user, props, team, field, tile, true)
        create_attack(user, props, team, field, tile:get_tile(Direction.UpLeft, 1), true)
        create_attack(user, props, team, field, tile:get_tile(Direction.UpRight, 1), true)
        create_attack(user, props, team, field, tile:get_tile(Direction.DownLeft, 1), true)
        create_attack(user, props, team, field, tile:get_tile(Direction.DownRight, 1), true)
    end)
    fx_anim:on_complete(function() fx:erase() end)
    field:spawn(fx, tile)

    return fx
end

function create_widesword(field, team, direction, user, props, tile)
    local fx = Battle.Artifact.new()
    fx:set_facing(direction)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-9)
    fx_sprite:set_texture(SWORD_SLASH_TEXTURE, true)
    local fx_anim = fx:get_animation()
    fx_anim:load(SWORD_SLASH_ANIMPATH)
    fx_anim:set_state("WIDE")
    fx_anim:refresh(fx_sprite)
    fx_anim:on_frame(1, function()
        print("WideSword attack tile: ("..tile:x()..";"..tile:y()..")")
        print("WideSword attack tile: ("..tile:get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.Up, 1):y()..")")
        print("WideSword attack tile: ("..tile:get_tile(Direction.Down, 1):x()..";"..tile:get_tile(Direction.Down, 1):y()..")")
        create_attack(user, props, team, field, tile, false)
        create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), false)
        create_attack(user, props, team, field, tile:get_tile(Direction.Down, 1), false)
    end)
    fx_anim:on_complete(function() fx:erase() end)
    field:spawn(fx, tile)

    return fx
end

function create_attack(user, props, team, field, tile, scnd)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self, other)
        if scnd then
            Engine.play_audio(AUDIO_DAMAGE1, AudioPriority.High)
        else
            Engine.play_audio(AUDIO_DAMAGE2, AudioPriority.High)
        end
    end

    field:spawn(spell, tile)

    --print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end