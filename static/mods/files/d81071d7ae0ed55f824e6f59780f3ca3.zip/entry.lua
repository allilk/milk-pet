local function get_character_id(folder)
    return "com.Dawn.FireID.SummonFireman." .. folder
end

local function define_character(folder)
    Engine.define_character(get_character_id(folder), _modpath..folder)
end

local modify, spawn_enemy, spawn_encounter

function package_init(block)
    define_character("FiremanBN1")

    block:declare_package_id("com.Dawn.FireID")
    block:set_name("FireID")
    block:set_description("Got a light?")
    block:set_color(Blocks.Red)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function spawn_enemy(player, folder, rank)
    local field = player:get_field()
    local team = player:get_team()
    local tile = player:get_tile(Direction.Up, 1)
    if not tile:is_walkable() or #tile:find_characters(function() return true end) ~= 0 then
        tile = nil
        for x = 1, 6, 1 do
            for y = 1, 3, 1 do

            end
        end
    end
    if tile ~= nil then
        local enemy = Battle.Character.from_package(get_character_id(folder), team, rank)
        field:spawn(enemy, tile)
    end
end

function spawn_encounter(player)    
    spawn_enemy(player, "FiremanBN1", Rank.V3)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)
    local cooldown = 1
    component.update_func = function()
        spawn_encounter(player)
        if cooldown <= 0 then
            local field = player:get_field()
            
			Engine.stream_music(_modpath.."music.mid")
            component:eject()
        else
            cooldown = cooldown - 1
        end
    end

    player:register_component(component)
end
