function package_init(package) 
    package:declare_package_id("com.claris.card.ElecPulse2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'A', 'E', 'J'})

    local props = package:get_card_props()
    props.shortname = "ElcPuls2"
    props.damage = 120
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Pull in foes w/ elec puls"
	props.limit = 3
end

function card_create_action(actor, props)
	local TEXTURE = Engine.load_texture(_modpath.."elecpulse.png")
	local FRAMES = make_frame_data({{1, 0.1833}})
	local audio = Engine.load_audio(_modpath.."sfx.ogg")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(FRAMES)
	action:set_lockout(make_animation_lockout())

    local pulse = create_pulse(actor, props, audio)
	action.animate_component = nil
	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		local buster_sprite = buster:sprite()
		buster_sprite:set_texture(TEXTURE, true)
		buster_sprite:set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."elecpulse.animation")
		buster_anim:set_state("WAIT")
		buster_anim:refresh(buster_sprite)
		buster_anim:on_complete(function()
			buster_anim:set_state("DISH")
			buster_anim:set_playback(Playback.Loop)
		end)

		local pulse_visual = buster_sprite:create_node()
		pulse_visual:set_texture(TEXTURE)
		pulse_visual:set_layer(-2)
		local pulse_anim = Engine.Animation.new(_modpath.."elecpulse.animation")
		pulse_anim:set_state("PULSE")
		pulse_anim:refresh(pulse_visual)
		pulse_anim:set_playback(Playback.Loop)
		self.animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
		self.animate_component.count = 0
		local ref = self
		self.animate_component.update_func = function(self, dt)
			self.count = self.count + dt
			if self.count >= 0.1833 then
				ref.animate_component = nil
				self:eject()
				return
			end
			pulse_anim:update(dt, pulse_visual)
		end
		user:register_component(self.animate_component)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(pulse, tile)
	end
	action.action_end_func = function(self)
		if self.animate_component ~= nil then self.animate_component:eject() end
	end
    return action
end

function create_pulse(user, props, audio)
    local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Drag | Hit.Pierce | Hit.Retangible, 
            props.element,
            user:get_context(),
            Drag.new(Direction.reverse(direction), 1)
        )
    )
	local tile, tile1, tile2, tile3
	local function define_tiles(spell, tile, tile1, tile2, tile3)
    	tile = spell:get_current_tile()
		tile1 = tile:get_tile(direction, 1)
		tile2 = tile1:get_tile(Direction.Up, 1)
		tile3 = tile1:get_tile(Direction.Down, 1)
		return tile, tile1, tile2, tile3
	end
	local field = user:get_field()
	local spell_time = 11 -- lifetime of the hitboxes in frames
	local attacking = true
	local start_delay = 1
	local delayed_loop
	local spawn_hitboxes = true
	local hitbox_1 = Battle.SharedHitbox.new(spell, 0.1833)
	hitbox_1:set_hit_props(spell:copy_hit_props())
	local hitbox_2 = Battle.SharedHitbox.new(spell, 0.1833)
	hitbox_2:set_hit_props(spell:copy_hit_props())
	local hitbox_3 = Battle.SharedHitbox.new(spell, 0.1833)
	hitbox_3:set_hit_props(spell:copy_hit_props())
    spell.update_func = function(self, dt)
		if start_delay then
			start_delay = start_delay - 1
			if start_delay < 0 then
				delayed_loop = true
				start_delay = nil
				tile, tile1, tile2, tile3 = define_tiles(spell, tile, tile1, tile2, tile3)
			end
		end
		if delayed_loop then
			if tile and attacking then
				tile:attack_entities(self)
				tile:highlight(Highlight.Solid)
			end
			if tile1 and attacking then
				tile1:highlight(Highlight.Solid)
			end
			if tile2 and attacking then
				tile2:highlight(Highlight.Solid)
			end
			if tile3 and attacking then
				tile3:highlight(Highlight.Solid)
			end
			if spawn_hitboxes then
				if tile1 then
					field:spawn(hitbox_1, tile1)
				end
				if tile2 then
					field:spawn(hitbox_2, tile2)
				end
				if tile3 then
					field:spawn(hitbox_3, tile3)
				end
				spawn_hitboxes = false
			end
			spell_time = spell_time - 1
			if spell_time <= 0 then
				self:delete()
			end
		end
    end
	local function turn_off_hitboxes(spell1)
		attacking = false
		if not spell1:is_deleted() then spell1:erase() end
	end
	spell.collision_func = function(self, other)
		turn_off_hitboxes(self)
	end
	spell.attack_func = function(self, other)
		turn_off_hitboxes(self)
	end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	Engine.play_audio(audio, AudioPriority.Low)
    return spell
end