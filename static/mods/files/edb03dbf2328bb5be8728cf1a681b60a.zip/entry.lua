nonce = function() end

local DAMAGE = 130
local TEXTURE = Engine.load_texture(_modpath.."spell_zapring.png")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster_zapring.png")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")
local AUDIO_power1 = Engine.load_audio(_modpath.."MagPullCastA.ogg")
local AUDIO_power2 = Engine.load_audio(_modpath.."SarynMolt.ogg")
local AUDIO_shotgun = Engine.load_audio(_modpath.."shotgun.ogg")
function package_init(package) 
    package:declare_package_id("com.DJ.Duality")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"D","H", "W"})

    local props = package:get_card_props()
    props.shortname = "Duality"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Pwr+ on grass or poison!"
    props.long_description = "Blaster powered up on grass and poison!"
    props.card_class = CardClass.Standard
    props.limit = 4
end

--[[
    1. megaman loads buster
    2. zapring flies out
--]]

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    local frame1 = {1, 0.109}
	local frame2 = {2, 0.1}--fires
	local frame3 = {3, 0.1}
    local frame4 = {4, 0.39}
	
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4})
    action:override_animation_frames(frame_sequence)
	
	action:set_lockout(make_animation_lockout())
   
    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
       

        --the fun stuff for the element boost!
        
        local cur_tile = user:get_current_tile()
        if cur_tile and cur_tile:get_state() == TileState.Grass then
            props.damage = props.damage+50
            cur_tile:set_state(TileState.Normal)
            Engine.play_audio(AUDIO_power1, AudioPriority.Highest)
            
            
        elseif cur_tile and cur_tile:get_state() == TileState.Poison then
            
            
            
            props.damage = props.damage+100
            
            cur_tile:set_state(TileState.Normal)
            Engine.play_audio(AUDIO_power2, AudioPriority.Highest)

		end
        
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."buster_zapring.animation")
		buster_anim:set_state("DEFAULT")
        
		
    
        self:add_anim_action(2, function() 
          local animation_state = "DEFAULT"
		  local cannonshot = create_zap(animation_state,user, props)
          print("Action frame 2")
		  local tile = user:get_tile(user:get_facing(), 1)
          
		  actor:get_field():spawn(cannonshot, tile)
          Engine.play_audio(AUDIO_shotgun, AudioPriority.Highest)
        end)
        self:add_anim_action(3, function()
           
        end)
        
    

    end
    return action
end

function create_zap(animation_state, user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(TEXTURE, true)
    spell:highlight_tile(Highlight.Solid)
	local direction = user:get_facing()
    spell.slide_started = false
	
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.Wood,
            user:get_context(),
            Drag.None
        )
    )
	
    local anim = spell:get_animation()
    anim:load(_modpath.."spell_zapring.animation")
    anim:set_state(animation_state)

    spell.update_func = function(self, dt) 

       


        self:get_current_tile():attack_entities(self)
        

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(2), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
       
        
    end
	
	spell.collision_func = function(self, other)
        self:erase()
        
	
	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
        
        return true
    end

	

    return spell
end
