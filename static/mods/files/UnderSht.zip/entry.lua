nonce = function() end
  
function package_init(package)
    package:declare_package_id("rune.legacy.undersht")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"H","J","N","R","W","*"})
 
    local props = package:get_card_props()
    props.shortname = "UnderSht"
    props.damage = 0-0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Lethal hit reduced to just 1HP!"
   
    AUDIO = Engine.load_audio(_modpath.."shine.ogg")
end


function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        actor:set_air_shoe(true)
        actor:set_color(Color.new(16,255,49,225))
        actor:set_color(Color.new(80,255,80,225))
        actor:set_color(Color.new(16,255,49,225))
        Engine.play_audio(AUDIO1, AudioPriority.Low)    
    end


    return action
end




function modify(player)
    local hit = false;
    local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
    local damage
    local component = Battle.Component.new(player, Lifetimes.Scene)
    local prevHP = player:get_health()


    undershirt.can_block_func = function(judge, attacker, defender)
        damage = attacker:copy_hit_props().damage

        if prevHP > 1 and (player:get_health() - damage) <= 0 then 
            player:mod_max_health(damage)
            hit = true
        end

        
    end

    component.update_func = function()
        if hit then 
            player:mod_max_health(damage*-1) 
            player:set_health(1)
            hit = false 

        end
        prevHP = player:get_health()

    end
        
    player:register_component(component)
    player:add_defense_rule(undershirt)
end
