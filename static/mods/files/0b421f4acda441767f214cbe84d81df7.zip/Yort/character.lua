-- Imports
---@type BattleHelper
local battle_helpers = include("battle_helpers.lua")
---@type FxHelper
local fx_helper = include("fx.lua")
-- Animations, Textures and Sounds
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local YOYO_SFX = Engine.load_audio(_folderpath .. "yoyothrow.ogg")
local HIT_SFX = Engine.load_audio(_folderpath .. "yoyohit.ogg")
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"


--possible states for character
local states = { IDLE = 1, MOVE = 2, WAIT = 3 }
local debug = false

function debug_print(str)
    if debug then
        print("[bugTank] " .. str)
    end
end

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = (character_info.damage)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.animation:set_state("IDLE")
    self.frame_counter = 0
    self.started = false
    self.idle_frames = 8
    --Select move direction
    self.move_direction = Direction.Up
    self.move_speed = character_info.move_speed
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self:set_air_shoe(true)
    self:set_float_shoe(true)
    self.reached_edge = false
    self.has_attacked_once = false
    self.guard = true

    --Yort yoyo node
    self.yoyoNode = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.yoyoNode:set_texture(Engine.load_texture(_folderpath .. "battle.greyscaled.png")) --Just set their texture...
    self.yoyoNode_anim = Engine.Animation.new(_folderpath .. "battle.animation") --And they have no get_animation, so we create one...
    self.yoyoNode:set_layer(1) --Set their layer, they're already a sprite...
    self.yoyoNode_anim:set_state("YOYO_IDLE")
    self.yoyoNode_anim:refresh(self.yoyoNode)
    self.yoyoNode:enable_parent_shader(true)

    self.back_shadow = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.back_shadow:set_texture(Engine.load_texture(_folderpath .. "battle.greyscaled.png")) --Just set their texture...
    self.back_shadow_anim = Engine.Animation.new(_folderpath .. "battle.animation") --And they have no get_animation, so we create one...
    self.back_shadow:set_layer(3) --Set their layer, they're already a sprite...
    self.back_shadow_anim:set_state("BACK_SHADOW")
    self.back_shadow_anim:refresh(self.back_shadow)
    self.back_shadow:enable_parent_shader(true)
    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.yoyoNode_anim:update(dt, ref.yoyoNode)
    end
    self:register_component(self.animate_component)
    -- actions for states


    ---state idle
    ---@param frame number
    self.action_idle = function(frame)
        if (frame == self.idle_frames) then
            ---choose move direction.
            self.animation:set_state("IDLE")
            self.yoyoNode_anim:set_state("YOYO_RETURN")
            self.animation:set_playback(Playback.Loop)
            self.set_state(states.MOVE)
        end
    end

    self.turn = function()
        self.move_direction = Direction.reverse(self.move_direction)

    end

    ---state move
    ---@param frame number
    self.action_move = function(frame)
        if (frame == 1) then
            local target_tile = getNextTile(self)
            if (not is_tile_free_for_movement(target_tile, self)) then
                self.turn()
                local turned_tile = self:get_tile(self.move_direction, 1)
                if (is_tile_free_for_movement(turned_tile, self)) then
                    --free to move to the turned tile, otherwise stuck.
                    self.set_state(states.MOVE)
                end
            end
            self:slide(target_tile, frames(self.move_speed), frames(0), ActionOrder.Immediate, nil)

        end
        if (frame >= self.move_speed and not self:is_sliding()) then
            local target_tile = getNextTile(self)
            if (self:get_tile():y() == target_tile:y()) then
                -- once yort is aligned with target, attack
                self.attack()
                self.set_state(states.WAIT)
            else
                self.set_state(states.MOVE)
            end
        end
    end

    ---state wait
    ---@param frame number
    self.action_wait = function(frame)
        if (frame == 40) then

            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_wait }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --- this runs once the battle is started
            self.current_direction = self:get_facing()
            self.started = true
            self.set_state(states.MOVE)
        else
            --- On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    self.attack = function()

        self.has_attacked_once = true
        self.yoyoNode_anim:set_state("YOYO_THROW")

        self.yoyoNode_anim:on_frame(3, function()
            self.guard = false
            self:toggle_counter(true)
        end)
        self.yoyoNode_anim:on_frame(5, function()
            debug_print("attacking")
            Engine.play_audio(YOYO_SFX, AudioPriority.High)
            self:toggle_counter(false)
            local yoyo_tile = self:get_current_tile():get_tile(self:get_facing(), 1)
            spawn_yoyo(self, self:get_team(), self:get_field(), yoyo_tile, self:get_facing(), self.damage,
                self:get_texture(), HIT_SFX, frames(7), 3)
            self.set_state(states.WAIT)
        end)
    end


    function Tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end

    function directiontostring(dir)

        if dir == Direction.Up then return "Up"
        elseif dir == Direction.Down then return "Down"
        end
    end

end

function getNextTile(entity)
    local target_character = find_target(entity)
    if not (target_character) then
        return entity:get_tile()
    end
    local target_character_tile = target_character:get_current_tile()
    local tile = entity:get_current_tile()
    local target_movement_tile = tile
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down, 1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up, 1)
    end
    return target_movement_tile;
end

--find a target character
function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        return
    end
    local target_character = target_list[1]
    return target_character
end

---Checks if the tile in 2 given directions is free and returns that direction
function get_free_direction(tile, direction1, direction2)
    if (not tile:get_tile(direction1, 1):is_edge()) then
        return direction1
    else return direction2

    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() or tile:is_reserved({ character:get_id(), character._reserver }) then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (ent:get_health() <= 0) then
            return false
        end
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

-- Yoyo Stuff

function hit_func(self, entity)
    fx_helper.create_hit_effect(entity:get_field(), entity:get_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "8", HIT_SFX)
end

function spawn_hitbox(team, field, tile, hitbox_props)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(hitbox_props)
    spell.update_func = function()
        tile:attack_entities(spell)
        spell:erase()
    end
    spell.attack_func = hit_func
    field:spawn(spell, tile)
end

function spawn_yoyo(owner, team, field, tile, direction, damage, texture, sfx, speed, hits)
    local spawn_next
    spawn_next = function()
        local spell = Battle.Obstacle.new(team)
        spell:set_health(10)
        spell.max_move_count = 3
        spell.move_count = spell.max_move_count
        spell.waiting = false
        spell.returning = false
        spell.hits = 6
        local hit_frame = 3
        spell:set_facing(direction)
        spell:set_move_direction(direction)
        spell:highlight_tile(Highlight.None)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact | Hit.Flinch, Element.Sword, owner:get_context(), Drag.None))

        -- YOYO DEFENSE
        spell.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
        local defense_texture = Engine.load_texture(_folderpath .. "guard_hit.png")
        local defense_animation = _folderpath .. "guard_hit.animation"
        local defense_audio = Engine.load_audio(_folderpath .. "tink.ogg", true)
        spell.defense_rule.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                --cant block breaking hits
                return
            end
            judge:block_impact()
            judge:block_damage()
            local artifact = Battle.Spell.new(spell:get_team())
            artifact:set_texture(defense_texture)
            local anim = artifact:get_animation()
            anim:load(defense_animation)
            anim:set_state("DEFAULT")
            anim:refresh(artifact:sprite())
            anim:on_complete(function()
                artifact:erase()
            end)
            spell:get_field():spawn(artifact, spell:get_tile())
            Engine.play_audio(defense_audio, AudioPriority.High)
        end
        spell:add_defense_rule(spell.defense_rule)

        --#end yoyo defense
        local sprite = spell:sprite()
        sprite:set_texture(texture)
        spell:set_palette(owner:get_current_palette())
        local animation = spell:get_animation()
        animation:load(CHARACTER_ANIMATION)
        animation:set_state("YOYO")
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)

        spell.can_move_to_func = function(tile)
            return true
        end

        spell.attack_func = hit_func

        spell.delete_func = function(self)
            local fx = Battle.Explosion.new(1, 1.0)
            self:get_field():spawn(fx, self:get_current_tile())
            self:erase()
        end

        spell.update_func = function()
            if (spell:get_current_tile():get_team() == spell:get_team()) then
                spell:share_tile(true)
            else
                spell:share_tile(false)
            end
            if not spell.waiting then
                -- yoyo hits 3 times when on the target tile where it waits
                -- otherwise attack the tile it is on
                spell:get_current_tile():attack_entities(spell)
            end

            if not spell:is_sliding() then
                spell.move_count = spell.move_count - 1

                if spell.move_count == 0 then
                    if spell.returning then
                        spell:erase()
                    else
                        if not spell.waiting then
                            spell.waiting = true
                            animation:on_complete(
                                function()
                                    if (spell.hits == hit_frame) then
                                        spawn_hitbox(team, field, spell:get_current_tile(), spell:copy_hit_props())
                                    end
                                    spell.hits = spell.hits - 1
                                    if spell.hits == 0 then
                                        spawn_hitbox(team, field, spell:get_current_tile(), spell:copy_hit_props())
                                        spell.returning = true
                                        spell.waiting = false
                                        spell.move_count = spell.max_move_count
                                        spell:set_move_direction(spell:get_facing_away())
                                    end
                                end
                            )

                            return
                        end
                    end
                end

                if not spell.waiting then
                    spell:slide(
                        spell:get_tile(spell:get_move_direction(), 1),
                        speed,
                        frames(0),
                        ActionOrder.Immediate,
                        nonce
                    )
                end
            end
        end

        field:spawn(spell, tile)

        spell:slide(spell:get_tile(spell:get_move_direction(), 1), speed, frames(0), ActionOrder.Immediate, nonce)

        return spell:get_id()
    end

    return spawn_next()
end

return package_init
