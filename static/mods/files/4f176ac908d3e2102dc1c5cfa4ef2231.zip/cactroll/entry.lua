local shared_package_init = include("../cactikil_shared/entry.lua")

function package_init(character)
  shared_package_init(character)

  if character:get_rank() == Rank.EX then
    character:set_name("Cactrl")
    character:set_health(190)
    character._damage = 100
    character:set_palette(Engine.load_texture(_modpath.."cactrollEX.palette.png"))
  else
    character:set_name("Cactroll")
    character:set_health(150)
    character._damage = 70
    character:set_palette(Engine.load_texture(_modpath.."cactroll.palette.png"))
  end
end
