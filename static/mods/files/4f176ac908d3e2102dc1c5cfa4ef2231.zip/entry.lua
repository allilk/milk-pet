local function get_character_id(folder)
    return "com.discord.Konstinople#7692.block.Encounter.blue.enemy." .. folder
end

local function define_character(folder)
    Engine.define_character(get_character_id(folder), _modpath..folder)
end

local modify, spawn_enemy, spawn_encounter

function package_init(block)
    define_character("powie")
    define_character("powie2")
    define_character("powie3")
    define_character("cactikil")
    define_character("cactroll")
    define_character("cacter")
    define_character("mettaur")

    block:declare_package_id("com.discord.Konstinople#7692.block.Friends.red")
    block:set_name("Friends")
    block:set_description("Spawns friends!")
    block:set_color(Blocks.Red)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 0, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function spawn_enemy(player, folder, rank, x, y)
    local field = player:get_field()
    local team = player:get_team()

    if player:get_facing() == Direction.Left then
        print("[Encounter NCP] need to flip enemy spawn")
        x = field:width() - x + 1
    end

    local tile = field:tile_at(x, y)

    if not tile:is_walkable() or #tile:find_characters(function() return true end) ~= 0 then
        print("[Encounter NCP] could not spawn enemy at ("..x..", "..y..")")
        return
    end

    local enemy = Battle.Character.from_package(get_character_id(folder), team, rank)
    field:spawn(enemy, tile)
end

function spawn_encounter(player)
    local encounter_index = math.random(5)
    if encounter_index == 1 then
        spawn_enemy(player, "cacter", Rank.EX, 1, 1)
        spawn_enemy(player, "powie2", Rank.EX, 1, 3)
    elseif encounter_index == 2 then
        spawn_enemy(player, "cacter", Rank.EX, 1, 1)
        spawn_enemy(player, "powie2", Rank.EX, 1, 3)
        spawn_enemy(player, "mettaur", Rank.V1, 2, 3)
    elseif encounter_index == 3 then
        spawn_enemy(player, "powie2", Rank.EX, 1, 1)
        spawn_enemy(player, "powie3", Rank.EX, 2, 3)
    elseif encounter_index == 4 then
        spawn_enemy(player, "cacter", Rank.EX, 1, 1)
        spawn_enemy(player, "powie2", Rank.EX, 2, 1)
        spawn_enemy(player, "cacter", Rank.EX, 1, 3)
        spawn_enemy(player, "powie2", Rank.EX, 2, 3)
    else
        spawn_enemy(player, "cacter", Rank.EX, 2, 1)
        spawn_enemy(player, "cacter", Rank.EX, 3, 2)
        spawn_enemy(player, "powie3", Rank.EX, 1, 3)
    end
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    component.update_func = function()
        spawn_encounter(player)
        component:eject()
    end

    player:register_component(component)
end
