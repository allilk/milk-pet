local DAMAGE = 100

local attack_sprite = Engine.load_texture(_modpath .. "snowflake.png")
local attack_anim = _modpath .. "snowflake.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"
local HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")
local BUSTER_TEXTURE = Engine.load_texture(_modpath .. "penguin.png")

local AUDIO_SHOOT = Engine.load_audio(_modpath .. "icewave.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.icewave")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "A", "C", "E", "I", "W" })

    local props = package:get_card_props()
    props.shortname = "IceWave"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Creates a 2sq wave"
    props.long_description = "Creates a freezing 2 tile wave!"
    props.can_boost = true
    props.card_class = CardClass.Standard
    props.limit = 3
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    local frame1 = { 1, 0.033 }
    local frame2 = { 1, 0.305 }
    action.frames = { frame1, frame1, frame1, frame2 }
    local frame_data = make_frame_data(action.frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(BUSTER_TEXTURE, true)
        buster:sprite():set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "penguin.animation")
        buster_anim:set_state("DEFAULT")


        local attacking = false

        self:add_anim_action(1, function()
            user:toggle_counter(true)
            attacking = true
        end)



        self:add_anim_action(3, function()
            if attacking then
                Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                create_icewave(user, props.damage, 32, user:get_facing())
            end
        end)
        self:add_anim_action(4, function()
            user:toggle_counter(false)
            attacking = false
        end)

    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

---@param user Entity The user summoning a tornado
---@param damage number The amount of damage the tornado will do
---@param speed number The number of frames it takes the tornado to travel 1 tile.
---@param direction any The direction the
function create_icewave(user, damage, speed, direction)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())
    local tile = user:get_tile():get_tile(user:get_facing(), 1)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Freeze,
            Element.Aqua,
            user:get_context(),
            Drag.new()
        )
    )
    -- Setup sprite of the spell
    local sprite = spell:sprite()
    sprite:set_texture(attack_sprite)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(attack_anim)
    spell.current_tile = tile
    spell.base_tile = tile
    spell.offsetDirection = Direction.None
    spell:set_facing(user:get_facing())

    local chosen_y = user:get_tile():y()
    --randomize if middle.
    if (chosen_y == 2) then
        if (math.random(1, 2) == 1) then
            chosen_y = 1
        else
            chosen_y = 3
        end
    end
    local wave_anim = ""
    if (chosen_y == 1) then
        spell.wave_state = "DOWN"
        wave_anim = "WAVE_START_DOWN"
    elseif (chosen_y == 3) then
        spell.wave_state = "DOWN"
        wave_anim = "WAVE_START_UP"
    end
    do_wave(spell, anim, wave_anim)

    spell.horizontal_speed = 4
    if (user:get_facing() == Direction.Left) then

        spell.horizontal_speed = -4
    end

    anim:refresh(sprite)


    spell.update_func = function(self, dt)
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        spell:set_offset(spell:get_offset().x + spell.horizontal_speed, 0)
        local x_offset = math.abs(spell:get_offset().x)
        --tilewidth=80
        local tile_offset = math.floor(x_offset / 80)
        spell.current_tile = spell.base_tile:get_tile(direction, tile_offset)

        if (spell.current_tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            spell:erase()
            return
        end
        --- Attacks the entities this spell collides with.
        spell.current_tile:get_tile(spell.offsetDirection, 1):attack_entities(self)
        spell.current_tile:get_tile(spell.offsetDirection, 1):highlight(Highlight.Solid)
    end

    spell.attack_func = function(self, other)
        -- Erases the spell once it hits something
        create_hit_effect(spell:get_field(), spell.current_tile, HIT_TEXTURE, HIT_ANIM_PATH, "AQUA", HIT_SOUND)
        spell:erase()
    end

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

--- create hit effect.
---@param field any #A field to spawn the effect on
---@param tile Tile tile to spawn effect on
---@param hit_texture any Texture hit effect. (Engine.load_texture)
---@param hit_anim_path any The animation file path
---@param hit_anim_state any The hit animation to play
---@param sfx any Audio # Audio object to play
---@return any returns the hit fx
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    -- Create artifact, artifacts do not have hitboxes and are used mostly for special effects
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    -- This will randomize the position of the effect a bit.
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end

function do_wave(spell, anim, wave_anim)
    if (spell.wave_state == "DOWN") then
        anim:set_state(wave_anim)
        spell.wave_state = "DOWN"
        anim:on_frame(10, function()
            if (wave_anim == "WAVE_START_UP") then
                spell.offsetDirection = Direction.Up
            else
                spell.offsetDirection = Direction.Down
            end
        end)
        anim:on_complete(function()
            --reverse
            spell.wave_state = "UP"
            do_wave(spell, anim, wave_anim)
        end)
    else
        anim:set_state(wave_anim)
        anim:set_playback(Playback.Reverse)
        spell.wave_state = "UP"
        anim:on_frame(10, function()
            spell.offsetDirection = Direction.None
        end)
        anim:on_complete(function()
            --reverse
            spell.wave_state = "DOWN"
            do_wave(spell, anim, wave_anim)
        end)
    end
end
