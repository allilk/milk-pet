function package_init(package)
    package:declare_package_id("com.discord.KorokoMystia.player.VideoMan")
    package:set_special_description("You can't do this with a DVD!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."ow.animation")
    package:set_overworld_texture_path(_folderpath.."ow.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
end

function player_init(player)
    player:set_name("VideoMan")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(74.0)

    local base_texture = Engine.load_texture(_folderpath.."battle.png")
    local base_animation_path = _folderpath.."battle.animation"
    local base_charge_color = Color.new(57, 198, 243, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, 0)
	
	

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end
	
	player.battle_start_func = function()
    player:set_air_shoe(true)
	player:set_float_shoe(true)
	end

    
end
