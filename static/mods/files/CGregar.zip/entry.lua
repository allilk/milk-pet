local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package)
    package:declare_package_id("CGregar")
    package:set_special_description("Not quite Gregar...?")
    package:set_speed(1.0)
    package:set_attack(2)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."overworld.animation")
    package:set_overworld_texture_path(_folderpath.."overworld.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
end

function player_init(player)
    player:set_name("CGregar")
    player:set_health(1500)
    player:set_element(Element.None)
    player:set_height(38.0)

    local base_texture = Engine.load_texture(_folderpath.."Gregar_atlus.png")
    local base_animation_path = _folderpath.."Gregar_atlus.animation"
    local base_charge_color = Color.new(100, 0, 0, 50)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    local buster_cooldown = 5
    local current_buster_cooldown = 0
    local frame1 = {1, 0.03}
    local frame2 = {2, 0.03}
    local frames = make_frame_data({frame1, frame2})
    
    local has_super_armor = false

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end
    
    player.update_func = function(self, dt)
        if player:input_has(Input.Held.Special) and player:get_animation():get_state() == "PLAYER_IDLE" then
            if current_buster_cooldown <= 0 then
                local action2 = Battle.Buster.new(player, true, player:get_attack_level())
                action2:override_animation_frames(frames)
                action2:set_lockout(make_animation_lockout())
                player:card_action_event(action2, ActionOrder.Voluntary)
                current_buster_cooldown = buster_cooldown
            else
                current_buster_cooldown = current_buster_cooldown - 1
            end
        else
            current_buster_cooldown = 0
        end
    end

    player.charged_attack_func = function(user)
        DAMAGE = user:get_max_health() - user:get_health()
            if user:get_health() > 1499 then
	            DAMAGE = user:get_attack_level() * 10
            end
            if user:get_health() < 1500 and user:get_health() > 999 then
	            DAMAGE = (user:get_attack_level() * 10) + 50
            end
            if user:get_health() < 1000 and user:get_health() > 499 then
	        DAMAGE = (user:get_attack_level() * 10) + 100
            end
            if user:get_health() < 500 and user:get_health() > 0 then
	        DAMAGE = (user:get_attack_level() *10) + 150
            end     
        local desired_tile = player:get_tile(player:get_facing(), 2)
        local original_tile = player:get_tile()
        local is_occupied = function(query)
            return query and not query:is_deleted() and Battle.Character.from(query) ~= nil or query and not query:is_deleted() and Battle.Obstacle.from(query) ~= nil
        end
        if desired_tile and not desired_tile:is_reserved({player:get_id()}) and #desired_tile:find_entities(is_occupied) == 0 then
            local action = Battle.CardAction.new(player, "PLAYER_CLAW")
            action.can_move_to_func = function(tile)
                return true
            end
            action:set_lockout(make_animation_lockout())
            local props = HitProps.new(
                DAMAGE,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Sword,
                player:get_context(),
                Drag.None
            )
            action.action_end_func = function(self)
                desired_tile:remove_entity_by_id(player:get_id())
                original_tile:remove_entity_by_id(player:get_id())
                original_tile:add_entity(player)
            end
            action.execute_func = function(self, user)
                desired_tile:add_entity(player)
                self:add_anim_action(3,	function()
                    local sword = create_slash(user, props)
                    local tile = user:get_tile(user:get_facing(), 1)
                    local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
                    sharebox1:set_hit_props(sword:copy_hit_props())
                    local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
                    sharebox2:set_hit_props(sword:copy_hit_props())
                    player:get_field():spawn(sharebox1, tile:get_tile(Direction.Up, 1))
                    player:get_field():spawn(sword, tile)
                    player:get_field():spawn(sharebox2, tile:get_tile(Direction.Down, 1))
                    local fx = Battle.Artifact.new()
                    fx:set_facing(sword:get_facing())
                    local anim = fx:get_animation()
                    fx:set_texture(Engine.load_texture(_modpath.."spell_sword_slashes.png"), true)
                    anim:load(_modpath.."spell_sword_slashes.animation")
                    anim:set_state("WIDE")
                    anim:on_complete(function()
                        fx:erase()
                        
                        sword:erase()
                    end)
                    player:get_field():spawn(fx, tile)
                end)
            end
		    return action
        else
            return Battle.CardAction.new(player, "PLAYER_MOVE")
        end
    end
end

local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(props)
	spell.update_func = function(self, dt)
		if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
			self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
		end
		if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
			self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
		end
		self:get_tile():attack_entities(self)

	end
	spell.can_move_to_func = function(tile)
		return true
	end
    spell.attack_func = function()
        local gain = math.floor(user:get_max_health()*0.01)
        user:set_health(user:get_health() + gain)
    end
	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end