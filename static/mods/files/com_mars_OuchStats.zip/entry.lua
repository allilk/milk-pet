function package_init(block)
    block:declare_package_id("com.mars.OuchStats")
    block:set_name("OuchStats")
    --block:as_program()
    block:set_description("Print hitprops when hit")
    block:set_color(Blocks.Red)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

local status_names = {
    {Hit.Impact, "Impact"},
    {Hit.Flinch, "Flinch"},
    {Hit.Flash, "Flash"},
    {Hit.Pierce, "Pierce"},
    {Hit.Breaking, "Breaking"},
    {Hit.Stun, "Stun"},
    {Hit.Freeze, "Freeze"},
    {Hit.Bubble, "Bubble"},
    {Hit.Root, "Root"},
    {Hit.Shake, "Shake"},
    {Hit.Drag, "Drag"},
}

local elem_names = {
    {Element.Fire, "Fire"},
    {Element.Aqua, "Aqua"},
    {Element.Elec, "Elec"},
    {Element.Wood, "Wood"},
    {Element.Sword, "Sword"},
    {Element.Wind, "Wind"},
    {Element.Cursor, "Cursor"},
    {Element.Summon, "Summon"},
    {Element.Plus, "Plus"},
    {Element.Break, "Break"},
}

function modify(player) 
    local ouchstats = Battle.DefenseRule.new(420, DefenseOrder.CollisionOnly)
	ouchstats.filter_statuses_func = function(deets)
        local print_flags =  tostring(deets.damage)
        for ii=1,#elem_names do
            if deets.element == elem_names[ii][1] then
                print_flags = print_flags .. " " .. elem_names[ii][2]
            end
        end
        print_flags = print_flags .. " DMG"
        for ii=1,#status_names do
            if deets.flags & status_names[ii][1] == status_names[ii][1] then
                print_flags = print_flags .. " | " .. status_names[ii][2]
            end
        end
        print(print_flags)
	   return deets
	end
	player:add_defense_rule(ouchstats)
end