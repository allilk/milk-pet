--This is originally a mod by SusThor. It was then minorly altered by GimmeChips.
--I saw the lack of major edits and took it upon myself to make a more serious Shooting Star Rockman mod.

function package_init(package)
    package:declare_package_id("com.TransCode003.Megaman.OnTheAir")
    package:set_special_description("Transcode 003! MegaMan, On The Air!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
  player:set_name("Geo Stelar")
  player:set_health(1000)
  player:set_element(Element.None)
  player:set_height(48.0)

  local base_texture = Engine.load_texture(_modpath.."battle.png")
  local base_animation_path = _modpath.."battle.animation"
  local base_charge_color = Color.new(57, 198, 243, 255)

  local RapidBuster = include("chargedbusters/RapidBuster/entry.lua")
  local CorvusFlame = include("chargedbusters/corvus/entry.lua")
  local CancerClaw = include("chargedbusters/cancer/entry.lua")
  local GeminiSlash = include("chargedbusters/gemini/entry.lua")
  local RyuuseiGuard = include("chargedbusters/guard/guard.lua")
  local MuBlade = include("chargedbusters/mublade/entry.lua")
  local charged_texture = Engine.load_texture(_folderpath.."custom_charge.png")

  player:set_animation(base_animation_path)
  player:set_texture(base_texture, true)
  player:set_fully_charged_color(base_charge_color)
  player:set_charge_position(0, -20)

  local current_form = "None"
  local is_charged = false
  local current_charge_time = 0
  local function get_charge_time()
    local level = player:get_charge_level()
    if level == 5 then return 120
    elseif level == 4 then return 130
    elseif level == 3 then return 140
    elseif level == 2 then return 150
    else return 160 end
  end

  local Corvus = player:create_form()
  Corvus:set_mugshot_texture_path(_modpath.."forms/Corvus_Entry.png")

  Corvus.charged_attack_func = function()
    local props = HitProps.new(
      (player:get_attack_level() * 5) + 55,
      Hit.Impact | Hit.Flinch | Hit.Root,
      Element.Fire,
      nil,
      Drag.None
    )
    return CorvusFlame.card_create_action(player, props)
  end

  Corvus.on_activate_func = function(self, player)
    current_form = "Corvus"
    player:set_animation(_modpath.."forms/Corvus.animation")
    player:set_texture(Engine.load_texture(_modpath.."forms/Corvus.png"), true)
    player:set_fully_charged_color(Color.new(243, 57, 198, 255))
    player:set_element(Element.Fire)
  end

  Corvus.on_deactivate_func = function(self, player)
    current_form = "None"
    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_element(Element.None)
  end

  local Gemini = player:create_form()
  Gemini:set_mugshot_texture_path(_modpath.."forms/Gemini_Entry.png")
  Gemini.on_activate_func = function(self, player)
    current_form = "Gemini"
    player:set_animation(_modpath.."forms/Gemini.animation")
    player:set_texture(Engine.load_texture(_modpath.."forms/Gemini.png"), true)
    player:set_fully_charged_color(Color.new(243, 57, 198, 255))
    player:set_element(Element.Elec)
  end

  Gemini.charged_attack_func = function()
    local props = HitProps.new(
      (player:get_attack_level()*10) + 10,
      Hit.Impact | Hit.Flinch | Hit.Stun,
      Element.Elec,
      nil,
      Drag.None
    )
    return GeminiSlash.card_create_action(player, props)
  end

  Gemini.on_deactivate_func = function(self, player)
    current_form = "None"
    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_element(Element.None)
  end

  local Rogue = player:create_form()
  Rogue:set_mugshot_texture_path(_modpath.."forms/Rogue_Entry.png")
  
  Rogue.on_activate_func = function(self, player)
    current_form = "Rogue"
    player:set_animation(_modpath.."forms/Rogue.animation")
    player:set_texture(Engine.load_texture(_modpath.."forms/Rogue.png"), true)
    player:set_fully_charged_color(Color.new(243, 57, 198, 255))
    player:set_element(Element.Sword)
  end

  Rogue.charged_attack_func = function()
    local DAMAGE = player:get_max_health() - player:get_health()
    if DAMAGE > 200 then DAMAGE = 200 end
    local props = HitProps.new(
      DAMAGE,
      Hit.Impact | Hit.Flinch | Hit.Flash,
      Element.Sword,
      nil,
      Drag.None
    )
    return MuBlade.card_create_action(player, props)
  end
  
    Rogue.on_deactivate_func = function(self, player)
      current_form = "None"
      player:set_animation(base_animation_path)
      player:set_texture(base_texture, true)
      player:set_fully_charged_color(base_charge_color)
      player:set_element(Element.None)
    end

    local Cancer = player:create_form()
    Cancer:set_mugshot_texture_path(_modpath.."forms/Cancer_Entry.png")
  
    Cancer.on_activate_func = function(self, player)
      current_form = "Cancer"
      player:set_animation(_modpath.."forms/Cancer.animation")
      player:set_texture(Engine.load_texture(_modpath.."forms/Cancer.png"), true)
      player:set_fully_charged_color(Color.new(243, 57, 198, 255))
      player:set_element(Element.Aqua)
    end
  
    Cancer.charged_attack_func = function()
      local props = HitProps.new(
        player:get_attack_level() + 5,
        Hit.Impact | Hit.Flinch | Hit.Breaking,
        Element.Aqua,
        nil,
        Drag.None
      )
      return CancerClaw.card_create_action(player, props)
    end

    Cancer.on_deactivate_func = function(self, player)
      current_form = "None"
      player:set_animation(base_animation_path)
      player:set_texture(base_texture, true)
      player:set_fully_charged_color(base_charge_color)
      player:set_element(Element.None)
    end
  
    local Taurus = player:create_form()
    Taurus:set_mugshot_texture_path(_modpath.."forms/Taurus_Entry.png")

    Taurus.on_activate_func = function(self, player)
      current_form = "Taurus"
      player:set_animation(_modpath.."forms/Taurus.animation")
      player:set_texture(Engine.load_texture(_modpath.."forms/Taurus.png"), true)
      player:set_fully_charged_color(Color.new(243, 57, 198, 255))
      player:set_element(Element.Fire)
    end

    Taurus.on_deactivate_func = function(self, player)
      current_form = "None"
      player:set_animation(base_animation_path)
      player:set_texture(base_texture, true)
      player:set_fully_charged_color(base_charge_color)
		  player:set_element(Element.None)
    end

    player.normal_attack_func = function()
    end

    player.charged_attack_func = function()
      --Nested if/else statement for returning the proper charge attack.
      --Gemini to Gemini, Corvus to Corvus, etc.
      --No Noise and Taurus both return a Buster action.
      if current_form == "Gemini" then return Gemini.charged_attack_func()
      elseif current_form == "Corvus" then return Corvus.charged_attack_func()
      elseif current_form == "Cancer" then return Cancer.charged_attack_func()
      elseif current_form == "Rogue" then return Rogue.charged_attack_func() end
      return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end
    
    local rogue_tile = nil
    local rogue_special_used = false
    local player_anim = player:get_animation()
    local desired_charge_start = math.floor(get_charge_time() / 4)
    local desired_charge_finish = get_charge_time()
    local sound_first = true
    local sound_second = true
    
    local function reset_charge_variables()
      current_charge_time = 0
      is_charged = false
      sound_first = true
      sound_second = true
      player.charge:hide()
    end
    
    player.special_attack_func = function()
      reset_charge_variables()
      return RyuuseiGuard.card_create_action(player)
    end

    player.is_rapid_buster = false
    player.rapid_queue_time = 5
    player.update_func = function(self, dt)
        if player.is_rapid_buster then 
            player.rapid_queue_time = player.rapid_queue_time - 1
        end
      if player_anim:get_state() ~= "PLAYER_IDLE" and not player:is_moving() then
        reset_charge_variables()
      end
      --Nesting bullshit.
      --This reads: if we have used Rogue's special, and the stored tile is not our current tile, then mark the special as unused so we can use it again.
      if rogue_special_used then if rogue_tile ~= player:get_tile() then rogue_special_used = false end end
        if not player:input_has(Input.Held.Use) and (player:input_has(Input.Released.Shoot) or not player:input_has(Input.Held.Shoot)) then
            if player.charge then
                current_charge_time = current_charge_time + 1
                if current_charge_time >= desired_charge_finish and sound_second then
                    sound_second = false
                    Engine.play_audio(AudioType.BusterCharged, AudioPriority.High)
                    is_charged = true
                    player.charge:show()
                    player.charge_animation:set_state("CHARGED")
                    player.charge_animation:set_playback(Playback.Loop)
                elseif current_charge_time >= desired_charge_start and sound_first then
                    sound_first = false
                    Engine.play_audio(AudioType.BusterCharging, AudioPriority.High)
                    player.charge:show()
                    player.charge_animation:set_state("CHARGING")
                    player.charge_animation:set_playback(Playback.Loop)
                end
            end
            
            if player.rapid_queue_time < 1 or not player.is_rapid_buster then 
                player.is_rapid_buster = false
                player.rapid_queue_time = 5
            end
        end
        if not player:input_has(Input.Held.Use) then
            if is_charged and player:input_has(Input.Pressed.Shoot) and (player:is_moving() or player_anim:get_state() == "PLAYER_IDLE") then
                current_charge_time = 0
                local action = player.charged_attack_func()
                player:card_action_event(action, ActionOrder.Immediate)
                reset_charge_variables()
                player.charge:hide()
            elseif not is_charged and not player.is_rapid_buster and player:input_has(Input.Held.Shoot) and not player:is_moving() and player_anim:get_state() == "PLAYER_IDLE" then
                reset_charge_variables()
                player.is_rapid_buster = true
                local action = RapidBuster.card_create_action(player)
                player:card_action_event(action, ActionOrder.Immediate)
            end
        end
    end
    player.battle_start_func = function()
        player.charge = player:create_node()
        player.charge:hide()
        player.charge:set_layer(-3)
        player.charge:set_texture(charged_texture)
        player.charge_animation = Engine.Animation.new(_folderpath.."custom_charge.animation")
        player.charge_animation:set_state("CHARGING")
        player.charge_animation:refresh(player.charge)
        player.charge_animation:set_playback(Playback.Loop)
    
        player.charge_animate_component = Battle.Component.new(player, Lifetimes.Battlestep)
        
        player.charge_animate_component.update_func = function(self, dt)
            if self and player.charge then player.charge_animation:update(dt, player.charge) end
        end
        player:register_component(player.charge_animate_component)
        end
        player.battle_end_func = function(self)
        if player.charge then player.charge = nil end
        if player.charge_animate_component then player.charge_animate_component:eject() end
    end
end