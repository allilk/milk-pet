function package_init(package)
    package:declare_package_id("Ecanoya's Zero")
    package:set_special_description("The Legendary Reploid")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."overworld.animation")
    package:set_overworld_texture_path(_folderpath.."overworld.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Zero")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(48.0)

    local base_texture = Engine.load_texture(_folderpath.."battle.png")
    local base_animation_path = _folderpath.."zero.animation"
    local base_charge_color = Color.new(0, 87, 40, 255)
	
	local BBAudio = Engine.load_audio(_modpath.."sounds/buster.ogg")
	local CBAudio = Engine.load_audio(_modpath.."sounds/buster_cs.ogg")
	local SaberAudio = Engine.load_audio(_modpath.."sounds/saber.ogg")
	local CSaberAudio = Engine.load_audio(_modpath.."sounds/saber_cs.ogg")
	local ChargingAudio = Engine.load_audio(_modpath.."sounds/charging.ogg")
	local ChargedAudio = Engine.load_audio(_modpath.."sounds/charged.ogg")
	
	player.charge_effect = nil
	player.charge_animation = nil
	player.full_charge_effect = nil
	player.full_charge_animation = nil
	
	--code to run the charging effect
	local function create_charge_node(user)
	user.charge_effect = user:create_node()
	user.charge_effect:set_texture(Engine.load_texture(_modpath.."charge.png"), false)
	user.charge_animation = Engine.Animation.new(_modpath.."charge.animation")
	user.charge_animation:load(_modpath.."charge.animation")
	user.charge_animation:set_state("CHARGING")
	user.charge_animation:refresh(user.charge_effect)
	user.charge_animation:set_playback(Playback.Loop)
	user.charge_effect:set_layer(-2)
	end
	
	--code to run the fully charged effect
	local function create_full_charge_node(user)
	user.full_charge_effect = user:create_node()
	user.full_charge_effect:set_texture(Engine.load_texture(_modpath.."charge.png"), false)
	user.full_charge_animation = Engine.Animation.new(_modpath.."charge.animation")
	user.full_charge_animation:load(_modpath.."charge.animation")
	user.full_charge_animation:set_state("CHARGED")
	user.full_charge_animation:refresh(user.charge_effect)
	user.full_charge_animation:set_playback(Playback.Loop)
	user.full_charge_effect:set_layer(-1)
	end

	local counter = 1 -- used to count fps frames for the charge effect
	local max_charge = 144 --set to a multiple of 24 to keep in sync with the audio.
	local isCharging = false
	player.update_func = function(self, dt) --This runs the charge attack. Handles both the charging effect, and queing the attack.
		
		--starts counting fps frames while the special button is held
		if self:input_has(Input.Held.Special) then
			counter = counter + 1
		end
		
		--this adds a delay before calling the charging effect and sound
		if counter >= 24 then
			isCharging = true
		end
		
		if player:get_attack_level() >= 5 then
			max_charge = 120
		end
		
		--triggers the charge slash function and removes the full charge animation
		if self:input_has(Input.Released.Special) and counter >= max_charge and player:get_attack_level() >= 4 then
			self:card_action_event(Charge_Slash_func(), ActionOrder.Immediate)
			if self.full_charge_animation then 
				self.full_charge_animation = nil
				self:sprite():remove_node(self.full_charge_effect)
				self.full_charge_effect = nil
			end
		end
		
		--disables the charging effect if released early, and resets the counter even after a charge attack
		if self:input_has(Input.Released.Special) then 
			counter = 0
			if self.charge_animation then 
				self.charge_animation = nil
				self:sprite():remove_node(self.charge_effect)
				self.charge_effect = nil
			end
			isCharging = false
		end
		
		--Not sure what this one does. Al said to add it, so I did
		if self.charge_animation then 
			self.charge_animation:update(dt, self.charge_effect)
		end
		
		--switches on the charging effect and plays/loops the charging audio
		if isCharging then 
			if not self.charge_effect then 
				create_charge_node(self)
			end
			if not self.full_charge_effect then 
				create_full_charge_node(self)
			end
			if counter % 24 == 0 then
				Engine.play_audio(ChargingAudio, AudioPriority.Low)
			end
		end
		
		--Switches off the charging animation to start the charged one. Also loops the Full charge sound.
		if counter >= max_charge and player:get_attack_level() >= 4 then 
			isCharging = false
			 if counter % 24 == 0 then
				Engine.play_audio(ChargedAudio, AudioPriority.Low)
			end
			if self.charge_animation then 
				self.charge_animation = nil
				self:sprite():remove_node(self.charge_effect)
				self.charge_effect = nil
			end
		end
		
		--Same as the one for charging. No idea what this is for, but it makes the code work.
		if self.full_charge_animation then 
			self.full_charge_animation:update(dt, self.full_charge_effect)
		end
		
		--cancels the charge if player presses the use button, or enters an animation that isn't idle besides movement
		if (player:input_has(Input.Pressed.Use)) or (player:get_animation():get_state() ~= "PLAYER_IDLE" and not player:is_moving()) then
		counter = 0
			if self.full_charge_animation then 
				self.full_charge_animation = nil
				self:sprite():remove_node(self.full_charge_effect)
				self.full_charge_effect = nil
			end
			isCharging = false
			if self.charge_animation then 
				self.charge_animation = nil
				self:sprite():remove_node(self.charge_effect)
				self.charge_effect = nil
			end
		end
	end
	
    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(248, 152, 56, 255))
    player:set_charge_position(2,-22)
	
	

    player.normal_attack_func = function() --This actually calls in a different animation for the buster, so a new function had to be made
    local action = Battle.CardAction.new(player, "PLAYER_BUSTER")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, player)
		
		
		local cannonshot = basic_buster(player)
		local tile = player:get_tile(player:get_facing(), 1)
		player:get_field():spawn(cannonshot, tile)
	end
    return action
end

	function basic_buster()
		local spell = Battle.Spell.new(player:get_team())
		spell:set_facing(player:get_facing())
		spell.slide_started = false
		local direction = spell:get_facing()
		local props = Battle.CardProperties:new()
		props.damage = player:get_attack_level()
		spell:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact, 
				Element.None,
				player:get_context(),
				Drag.new(direction, 1)
			)
		)
		spell.update_func = function(self, dt) 
			self:get_current_tile():attack_entities(self)
			if self:is_sliding() == false then
				if self:get_current_tile():is_edge() and self.slide_started then 
					self:delete()
				end 
				
				local dest = self:get_tile(direction, 1)
				local ref = self
				self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
					function()
						ref.slide_started = true 
					end
				)
			end
		end
		spell.collision_func = function(self, other)
			self:delete()
		end
		spell.attack_func = function(self, other) 
		end
	
		spell.delete_func = function(self)
			self:erase()
		end

		spell.can_move_to_func = function(tile)
			return true
		end

		Engine.play_audio(BBAudio, AudioPriority.Low)
		return spell
	end

    player.charged_attack_func = function() -- Same with this.
	local action = Battle.CardAction.new(player, "PLAYER_CBUSTER")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, player)
		
		
		local cannonshot = charge_buster(player)
		local tile = player:get_tile(player:get_facing(), 1)
		player:get_field():spawn(cannonshot, tile)
	end
    return action
end

	function charge_buster()
		local spell = Battle.Spell.new(player:get_team())
		spell:set_facing(player:get_facing())
		spell.slide_started = false
		local direction = spell:get_facing()
		local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level()*10)
		spell:set_hit_props(
			HitProps.new(
            props.damage,
            Hit.Impact, 
            Element.None,
            player:get_context(),
            Drag.new(direction, 1)
			)
		)
		spell.update_func = function(self, dt) 
			self:get_current_tile():attack_entities(self)
			if self:is_sliding() == false then
				if self:get_current_tile():is_edge() and self.slide_started then 
					self:delete()
				end 
			
				local dest = self:get_tile(direction, 1)
				local ref = self
				self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
					function()
						ref.slide_started = true 
					end
				)
			end
		end
		spell.collision_func = function(self, other)
			self:delete()
		end
		spell.attack_func = function(self, other) 
		end

		spell.delete_func = function(self)
			self:erase()
		end

		spell.can_move_to_func = function(tile)
			return true
		end

		Engine.play_audio(CBAudio, AudioPriority.Low)
		return spell
	end

    player.special_attack_func = function() --This is the whole Z saber combo in one function. Uses steps for each slash.
        local action = Battle.CardAction.new(player, "PLAYER_Z-SABER_1")
		action:set_lockout(make_sequence_lockout())
		
		action.execute_func = function(self)
			player.combo = false
			local step1 = Battle.Step.new()
			local slash1_first = true
			local next_attack1 = false
			local Slash1_cancelable = false

			local step2 = Battle.Step.new()
			local slash2_first = true
			local next_attack2 = false
			local Slash2_cancelable = false
		
			local step3 = Battle.Step.new()
			local slash3_first = true
		
			local actor = self:get_actor()
		
		
			local spell_list = {}
			local field = player:get_field()
			local tile_in_front = player:get_tile(player:get_facing(), 1)
			local steps_used = 0
		
			step1.update_func = function(self)
				if slash1_first then
					action:add_anim_action(2, function()
						spell_list[1] = create_Slash1(player, tile_in_front, player.combo)
						field:spawn(spell_list[1], tile_in_front)
						Engine.play_audio(SaberAudio, AudioPriority.Low)
						steps_used = steps_used+1
							
						player.combo = false
					end)
					
					player:get_animation():on_frame(6, function()
						Slash1_cancelable = true
					end)

					player:get_animation():on_complete(function()
						if next_attack1 then
							action:add_step(step2)
						end
						
						step1:complete_step()
					end)

					slash1_first = false
				end
				
				if player:input_has(Input.Pressed.Special) and player:get_attack_level() >= 2 then
					next_attack1 = true
				end
				
				if next_attack1 and Slash1_cancelable then
					action:add_step(step2)
					step1:complete_step()
				end
            
			end

			step2.update_func = function(self)
				if slash2_first then
					player:get_animation():set_state("PLAYER_Z-SABER_2")
					player:get_animation():on_frame(1, function()
						spell_list[2] = create_Slash2(player, tile_in_front, player.combo)
						field:spawn(spell_list[2], tile_in_front)
						Engine.play_audio(SaberAudio, AudioPriority.Low)
						steps_used = steps_used+1
						
						player.combo = false
						
					end)
					
					player:get_animation():on_frame(5, function()
						Slash2_cancelable = true
					end)
					
					player:get_animation():on_complete(function()
						if next_attack2 then
							action:add_step(step3)
						end
						step2:complete_step()
						
					end)
					slash2_first = false
				end	
				
				if player:input_has(Input.Pressed.Special) and player:get_attack_level() >= 3 then
					next_attack2 = true
				end
				
				if next_attack2 and Slash2_cancelable then
					action:add_step(step3)
					step2:complete_step()
				end	
			end
			
			step3.update_func = function(self)
				if slash3_first then
					player:get_animation():set_state("PLAYER_Z-SABER_3")
					player:get_animation():on_frame(3, function()
						spell_list[3] = create_Slash3(player, tile_in_front, player.combo)
						field:spawn(spell_list[3], tile_in_front) 
						Engine.play_audio(SaberAudio, AudioPriority.Low)
						steps_used = steps_used+1
						
						player.combo = false
					end)
					
					player:get_animation():on_complete(function()
						step3:complete_step()
					end)
					slash3_first = false
				end
			
			end
			
			action:add_step(step1)
			
			action.action_end_func = function()
				for i=1, steps_used, 1
				do
					if not spell_list[i]:is_deleted() then
						spell_list[i]:delete()
					end	
				end
				player.combo = false
			end
		end
		 
		return action
	end	
	
	function create_Slash1(user, props)
		local hasHit = false
		local counter = 0
		local spell = Battle.Spell.new(user:get_team())
		spell:set_facing(user:get_facing())
		local damage = user:get_attack_level() * 5
		local flags = Hit.Impact | Hit.Flinch | Hit.Flash
		if combo then
			flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
		end

		local element = Element.Sword
		local direction = spell:get_facing()
		spell:set_hit_props(
			HitProps.new(
				damage,
				flags,
				element,
				user:get_context(),
				Drag.None
			)
		)
		local attack_once = true
		local field = user:get_field()
		spell.update_func = function(self, dt) 
			local tile = spell:get_current_tile()
			local tile_next = tile:get_tile(Direction.Up, 1)
			local tile_next_two = tile:get_tile(Direction.Down, 1)
			if tile_next and not tile_next:is_edge() then
				tile_next:highlight(Highlight.Solid)
			end
			if tile_next_two and not tile_next_two:is_edge() then
				tile_next_two:highlight(Highlight.Solid)
			end
			if attack_once then
				if tile_next and not tile_next:is_edge() then
					local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
					hitbox_r:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox_r, tile_next)
				end
				if tile_next_two and not tile_next_two:is_edge() then
					local hitbox_l = Battle.SharedHitbox.new(self, 0.2)
					hitbox_l:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox_l, tile_next_two)
				end
				attack_once = false
			end
			tile:attack_entities(self)
			spell:get_current_tile():highlight(Highlight.Solid)
			
			if counter == 4 then
				self:erase()
			else
				counter = counter + 1
			end
		end

		spell.attack_func = function()
			user.combo = true
		end

		spell.can_move_to_func = function(tile)
			return true
		end

		return spell
	end

	function create_Slash2(user, tile, combo)
		local hasHit = false
		local counter = 0
		local spell = Battle.Spell.new(user:get_team())
		spell:set_facing(user:get_facing())
		
		local damage = user:get_attack_level() * 5
		local flags = Hit.Impact | Hit.Flinch | Hit.Flash
		if combo then
			flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
		end

		local element = Element.Sword
		local direction = spell:get_facing()
		spell:set_hit_props(
			HitProps.new(
				damage,
				flags,
				element,
				user:get_context(),
				Drag.None
			)
		)
		local attack_once = true
		local field = user:get_field()
		spell.update_func = function(self)
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(spell:get_facing(), 1)
			if tile_next and not tile_next:is_edge() then
				tile_next:highlight(Highlight.Solid)
			end
			if attack_once then
				if tile_next and not tile_next:is_edge() then
					local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
					hitbox_r:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox_r, tile_next)
				end
				attack_once = false
			end
			tile:attack_entities(self)
			spell:get_current_tile():highlight(Highlight.Solid)
			
			if counter == 4 then
				self:erase()
			else
				counter = counter + 1
			end

		end
		
		spell.attack_func = function()
			user.combo = true
		end
		
		spell.can_move_to_func = function(tile)
		    return true
		end
		
		return spell

	end
	
	function create_Slash3(user, tile, combo)

		local hasHit = false
		local counter = 0
		local spell = Battle.Spell.new(user:get_team())
		spell:set_facing(user:get_facing())
		
		local damage = user:get_attack_level() * 6
		local flags = Hit.Impact | Hit.Flinch | Hit.Flash
		if combo then
			flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
		end

		local element = Element.Sword
		local direction = spell:get_facing()
		spell:set_hit_props(
			HitProps.new(
				damage,
				flags,
				element,
				user:get_context(),
				Drag.None
			)
		)
		local attack_once = true
		local field = user:get_field()
		spell.update_func = function(self)
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(spell:get_facing(), 1)
			if tile_next and not tile_next:is_edge() then
				tile_next:highlight(Highlight.Solid)
			end
			if attack_once then
				if tile_next and not tile_next:is_edge() then
					local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
					hitbox_r:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox_r, tile_next)
				end
				attack_once = false
			end
			tile:attack_entities(self)
			spell:get_current_tile():highlight(Highlight.Solid)
			
			if counter == 4 then
				self:erase()
			else
				counter = counter + 1
			end

		end
		
		spell.attack_func = function()
			user.combo = true
		end
		
		spell.can_move_to_func = function(tile)
		    return true
		end
		
		return spell

	end
	
	function Charge_Slash_func() --I'm surprised by how rediculously simple this one is.
		local action = Battle.CardAction.new(player, "PLAYER_ZCS")
		action:set_lockout(make_animation_lockout())
		action.execute_func = function(self, player)
			player:get_animation():on_frame(2, function()
				local ChargeSlash = create_CSlash(player)
				local tile = player:get_tile(player:get_facing(), 1)
					local sharebox1 = Battle.SharedHitbox.new(ChargeSlash, 0.15)
						sharebox1:set_hit_props(ChargeSlash:copy_hit_props())
						local sharebox2 = Battle.SharedHitbox.new(ChargeSlash, 0.15)
						sharebox2:set_hit_props(ChargeSlash:copy_hit_props())
						local sharebox3 = Battle.SharedHitbox.new(ChargeSlash, 0.15)
						sharebox3:set_hit_props(ChargeSlash:copy_hit_props())
						player:get_field():spawn(sharebox1, tile:get_tile(Direction.Up, 1))
						player:get_field():spawn(ChargeSlash, tile)
						player:get_field():spawn(sharebox2, tile:get_tile(Direction.Down, 1))
						player:get_field():spawn(sharebox3, tile:get_tile(Direction.Right, 1))
				player:get_field():spawn(ChargeSlash, tile)
			end)
		end

		return action
	end
	
	function create_CSlash()
		local counter = 0
		local spell = Battle.Spell.new(player:get_team())
		spell:set_facing(player:get_facing())
		
		local damage = player:get_attack_level() * 20 + 60
		local flags = Hit.Impact | Hit.Flinch | Hit.Flash

		local element = Element.Sword
		local direction = spell:get_facing()
		spell:highlight_tile(Highlight.Solid)
		spell:set_hit_props(
			HitProps.new(
				damage,
				flags,
				element,
				player:get_context(),
				Drag.None
			)
		)
		spell.update_func = function(self, dt)
			if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
				self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Solid)
			end
			if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
				self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Solid)
			end
			if not self:get_tile():get_tile(Direction.Right, 1):is_edge() then
				self:get_tile():get_tile(Direction.Right, 1):highlight(Highlight.Solid)
			end
			self:get_tile():attack_entities(self)
			if counter == 4 then
				spell:delete()
			else
				counter = counter + 1
			end
		end

		spell.can_move_to_func = function(tile)
			return true
		end
		
		Engine.play_audio(CSaberAudio, AudioPriority.Low)
		return spell
	end

end