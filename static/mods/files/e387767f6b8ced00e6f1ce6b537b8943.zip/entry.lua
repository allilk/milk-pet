local DAMAGE = 200

local VIDEOMAN_TEXTURE = Engine.load_texture(_modpath.."videoman.png")
local VIDEOMAN_ANIMPATH = _modpath.."videoman.animation"
local LASERMAN_TEXTURE = Engine.load_texture(_modpath.."laserman.png")
local LASERMAN_ANIMPATH = _modpath.."laserman.animation"
local KENDOMAN_TEXTURE = Engine.load_texture(_modpath.."kendoman.png")
local KENDOMAN_ANIMPATH = _modpath.."kendoman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_ROKUGASAISEI = Engine.load_audio(_modpath.."rokugasaisei.ogg")
local AUDIO_POWERDOWNLASER = Engine.load_audio(_modpath.."powerdownlaser.ogg")
local AUDIO_MEN = Engine.load_audio(_modpath.."men.ogg")

local WARP_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local WARP_ANIMPATH = _modpath.."mob_move.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = true

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-276-GrandPrixPower")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G"})

    local props = package:get_card_props()
    props.shortname = "GPrixPwr"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "GrandPrix 3 Navis atk tgthr"
    props.long_description = "The 3 Grand Prix winning Navis' dream appearance together!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_current_tile()
        local self_Y    = self_tile:y()

        local tile1 = self_tile
        local tile2 = user:get_tile(direction, 1)
        local tile3 = nil
        if team == Team.Red then
			if direction == Direction.Right then
				tile3 = field:tile_at(0, self_Y)
			else
				tile3 = field:tile_at(7, self_Y)
			end
		else
			if direction == Direction.Left then
				tile3 = field:tile_at(0, self_Y)
			else
				tile3 = field:tile_at(7, self_Y)
			end
		end

        local check = function(user, ent)
            if not user:is_team(ent:get_team()) then
				return true
			end
        end
        local dark_query = function(o)
            return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
        end

        local laser_start = false
        local finish_step = false

		local step1 = Battle.Step.new()

        self.videoman = nil
        self.laserman = nil
        self.kendoman = nil

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)

            if finish_step then
                step1:complete_step()
            end

            local kendoman = Battle.Spell.new(team)
            kendoman:set_facing(direction)
            kendoman.kendoman_slide = false
            --[[kendoman:set_hit_props(HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                props.element, 
                user:get_id(), 
                Drag.None)
            )]]
            local kendo_sprite = kendoman:sprite()
            kendo_sprite:set_layer(-6)
            kendo_sprite:set_texture(KENDOMAN_TEXTURE, true)
            kendoman:set_offset(0, -7)
            local kendo_anim = kendoman:get_animation()
            kendo_anim:load(KENDOMAN_ANIMPATH)
            kendo_anim:set_state("0")
            kendo_anim:set_playback(Playback.Loop)
		    kendo_anim:refresh(kendo_sprite)
            kendoman.update_func = function(self)
                --self:get_current_tile():attack_entities(self)
                --[[if self:get_current_tile() == nil or self:get_current_tile():is_hole() then
                    self:delete()
                end]]
                if direction == Direction.Right then
                    if self:get_current_tile():x() ~= 0 and self:get_current_tile():x() ~= 7 and self:get_current_tile():is_hole() then
                        create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, kendoman:get_current_tile())
                        self:delete()
                    elseif self:get_current_tile():x() == 7 and self:get_current_tile():is_edge() then
                        create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, kendoman:get_current_tile())
                        self:delete()
                    end
                else
                    if self:get_current_tile():x() ~= 0 and self:get_current_tile():x() ~= 7 and self:get_current_tile():is_hole() then
                        create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, kendoman:get_current_tile())
                        self:delete()
                    elseif self:get_current_tile():x() == 0 and self:get_current_tile():is_edge() then
                        create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, kendoman:get_current_tile())
                        self:delete()
                    end
                end
                if self:is_sliding() == false then 
                    --[[if self:get_current_tile() == nil or self:get_current_tile():is_hole() and self.kendoman_slide then
                        create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                        self:delete()
                        finish_step = true
                    end]]
        
                    local dest = self:get_tile(direction, 1)
                    local ref = self
                    self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                        function()
                            ref.kendoman_slide = true 
                        end
                    )
                end
            end
            kendoman.delete_func = function(self)
                finish_step = true
                kendoman:erase()
            end
            --[[kendoman.attack_func = function(self)
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            end]]
            kendoman.can_move_to_func = function(tile)
                return true
            end

            if do_once then
                do_once = false

                ref.videoman = Battle.Artifact.new()
                ref.videoman:set_facing(direction)
                local video_sprite = ref.videoman:sprite()
                video_sprite:set_layer(-4)
                video_sprite:set_texture(VIDEOMAN_TEXTURE, true)
                ref.videoman:set_offset(0, -7)
                local video_anim = ref.videoman:get_animation()
                video_anim:load(VIDEOMAN_ANIMPATH)
                video_anim:set_state("0")
		        video_anim:refresh(video_sprite)

                ref.laserman = Battle.Artifact.new()
                ref.laserman:set_facing(direction)
                local laser_sprite = ref.laserman:sprite()
                laser_sprite:set_layer(-5)
                laser_sprite:set_texture(LASERMAN_TEXTURE, true)
                ref.laserman:set_offset(0, -7)
                local laser_anim = ref.laserman:get_animation()
                laser_anim:load(LASERMAN_ANIMPATH)
                laser_anim:set_state("0")
		        laser_anim:refresh(laser_sprite)
                
                video_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                video_anim:on_frame(6, function()
                    print("VideoMan: RokugaSaisei!")
                    Engine.play_audio(AUDIO_ROKUGASAISEI, AudioPriority.High)
                end)
                video_anim:on_frame(17, function()
                    laser_start = true
                    field:spawn(ref.laserman, tile2)
                end)
                video_anim:on_frame(31, function()
                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                end)
		    	video_anim:on_complete(function()
		    		ref.videoman:delete()
		    	end)

                laser_anim:on_frame(28, function()
                    if #tile2:find_characters(check) > 0 or #tile2:find_entities(dark_query) > 0 or tile2:is_hole() or tile2:is_edge() then
                        finish_step = true
                        ref.laserman:delete()
                    end
                end)
                laser_anim:on_frame(30, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.Highest)
                end)
                laser_anim:on_frame(34, function()
                    print("LaserMan: PowerDownLaser!")
                    Engine.play_audio(AUDIO_POWERDOWNLASER, AudioPriority.High)
                end)
                laser_anim:on_frame(40, function()
                    laser_hitbox(user, props, tile2:get_tile(direction, 1), team, direction, field)
                    laser_hitbox(user, props, tile2:get_tile(direction, 2), team, direction, field)
                    laser_hitbox(user, props, tile2:get_tile(direction, 3), team, direction, field)
                    laser_hitbox(user, props, tile2:get_tile(direction, 4), team, direction, field)
                    laser_hitbox(user, props, tile2:get_tile(direction, 5), team, direction, field)
                end)
                --[[laser_anim:on_frame(63, function()
                    Engine.play_audio(AUDIO_POWERDOWNLASER, AudioPriority.High)
                end)]]
                laser_anim:on_frame(74, function()
                    Engine.play_audio(AUDIO_MEN, AudioPriority.High)
                    field:spawn(kendoman, tile3)
                    kendoman_hitbox(user, props, tile3, team, direction, field, tile1)
                end)
                laser_anim:on_complete(function()
                    ref.laserman:delete()
                end)

                field:spawn(ref.videoman, tile1)
            end
            --[[video_anim:on_frame(17, function()
                print("laser_start = true")
                laser_start = true
            end)]]
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function laser_hitbox(owner, props, tile, team, direction, field)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element, 
            owner:get_id(), 
            Drag.None)
        )

        local animation = spell:get_animation()
        animation:load(_modpath .. "attack.animation")
        animation:set_state("1")
        animation:on_complete(function()
            spell:erase()
        end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn()
end

function kendoman_hitbox(owner, props, tile, team, direction, field, tile1)
    local kendoman = Battle.Spell.new(team)
    kendoman:set_facing(direction)
    kendoman.kendoman_slide = false
    kendoman:set_hit_props(HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flinch | Hit.Flash, 
        props.element, 
        owner:get_id(), 
        Drag.None)
    )
    kendoman.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        if direction == Direction.Right then
            if self:get_current_tile():x() ~= 0 and self:get_current_tile():x() ~= 7 and self:get_current_tile():is_hole() then
                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                self:delete()
            elseif self:get_current_tile():x() == 7 and self:get_current_tile():is_edge() then
                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                self:delete()
            end
        else
            if self:get_current_tile():x() ~= 0 and self:get_current_tile():x() ~= 7 and self:get_current_tile():is_hole() then
                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                self:delete()
            elseif self:get_current_tile():x() == 0 and self:get_current_tile():is_edge() then
                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -15, field, tile1)
                self:delete()
            end
        end
        if self:is_sliding() == false then
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.kendoman_slide = true 
                end
            )
        end
    end
    kendoman.collision_func = function(self, other)
        kendoman:delete()
	end
    kendoman.delete_func = function(self)
        kendoman:erase()
    end
    kendoman.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    kendoman.can_move_to_func = function(tile)
        return true
    end
    field:spawn(kendoman, tile)
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end