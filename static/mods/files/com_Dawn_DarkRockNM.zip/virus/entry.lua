local Tornado = include("Chips/Tornado/entry.lua")
local DarkSwrd = include("Chips/DrkSword/entry.lua")
local DarkVulcan = include("Chips/DarkVulcan/vulcan/vulcan.lua")
local FireSwrd = include("Chips/FireSwrd/entry.lua")
local AquaSwrd = include("Chips/AquaSwrd/entry.lua")
local BambSwrd = include("Chips/BambSwrd/entry.lua")
local ElecSwrd = include("Chips/ElecSwrd/entry.lua")
local GunDelHel = include("Chips/GunDelHell/entry.lua")
local DarkHockey = include("Chips/WildRide/entry.lua")
local PiercingCannon = include("Chips/DarkCannonPiercing/entry.lua")
local Uninstall = include("Chips/rune_legacy_uninstll/entry.lua")
local PushBack = include("Chips/PushBack/entry.lua")
local DarkAura = include("Chips/rune_legacy_evilaura/entry.lua")
local DarkRecov = include("Chips/entropy_recovdark/entry.lua")
local AreaGrab = include("Chips/Areagrab/entry.lua")
local DarkLance = include("Chips/DarkLance/entry.lua")

local function spawn_mob_move(dark_rock)
    local fx = Battle.Artifact.new()
    fx:set_texture(Engine.load_texture(_modpath.."mob_move.png", true))
    local anim = fx:get_animation()
    anim:load(_modpath.."mob_move.animation")
    anim:set_state("DEFAULT")
    anim:refresh(fx:sprite())
    anim:on_complete(function()
        fx:erase()
    end)
    local field = dark_rock:get_field()
    field:spawn(fx, dark_rock:get_tile())
end

local function find_best_target(dark_rock)
    local target = dark_rock:get_target()
    local field = dark_rock:get_field()
    local query = function(c)
        return c:get_team() ~= dark_rock:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 9999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

local function move_towards_character(self, chosen_attack)
    local target_character = find_best_target(self)
    if not target_character or target_character and target_character:is_deleted() then return false end
    local target_character_tile = target_character:get_current_tile()
    local tile = self:get_current_tile()
    local moved = false
    local field = self:get_field()
    local target_movement_tile = nil
	local is_occupied = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
    local same_row_list = {"PiercingCannon", "DarkVulcan", "Buster Spam", "Uninstall", "GunDelHel"}
    local whatever_list = {"WildRide", "DarkAura", "DarkRecov", "AreaGrab", "Dark Lance"}
    local specific_distance_list = {"Tornado", "DarkSwrd", "FireSwrd", "AquaSwrd", "BambSwrd", "ElecSwrd"}
    local function includes(table, value)
        for _, v in ipairs(table) do
            if value == v then
                return true
            end
        end
        return false
    end
    if chosen_attack == nil then return false end
    if includes(specific_distance_list, chosen_attack.name) then
        if chosen_attack.name == "Tornado" then
            local desired_tile = target_character:get_tile(target_character:get_facing(), 2)
            local alt_tile = target_character:get_tile(target_character:get_facing_away(), 2)
            if desired_tile and self.can_move_to_func(desired_tile) then
                target_movement_tile = desired_tile
            elseif alt_tile and self.can_move_to_func(alt_tile) then
                target_movement_tile = alt_tile
            else
                return true
            end
        else
            local desired_tile = target_character:get_tile(target_character:get_facing(), 1)
            local alt_tile = target_character:get_tile(target_character:get_facing_away(), 1)
            if desired_tile and self.can_move_to_func(desired_tile) then
                target_movement_tile = desired_tile
            elseif alt_tile and self.can_move_to_func(alt_tile) then
                target_movement_tile = alt_tile
            else
                for i = 1, 6, 1 do
                    if target_movement_tile ~= nil then
                        break
                    else
                        local check_tile = field:tile_at(i, target_character:get_tile():y())
                        if check_tile and self.can_move_to_func(check_tile) then
                            target_movement_tile = check_tile
                        end
                    end
                end
            end
        end
    end
    if includes(whatever_list, chosen_attack.name) then return true end
	if includes(same_row_list, chosen_attack.name) then
        for i = 1, 6, 1 do
            if target_movement_tile ~= nil then
                break
            else
                local check_tile = field:tile_at(i, target_character:get_tile():y())
                if check_tile and self.can_move_to_func(check_tile) then
                    target_movement_tile = check_tile
                end
            end
        end
    end
    if target_movement_tile then
        moved = self:teleport(target_movement_tile, ActionOrder.Immediate, function()
            spawn_mob_move(self)
            if self:get_tile():x() >= target_character:get_tile():x() then
                self:set_facing(Direction.Left)
            else
                self:set_facing(Direction.Right)
            end
        end)
        if moved then
            self._movement_wait = 15
        end
    end
    return moved
end

local function move_at_random(self)
	local current_tile = self:get_tile()
	local field = self:get_field()
	local target_tile_x = math.floor(math.random(6))
	local target_tile_y = math.floor(math.random(3))
	local target_tile = nil
	local dummy_tile = nil
    local original_tile_array = {}
    for x = 6, 4, -1 do
        for y = 1, 3, 1 do
            local is_my_tile = field:tile_at(x, y)
            if is_my_tile and self:is_team(is_my_tile:get_team()) and not is_my_tile:is_edge() then
                table.insert(original_tile_array, is_my_tile)
            end
        end
    end
	local is_occupied = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
    local tile_array = {}
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local prospective_tile = field:tile_at(x, y)
            if prospective_tile and self.can_move_to_func(prospective_tile) then
                table.insert(tile_array, prospective_tile)
            end
        end
    end
    if #original_tile_array < 9 then
        if self.push_cooldown <= 0 then
            self.push_cooldown = 75
            if math.random(1, 20) > 12 then
                local action = PushBack.card_create_action(self)
                self:card_action_event(action, ActionOrder.Involuntary)
            end
        end
    end
    if #tile_array == 0 then return false end
	target_tile = tile_array[math.random(1, #tile_array)]
	if target_tile then
		moved = self:teleport(target_tile, ActionOrder.Immediate, function()
            spawn_mob_move(self)
            self._teleports = self._teleports + 1
            if self._teleports >= self._goal_teleports then
                self._teleports = 0
                self._goal_teleports = 4
                self._should_attack = true
                self._should_move = false
            end
        end)
		if moved then
			self._movement_wait = 15
		end
	end
	return moved
end

local function buster_spam_action(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    local damage = 50
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function package_init(self)
    --meta
    self:set_name("Dark Rock")
    self:set_health(3000)
    self:set_texture(Engine.load_texture(_modpath.."navi_megaman_atlas.og.png"))
    local anim = self:get_animation()
    anim:load(_modpath.."megaman.animation")
    anim:set_state("PLAYER_IDLE")
    --Give him immunity to a few statuses. This is a true NIGHTMARE of a fight.
    --Immunity to Blind. After all, he was born of darkness.
    --Immunity to Stun. Unless you counter him, he won't be stunned, because his body isn't conducive to it.
    --Immunity to Flinch. He's just built different.
    local DarkDefense = Battle.DefenseRule.new(313, DefenseOrder.CollisionOnly)
    DarkDefense.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Blind
        statuses.flags = statuses.flags & ~Hit.Flinch
        statuses.flags = statuses.flags & ~Hit.Stun
        return statuses
    end
    self:add_defense_rule(DarkDefense)
    self._movement_wait = 0 --Initial wait on moving. It's 0 at the start of the fight, since he opens by attacking.
    self._should_move = false
    self._should_attack = true
    local attack_list = {
        {Uninstall, AreaGrab, Tornado},
        {{name="Buster Spam"}, {name="Buster Spam"}, {name="Buster Spam"}},
        {DarkLance, AquaSwrd, DarkLance, FireSwrd, DarkLance, BambSwrd, DarkLance, ElecSwrd, AreaGrab},
        {{name="Buster Spam"}, {name="Buster Spam"}, {name="Buster Spam"}},
        {GunDelHel, DarkSwrd},
        {{name="Buster Spam"}, {name="Buster Spam"}},
        {PiercingCannon, DarkVulcan},
        {{name="Buster Spam"}},
        {{name="Buster Spam"}},
        {{name="Buster Spam"}},
        {DarkHockey, DarkHockey, DarkHockey},
    }
    local attack_list_index = 1
    local attack_list_inner_index = 1
    local attack_once = true
    local chosen_attack = nil
    local buster_spam_cooldown = 4
    local current_spam_counter = 0
    local frame1 = {1, 0.05}
    local frame2 = {2, 0.05}
    local frame3 = {3, 0.05}
    local frame4 = {1, 0.05}
    local frame5 = {2, 0.05}
    local frame6 = {3, 0.05}
    local frame7 = {1, 0.05}
    local frame8 = {2, 0.05}
    local frame9 = {3, 0.05}
    local frame10 = {4, 0.1}
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
    local tile_array = {}
    local do_once = true
    self._teleports = 0 --How many times has he moved? 0 by default, since he hasn't yet.
    self._goal_teleports = 4 --How many times does he move before going back to attacking? He wants to move 4 times by default.
    self.push_cooldown = 0 --How long before he can use Push Back again? 0 frames by default. He can use it.
    local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
    undershirt.can_block_func = function(judge, attacker, defender)
        local attacker_props = attacker:copy_hit_props()
        if defender:get_health() > 1 and (defender:get_health() - attacker_props.damage) <= 0 then 
            attacker_props.damage = defender:get_health() - 1
            attacker:set_hit_props(attacker_props)
        end
    end
    self:add_defense_rule(undershirt)
    --Dragging him around makes him angry. He will counterattack instead of continuing to move.
    self:register_status_callback(Hit.Drag, function()
        self._should_attack = true
        self._should_move = false
        attack_once = true
        current_spam_counter = 0
    end)
    self:register_status_callback(Hit.Root, function()
        self._should_attack = true
        self._should_move = false
        attack_once = true
        current_spam_counter = 0
        chosen_attack = attack_list[attack_list_index][attack_list_inner_index]
    end)
    --Give him omnishoes. Bring your uninstall.
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    local entity_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        --Tile exists, tile team is compatible, tile is not an edge tile, and no matching entities exist on tile?
        --Then he can move to it.
        return tile and self:is_team(tile:get_team()) and not tile:is_edge() and #tile:find_entities(entity_query) == 0
    end
    local idle_counter = 0
    self.has_tangoed = false
    self.update_func = function(self, dt)
        if self:get_health() == 1 and not self.has_tangoed then
            self.has_tangoed = true
            local props = Battle.CardProperties:new()
            local heal = DarkRecov.card_create_action(self, props)
            self:card_action_event(heal, ActionOrder.Involuntary)
            local aura = DarkAura.card_create_action(self, props)
            self:card_action_event(aura, ActionOrder.Involuntary)
        end
        if self.push_cooldown > 0 then self.push_cooldown = self.push_cooldown - 1 end
        if self._should_attack and anim:get_state() == "PLAYER_IDLE" then --If he's idle we need to check for how long.
            idle_counter = idle_counter + 1 --Increment a counter.
            if idle_counter >= 30 then --If it's been more than 30 frames...
                self._should_attack = false --He shouldn't attack anymore.
                self._should_move = true --He should move instead.
                --Reset variables for attacking later.
                attack_once = true
                idle_counter = 0
            end
            if attack_once then --This is a boolean that determines he's only going to attack once, instead of spamming this code in his update func.
                attack_once = false
                chosen_attack = attack_list[attack_list_index][attack_list_inner_index]
                attack_list_inner_index = attack_list_inner_index + 1
                if attack_list_inner_index > #attack_list[attack_list_index] then --reset the inner index to 1 if it exceeds the current inner attack list length
                    attack_list_inner_index = 1
                    attack_list_index = attack_list_index + 1
                    if attack_list_index > #attack_list then --reset the overall attack list index if it exceeds the overall attack list length
                        attack_list_index = 1
                        attack_list_inner_index = 1
                    end
                end
                local movement = false
                movement = move_towards_character(self, chosen_attack)
                if movement then
                    if chosen_attack.name == "Buster Spam" then
                        move_towards_character(self, {name="Buster Spam"})
                        local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
                        action:override_animation_frames(frame_sequence)
                        action:set_lockout(make_animation_lockout())
                        action.execute_func = function(act, user)
                            local buster = act:add_attachment("BUSTER")
                            local sprite = buster:sprite()
                            sprite:set_texture(self:get_texture())
                            sprite:enable_parent_shader(true)
                            sprite:set_layer(-1)

                            local buster_anim = buster:get_animation()
                            buster_anim:copy_from(self:get_animation())
                            buster_anim:set_state("BUSTER")
                            buster_anim:refresh(sprite)
                            act:add_anim_action(1, function()
                                local flare = buster:add_attachment("endpoint")
                                local flare_sprite = flare:sprite()
                                flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                                flare_sprite:set_layer(-1)

                                local flare_anim = flare:get_animation()
                                flare_anim:load(_modpath.."pew.animation")
                                flare_anim:set_state("0")
                                flare_anim:refresh(flare_sprite)
                                flare_anim:on_complete(function()
                                    flare_sprite:hide()
                                end)
                                local spell = buster_spam_action(self)
                                self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                            end)
                            act:add_anim_action(4, function()
                                local flare = buster:add_attachment("endpoint")
                                local flare_sprite = flare:sprite()
                                flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                                flare_sprite:set_layer(-1)

                                local flare_anim = flare:get_animation()
                                flare_anim:load(_modpath.."pew.animation")
                                flare_anim:set_state("0")
                                flare_anim:refresh(flare_sprite)
                                flare_anim:on_complete(function()
                                    flare_sprite:hide()
                                end)
                                local spell = buster_spam_action(self)
                                self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                            end)
                            act:add_anim_action(7, function()
                                local flare = buster:add_attachment("endpoint")
                                local flare_sprite = flare:sprite()
                                flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                                flare_sprite:set_layer(-1)

                                local flare_anim = flare:get_animation()
                                flare_anim:load(_modpath.."pew.animation")
                                flare_anim:set_state("0")
                                flare_anim:refresh(flare_sprite)
                                flare_anim:on_complete(function()
                                    flare_sprite:hide()
                                end)
                                local spell = buster_spam_action(self)
                                self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                            end)
                        end
                        action.action_end_func = function(self)
                            self._should_attack = false
                            self._should_move = true
                        end
                        self:card_action_event(action, ActionOrder.Involuntary)
                        current_spam_counter = buster_spam_cooldown
                    else
                        local action = chosen_attack.card_create_action(self)
                        self:card_action_event(action, ActionOrder.Involuntary)
                    end
                end
                chosen_attack = nil
            end
        elseif self._should_move then
            if self._movement_wait <= 0 then
                if not self:is_teleporting() then
                    --If we want to move and movement wait is 0, and we're not already teleporting, then move at random.
                    move_at_random(self)
                end
            else
                self._movement_wait = self._movement_wait - 1
            end
        end
    end
end