function package_init(package)
    package:declare_package_id("Dawn.BN6.HPBug")
end

local HPBug = {
	target_table = {}
}

HPBug.inflict_health_bug = function(other)
	local target = HPBug.search_target_table(other)
	local bug_level = 0
	if target then
		if not other:is_deleted() and other:get_health() > 0 then
			local temp_bug = HPBug.search_target_table_for_bug(other)
			if temp_bug ~= nil then
				HPBug.search_target_table_for_bug(other):eject()
			end
			bug_level = HPBug.search_target_table_for_level(other)
		end
	end
	if not other:is_deleted() and other:get_health() > 0 then
		local hp_bug = Battle.Component.new(other, Lifetimes.Battlestep)
		local do_once = true
		hp_bug.update_func = function(self, dt)
			if do_once then
				self.cooldown = 10
				self.original_cooldown = 10				
				do_once = false
			end
			if self:get_owner():get_health() > 1 then
				self.cooldown = self.cooldown - 1
				if self.cooldown <= 0 then
					self:get_owner():set_health(self:get_owner():get_health() - 1)
					self.cooldown = self.original_cooldown
				end
			end
		end
		bug_level = bug_level + 1
		other:register_component(hp_bug)
		if not target then
			HPBug.add_to_target_table(other, hp_bug, bug_level)
		end
		print(#HPBug.target_table)
	end
end

HPBug.search_target_table = function(other)
	for k, v in pairs(HPBug.target_table) do
		if k and v[1] == other:get_id() then
			return true
		end
	end
	return false
end

HPBug.search_target_table_for_bug = function(other)
	for k, v in pairs(HPBug.target_table) do
		if k and v[1] == other:get_id() then
			return v[2]
		end
	end
	return nil
end

HPBug.search_target_table_for_level = function(other)
	for k, v in pairs(HPBug.target_table) do
		if k and v[1] == other:get_id() then
			return v[3]
		end
	end
	return 0
end

HPBug.add_to_target_table = function(other, bug, level)
	table.insert(HPBug.target_table, {other:get_id(), bug, level})
end

HPBug.clear_target_table = function()
	HPBug.target_table = {}
	print("table nullified")
	print(#HPBug.target_table)
end

return HPBug