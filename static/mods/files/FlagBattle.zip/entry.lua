local function get_character_id(folder)
    return "com.Dawn.BN3PVP.Flag." .. folder
end

local function define_character(folder)
    Engine.define_character(get_character_id(folder), _modpath..folder)
end

local function create_flag(player)
    local field = player:get_field()
    local team = player:get_team()
    local facing = player:get_facing()
    local facing_away = player:get_facing_away()
    local tile = player:get_tile()
    local desired_tile = nil
    local direction_list = {
        facing_away,
        Direction.join(facing_away, Direction.Down),
        Direction.join(facing_away, Direction.Up),
        Direction.Down,
        Direction.Up,
        Direction.join(facing, Direction.Down),
        Direction.join(facing, Direction.Up),
        facing
    }
    for i = 1, #direction_list, 1 do
        local test_tile = tile:get_tile(direction_list[i], 1)
        if test_tile and test_tile:is_walkable() and #test_tile:find_characters(function() return true end) == 0 then
            desired_tile = test_tile
            break
        end
    end
    if desired_tile ~= nil then
        local enemy = Battle.Character.from_package(get_character_id("flag"), team, Rank.V1)
        field:spawn(enemy, desired_tile)
    end
end

local function find_opponent(player)
    local opponent

    player:get_field():find_characters(function(c)
        if c:get_team() == player:get_team() then
            -- already on the same team
            return false
        end

        local possible_p = Battle.Player.from(c)

        if possible_p then
            -- is a player on the opposite team!
            -- found the opponent!
            opponent = possible_p
        end

        return false
    end)

    return opponent
end

local function recruit(player)
    local opponent = find_opponent(player)

    if not opponent then
        -- no opponent
        return
    end
    create_flag(player)
    create_flag(opponent)
end

local function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Scene)

    local i = 0

    component.update_func = function ()
        i = i + 1

        -- allow time for setup
        if i == 1 then return end

        recruit(player)
        component:eject()
    end

    player:register_component(component)
end


function package_init(block)
    define_character("flag")
    block:declare_package_id("com.Dawn.BN3.FlagPVP")
    block:set_name("Flag PVP")
    block:as_program()
    block:set_description("Capture the Flag!")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end