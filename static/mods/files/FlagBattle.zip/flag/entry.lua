function package_init(self)

	self.can_move_to_func = function(tile)
		return false
	end

	self.update_func = function(flag, dt)
		if self.owner:get_health() == 0 then self:delete() return end
		if self:get_health() == 0 then
			if self.owner and not self.owner:is_deleted() then self.owner:delete() end
		end
	end
	self:set_name("Flag")
	self:set_health(1000)
	self:set_element(Element.None)
	self:set_texture(Engine.load_texture(_modpath.."flag.png"), true)
	self:set_height(60)
	self:share_tile(false)

	self.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
  	self:add_defense_rule(self.defense)
	self.defense2 = Battle.DefenseRule.new(999, DefenseOrder.CollisionOnly)
	self.defense2.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Freeze
		statuses.flags = statuses.flags & ~Hit.Flash
		statuses.flags = statuses.flags & ~Hit.Flinch
		statuses.flags = statuses.flags & ~Hit.Stun
		statuses.flags = statuses.flags & ~Hit.Drag
		statuses.element = Element.None
		return statuses
	end
	self:add_defense_rule(self.defense2)

	local anim = self:get_animation()
	anim:load(_modpath .. "flag.animation")
	anim:set_state("DEFAULT")
	anim:set_playback(Playback.Loop)
	local query = function(e)
		if not e or e and e:get_health() <= 0 then return false end
		local probably_p = Battle.Player.from(e)
		if probably_p and probably_p:get_team() == self:get_team() then return true end
	end
	self.on_spawn_func = function()
		local field = self:get_field()
		for x = 1, 6, 1 do
			for y = 1, 3, 1 do
				local tile = field:tile_at(x, y)
				if tile and #tile:find_characters(query) > 0 then
					self.owner = tile:find_characters(query)[1]
					self:set_facing(self.owner:get_facing_away())
				end
			end
		end
	end
end
