local DAMAGE = 100

local DIMMING_TEXTURE = Engine.load_texture(_modpath.."dimming.png")
local DIMMING_ANIMPATH = _modpath.."dimming.animation"

local FALZER_TEXTURE = Engine.load_texture(_modpath.."falzer.png")
local FALZER_ANIMPATH = _modpath.."falzer.animation"
local FALZER_AUDIO_SPAWN = Engine.load_audio(_modpath.."falzer-spawn.ogg")
local FALZER_AUDIO_APPEAR = Engine.load_audio(_modpath.."nightmare-spawn.ogg")
local FALZER_AUDIO_ATTACK = Engine.load_audio(_modpath.."falzer-attack.ogg")
local STRIKEFEATHER_TEXTURE = Engine.load_texture(_modpath.."strikefeather.png")
local STRIKEFEATHER_ANIMPATH = _modpath.."strikefeather.animation"
local STRIKEFEATHER_AUDIO = Engine.load_audio(_modpath.."strikefeather.ogg")
local SONICWAVE_TEXTURE = Engine.load_texture(_modpath.."sonicwave.png")
local SONICWAVE_ANIMPATH = _modpath.."sonicwave.animation"

local BOOM_TEXTURE = Engine.load_texture(_modpath.."boom.png")
local BOOM_ANIMPATH = _modpath.."boom.animation"
local BOOM_AUDIO = Engine.load_audio(_modpath.."boom.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.isabelle.chip.EXE6-295-Falzer")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"X"}) --Dawn: uppercased the code for consistency with other mods.

    local props = package:get_card_props()
    props.shortname = "Falzar"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Falzar's storming tornado!"
	props.long_description = "Cybeast Falzar uses its tornado attack! Blows away everything"
    props.can_boost = true
    props.card_class = CardClass.Giga
    props.limit = 1
end

--[[
1. megaman is hidden
2. 10 feathers spawn from the sky
        (destroy all objects
        (attack
        (Feathers cannot be attack boosted. Each feather has a 9/16 chance to target the enemy, 7/16 chance to target a random blue panel. Feathers never hit the same panel twice in a row. Fires 10 feathers that can hit up to 5 times.
        (feathers disappear after hiting something even an empty tile
3. falzar spawns in + 4. falzar moves back a bit + 5. falzar moves foward opens mouth + 6. falzar breath attacks
        (hits once right infront of falzar
        (hits twice 2 tiles infront of falzar
        (hits 3 times 3 tiles and is wide sword range infront of falzar
4. remove falzar + 8. megaman is unhidden
--]]

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    local target_tile = nil
    local enemy_list = nil
    local repeat_feather = 10

    local hits = 0

    local feather_cooldown = 0 --Dawn: added a cooldown between feather spawns
    local original_feather_cooldown = 10
    local state_cooldown = 60
    local previous_panel = nil

    --local user_field = actor:get_field()
    local user_tile = actor:get_current_tile()

    action.execute_func = function(self, user)
        local stunt_double = nil
        stunt_double = self:get_actor()

        local field = user:get_field()
        local team = user:get_team()
        local facing = user:get_facing()
        --Returns a list of all characters not on my team
        --Dawn: moved this function into action execute func to use the User variable.
        local enemy_filter = function(character)
            return character:get_team() ~= team
        end
        local step1 = Battle.Step.new()
        local step2 = Battle.Step.new()
        local step3 = Battle.Step.new()
        local step4 = Battle.Step.new()

        local enemy_tiles = {}

        local falzer_spawned = false

        for i = 0, 6, 1 do
            for j = 0, 3, 1 do
                local tile = field:tile_at(i, j)
                if tile and not tile:is_edge() and tile:get_team() ~= team then
                    table.insert(enemy_tiles, tile)
                end
            end
        end

        --K1rbYat1Na: dimming effect sprite
        local dimming = Battle.Artifact.new()
        local dimming_sprite = dimming:sprite()
        dimming_sprite:set_layer(-9)
        dimming_sprite:set_texture(DIMMING_TEXTURE, true)
        local dimming_anim = dimming:get_animation()
        dimming_anim:load(DIMMING_ANIMPATH)
        dimming_anim:set_state("0")
        dimming_anim:refresh(dimming_sprite)
        field:spawn(dimming, 3, 0) --spawn dimming effect sprite

        local buffer1 = 50

        step1.update_func = function(self, dt)
            --dimming effect fade in
            if dimming_anim:get_state() == "0" then
                dimming_anim:on_complete(function()
                    stunt_double:hide()
                end)
            end
            --stunt_double:hide()
            --delay 1
            if buffer1 <= 0 then
                self:complete_step()
            else
                buffer1 = buffer1 - 1
            end
        end

        step2.update_func = function(self, dt)
            --clear field
            if repeat_feather > 0 then
                if feather_cooldown <= 0 then
                    --Dawn: Implement the cooldown.
                    feather_cooldown = original_feather_cooldown
                    local randomNumber = math.random(1, 16)
					enemy_list = field:find_nearest_characters(user, enemy_filter) --Dawn: Use the correct inputs for the find nearest function.
                    if randomNumber <= 9 and hits <= 4 then
                        -- Find_nearest used with the filter to get the nearest character not on my team
                        -- It's an ordered list, so I access the first entry next
                        if enemy_list[1] then
                            target_tile = enemy_list[1]:get_current_tile()
                        else
                            target_tile = user:get_tile(user:get_facing(), 1)
                        end
                        if previous_panel == target_tile then
                            feather_cooldown = 0
                        else
                            hits = hits + 1
                            --create_strikefeather(user, props, team, facing, field, target_tile) --K1rbYat1Na: spawn Strike Feather
                            local feather1 = create_strikefeather(user, props, team, user:get_facing(), field, target_tile)
                            field:spawn(feather1, target_tile) --Dawn: actually spawn the attack
                            repeat_feather = repeat_feather - 1 --Dawn: decrement the feather count properly
                            previous_panel = target_tile

                        end
                    else
                        local player_check = enemy_list[1]:get_current_tile()
                        target_tile = enemy_tiles[math.random(1, #enemy_tiles)]
                        if player_check == target_tile then
                            --re run this loop with out sub tracking from count
                        else
                            if previous_panel == target_tile then
                                feather_cooldown = 0
                            else
                                --create_strikefeather(user, props, team, facing, field, target_tile) --K1rbYat1Na: spawn Strike Feather
                                local feather2 = create_strikefeather(user, props, team, user:get_facing(), field, target_tile)
                                field:spawn(feather2, target_tile)--Dawn: actually spawn the attack
                                repeat_feather = repeat_feather - 1 --Dawn: decrement the feather count properly
                                previous_panel = target_tile
                            end
                        end

                    end
                else
                    feather_cooldown = feather_cooldown - 1 --Dawn: decrement the cooldown
                end
            else
                state_cooldown = state_cooldown - 1

                if state_cooldown == 0 then
                    self:complete_step()
                end
            end
        end

        step3.update_func = function(self, dt)
            --spawn Falzer
            --do animation
            if falzer_spawned then return end
            summon_falzer(user, props, team, facing, field, user_tile, self, dimming_anim, dimming_sprite)
            --summon_falzer(user, props, team, facing, field, user_tile, self)
            falzer_spawned = true
        end

        local buffer2 = 50
        local doOnce = true

        step4.update_func = function(self, dt)
            --dimming effect fade out
            if doOnce then 
                if dimming_anim:get_state() == "1" then         
                    dimming_anim:on_complete(function()
                        dimming:erase()
                        stunt_double:reveal()
                        doOnce = false
                    end)
                end
            end
            --stunt_double:reveal()
            --delay 2
            if buffer2 <= 0 then
                self:complete_step()
            else
                buffer2 = buffer2 - 1
            end
        end
        self:add_step(step1)
        self:add_step(step2)
        self:add_step(step3)
        self:add_step(step4)
    end

    return action
end

function create_strikefeather(user, props, team, facing, field, target_tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_id(),
			Drag.None
		)
    )
    local spell_sprite = spell:sprite()
    spell_sprite:set_layer(-99)
    spell_sprite:set_texture(STRIKEFEATHER_TEXTURE, true)
    local anim = spell:get_animation()
    anim:load(STRIKEFEATHER_ANIMPATH)
    anim:set_state("0")
    anim:set_playback(Playback.Once)
    anim:refresh(spell_sprite)
    anim:on_frame(1, function()
        Engine.play_audio(STRIKEFEATHER_AUDIO, AudioPriority.Highest)
    end)
    if spell:get_facing() == Direction.Right then
        spell:set_offset(-270.0, -270.0)
    else
        spell:set_offset(270.0, -270.0)
    end
    local delete_cooldown = 1
    spell.update_func = function(self, dt)
        if self:get_offset().x == 0 and self:get_offset().y == 0 then
            self:get_tile():attack_entities(self)
            if delete_cooldown <= 0 then
                self:shake_camera(4.0, 0.5)
                self:delete()
            else
                delete_cooldown = delete_cooldown - 1
            end
        else
            if spell:get_facing() == Direction.Right then
                spell:set_offset(self:get_offset().x + 27.0, self:get_offset().y + 27.0)
            else
                spell:set_offset(self:get_offset().x - 27.0, self:get_offset().y + 27.0)
            end
        end
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(BOOM_TEXTURE, BOOM_ANIMPATH, "0", math.random(-5,5), math.random(-5,5), field, target_tile)
    end
    spell.delete_func = function(self)
        print("StrikeFeather ("..target_tile:x()..";"..target_tile:y()..") deleted!")
        Engine.play_audio(BOOM_AUDIO, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", 0, 0, field, target_tile)
    end
    --[[spell.battle_end_func = function(self)
        spell:erase()
    end]]

    --field:spawn(spell, target_tile)
    print("StrikeFeather spawned at tile ("..target_tile:x()..";"..target_tile:y()..")")

    return spell
end

function summon_falzer(user, props, team, facing, field, tile, step, dimming_anim, dimming_sprite)
    local falzer = Battle.Artifact.new()
    falzer:set_facing(facing)
    --falzer.alpha = 0
    --falzer.fadein = true
    local falzer_sprite = falzer:sprite()
    falzer_sprite:set_layer(-98)
    falzer_sprite:set_texture(FALZER_TEXTURE, true)
    local falzer_anim = falzer:get_animation()
    falzer_anim:load(FALZER_ANIMPATH)
    falzer_anim:set_state("0")
    falzer_anim:refresh(falzer_sprite)
    --[[if facing == Direction.Right then
        falzer_sprite:set_offset(-50, 100)
    else
        falzer_sprite:set_offset(50, 100)
    end]]
    falzer_anim:on_frame(2, function()
        Engine.play_audio(FALZER_AUDIO_SPAWN, AudioPriority.High)
    end)
    falzer_anim:on_frame(27, function()
        Engine.play_audio(FALZER_AUDIO_APPEAR, AudioPriority.High)
    end)
    falzer_anim:on_frame(31, function()
        Engine.play_audio(FALZER_AUDIO_ATTACK, AudioPriority.High)
        summon_breath(user, props, team, facing, field, tile) -- spawn Sonic Wave
        falzer:shake_camera(22.0, 2.1)
    end)
    --[[falzer_anim:on_complete(function()
        falzer.fadein = false 
    end)]]

    falzer.update_func = function(self, dt)
        --[[if self.fadein == true then
            self.alpha = self.alpha + 20
            self.alpha = math.min(self.alpha, 510)
        else 
            self.alpha = self.alpha - 20
            self.alpha = math.max(self.alpha, 0)

            if self.alpha == 0 then
                visual_artifact:erase()
                step:complete_step()
            end
        end

        local opacity = math.min(self.alpha, 255)
        local white = self.alpha

        if white > 255 then 
            white = 510-white
        end

        self:set_color(Color.new(white, white, white, opacity))]]
        falzer_anim:on_complete(function()
            dimming_anim:set_state("1")
            dimming_anim:refresh(dimming_sprite)
            falzer:erase()
            step:complete_step()
        end)
    end

    field:spawn(falzer, tile)

    return falzer
end

function summon_breath(user, props, team, facing, field, user_tile)
    local spellB = Battle.Spell.new(team)
    spellB:set_facing(facing)
    spellB:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.damage,
			user:get_id(),
			Drag.None
		)
    )
    local sprite = spellB:sprite()
    sprite:set_layer(-99)
    sprite:set_texture(SONICWAVE_TEXTURE, true)
    if spellB:get_facing() == Direction.Right then
        spellB:set_offset(160, 50)
    else
        spellB:set_offset(-160, 50)
    end
	--[[local do_once = true
	spellB.tile_array = {}
	if user:get_tile(facing, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 1)) end
	if user:get_tile(facing, 2) then table.insert(spellB.tile_array, user:get_tile(facing, 2)) end
	if user:get_tile(facing, 3) then
		table.insert(spellB.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spellB.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
		for j = 1, #self.tile_array, 1 do
			self.tile_array[j]:highlight(Highlight.Flash)
		end
    end]]

    spellB.can_move_to_func = function(tile)
        return true
    end

    local anim = spellB:get_animation()
    anim:load(SONICWAVE_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_frame(2, function()
        create_attack(user, props, user_tile:get_tile(facing, 1), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 2), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Up, 1), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Down, 1), team, field)
    end)
    anim:on_frame(18, function()
        create_attack(user, props, user_tile:get_tile(facing, 3), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Up, 1), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Down, 1), team, field)
    end)
    anim:on_frame(24, function()
        create_attack(user, props, user_tile:get_tile(facing, 2), team, field)
    end)
    anim:on_frame(39, function()
        create_attack(user, props, user_tile:get_tile(facing, 3), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Up, 1), team, field)
        create_attack(user, props, user_tile:get_tile(facing, 3):get_tile(Direction.Down, 1), team, field)
    end)
    anim:on_complete(function()
        spellB:erase()
    end)

    spellB.battle_end_func = function(self)
        spellB:erase()
    end

    --[[local breath_two = breath_two(props, user)
    field:spawn(breath_two, user_tile)

    local breath_three = breath_three(props, user)
    field:spawn(breath_three, user_tile)]]

    field:spawn(spellB, user_tile)

    return spellB
end

--[[function breath_two(props, user)
    local spell2 = Battle.Spell.new(user:get_team())
    spell2:set_facing(user:get_facing())
    spell2:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake,
			Element.None,
			user:get_context(),
			Drag.None
		)
    )
	local do_once = true
	spell2.tile_array = {}
	local field = user:get_field()
	local facing = user:get_facing()
	if user:get_tile(facing, 2) then table.insert(spell2.tile_array, user:get_tile(facing, 2)) end
	if user:get_tile(facing, 3) then
		table.insert(spell2.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spell2.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spell2.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spell2.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
    end

    spell2.battle_end_func = function(self)
        spell2:erase()
    end

    spell2:get_animation():on_complete(function()
        spell2:erase()
    end)
    return spell2
end

function breath_three(props, user)
    local spell3 = Battle.Spell.new(user:get_team())
    spell3:set_facing(user:get_facing())
    spell3:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake | Hit.Flash ,
			Element.None,
			user:get_context(),
			Drag.None
		)
    )
	local do_once = true
	local facing = user:get_facing()
	spell3.tile_array = {}
	local field = user:get_field()
	if user:get_tile(facing, 3) then
		table.insert(spell3.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spell3.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spell3.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spell3.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
    end

    spell3.battle_end_func = function(self)
        spell3:erase()
    end

    spell3:get_animation():on_complete(function()
        spell3:erase()
    end)
    return spell3
end]]

function create_attack(owner, props, tile, team, field)
    --[[local spawn_attack
    spawn_attack = function()
        if tile == nil or tile:is_edge() then return end]]
         
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flinch | Hit.Flash, 
        props.element, 
        owner:get_id(), 
        Drag.new())
    )
     
    local animation = spell:get_animation()
    animation:load(_modpath.."attack.animation")
    animation:set_state("0")
    --[[animation:on_complete(function()
        spell:erase()
    end)]]
     
    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        animation:on_complete(function()
            spell:delete()
        end)
    end
     
    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "8", math.random(-7,7), math.random(-7,7), field, self:get_current_tile())
    end

    spell.delete_func = function(self)
        print("Spell deleted at tile ("..tile:x()..";"..tile:y()..")")
    end
     
    spell.can_move_to_func = function(tile)
        return true
    end
     
    field:spawn(spell, tile)
    --[[end

    spawn_attack()]]
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end