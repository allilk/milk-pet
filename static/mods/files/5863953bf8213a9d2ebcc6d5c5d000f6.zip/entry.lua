local bomb = include('bomb/bomb.lua')
 
bomb.name="IceBall"
bomb.damage=120
bomb.element=Element.Aqua
bomb.description = "Frz 3rd panel ahead"
bomb.codes = {"F","I","M","Q","S","*"}

function package_init(package)
    package:declare_package_id("rune.legacy.iceball")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"F","I","M","Q","S","*"})
 
    local props = package:get_card_props()
    props.shortname = "IceBall"
    props.damage = 120
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Freezes 3rd panel ahead"
   end

   card_create_action = bomb.card_create_action
