local DAMAGE = 20
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local SPARKLES_TEXTURE = Engine.load_texture(_folderpath.."sparkles.png")
local SPARKLES_ANIMPATH = _folderpath.."sparkles.animation"
local HEART_TEXTURE = Engine.load_texture(_folderpath.."heart.png")
local HEART_ANIMPATH = _folderpath.."heart.animation"
local HEAL_TEXTURE = Engine.load_texture(_folderpath.."spell_heal.png")
local HEAL_ANIMPATH = _folderpath.."spell_heal.animation"
local HEAL_AUDIO = Engine.load_audio(_folderpath.."heal.ogg")
local ROLL_TEXTURE = Engine.load_texture(_folderpath.."roll.png")
local ROLL_ANIMPATH = _folderpath.."roll.animation"
local ROLL_SPARKLES_TEXTURE = Engine.load_texture(_folderpath.."roll_sparkles.png")
local ROLL_WARP_AUDIO = Engine.load_audio(_folderpath.."roll-warp.ogg")
local ROLLWHIP_AUDIO = Engine.load_audio(_folderpath.."rollwhip.ogg")
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe6-spawn.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local roll = {
    codes = {"R","*"},
    shortname = "Roll",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.None,
    description = "Attacks 1 enemy and heals you",
    long_description = "Attacks 1 enemy, then heals you with a healing heart",
    can_boost = true,
    card_class = CardClass.Mega,
    limit = 4
}

roll.card_create_action = function(actor)
	props = Battle.CardProperties.new()
    props.shortname = roll.shortname
    props.damage = roll.damage
    props.time_freeze = roll.time_freeze
    props.element = roll.element
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_metadata(props)
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
		actor:hide()

        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local team_check = function(ent)
            if not user:is_team(ent:get_team()) then
                return true
            end
        end

        --[[local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end]]
    
        --local tile1_front = nil
        local targeted = false
        local tile1_check = false
        local tile2_check = false
        local tile_array1 = {}
        local enemy_tile
        --[[local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)
        enemy_tile = enemy_list[1]:get_tile(Direction.reverse(facing), 1)]]
        if facing == Direction.Right then
            for i = 1, 6, 1 do
                for j = 1, 3, 1 do
                    if i > self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                            tile2_check = tile2 and tile2 ~= nil and not tile2:is_edge() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        else
            for i = 6, 1, -1 do
                for j = 1, 3, 1 do
                    if i < self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                            tile2_check = tile2 and tile2 ~= nil and not tile2:is_edge() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        end

        local var1
        local var2

		local step1 = Battle.Step.new()

        self.roll = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                --
                local roll2 = Battle.Artifact.new()
                roll2:set_facing(facing)
                local roll2_sprite = roll2:sprite()
		    	roll2_sprite:set_texture(ROLL_TEXTURE, true)
		    	roll2_sprite:set_layer(-3)
                local roll2_anim = roll2:get_animation()
                roll2_anim:load(ROLL_ANIMPATH)
                roll2_anim:set_state("R2")
		    	roll2_anim:refresh(roll2_sprite)
                for j=5, 21, 8 do
                    roll2_anim:on_frame(j, function()
                        if j==5 then
                            Engine.play_audio(ROLLWHIP_AUDIO, AudioPriority.High)
                        end
                        create_attack(user, props, team, facing, field, enemy_tile:get_tile(facing,1))
                    end)
                end
                roll2_anim:on_frame(35, function()
                    Engine.play_audio(ROLL_WARP_AUDIO, AudioPriority.High)
                    if math.random(1,2) == 1 then
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -73.0*2, -4, field, enemy_tile)
                    else
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -73.0*2, -4, field, enemy_tile)
                    end
                end)
                roll2_anim:on_frame(36, function()
                    if math.random(1,2) == 1 then
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -134.0*2, -4, field, enemy_tile)
                    else
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -134.0*2, -4, field, enemy_tile)
                    end
                end)
                roll2_anim:on_complete(function()
                    roll2:erase()
                end)
                --
                local rollsprk = Battle.Artifact.new()
                local sprk_sprite = rollsprk:sprite()
		    	sprk_sprite:set_texture(ROLL_SPARKLES_TEXTURE, true)
		    	sprk_sprite:set_layer(-3)
                local sprk_anim = rollsprk:get_animation()
                sprk_anim:load(ROLL_ANIMPATH)
                sprk_anim:set_state("R1")
		    	sprk_anim:refresh(sprk_sprite)
                sprk_anim:set_playback(Playback.Once)
                sprk_anim:on_complete(function()
                    rollsprk:erase()
                end)
                --
                ref.roll = Battle.Artifact.new()
                ref.roll:set_facing(facing)
                local roll_sprite = ref.roll:sprite()
		    	roll_sprite:set_texture(ROLL_TEXTURE, true)
		    	roll_sprite:set_layer(-3)
                local roll_anim = ref.roll:get_animation()
                roll_anim:load(ROLL_ANIMPATH)
                --[[if self_tile ~= nil or not self_tile:is_hole() then
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
                    forte_anim:set_state("0")
		    	    forte_anim:refresh(forte_sprite)
				else
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
                    forte_anim:set_state("1")
		    	    forte_anim:refresh(forte_sprite)
				end]]
                if targeted then
                    print("targeted ON")
                    roll_anim:set_state("R1")
                    roll_anim:refresh(roll_sprite)
                else
                    print("targeted OFF")
                    roll_anim:set_state("R1_NOTARGET")
                    roll_anim:refresh(roll_sprite)
                end
                --roll_anim:set_state("R1")
		    	--roll_anim:refresh(roll_sprite)
                roll_anim:set_playback(Playback.Once)
                roll_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                roll_anim:on_frame(23, function()
                    Engine.play_audio(ROLL_WARP_AUDIO, AudioPriority.High)
                    if math.random(1,2) == 1 then
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -59.0*2, -4, field, ref.tile)
                    else
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -59.0*2, -4, field, ref.tile)
                    end
                end)
                roll_anim:on_frame(24, function()
                    Engine.play_audio(ROLL_WARP_AUDIO, AudioPriority.High)
                    if math.random(1,2) == 1 then
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -118.0*2, -4, field, ref.tile)
                    else
                        create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -118.0*2, -4, field, ref.tile)
                    end
                end)
                if targeted then
                    roll_anim:on_frame(25, function()
                        if math.random(1,2) == 1 then
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -118.0*2, -4, field, enemy_tile)
                        else
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -118.0*2, -4, field, enemy_tile)
                        end
                    end)
                    roll_anim:on_frame(26, function()
                        if math.random(1,2) == 1 then
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -73.0*2, -4, field, enemy_tile)
                        else
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -73.0*2, -4, field, enemy_tile)
                        end
                    end)
                    roll_anim:on_frame(27, function()
                        if math.random(1,2) == 1 then
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -59.0*2, -4, field, enemy_tile)
                        else
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -59.0*2, -4, field, enemy_tile)
                        end
                    end)
                    roll_anim:on_frame(28, function()
                        if math.random(1,2) == 1 then
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, -44.0*2, -4, field, enemy_tile)
                        else
                            create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, -44.0*2, -4, field, enemy_tile)
                        end
                        field:spawn(roll2, enemy_tile)
                    end)
                end
		    	--[[roll_anim:on_complete(function()
		    		ref.roll:erase()
                    step1:complete_step()
		    	end)]]
                if targeted then
                    var1 = roll2_anim
                    var2 = 37
                else
                    var1 = roll_anim
                    var2 = 25
                end
                var1:on_frame(var2, function()
                    actor:reveal()
                    create_heart(user, props, field, ref.tile)
                end)
                var1:on_complete(function()
		    		ref.roll:erase()
                    step1:complete_step()
                end)
                field:spawn(rollsprk, ref.tile)
                field:spawn(ref.roll, ref.tile)
                create_effect(facing, ROLL_SPARKLES_TEXTURE, ROLL_ANIMPATH, "0", 0, 0, -4, field, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_attack(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )

    local anim = spell:get_animation()
    anim:load(_folderpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
		if facing == Direction.Right then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", -20, -15, -999999, field, self:get_current_tile())
		else
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", 20, -15, -999999, field, self:get_current_tile())
		end
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
		end
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

    return spell
end

function create_heart(user, props, field, tile)
    local y_offset = -360.0
    local heart = Battle.Artifact.new()
    heart:set_facing(Direction.Right)
    heart:set_texture(HEART_TEXTURE, true)
    heart:set_offset(0, y_offset)
    local heart_sprite = heart:sprite()
    heart_sprite:set_layer(-4)
    local heart_anim = heart:get_animation()
	heart_anim:load(HEART_ANIMPATH)
	heart_anim:set_state("0")
	heart_anim:refresh(heart_sprite)
    heart_anim:set_playback(Playback.Loop)
    local do_once = true
    local do_once_2 = true
    heart.update_func = function(self)
        heart:set_offset(0, y_offset)
        if y_offset >= 0 then
            if do_once_2 then
                do_once_2 = false
                create_recov(user, props, field, tile)
                heart:erase()
            end
        else
            y_offset = y_offset + 7.0
        end
        if do_once then
            do_once=false
            heart_anim:on_frame(1, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(3, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(5, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(7, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(9, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(11, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(13, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(15, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(17, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_frame(19, function()
                if math.random(1,2) == 1 then
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", 10.0*2, y_offset, -4, field, tile, 1)
                else
                    create_effect(Direction.Right, SPARKLES_TEXTURE, SPARKLES_ANIMPATH, "SPARKLE", -3.0*2, y_offset, -4, field, tile, 1)
                end
            end)
            heart_anim:on_complete(function()
                heart_anim:set_playback(Playback.Loop)
            end)
        end
    end
    field:spawn(heart, tile)
end

function create_recov(user, props, field, tile)
    local spell = Battle.Spell.new(Team.Other)
    spell:set_texture(HEAL_TEXTURE, true)
	spell:set_facing(Direction.Right)
    --[[spell:set_hit_props(
        HitProps.new(
            0,
			Hit.None,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )]]
	spell:sprite():set_layer(-1)
    local anim = spell:get_animation()
    anim:load(HEAL_ANIMPATH)
    anim:set_state("DEFAULT")
	spell:get_animation():on_complete(function()
		spell:erase()
	end)

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(HEAL_AUDIO, AudioPriority.High)

    field:spawn(spell, tile)
	user:set_health(user:get_health() + (props.damage * 3))

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return roll