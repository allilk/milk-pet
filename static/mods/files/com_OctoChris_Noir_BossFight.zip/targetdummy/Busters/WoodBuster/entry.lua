local HIT = nil
local THROW = nil
local SFX = nil
local CHARGE = nil
local chip = {}

function chip.card_create_action(user)
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
    action:set_lockout(make_async_lockout(2))
    local override_frames = {
        {1, 0.4}, {2, 0.05}, {3, 0.05}, {4, 0.05}, {4, 0.05}, {4, 0.166}, {4, 0.033}, {4, 0.033}, {4, 0.033}
    }

    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user and not user:is_deleted() and user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function create_tower(user, id, facing, team, tile)
        if not tile or (tile and not tile:is_walkable()) then return end
        local spell = graphic_init("spell", 0, 0, "tower.png", "tower.animation", -2, "DEFAULT", user, facing, true)
       -- if not tile:is_edge() then 
         --   spell:highlight_tile(Highlight.Solid)
        --end

        local new_dir = facing
        local attacking = false
        local actor = nil
        local highlighting = false

        spell:get_animation():on_frame(2, function()
            attacking = true
            highlighting = true
        end)

        spell:get_animation():on_frame(4, function()
            create_tower(user, id, spell:get_facing(), spell:get_team(), tile:get_tile(new_dir, 1))
            highlighting = false
        end)

        spell.on_spawn_func = function()
            Engine.play_audio(SFX, AudioPriority.High)
            if not user:is_deleted() then 
                local u_y = user:get_tile():y()
                local y = spell:get_tile():y()

                local dif = u_y - y

                if dif > 0 then 
                    new_dir = Direction.join(facing, Direction.Down)

                elseif dif < 0 then 
                    new_dir = Direction.join(facing, Direction.Up)

                end

            end
        end
        

        local hit_props = HitProps.new(
            50,
            Hit.Impact | Hit.Flinch | Hit.Breaking | Hit.Pierce | Hit.Flash,
            Element.Wood, 
            id, 
            Drag.None
        )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            if attacking then 
                self:get_current_tile():attack_entities(self)
            end

            if highlighting then 
                self:get_current_tile():highlight(Highlight.Solid)
            end
        end

        spell.collision_func = function(self)
            self:delete()
        end

        spell.attack_func = function(self)
            local artifact = graphic_init("artifact", 20, -30, "objFC_animations.png", "objFC_animations.animation", -2, "0", self, spell:get_facing(), true)
            Engine.play_audio(HIT, AudioPriority.High)

            spell:get_field():spawn(artifact, self:get_current_tile())
        end

        user:get_field():spawn(spell, tile)
    end

    action.execute_func = function(self)
        HIT = Engine.load_audio(_folderpath.."hit.ogg")
        THROW = Engine.load_audio(_folderpath.."raise.ogg")
        SFX = Engine.load_audio(_folderpath.."tower_sfx.ogg")
        CHARGE = Engine.load_audio(_folderpath.."charge.ogg")
        
        action:add_anim_action(1, function()
            Engine.play_audio(CHARGE, AudioPriority.High)
            local attach = self:add_attachment("HAND")
            local attach_sprite = attach:sprite()
            attach_sprite:set_texture(Engine.load_texture(_folderpath.."attachment.png"), false)
            attach_sprite:set_layer(-2)
            attach_sprite:enable_parent_shader(false)
            
            local attach_anim = attach:get_animation()
            attach_anim:load(_folderpath.."attachment.animation")
            attach_anim:set_state("DEFAULT")

        
        
        end)

        action:add_anim_action(3, function()
            Engine.play_audio(THROW, AudioPriority.High)
        end)

        action:add_anim_action(5, function()
            create_tower(user, user:get_id(), user:get_facing(), user:get_team(), user:get_tile(user:get_facing(), 1))

        end)

        
    end


    action.action_end_func = function()
        

    end


    return action
end

return chip