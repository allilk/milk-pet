local package_id = "com.OctoChris.mob.Noir"
local character_id = "com.OctoChris.enemy.Noir"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."targetdummy")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Noir")
  package:set_description("If you expect defeat, that is what you'll get...")
  package:set_speed(5)
  package:set_attack(5)
  package:set_health(1500)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  mob
    :create_spawner(character_id, Rank.V1)
    :spawn_at(5, 2)
end
