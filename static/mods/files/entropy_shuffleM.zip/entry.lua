function package_init(block)
    block:declare_package_id("Entropy.shufflemisc")
    block:set_name("ShuffleM")
    block:set_description("Shuffle music! (misc)")
    block:set_color(Blocks.White)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
	local music_player = Battle.Component.new(player, Lifetimes.Local)
	local cooldown = 1/60
	local shuffle = math.random(1,7)
	music_player.update_func = function(self, dt)
		if cooldown <= 0 then
			if shuffle == 1 then
				Engine.stream_music(_modpath.."music.mid")
				print ("[SHUFFLE] Now playing: The Prayer Bells do not Toll (Energy Breaker)")
			elseif shuffle ==2 then
				Engine.stream_music(_modpath.."music1.mid")
				print ("[SHUFFLE] Now playing: Battle (Final Fantasy 6)")
			elseif shuffle ==3 then
				Engine.stream_music(_modpath.."music2.mid")
				print ("[SHUFFLE] Now playing: Boss (Super Mario RPG)")
			elseif shuffle ==4 then
				Engine.stream_music(_modpath.."music3.mid")
				print ("[SHUFFLE] Now playing: Sinister Sundown (Kingdom Hearts 2)")
			elseif shuffle ==5 then
				Engine.stream_music(_modpath.."music4.mid")
				print ("[SHUFFLE] Now playing: Altair 1 (Bomberman 64)")
			elseif shuffle ==6 then
				Engine.stream_music(_modpath.."music5.mid")
				print ("[SHUFFLE] Now playing: Boss (Kirby 64)")
			elseif shuffle ==7 then
				Engine.stream_music(_modpath.."music6.mid")
				print ("[SHUFFLE] Now playing: Petunia Under Attack! (Paper Mario)")
			
			end
			self:eject()
		else
			cooldown = cooldown - dt
		end
	end
	player:register_component(music_player)
end