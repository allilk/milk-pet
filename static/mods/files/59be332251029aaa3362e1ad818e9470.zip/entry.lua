local DAMAGE = 110

local TEXTURE_KILBY = Engine.load_texture(_modpath.."kilby.png")
local ANIMPATH_KILBY = _modpath.."kilby.animation"
local AUDIO_SLASH = Engine.load_audio(_modpath.."slash.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-073-SideBamboo2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"H","O","S"})

    local props = package:get_card_props()
    props.shortname = "SidBamb2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "BambLance attck 3sq ahead"
    props.long_description = "2 square Bamboo Lance hits from the top of the area 3 squares ahead!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local field = user:get_field()

        local self_tile = user:get_tile()
        local x = self_tile:x()
        local y = self_tile:y()

        local direction = actor:get_facing()

        local x_offset = nil

        if direction == Direction.Right then
            x_offset = x + 3
        else
            x_offset = x - 3
        end

        local lance1 = create_bamboolance(user, props)
        local lance2 = create_bamboolance(user, props)
        local kilby = Battle.Artifact.new()
        kilby:set_facing(Direction.Right)
        local kilby_anim = kilby:get_animation()
		kilby:set_texture(TEXTURE_KILBY, true)
		kilby_anim:load(ANIMPATH_KILBY)
		kilby_anim:set_state("DEFAULT")
        kilby_anim:on_frame(5, function()
            Engine.play_audio(AUDIO_SLASH, AudioPriority.High)
            field:spawn(lance1, x_offset, 1)
        end)
        kilby_anim:on_frame(7, function()
            field:spawn(lance2, x_offset, 2)
        end)
        kilby_anim:on_frame(9, function()
            lance2:erase()
        end)
        kilby_anim:on_frame(10, function()
            lance1:erase()
        end)
        kilby_anim:on_complete(function()
            kilby:erase()
        end)
        field:spawn(kilby, x_offset, 0)
    end

    return action
end

function create_bamboolance(user, props)
    local spell = Battle.Spell.new(user:get_team())
    local field = user:get_field()
    local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

    return spell
end