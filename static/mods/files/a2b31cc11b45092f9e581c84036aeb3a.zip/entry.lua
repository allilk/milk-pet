function package_init(package) 
    package:declare_package_id("com.Dawn.JojoReference.Oraora")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'O'})

    local props = package:get_card_props()
    props.shortname = "RushAtk"
    props.damage = 20
    props.time_freeze = false
    props.element = Element.Break
    props.card_class = CardClass.Giga
    props.description = "Ceaseless stream of punches!"
	props.can_boost = true
	props.limit = 1
	props.long_description = "Stand firm and unleash your assault!"
	props.can_boost = false
end


function card_create_action(player, props)
    local rapid_buster_cooldown = 0
    local rapid_buster_cooldown_max = 10
    local feather = Engine.load_texture(_folderpath.."feather.png")
    local action = Battle.CardAction.new(player, "PLAYER_IDLE")
    local is_rapid_buster = true
	local stand_filter = function(c)
		return Battle.Character.from(c) ~= nil and c:get_health() > 0 or Battle.Obstacle.from(c) ~= nil and c:get_health() > 0
	end
	local facing = player:get_facing()
	local facing_away = player:get_facing_away()
	local direction_table = {
		facing,
		Direction.join(facing, Direction.Up),
		Direction.join(facing, Direction.Down),
		Direction.Up,
		Direction.Down,
		facing_away,
		Direction.join(facing_away, Direction.Up),
		Direction.join(facing_away, Direction.Down)
	}
	local stand_tile = nil
	local starman_platinum = Battle.Artifact.new()
	starman_platinum:set_facing(facing)
    action:set_lockout(make_sequence_lockout())
	action.action_end_func = function(self)
		if not starman_platinum:is_deleted() then starman_platinum:erase() end
	end
    action.execute_func = function(self, user)
		starman_platinum:set_texture(Engine.load_texture(_folderpath.."battle_compressed.png"))
		local stand_anim = starman_platinum:get_animation()
		local stand_sprite = starman_platinum:sprite()
		stand_sprite:set_layer(-2)
		stand_anim:load(_folderpath.."battle_compressed.animation")
		stand_anim:set_state("PLAYER_IDLE")
		stand_anim:refresh(stand_sprite)
		local field = user:get_field()
		for i = 1, #direction_table, 1 do
			local tile = user:get_tile(direction_table[i], 1)
			if tile and not tile:is_edge() and #tile:find_entities(stand_filter) == 0 then stand_tile = tile break end
		end
		if stand_tile ~= nil then field:spawn(starman_platinum, stand_tile) end
        local step = Battle.Step.new()
        local tile = player:get_tile(player:get_facing(), 1)
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)
        local cycle_count = 0
        local fail_check = false
        step.update_func = function(self, dt)
            if rapid_buster_cooldown <= 0 then
				if player:input_has(Input.Released.Use) or not player:input_has(Input.Held.Use) then
					is_rapid_buster = false
				end
                if not is_rapid_buster then
                    player:get_animation():set_state("PLAYER_IDLE")
                    self:complete_step()
                else
                    fail_check = false
                    cycle_count = cycle_count + 1
                    if cycle_count >= 3 then
                        fail_check = true
                        cycle_count = 0
                    end
                    rapid_buster_cooldown = rapid_buster_cooldown_max
                    local spell = buster_spam_action(player, props, feather)
                    field:spawn(spell, tile)
                    if not fail_check then
						if cycle_count % 2 == 0 then
							local spell2 = buster_spam_action(player, props, feather)
							field:spawn(spell2, tile2)
						else
							local spell3 = buster_spam_action(player, props, feather)
							field:spawn(spell3, tile3)
						end
                    end
                end
            else
                rapid_buster_cooldown = rapid_buster_cooldown - 1
            end
        end
        self:add_step(step)
    end
    return action
end

function buster_spam_action(dark_rock, props, texture)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_texture(texture)
    spell:set_float_shoe(true)
    spell:set_air_shoe(true)
    local anim = spell:get_animation()
    anim:load(_folderpath.."feather.animation")
    anim:set_state("LOWER")
    anim:refresh(spell:sprite())
    anim:set_playback(Playback.Loop)
    local x = 0
    if dark_rock:get_facing() == Direction.Right then x = x * - 1 end
    spell:set_offset(x, -40)
    spell:set_facing(dark_rock:get_facing())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Breaking,
            props.element,
            nil,
            Drag.None
        )
    )
    local current = 0
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if not self:is_sliding() then
            --Delete the attack if it hits an edge tile.
            if self:get_current_tile():is_edge() and self.slide_started then self:delete() end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true
            end)
        end
    end
    --Delete the buster shot on collision with something it can hurt.
    spell.collision_func = function(self, other)
        other:shake_camera(16.0, 0.3)
        self:delete()
    end
    spell.attack_func = function(self, other)
    end

    spell.delete_func = function(self) self:erase() end
    --Can move anywhere.
    spell.can_move_to_func = function(tile) return true end
    --Play the buster pea shot sound effect. Low priority so as not to be too annoying, but also so it can override itself.
    Engine.play_audio(AudioType.Meteor, AudioPriority.Low)
    return spell
end