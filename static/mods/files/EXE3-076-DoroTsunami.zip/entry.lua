local DAMAGE = 100

local TSUNAMI_TEXTURE = Engine.load_texture(_modpath.."tsunami.png")
local TSUNAMI_ANIMPATH = _modpath.."tsunami.animation"
local TSUNAMI_AUDIO1 = Engine.load_audio(_modpath.."tsunami1.ogg")
local TSUNAMI_AUDIO2 = Engine.load_audio(_modpath.."tsunami2.ogg")
local TSUNAMI_AUDIO3 = Engine.load_audio(_modpath.."tsunami3.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE3-076-DoroTsunami")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"D","G","M","V","Z"})

    local props = package:get_card_props()
    props.shortname = "MudTsnm"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "MudTsunam moves 3sq vertical"
    props.long_description = "Creates a tsunami of mud that travels 3 squares vertically"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.050},{2,0.050},{3,0.050},{4,0.050},{5,0.255}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        local tile = user:get_tile(direction, 1)
        self:add_anim_action(2,function()
            user:toggle_counter(true)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self:add_anim_action(5,function()
            create_tsunami_1(field:tile_at(tile:x(),1), team, user, props, direction, field, TSUNAMI_AUDIO1, true)
            create_tsunami_1(field:tile_at(tile:x(),2), team, user, props, direction, field, TSUNAMI_AUDIO1, true)
            create_tsunami_1(field:tile_at(tile:x(),3), team, user, props, direction, field, TSUNAMI_AUDIO1, true)
        end)
    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

function create_tsunami_1(tile, team, owner, props, direction, field, audio, msg)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_2(tile, team, owner, props, direction, field, TSUNAMI_AUDIO2)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other) 
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        if msg then
            print("Tsunami spawned at tile ("..tile:x()..";"..tile:y()..")")
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_tsunami_2(tile, team, owner, props, direction, field, audio)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_3(tile, team, owner, props, direction, field, TSUNAMI_AUDIO3)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other) 
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_tsunami_3(tile, team, owner, props, direction, field, audio)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_1(tile, team, owner, props, direction, field, TSUNAMI_AUDIO1, false)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other)  
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end