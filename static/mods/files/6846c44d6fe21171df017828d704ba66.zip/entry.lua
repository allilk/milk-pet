nonce = function() end

local DAMAGE = 80
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."widebust.png")
local SHOT_TEXTURE = Engine.load_texture(_modpath.."wideshot.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.ijuinpersonalterminalcompany.card.wideshot2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'L','M','N'})

    local props = package:get_card_props()
    props.shortname = "WideSht2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "3sq shotgun blast"
    props.long_description = "Fires 3sq Shotgun blast!"
    props.limit = 3


end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."widebust.animation")
		buster_anim:set_state("DEFAULT")
		
		local cannonshot = create_sonic_slash(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
	end
    return action
end


function create_sonic_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(SHOT_TEXTURE, true)
	anim:load(_modpath.."wideshot.animation")
	anim:set_state("DEFAULT")
	spell.update_func = function(self, dt)
		if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
			self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
			self:get_tile():get_tile(Direction.Up, 1):attack_entities(self)
		end
		if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
			self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
			self:get_tile():get_tile(Direction.Down, 1):attack_entities(self)
		end
		self:get_tile():attack_entities(self)
		if self:is_sliding() == false then
			if self:get_current_tile():is_edge() and self.slide_started then 
				self:delete()
			end 

			local dest = self:get_tile(spell:get_facing(), 1)
			local ref = self
			self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, 
				function()
					ref.slide_started = true 
				end
			)
		end

	end
    	spell.collision_func = function(self, other) 
		self:delete()
    	end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end