local DAMAGE = 260

local TEXTURE_DJANGO = Engine.load_texture(_modpath.."django.png")
local ANIMPATH_DJANGO = _modpath .. "django.animation"
local AUDIO_INPUT = Engine.load_audio(_modpath.."input.ogg")
local AUDIO_BIKE = Engine.load_audio(_modpath.."bike.ogg")
local AUDIO_SWORD = Engine.load_audio(_modpath.."sword.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = false

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-281-DjangoV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"D"})

    local props = package:get_card_props()
    props.shortname = "DjangoV3"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Hit enmy with bike rdng Djgo"
    props.long_description = "Django riding a bike forward and attacking"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local input_1 = false
        local input_2 = false
        local input_3 = false
        local input_success = false
        local success_played = false

        local actor = self:get_actor()
		actor:hide()

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local self_Y = self_tile:y()

        local query = function(ent)
			if not user:is_team(ent:get_team()) then
				return true
			end
		end

        local tile = nil
		if team == Team.Red then
			if direction == Direction.Right then
				tile = field:tile_at(1, self_Y)
			else
				tile = field:tile_at(6, self_Y)
			end
		else
			if direction == Direction.Left then
				tile = field:tile_at(6, self_Y)
			else
				tile = field:tile_at(1, self_Y)
			end
		end
		local tile_array = {}
		local count = 1
		local max = 6
		local tile_front = nil
        local enemy_front = false
		local check_front = false
        local target_locked = false
		
		for i = count, max, 1 do
			
			tile_front = tile:get_tile(direction, i)

            enemy_front = tile_front and #tile_front:find_characters(query) > 0
			
			check_front = tile_front and not user:is_team(tile_front:get_team()) and not tile_front:is_edge() and not tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(direction), 1):get_team())

            if enemy_front then
                if SHOW_DEBUG_TEXT then
                    print("TARGET LOCKED")
                end
                target_locked = true
				table.insert(tile_array, tile_front)
				break
			end
		end

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local remaining_time = 150

        local input_once = true
        local input_once_part_two = true
        local input_once_part_three = true

        local do_once = true
        local do_once_part_two = true
        local do_once_part_three = true
        local do_once_final = true
        step1.update_func = function(self, dt)
            remaining_time = remaining_time - 1
            if remaining_time > 0 and remaining_time < 100 then
                if SHOW_DEBUG_TEXT then
                    print("read")
                end
                if user:input_has(Input.Pressed.Left) and not input_1 and not input_2 and not input_3 and not input_success then
                    if SHOW_DEBUG_TEXT then
                        print("PRESSED")
                    end
                    input_1 = true
                end
                if user:input_has(Input.Pressed.Left) and input_1 and not input_2 and not input_3 and not input_success then
                    if SHOW_DEBUG_TEXT then
                        print("PRESSED")
                    end
                    input_2 = true
                end
                if user:input_has(Input.Pressed.Left) and input_1 and input_2 and not input_3 and not input_success then
                    if SHOW_DEBUG_TEXT then
                        print("PRESSED")
                    end
                    input_3 = true
                end
                if user:input_has(Input.Pressed.Use) and input_1 and input_2 and input_3 and not input_success then
                    if SHOW_DEBUG_TEXT then
                        print("PRESSED")
                    end
                    input_success = true
                end
                if input_success then
                    if not success_played then
                        print("SUCCESS")
                        Engine.play_audio(AUDIO_INPUT, AudioPriority.High)
                        success_played = true
                    end
                end
            end
            --[[if remaining_time <= 1 then
                print("read_input: OFF")
            end]]

            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
                local navi_sprite = ref.navi:sprite()
		    	navi_sprite:set_texture(TEXTURE_DJANGO, true)
		    	navi_sprite:set_layer(-99)
                local navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_DJANGO)
                navi_anim:set_state("SPAWN")
		    	navi_anim:refresh(navi_sprite)
                --[[navi_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)]]
                navi_anim:on_frame(12, function()
                    if not ref.tile:is_hole() then
                        ref.navi:shake_camera(30, 0.3)
                    end
                end)
		    	navi_anim:on_complete(function()
                    if not ref.tile:is_hole() then
                        if SHOW_DEBUG_TEXT then
                            print("DJANGO: RIDING")
                        end
		    		    navi_anim:set_state("RIDING_DELAY")
		    		    navi_anim:refresh(navi_sprite)
                    else
                        navi_anim:set_state("END")
		    		    navi_anim:refresh(navi_sprite)
                    end
		    	end)
                field:spawn(ref.navi, tile)
            end
            local anim = ref.navi:get_animation()

            local hitbox = create_attack(user, props, team, direction)
            local django_fx = Battle.Artifact.new()
            django_fx:set_facing(direction)
            local django_sprite = django_fx:sprite()
            django_sprite:set_texture(TEXTURE_DJANGO, true)
            django_sprite:set_layer(-9)
            local django_anim = django_fx:get_animation()
            django_anim:load(ANIMPATH_DJANGO)
            django_anim:set_state("SWORD")
            django_anim:refresh(django_sprite)
            django_anim:on_frame(4, function()
                Engine.play_audio(AUDIO_SWORD, AudioPriority.High)
            end)
            django_anim:on_frame(5, function()
                field:spawn(hitbox, django_fx:get_tile(direction, 1))
            end)
            django_anim:on_complete(function()
                hitbox:erase()
                django_fx:erase()
            end)

            local bike_spell = Battle.Spell.new(team)
            bike_spell:set_facing(direction)
            bike_spell:set_hit_props(HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Breaking, 
                props.element, 
                user:get_id(), 
                Drag.new())
            )
            bike_spell.slide_started = false
            local bike_sprite = bike_spell:sprite()
            bike_sprite:set_texture(TEXTURE_DJANGO)
            bike_sprite:set_layer(-3)
            local bike_anim = bike_spell:get_animation()
            bike_anim:load(ANIMPATH_DJANGO)
            bike_anim:set_state("RIDING")
            bike_anim:set_playback(Playback.Loop)
            bike_anim:refresh(bike_sprite)
            bike_spell.update_func = function(self, dt) 
                self:get_current_tile():attack_entities(self)
            
                if self:is_sliding() == false then 
                    if self:get_current_tile():is_hole() and self.slide_started then 
                        self:delete()
                    end
                
                    local dest = self:get_tile(direction, 1)
                    local ref = self
                    self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, function()
                        ref.slide_started = true 
                    end)
                end
            end
            bike_spell.attack_func = function(self)
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            end
            bike_spell.delete_func = function(self)
                remaining_time=0
                if input_success then
                    if target_locked then
                        if SHOW_DEBUG_TEXT then
                            print("NEW ATTACK")
                        end
                        anim:set_state("SWORD_DELAY")
		    	        anim:refresh(ref.navi:sprite())
                    else
                        if SHOW_DEBUG_TEXT then
                            print("THE END")
                        end
                        anim:set_state("END")
		    	        anim:refresh(ref.navi:sprite())
                    end
                else
                    if SHOW_DEBUG_TEXT then
                        print("THE END")
                    end
                    anim:set_state("END")
                    anim:refresh(ref.navi:sprite())
                end
            end
            bike_spell.can_move_to_func = function(tile)
                return true
            end

            if anim:get_state() == "RIDING_DELAY" then
                if do_once_part_two then
                    do_once_part_two = false
                    
                    anim:on_frame(1, function()
                        field:spawn(bike_spell, tile)
                        Engine.play_audio(AUDIO_BIKE, AudioPriority.High)
                    end)
                end
            end

            if anim:get_state() == "SWORD_DELAY" then
                if do_once_part_three then
                    do_once_part_three = false
                    
                    anim:on_frame(1, function()
                        field:spawn(django_fx, tile_array[1]:get_tile(Direction.reverse(direction), 1))
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
		    		    anim:refresh(ref.navi:sprite())
                    end)
                end
            end

            if anim:get_state() == "END" then
                if do_once_final then
                    do_once_final = false
                    
                    anim:on_complete(function()
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_attack(owner, props, team, direction)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        props.element, 
        owner:get_id(), 
        Drag.new())
    )
    spell.slide_started = false

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_texture(effect_texture, true)
    hitfx_sprite:set_layer(-999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end