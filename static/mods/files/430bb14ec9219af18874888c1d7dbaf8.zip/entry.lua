local package_id = "com.DawnPSIV.ReverentOne"
local character_id = "com.DawnPSIV.Enemy.ReverentOne"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Apostle Zio")
    package:set_description("The Destruction of all life...what a fine thing indeed!")
    package:set_speed(1)
    package:set_attack(100)
    package:set_health(2000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    print("_modpath is: ".._modpath)
    local texPath = _modpath.."bioplant.png"
    local animPath = _modpath.."bioplant.animation"
    mob:set_background(texPath, animPath, 0.0, 0.0)
    mob:stream_music(_modpath.."music.mid", 0, 0)

    mob:create_spawner(character_id, Rank.V1)
        :spawn_at(5, 2)
end