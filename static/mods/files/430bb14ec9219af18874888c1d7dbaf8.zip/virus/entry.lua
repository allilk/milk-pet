function find_best_target(zio)
    local target = zio:get_target()
    local field = zio:get_field()
    local query = function(c)
        return c:get_team() ~= zio:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 9999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

function create_attack(zio)
    local spell = Battle.Spell.new(zio:get_team())
    local boom_sound = Engine.load_audio(_modpath.."boom.ogg")
    spell:set_hit_props(
        HitProps.new(
            100,
            Hit.Flinch | Hit.Impact | Hit.Flash,
            Element.Fire,
            zio:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
    end
    Engine.play_audio(boom_sound, AudioPriority.Low)
    return spell
end

function create_punishment(zio)
    local spell = Battle.Spell.new(zio:get_team())
    spell:set_texture(zio:get_texture())
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(
        HitProps.new(
            350,
            Hit.Flinch | Hit.Impact | Hit.Flash,
            Element.Wind,
            zio:get_context(),
            Drag.None
        )
    )
    local animation = spell:get_animation()
    animation:copy_from(zio:get_animation())
    animation:set_state("DIVINE_PUNISHMENT")
    animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    animation:on_complete(function()
        spell:erase()
    end)
    local attack_delay = 30
    spell.update_func = function(self, dt)
        if attack_delay <= 0 then
            self:get_tile():attack_entities(self)
        else
            attack_delay = attack_delay - 1
        end
    end
    return spell
end

function package_init(self)
    self.teleport_wait = 60
    self._explosion_range = {}
    self._spawn_flames = false
    self._current_attack_delay = 0
    self._count_between_attack_sends = 10
    self:set_health(2000)
    self:set_texture(Engine.load_texture(_modpath.."zio.png"))
    
    local boom_texture = Engine.load_texture(_modpath.."spell_explosion.png")
    local boom_anim = _modpath.."spell_explosion.animation"
    local j = 1

    local anim = self:get_animation()
    anim:load(_modpath.."zio.animation")
    anim:set_state("IDLE")
    local ReverentDefense = Battle.DefenseRule.new(2,DefenseOrder.CollisionOnly)
    ReverentDefense.can_block_func = function(judge, attacker, defender)
        local attacker_props = attacker:copy_hit_props()
        if attacker_props.flags & Hit.Pierce ~= Hit.Pierce then
			judge:block_damage()
            judge:block_impact()
        end
    end
    
    local current_state_table = {"IDLE", "TAUNT", "FLAME_CROSS", "PUNISHMENT_POSE"}
    local current_state_index = 1
    local do_once = true
    local available_tiles = {}
    local field = nil
    self.on_spawn_func = function(self)
        field = self:get_field()
    end
    self:add_defense_rule(ReverentDefense)
    self.update_func = function(self, dt)
        if self:is_deleted() then return end
        if self._spawn_flames then
            if self._current_attack_delay <= 0 then
                local plane_blast = create_attack(self)
                local blast_fx = Battle.Artifact.new()
                blast_fx:set_texture(boom_texture)
                local blast_anim = blast_fx:get_animation()
                blast_anim:load(boom_anim)
                blast_anim:set_state("Default")
                blast_fx:sprite():set_layer(-2)
                blast_anim:on_complete(function()
                    blast_fx:erase()
                    plane_blast:erase()
                end)
                field:spawn(blast_fx, self._explosion_range[j])
                field:spawn(plane_blast, self._explosion_range[j])
                self._current_attack_delay = self._count_between_attack_sends
                if self:get_facing() == Direction.Right then
                    if j == #self._explosion_range then
                        self._spawn_flames = false
                    else
                        j = j + 1
                    end
                else
                    if j == 1 then
                        self._spawn_flames = false
                    else
                        j = j - 1
                    end
                end
            else
                self._current_attack_delay = self._current_attack_delay - 1
            end
        end
        if current_state_table[current_state_index] == "TAUNT" and do_once then
            if do_once then
                print("taunting")
                anim:set_state("TAUNT")
                anim:on_complete(function()
                    anim:set_state("IDLE")
                    current_state_index = 1
                    self.teleport_wait = 60
                end)
                do_once = false
            end
        elseif current_state_table[current_state_index] == "PUNISHMENT_POSE" and do_once then
            if do_once then
                anim:set_state("PUNISHMENT_POSE")
                anim:on_complete(function()
                    anim:set_state("IDLE")
                    current_state_index = 1
                    self.teleport_wait = 60
                end)
            end
            local target = find_best_target(self)
            target_tile = self:get_tile(self:get_facing(), 3)
            if target and not target:is_deleted() then
                target_tile = target:get_tile()
            end
            local attack = create_punishment(self)
            field:spawn(attack, target_tile)
            target_tile:set_state(TileState.Normal)
            do_once = false
        elseif current_state_table[current_state_index] == "FLAME_CROSS" and do_once then
            if do_once then
                print("flame cross attack")
                anim:set_state("FLAME_CROSS")
                anim:on_frame(7, function()
                    self._spawn_flames = true
                end)
                anim:on_complete(function()
                    anim:set_state("IDLE")
                    current_state_index = 1
                    self.teleport_wait = 60
                end)
                self._explosion_range = {}
                for i = 1, 6, 1 do
                    local tile = field:tile_at(i, 2)
                    local top_tile = field:tile_at(i, 2):get_tile(Direction.Up, 1)
                    local bottom_tile = field:tile_at(i, 2):get_tile(Direction.Down, 1)
                    local team = self:get_team()
                    if tile and not tile:is_edge() and tile:get_team() ~= team or top_tile and not top_tile:is_edge() and top_tile:get_team() ~= team or bottom_tile and not bottom_tile:is_edge() and bottom_tile:get_team() ~= team then
                        if tile:x() > self:get_tile():x() and self:get_facing() == Direction.Right or tile:x() < self:get_tile():x() and self:get_facing() == Direction.Left then
                            if i % 2 == 0 then
                                table.insert(self._explosion_range, tile:get_tile(Direction.Up, 1))
                                table.insert(self._explosion_range, tile)
                                table.insert(self._explosion_range, tile:get_tile(Direction.Down, 1))
                            else
                                table.insert(self._explosion_range, tile:get_tile(Direction.Down, 1))
                                table.insert(self._explosion_range, tile)
                                table.insert(self._explosion_range, tile:get_tile(Direction.Up, 1))
                            end
                        end
                    end
                end
                if self:get_facing() == Direction.Right then
                    j = 1
                else
                    j = #self._explosion_range
                end
                do_once = false
            end
        elseif current_state_table[current_state_index] == "IDLE" and self.teleport_wait <= 0 then
            for i = 1, 6, 1 do
                for j = 1, 3, 1 do
                    local tile = field:tile_at(i, j)
                    if tile and tile:is_walkable() and not tile:is_edge() then table.insert(available_tiles, tile) end
                end
            end
            current_state_index = math.random(2, #current_state_table)
            self:teleport(available_tiles[math.random(1, #available_tiles)], ActionOrder.Voluntary, nil)
            self.teleport_wait = 60
            do_once = true
        else
            self.teleport_wait = self.teleport_wait - 1
        end
    end
end