local falzar_sound = Engine.load_audio(_modpath .. "falzar.ogg")
local boom_texture = Engine.load_texture(_modpath .. "spell_explosion.png")
local boom_anim = _modpath .. "spell_explosion.animation"
local FALZAR = Engine.load_texture(_modpath .. "falzarbod.png")
local FEATHER = Engine.load_texture(_modpath .. "feather.png")
local BREATH = Engine.load_texture(_modpath .. "breath.png")

function package_init(package)

    package:declare_package_id("com.isabelle.chip.falzar")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'X' }) --Dawn: uppercased the code for consistency with other mods.

    local props = package:get_card_props()
    props.shortname = "Falzar"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.None
    props.limit = 1
    props.card_class = CardClass.Giga
    props.can_boost = true
    props.description = "Falzar's storming tornado!"
	props.long_description = "Falzar's storming tornado!"

end

--[[
1. megaman is hidden
2. 10 feathers spawn from the sky
        (destroy all objects
        (attack
        (Feathers cannot be attack boosted. Each feather has a 9/16 chance to target the enemy, 7/16 chance to target a random blue panel. Feathers never hit the same panel twice in a row. Fires 10 feathers that can hit up to 5 times.
        (feathers disappear after hiting something even an empty tile
3. falzar spawns in + 4. falzar moves back a bit + 5. falzar moves foward opens mouth + 6. falzar breath attacks
        (hits once right infront of falzar
        (hits twice 2 tiles infront of falzar
        (hits 3 times 3 tiles and is wide sword range infront of falzar
4. remove falzar + 8. megaman is unhidden

--]]

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    local target_tile = nil
    local enemy_list = nil
    local repeat_feather = 10

    local hits = 0

    local feather_cooldown = 0 --Dawn: added a cooldown between feather spawns
    local original_feather_cooldown = 10
    local state_cooldown = 60
    local previous_panel = nil

    local field = actor:get_field()
    local user_tile = actor:get_current_tile()

    action.execute_func = function(self, user)
        -- Returns a list of all characters not on my team
        --Dawn: moved this function into action execute func to use the User variable.
        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
        local step1 = Battle.Step.new()
        local step2 = Battle.Step.new()
        local step3 = Battle.Step.new()
        local step4 = Battle.Step.new()

        local stunt_double = nil
        stunt_double = self:get_actor()
        local enemy_tiles = {}

        local falzar_spawned = false

        for i = 0, 6, 1 do
            for j = 0, 3, 1 do
                local tile = field:tile_at(i, j)
                if tile and not tile:is_edge() and tile:get_team() ~= user:get_team() then
                    table.insert(enemy_tiles, tile)
                end
            end
        end

        step1.update_func = function(self, dt)
            stunt_double:hide()
            self:complete_step()
        end

        step2.update_func = function(self, dt)
            --clear field
            if repeat_feather > 0 then
                if feather_cooldown <= 0 then
                    --Dawn: Implement the cooldown.
                    feather_cooldown = original_feather_cooldown
                    local randomNumber = math.random(1, 16)
					enemy_list = field:find_nearest_characters(user, enemy_filter) --Dawn: Use the correct inputs for the find nearest function.
                    if randomNumber <= 9 and hits <= 4 then
                        -- Find_nearest used with the filter to get the nearest character not on my team
                        -- It's an ordered list, so I access the first entry next
                        if enemy_list[1] then
                            target_tile = enemy_list[1]:get_current_tile()
                        else
                            target_tile = user:get_tile(user:get_facing(), 1)
                        end
                        if previous_panel == target_tile then
                            feather_cooldown = 0
                        else
                            hits = hits + 1
                            local feather = summon_feathers(props, user)
                            field:spawn(feather, target_tile) --Dawn: actually spawn the attack
                            repeat_feather = repeat_feather - 1--Dawn: decrement the feather count properly
                            previous_panel = target_tile

                        end
                    else
                        local player_check = enemy_list[1]:get_current_tile()
                        target_tile = enemy_tiles[math.random(1, #enemy_tiles)]
                        if player_check == target_tile then
                            --re run this loop with out sub tracking from count
                        else
                            if previous_panel == target_tile then
                                feather_cooldown = 0
                            else
                                local feather = summon_feathers(props, user)
                                field:spawn(feather, target_tile)--Dawn: actually spawn the attack
                                repeat_feather = repeat_feather - 1--Dawn: decrement the feather count properly
                                previous_panel = target_tile
                            end
                        end

                    end
                else
                    feather_cooldown = feather_cooldown - 1--Dawn: decrement the cooldown
                end
            else
                state_cooldown = state_cooldown - 1

                if state_cooldown == 0 then
                    self:complete_step()
                end
            end
        end

        step3.update_func = function(self, dt)
            --spawn falzar
            --do animation
            if falzar_spawned then return end
            summon_falzar(props, user, self)
            falzar_spawned = true
        end

        local buffer = 40

        step4.update_func = function(self, dt)

            if buffer <= 0 then
                stunt_double:reveal()
                self:complete_step()
            else
                buffer = buffer - 1
            end

        end
        self:add_step(step1)
        self:add_step(step2)
        self:add_step(step3)
        self:add_step(step4)
    end

    return action
end

function summon_feathers(props, user)
    local spell = Battle.Spell.new(user:get_team())

    spell:set_facing(user:get_facing())
    spell:set_texture(FEATHER)
    spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake,
			props.element,
			user:get_context(),
			Drag.None
		)
    )
    local anim = spell:get_animation()
    anim:load(_modpath .. "featheranim.animation")
    anim:set_state("0")
    anim:refresh(spell:sprite())
    spell:sprite():set_layer(-1)
    if spell:get_facing() == Direction.Right then
        spell:set_offset(-270.0, -270.0)
    else
        spell:set_offset(270.0, -270.0)
    end
    local delete_cooldown = 1
    spell.update_func = function(self, dt)
        if self:get_offset().x == 0 and self:get_offset().y == 0 then
            self:get_tile():attack_entities(self)
            if delete_cooldown <= 0 then
                self:shake_camera(4.0, 0.5)
                self:delete()
            else
                delete_cooldown = delete_cooldown - 1
            end
        else
            if spell:get_facing() == Direction.Right then
                spell:set_offset(self:get_offset().x + 27.0, self:get_offset().y + 27.0)
            else
                spell:set_offset(self:get_offset().x - 27.0, self:get_offset().y + 27.0)
            end
        end
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.delete_func = function(self)
        local tile = self:get_tile()
        local fx = Battle.Artifact.new()
        fx:set_texture(boom_texture, true)
        local animation = fx:get_animation()
        animation:load(boom_anim)
        animation:set_state("Default")
        animation:refresh(fx:sprite())
        animation:on_complete(function()
            fx:erase()
        end)
        Engine.play_audio(AudioType.Explode, AudioPriority.Low)
        self:get_field():spawn(fx, tile)
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    return spell

end

function summon_falzar(props, user, step)
    local tile = user:get_current_tile()
    local visual_artifact = Battle.Artifact.new()
    visual_artifact.alpha = 0
    visual_artifact.fadein = true
    local field = user:get_field()
    visual_artifact:set_texture(FALZAR)
    local visual_artifact_anim = visual_artifact:get_animation()
    visual_artifact_anim:load(_modpath .. "falzarbod.animation")
    visual_artifact_anim:set_state("FALZAR")

    visual_artifact:set_facing(user:get_facing())

    if visual_artifact:get_facing() == Direction.Right then
        visual_artifact:set_offset(-50, 100)
    else
        visual_artifact:set_offset(50, 100)
    end
	
    field:spawn(visual_artifact, tile)
    Engine.play_audio(AudioType.Appear, AudioPriority.Low)

    visual_artifact_anim:on_complete(function()
        visual_artifact.fadein = false 
    end)

    visual_artifact_anim:on_frame(2, function()
        local breath = summon_breath(props, user)
        field:spawn(breath, tile)
        Engine.play_audio(falzar_sound, AudioPriority.Low)
    end)

    visual_artifact.update_func = function(self, dt)
        if self.fadein == true then
            self.alpha = self.alpha + 20
            self.alpha = math.min(self.alpha, 510)
        else 
            self.alpha = self.alpha - 20
            self.alpha = math.max(self.alpha, 0)

            if self.alpha == 0 then
                visual_artifact:erase()
                step:complete_step()
            end
        end

        local opacity = math.min(self.alpha, 255)
        local white = self.alpha

        if white > 255 then 
            white = 510-white
        end

        self:set_color(Color.new(white, white, white, opacity))
    end

end

function summon_breath(props, user)
    local spellB = Battle.Spell.new(user:get_team())
	local facing = user:get_facing()
    spellB:set_facing(facing)
    spellB:set_texture(BREATH)
    spellB:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake,
			Element.None,
			user:get_context(),
			Drag.None
		)
    )
	local do_once = true
	local field = user:get_field()
	spellB.tile_array = {}
	if user:get_tile(facing, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 1)) end
	if user:get_tile(facing, 2) then table.insert(spellB.tile_array, user:get_tile(facing, 2)) end
	if user:get_tile(facing, 3) then
		table.insert(spellB.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spellB.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spellB.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
		for j = 1, #self.tile_array, 1 do
			self.tile_array[j]:highlight(Highlight.Flash)
		end
    end

    spellB.can_move_to_func = function()
        return true
    end

    local anim = spellB:get_animation()
    anim:load(_modpath .. "breath.animation")
    anim:set_state("BREATH")
    anim:refresh(spellB:sprite())
    spellB:sprite():set_layer(-1)

    if spellB:get_facing() == Direction.Right then
        spellB:set_offset(160, 35)
    else
        spellB:set_offset(-160, 35)
    end

    spellB.battle_end_func = function(self)
        spellB:erase()
    end

    spellB:get_animation():on_complete(function()
        spellB:erase()
    end)

    local user_tile = user:get_current_tile()
    local field = user:get_field()

    local breath_two = breath_two(props, user)
    field:spawn(breath_two, user_tile)

    local breath_three = breath_three(props, user)
    field:spawn(breath_three, user_tile)

    return spellB

end
function breath_two(props, user)
    local spell2 = Battle.Spell.new(user:get_team())
    spell2:set_facing(user:get_facing())
    spell2:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake,
			Element.None,
			user:get_context(),
			Drag.None
		)
    )
	local do_once = true
	spell2.tile_array = {}
	local field = user:get_field()
	local facing = user:get_facing()
	if user:get_tile(facing, 2) then table.insert(spell2.tile_array, user:get_tile(facing, 2)) end
	if user:get_tile(facing, 3) then
		table.insert(spell2.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spell2.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spell2.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spell2.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
    end

    spell2.battle_end_func = function(self)
        spell2:erase()
    end

    spell2:get_animation():on_complete(function()
        spell2:erase()
    end)
    return spell2

end
function breath_three(props, user)
    local spell3 = Battle.Spell.new(user:get_team())
    spell3:set_facing(user:get_facing())
    spell3:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Shake | Hit.Flash ,
			Element.None,
			user:get_context(),
			Drag.None
		)
    )
	local do_once = true
	local facing = user:get_facing()
	spell3.tile_array = {}
	local field = user:get_field()
	if user:get_tile(facing, 3) then
		table.insert(spell3.tile_array, user:get_tile(facing, 3))
		if user:get_tile(facing, 3):get_tile(Direction.Up, 1) then table.insert(spell3.tile_array, user:get_tile(facing, 3):get_tile(Direction.Up, 1)) end
		if user:get_tile(facing, 3):get_tile(Direction.Down, 1) then table.insert(spell3.tile_array, user:get_tile(facing, 3):get_tile(Direction.Down, 1)) end
	end
    spell3.update_func = function(self, dt)
		local own_tile = self:get_tile()
		if do_once then
			for i = 1, #self.tile_array, 1 do
				if self.tile_array[i] and not self.tile_array[i]:is_edge() then
					local hitbox = Battle.SharedHitbox.new(self, 0.016)
					hitbox:set_hit_props(self:copy_hit_props())
					field:spawn(hitbox, self.tile_array[i])
				end
			end
			do_once = false
		end
    end

    spell3.battle_end_func = function(self)
        spell3:erase()
    end

    spell3:get_animation():on_complete(function()
        spell3:erase()
    end)
    return spell3

end