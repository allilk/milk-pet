function package_init(package) 
    package:declare_package_id("com.alrysc.card.FlareGun2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'K','M', 'P', 'U'})

    local props = package:get_card_props()
    props.shortname = "MFlarGun"
    props.damage = 130
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Explds 3 pnls ahead!"
    props.limit = 2

end



local HIT = Engine.load_audio(_modpath.."hit.ogg")
local SHOOT = Engine.load_audio(_modpath.."cannon.ogg")
local EXPLOSION = Engine.load_audio(_modpath.."bombmiddle.ogg")


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        
        {1, 0.033}, {2, 0.0166}, {2, 0.033}, {2, 0.3}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function create_explosion(user, tile, facing, team, from_collision)
        from_collision = from_collision or false
        local explosion = graphic_init("artifact", 0, 0, "effects.png", "effects.animation", -4, "EXPLOSION", user, facing)
        local field = user:get_field()
        field:spawn(explosion, tile)

        if from_collision then return end

        local spell = Battle.Spell.new(team)
        spell:highlight_tile(Highlight.Solid)
        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch,
                Element.Fire, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            self:delete()
        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        field:spawn(spell, tile)
    end

    local function create_flare(user, tile)
        if not tile or tile:is_edge() then return end
        local spell = graphic_init("spell", 0, -48, "effects.png", "effects.animation", -4, "FLARE", user, user:get_facing())
        spell:highlight_tile(Highlight.Solid)
        local anim = spell:get_animation()

        local moving = false
        local found_target = false
        local collision = false
        local stopped = false

        local hit_props = HitProps.new(
                math.floor(props.damage/2),
                Hit.Impact | Hit.Flinch,
                Element.Fire, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        local counter = 0
        local tiles_moved = 0
        local tiles = {
            tile:get_tile(Direction.Up, 1),
            tile:get_tile(Direction.UpRight, 1),
            tile:get_tile(Direction.Right, 1),
            tile:get_tile(Direction.DownRight, 1),
            tile:get_tile(Direction.Down, 1),
            tile:get_tile(Direction.DownLeft, 1),
            tile:get_tile(Direction.Left, 1),
            tile:get_tile(Direction.UpLeft, 1)
        }
        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if not moving and not found_target then 
                for i=1, #tiles
                do
                    local chars = tiles[i]:find_characters(function(c)
                        return c:get_team() ~= self:get_team()
                    end)
                    if #chars > 0 then 
                        found_target = true
                        break
                    end
                end
            end


            if not found_target and not moving then 
                counter = counter + 1
            end

            if not stopped and not found_target and counter == 5 then 
                moving = true
                if self:is_sliding() == false then
                    if tiles_moved == 0 then 
                        Engine.play_audio(SHOOT, AudioPriority.Low)
                    end
                    if tiles_moved < 2 then 
                        tiles_moved = tiles_moved + 1
                        if self:get_current_tile():is_edge() and self.slide_started then 
                            self:delete()
            
                        end 
                        
                        local dest = self:get_tile(self:get_facing(), 1)
                        local ref = self
                        self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary,
                            function()
                                ref.slide_started = true 
                            end
                        )
                    else
                        stopped = true
                    end
                end
            end

            if found_target or stopped then 
                anim:set_state("FLARE_LOOP")
                anim:on_complete(function()
                    if not collision then 
                        Engine.play_audio(EXPLOSION, AudioPriority.Low)
                        local tile = self:get_current_tile()
                        tiles = {
                            tile,
                            tile:get_tile(Direction.Up, 1),
                            tile:get_tile(Direction.UpRight, 1),
                            tile:get_tile(Direction.Right, 1),
                            tile:get_tile(Direction.DownRight, 1),
                            tile:get_tile(Direction.Down, 1),
                            tile:get_tile(Direction.DownLeft, 1),
                            tile:get_tile(Direction.Left, 1),
                            tile:get_tile(Direction.UpLeft, 1)
                        }
                    end

                    for i=1, #tiles
                    do
                        local t = tiles[i]
                        if t and not t:is_edge() then 
                            create_explosion(user, t, self:get_facing(), self:get_team())
                        end

                    end

                    self:delete()
                end)
                anim:refresh(self:sprite())

                self.update_func = function(self)
                    self:get_current_tile():attack_entities(self)
                end
            end
        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        spell.collision_func = function(self)
            collision = true
            Engine.play_audio(EXPLOSION, AudioPriority.Low)
            create_explosion(user, self:get_current_tile(), self:get_facing(), self:get_team(), true)
            local shake_artifact = Battle.Artifact.new()
            local time = 0
            shake_artifact.update_func = function(self)
                    
                self:shake_camera(200, 0.016)
                if time == 8 then 
                    self:delete()
                end
            
                time = time+1
            end

            field:spawn(shake_artifact, tile)
            self:delete()

        end

        spell.can_move_to_func = function()
            return true
        end

        user:get_field():spawn(spell, tile)
    end

    action.execute_func = function(self)
        action:add_anim_action(3, function()
            local attach = self:add_attachment("Buster")
            local attach_sprite = attach:sprite()
            attach_sprite:set_texture(Engine.load_texture(_modpath.."attachment.png"), false)
            attach_sprite:set_layer(-2)
            attach_sprite:enable_parent_shader(false)
            
            local attach_anim = attach:get_animation()
            attach_anim:load(_modpath.."attachment.animation")
            attach_anim:set_state("DEFAULT")

        
        
        end)

        action:add_anim_action(4, function()
            create_flare(user, user:get_tile(user:get_facing(), 1), "FLARE")
            Engine.play_audio(SHOOT, AudioPriority.Low)

        end)

       
    end

    return action
end