function package_init(block)
    block:declare_package_id("com.Dawn.IPC.Sunglasses")
    block:set_name("Sungls")
    block:as_program()
    block:set_description("Blocks all light")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 0, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    local sunglasses = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
	sunglasses.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Blind
		return statuses
	end
	player:add_defense_rule(sunglasses)
end