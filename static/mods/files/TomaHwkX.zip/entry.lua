function package_init(package) 
    package:declare_package_id("com.alrysc.card.TomaHawkX")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'T','X'})

    local props = package:get_card_props()
    props.shortname = "TomaHwkX"
    props.damage = 160
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Circ stg or come back!"
    props.limit = 1

end



local HIT = Engine.load_audio(_modpath.."hit.ogg")
local THROW = Engine.load_audio(_modpath.."knife.ogg")

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        
        {1, 0.05}, {2, 0.033}, {3, 0.033}, {4, 0.15}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function create_tomahawk(user, tile)
        if not tile or tile:is_edge() then return end
        local field = user:get_field()
        local spell = graphic_init("spell", 0, 0, "tomahawk.png", "tomahawk.animation", -4, "DEFAULT", user, user:get_facing())
        spell:get_animation():set_playback(Playback.Loop)
        spell:highlight_tile(Highlight.Solid)
        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch,
                Element.Wood, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        spell.turn_count = 0
        spell.slide_dir = spell:get_facing()
        spell.orig_dir = spell.slide_dir
        spell.straight = false

        if tile:y() == 1 then
            spell.second_dir = Direction.Down
        elseif tile:y() == field:height() then 
            spell.second_dir = Direction.Up
        else
            spell.straight = true
            spell.second_dir = Direction.reverse(spell.slide_dir)
        end

        spell.speed = 7

        local new_spell = nil

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if not self:is_sliding() then 
                if self.turn_count == 0 then 
                    if self:get_tile(self.slide_dir, 1):is_edge() then 
                        self.speed = 4

                        if self.second_dir == Direction.reverse(self.orig_dir) then 
                            self.speed = 7
                        end
                        self.slide_dir = self.second_dir
                        self.turn_count = self.turn_count+1

                        if self.straight then 
                            new_spell = Battle.Spell.new(self:get_team())
                            new_spell.lifetime = math.ceil(self.speed/2)
                            new_spell.update_func = function(self) -- New self here
                                self:get_current_tile():attack_entities(self)
                                self.lifetime = self.lifetime - 1
                                if self.lifetime == 0 then 
                                    self:delete()
                                end
                            end

                            new_spell.attack_func = self.attack_func
                            new_spell.collision_func = self.collision_func
            
                            field:spawn(new_spell, self:get_current_tile())
                        end
        
                    end

                elseif self.turn_count == 2 or (self.straight and self.turn_count == 1) then 
                    if self:get_tile(self.slide_dir, 1):is_edge() then 
                        self:delete()
                        return
                    end 

                elseif self.turn_count == 1 then
                    if self:get_tile(self.slide_dir, 1):is_edge() then 
                        self.speed = 7
                        self.slide_dir = Direction.reverse(self.orig_dir)
                        self.turn_count = self.turn_count+1
        
                    end

                end


                local dest = self:get_tile(self.slide_dir, 1)
                local ref = self
                self:slide(dest, frames(self.speed), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end

        end

        spell.can_move_to_func = function()
            return true
        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        spell.collision_func = function(self)
            field:spawn(graphic_init("artifact", 0, 0, "effect.png", "effect.animation", -5, "DEFAULT", self, self:get_facing(), true), self:get_current_tile())
        end 


        field:spawn(spell, tile)
    end
    

    action.execute_func = function(self)
        action:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)

        
        
        end)

        action:add_anim_action(3, function()
            create_tomahawk(user, user:get_tile(user:get_facing(), 1))
            Engine.play_audio(THROW, AudioPriority.Low)

        end)

       
    end

    return action
end