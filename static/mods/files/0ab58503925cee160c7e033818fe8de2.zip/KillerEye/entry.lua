local shared_package_init = include("./character.lua")
local character_id = "com.louise_enemy_"
function package_init(character)
    local character_info = {
        name="KillerEye",
        hp=100,
        damage=50,
        palette=_folderpath.."V1.png",
        height=80,
    }
    if character:get_rank() == Rank.SP then
        character_info.damage = 200
        character_info.palette=_folderpath.."SP.png"
        character_info.hp = 230
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 120
        character_info.palette=_folderpath.."rare1.png"
        character_info.hp = 170
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 250
        character_info.palette=_folderpath.."rare2.png"
        character_info.hp = 250
    end
    shared_package_init(character,character_info)
end
