nonce = function() end

local DAMAGE = 200
local TEXTURE = Engine.load_texture(_modpath.."spell_zapring.png")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster_zapring.png")
local AUDIO = Engine.load_audio(_modpath.."fwish.ogg")
local AUDIO_HIT = Engine.load_audio(_modpath .. "hitsound.ogg")
local AUDIO_FIRE = Engine.load_audio(_modpath .. "fire.ogg")

function package_init(package) 
    package:declare_package_id("DJ.Phantom.fixed")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"*"})

    local props = package:get_card_props()
    props.shortname = "Phantom"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "DARK PHANTOM HAUNTS "
    props.long_description = "DARK PHANTOM BESTOWS BAD LUCK"
    props.card_class = CardClass.Dark
    props.limit = 1
end

--[[
    1. megaman loads buster
    2. zapring flies out
--]]

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."buster_zapring.animation")
		buster_anim:set_state("DEFAULT")
		
		local cannonshot = create_zap("DEFAULT", user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
	end
    return action
end

function create_zap(animation_state, user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(TEXTURE, true)
    spell:highlight_tile(Highlight.Solid)
	spell:set_height(16.0)
    
	local direction = user:get_facing()
    spell.slide_started = false
	
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Pierce | Hit.Flinch | Hit.Blind, 
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell:set_facing(direction)
	
    local anim = spell:get_animation()
    anim:load(_modpath.."spell_zapring.animation")
    anim:set_state(animation_state)

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other)
        local component = Battle.Component.new(other, Lifetimes.Local)
        local prev_panel = other:get_current_tile()
        local tile_state = nil

        component.update_func = function()
            if other:get_current_tile() ~= prev_panel then 
                prev_panel:set_state(TileState.Poison)
                prev_panel = other:get_current_tile()
            end
        end

        other:register_component(component) 
        
    end
	
	spell.collision_func = function(self, other)
        Engine.play_audio(AUDIO_HIT, AudioPriority.Highest)

		self:erase()
	end


    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO, AudioPriority.Low)

    Engine.play_audio(AUDIO_FIRE, AudioPriority.Highest)

   

    return spell
end