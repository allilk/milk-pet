local tile_audio = Engine.load_audio(_folderpath .. 'sfx.ogg')
local blast_sfx = Engine.load_audio(_folderpath .. "blast.ogg")
local mine_texture = Engine.load_texture(_folderpath .. "mine.png")
local mine_anim = _folderpath .. "mine.animation"
local fx = Engine.load_texture(_folderpath .. "fx.png")
local fx_anim = _folderpath .. "fx.animation"

function package_init(package)
	package:declare_package_id("com.louise.card.Mine")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'A', 'S', 'T' })

	local props = package:get_card_props()
	props.shortname = "Mine"
	props.damage = 200
	props.time_freeze = true
	props.element = Element.None
	props.description = "Places a mine in enmy area"
	props.long_description = "Places a mine in enmy area!"
	props.can_boost = false
	props.limit = 3
end

function card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
		local step1 = Battle.Step.new()
		local desired_tile = user:get_tile(user:get_facing(), 1)
		if desired_tile:is_edge() then
			return
		end
		---@type Entity
		local mine = create_mine(actor, props.damage)
		step1.update_func = function(self, dt)
			if (mine.done) then
				self:complete_step()
			end

		end

		self:add_step(step1)
	end
	return action
end

function create_mine(user, damage)
	local mine = Battle.Obstacle.new(Team.Other)
	mine:set_name("mine" .. tostring(user:get_team()))

	local mine_filter = function(obstacle)
		return obstacle:get_name() == "mine" .. tostring(user:get_team())
	end
	local mines = user:get_field():find_obstacles(mine_filter)

	local freed_tile = nil
	if (#mines > 1) then
		explode(user:get_field(), mines[1]:get_current_tile())
		mines[1]:erase()
		freed_tile = mines[1]:get_current_tile()
	end
	local valid_tiles = {}
	for x = 1, 6, 1 do
		for y = 1, 3, 1 do
			local tile = user:get_field():tile_at(x, y)
			if (tile:is_walkable() and is_tile_free_for_movement(tile, mine, user:get_team())) then
				table.insert(valid_tiles, tile)
			end
		end
	end
	if (freed_tile) then
		table.insert(valid_tiles, freed_tile)
	end
	shuffle(valid_tiles)

	local spawn_tile = valid_tiles[1]
	mine:set_facing(user:get_facing())
	mine:set_texture(mine_texture, true)
	local anim = mine:get_animation()
	anim:load(mine_anim)
	anim:set_state("DEFAULT")
	anim:refresh(mine:sprite())
	user:get_field():spawn(mine, spawn_tile)
	mine:set_health(0)
	mine.do_once = false

	mine.move_count = 119
	mine.i = 2
	mine.done = false
	mine.skip = true
	mine:set_hit_props(HitProps.new(damage, Hit.Impact | Hit.Flinch | Hit.Pierce | Hit.Flash, Element.None,
		user:get_context(),
		Drag.None))
	mine.update_func = function(self, dt)
		if (mine.move_count > 0) then
			if (mine.skip == true) then
				mine.skip = false
				return
			else
				mine.skip = true
			end
			mine:teleport(valid_tiles[mine.i], ActionOrder.Immediate, nil)
			Engine.play_audio(tile_audio, AudioPriority.High)
			mine.i = mine.i + 1
			mine.move_count = mine.move_count - 1
			if (mine.i > #valid_tiles) then
				mine.i = 1
			end
		else
			if (not mine.done) then
				mine.done = true
				mine:hide()
			else
				mine:get_current_tile():attack_entities(mine)
			end

		end
	end

	mine.collision_func = function()
		explode(mine:get_field(), mine:get_current_tile())
		mine:erase()
	end



	mine.can_move_to_func = function()
		return true
	end
	mine.x_dir = user:get_facing_away()
	mine.y_dir = Direction.Down
	mine.delete_func = function(self, dt)
		mine.cloud:erase();
	end
	return mine
end

function explode(field, tile)
	local artifact = Battle.Artifact.new()
	artifact:set_texture(fx)
	artifact:set_animation(fx_anim)
	--FX
	local anim = artifact:get_animation()
	anim:set_state("0")
	artifact:get_animation():refresh(artifact:sprite())
	anim:on_complete(function()
		artifact:erase()
	end)
	field:spawn(artifact, tile)
	Engine.play_audio(blast_sfx, AudioPriority.High)

end

function is_tile_free_for_movement(tile, character, team)
	--Basic check to see if a tile is suitable for a chracter of a team to move to

	if tile:get_team() == team then
		return false
	end
	if (tile:is_edge()) then
		return false
	end
	local occupants = tile:find_entities(function(ent)
		if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
			return true
		else
			return false
		end
	end)
	if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
		return true
	end
	if #occupants > 0 then
		return false
	end

	return true
end

--shuffle function to provide some randomness
function shuffle(tbl)
	for i = #tbl, 2, -1 do
		local j = math.random(i)
		tbl[i], tbl[j] = tbl[j], tbl[i]
	end
	return tbl
end
