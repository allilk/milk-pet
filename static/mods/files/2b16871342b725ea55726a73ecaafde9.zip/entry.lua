local cutman = include("cutman/cutman.lua")

local DAMAGE = 200

cutman.codes = {"C"}
cutman.shortname = "CutManV2"
cutman.damage = DAMAGE
cutman.time_freeze = true
cutman.element = Element.None
cutman.description = "Scissor attacks 1 square!"
cutman.long_description = "Snip attack to 1 square in front of you!"
cutman.can_boost = true
cutman.card_class = CardClass.Mega
cutman.memory = 50
cutman.limit = 1

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-210-CutManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(cutman.codes)

    local props = package:get_card_props()
    props.shortname = cutman.shortname
    props.damage = cutman.damage
    props.time_freeze = cutman.time_freeze
    props.element = cutman.element
    props.description = cutman.description
    props.long_description = cutman.long_description
    props.can_boost = cutman.can_boost
	props.card_class = cutman.card_class
	props.limit = cutman.limit
end

card_create_action = cutman.card_create_action