local AUDIO = Engine.load_audio(_modpath.."fire.ogg") 

local function create_flame_spell(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(Engine.load_texture(_modpath.."burn.png"))
    local animation = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell:highlight_tile(Highlight.Solid)
    animation:load(_modpath.."burn.animation")
    animation:set_state("0")
    animation:set_playback(Playback.Loop)
    animation:refresh(spell:sprite())
    spell:set_facing(user:get_facing())
    spell.has_spawned = false
    local tile = nil
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
    end
    spell.update_func = function(self, dt)
        tile:attack_entities(self)
    end
    return spell
end

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = "TailBrn2"
    props.damage = 130
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Atk 3 sqrs ahead with flamethrowr."
    props.long_description = "Attack 3 squares ahead with flamethrower."
    props.limit = 3

    package:declare_package_id("com.seabitty.sftailburn2")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({"D","P","Q"})
end

function card_create_action(user,props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local field = user:get_field()
    local frame1 = {1, 0.017}
    local frame2 = {1, 0.05}
    local frame3 = {2, 0.033}
    local tile_array = {}
    local self_tile = user:get_tile()
    local y = self_tile:y()
    local x = self_tile:x()
    local increment = 1
    if user:get_facing() == Direction.Left then increment = -1 end
    for i = 1, 3, 1 do
        local prospective_tile = field:tile_at(x+(i*increment), y)
        if prospective_tile and not prospective_tile:is_edge() then
            table.insert(tile_array, prospective_tile)
        end
    end
    local frames = make_frame_data(
        {
            frame1,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2
        }
    )
    action:override_animation_frames(frames)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local buster_attachment = self:add_attachment("BUSTER")
        local buster_sprite = buster_attachment:sprite()
        buster_sprite:set_texture(user:get_texture(), false)
        buster_sprite:set_layer(-2)
        local buster_animation = buster_attachment:get_animation()
        buster_animation:copy_from(user:get_animation())
        buster_animation:set_state("BUSTER")
        buster_animation:refresh(buster_sprite)

        self.flame1 = create_flame_spell(user, props)
        self.flame2 = create_flame_spell(user, props)
        self.flame3 = create_flame_spell(user, props)
        
        self:add_anim_action(5, function()
            if #tile_array > 0 then
                field:spawn(self.flame1, tile_array[1])
   	            end
        end)
		
        self:add_anim_action(9, function()
            if #tile_array > 1 then
                field:spawn(self.flame2, tile_array[2])
            end
        end)

        self:add_anim_action(13, function()
            if #tile_array > 2 then
                field:spawn(self.flame3, tile_array[3])
            end
        end)

	Engine.play_audio(AUDIO, AudioPriority.Low)		

        self:add_anim_action(32, function()
            if self.flame1.has_spawned then
                self.flame1:get_animation():set_state("1")
                self.flame1:get_animation():refresh(self.flame1:sprite())
                self.flame1:get_animation():on_complete(function()
                    self.flame1:erase()
                end)
            end
        end)

        self:add_anim_action(36, function()
            if self.flame2.has_spawned then
                self.flame2:get_animation():set_state("1")
                self.flame2:get_animation():refresh(self.flame2:sprite())
                self.flame2:get_animation():on_complete(function()
                    self.flame2:erase()
                end)
            end
        end)

        self:add_anim_action(40, function()
            if self.flame3.has_spawned then
                self.flame3:get_animation():set_state("1")
                self.flame3:get_animation():refresh(self.flame3:sprite())
                self.flame3:get_animation():on_complete(function()
                    self.flame3:erase()
                end)
            end
        end)
    end
    action.action_end_func = function(self)
        if not self.flame1:is_deleted() then self.flame1:erase() end
        if not self.flame2:is_deleted() then self.flame2:erase() end
        if not self.flame3:is_deleted() then self.flame3:erase() end
    end
    Engine.play_audio(AUDIO, AudioPriority.High)
    return action
end