
--local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster.png")
local ATK_TEXTURE = Engine.load_texture(_modpath.."twinfangtexture.png")
local SHOOT_AUDIO = Engine.load_audio(_modpath.."yoyothrow.ogg")
local HIT_AUDIO = Engine.load_audio(_modpath.."yoyohit.ogg")


function package_init(package) -- Basic stuff
    package:declare_package_id("hoov.card.twinfang2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"O","P","Q"})

    local props = package:get_card_props()
    props.shortname = "TwnFng2"
    props.damage = 100
    props.time_freeze = false
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Launch 2 fangs up and down"
    props.limit = 4

    -- assign the global resources
    
    --AUDIO = Engine.load_audio(_modpath.."firetower.ogg")
end

function card_create_action(self, props)
    print("in create_card_action()!")
    
    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function (self, user)
        --buster sprite
        local buster = action:add_attachment("Buster")
        buster:sprite():set_texture(user:get_texture(), true)
        buster:sprite():set_layer(-1)
        buster:sprite():enable_parent_shader(true)
      
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        local direction = user:get_facing()
        local tile = user:get_current_tile()
        --gotta add the create shot functions. use code from 3way 
        local shot1 = create_shot(user, tile, 1, props)
        local shot2 = create_shot(user, tile, 2, props)
        user:get_animation():on_frame(1, function()
            user:get_field():spawn(shot1, tile)
            user:get_field():spawn(shot2, tile)
            Engine.play_audio(SHOOT_AUDIO, AudioPriority.Low)
        end, false)

    end

    return action
end

function create_shot(user, tile, vertical, props)

    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(ATK_TEXTURE)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_modpath.."twinfang.animation")
    anim:set_state("SPAWN")
    anim:refresh(spell:sprite())

    anim:on_complete(function()

        anim:set_state("IDLE")
        anim:set_playback(Playback.Loop)
    end)
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell:set_elevation(20)
    local hasmoved = true --backwards kinda like if it's true it hasn't moved 
    local coredirection = user:get_facing()
    spell.update_func = function(self, dt)
        local direction = nil
        
        
        if hasmoved then
            if vertical == 1 then
                direction = Direction.Up
                --print("moveup")
            elseif vertical == 2 then
                direction = Direction.Down
                --print("movedown")
            else 
                print("INVALID INPUT WHY DID YOU DO THIS")
            end
        else
            direction = coredirection
            --print("movefoward")
        end
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(direction, 1)
        
        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            print("erased")
            spell:erase()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        spell:slide(tile, frames(4), frames(0), ActionOrder.Voluntary, nil)
        --tilecount = tilecount + 1
        hasmoved = false
        --- Attacks the entities this spell collides with.
        self:get_current_tile():attack_entities(self)
        --spell:highlight_tile(Highlight.Solid)
    end
    spell.collision_func = function(self, other)
        --a
        spell:erase()
        
    end
    spell.attack_func = function(self, other)
        Engine.play_audio(HIT_AUDIO, AudioPriority.Low)
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    return spell
end