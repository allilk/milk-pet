local texture = nil
local battle_animation_path = nil
local sword = include("sword/sword.lua")

function package_init(package) 
    print("modpath: ".._modpath)
	package:declare_package_id("com.frozenLake.player.Sonic")
    package:set_special_description("The fastest thing alive!")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_modpath.."face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."OW.animation")
    package:set_overworld_texture_path(_modpath.."OW.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
    player:set_name("Sonic")
    player:set_health(1000)
    player:set_element(Element.Wind)
    player:set_height(50.0)

    player:set_animation(_modpath.."battle.animation")
    player:set_texture(Engine.load_texture(_modpath.."battle.png"), true)
    player:set_fully_charged_color(Color.new(0,255,255,255))
    player:set_charge_position(0,-10)

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end

    player.special_attack_func = function(player)
        print("charged attack")
        local props = Battle.CardProperties:new()
        props.damage = player:get_attack_level()*20
        local sword_action = sword.card_create_action(player,props)
        return sword_action
    end

end

