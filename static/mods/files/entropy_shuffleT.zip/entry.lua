function package_init(block)
    block:declare_package_id("Entropy.shuffletouhou")
    block:set_name("ShuffleT")
    block:set_description("Shuffle music! (Touhou)")
    block:set_color(Blocks.White)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
	local music_player = Battle.Component.new(player, Lifetimes.Local)
	local cooldown = 1/60
	local shuffle = math.random(1,6)
	music_player.update_func = function(self, dt)
		if cooldown <= 0 then
			if shuffle == 1 then
				Engine.stream_music(_modpath.."music.mid")
				print ("[SHUFFLE] Now playing: Ghostly Band ~ Phantom Ensemble (Touhou 9)")
			elseif shuffle ==2 then
				Engine.stream_music(_modpath.."music1.mid")
				print ("[SHUFFLE] Now playing: Flowering Night (Touhou 9)")
			elseif shuffle ==3 then
				Engine.stream_music(_modpath.."music2.mid")
				print ("[SHUFFLE] Now playing: Adventure of the Lovestruck Tomboy (Touhou 9)")
			elseif shuffle ==4 then
				Engine.stream_music(_modpath.."music3.mid")
				print ("[SHUFFLE] Now playing: Pure Furies ~ Whereabouts of the Heart (Touhou 15)")
			elseif shuffle ==5 then
				Engine.stream_music(_modpath.."music4.mid")
				print ("[SHUFFLE] Now playing: Faint Dream ~ Inanimate Dream (Touhou 4)")
			elseif shuffle ==6 then
				Engine.stream_music(_modpath.."music5.mid")
				print ("[SHUFFLE] Now playing: Eternal Spring Dream (Touhou 15)")
			end
			self:eject()
		else
			cooldown = cooldown - dt
		end
	end
	player:register_component(music_player)
end