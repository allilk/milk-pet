local DAMAGE = 100

local OLDWOOD_TEXTURE = Engine.load_texture(_modpath.."oldwood.png")
local OLDWOOD_ANIMPATH = _modpath.."oldwood.animation"
local AREASTEAL_AUDIO = Engine.load_audio(_modpath.."exe2-areasteal.ogg")
local STONECUBE_AUDIO = Engine.load_audio(_modpath.."exe2-stonecube.ogg")
local WOODYTOWER_TEXTURE = Engine.load_texture(_modpath.."woodytower.png")
local WOODYTOWER_ANIMPATH = _modpath.."woodytower.animation"
local WOODYTOWER_AUDIO = Engine.load_audio(_modpath.."exe2-woodytower.ogg")

local HIT_TEXTURE = Engine.load_texture(_modpath.."guard_hit.png")
local HIT_ANIMPATH = _modpath.."guard_hit.animation"
local HIT_AUDIO = Engine.load_audio(_modpath.."exe2-tink.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-113-OldWood")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"C","M","S","T","W"})

    local props = package:get_card_props()
    props.shortname = "OldWood"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Wood
    props.description = "Summons     an Old Wood!"
    props.long_description = "Summon an Old Wood from the hole in front of you!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()
        local spawn_tile = user:get_tile(direction, 1)
        local attacked = false

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()
        self.loops = 3

        local ref = self

        local do_once = true
        local do_once_2 = true
        local do_once_3 = true
        local do_once_4 = true
        local do_once_5 = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
		    	ref.navi:sprite():set_texture(OLDWOOD_TEXTURE, true)
		    	ref.navi:sprite():set_layer(-3)
                ref.navi:set_offset(0.0, -356.0)

                local anim = ref.navi:get_animation()
                anim:load(OLDWOOD_ANIMPATH)
                anim:set_state("DELAY1")
                anim:set_playback(Playback.Loop)
		    	anim:refresh(ref.navi:sprite())
		    	anim:on_complete(function()
                    print("Sphere spawned")
                    Engine.play_audio(AREASTEAL_AUDIO, AudioPriority.High)
		    		anim:set_state("SPHERE")
		    		anim:refresh(ref.navi:sprite())
		    	end)
                field:spawn(ref.navi, spawn_tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "SPHERE" then
                if ref.navi:get_offset().y >= -13 then
                    if do_once_2 then
                        do_once_2 = false
                        ref.navi:set_offset(0.0, 0.0)
                        if spawn_tile:is_hole() then
                            print("Spawn tile IS a hole!")
                            print("GodStone spawned")
		    		        anim:set_state("OLDWOOD_SPAWN")
                            anim:set_playback(Playback.Once)
		    		        anim:refresh(ref.navi:sprite())
                            anim:on_frame(1, function()
                                Engine.play_audio(STONECUBE_AUDIO, AudioPriority.Highest)
                            end)
                            anim:on_complete(function()
                                anim:set_state("OLDWOOD_LOOP1")
                                anim:refresh(ref.navi:sprite())
                            end)
                        else
                            print("Spawn tile is NOT a hole!")
                            Engine.play_audio(HIT_AUDIO, AudioPriority.Highest)
                            create_effect(HIT_TEXTURE, HIT_ANIMPATH, "0", 0, 0, field, spawn_tile)
                            anim:set_state("DELAY2")
		    		        anim:refresh(ref.navi:sprite())
                            anim:on_complete(function()
                                ref.navi:erase()
                                step1:complete_step()
                            end)
                        end
                    end
                else
                    ref.navi:set_offset(0.0, ref.navi:get_offset().y + 13.0)
                end
            end
            if anim:get_state() == "OLDWOOD_LOOP1" then
		    	anim:on_complete(function()
		    		anim:set_state("OLDWOOD_LOOP2")
                    anim:set_playback(Playback.Loop)
		    		anim:refresh(ref.navi:sprite())
		    	end)
            end
            if anim:get_state() == "OLDWOOD_LOOP2" then
                anim:on_frame(1, function()
                    if do_once_4 then
                        do_once_4 = false
                        print("LOOP2")
                        woodytower_spawner(field, user, props, team, direction, spawn_tile, attacked, ref.navi, ref.navi:sprite())
                    end
                end)
                anim:on_complete(function()
                    --print("COMP2")
                    if attacked then
                        anim:set_state("OLDWOOD_LOOP3")
                        anim:set_playback(Playback.Loop)
                        anim:refresh(ref.navi:sprite())
                    end
                end)
            end
            if anim:get_state() == "OLDWOOD_LOOP3" then
                if do_once_5 then
                    do_once_5 = false
                    anim:on_frame(1, function()
                        print("LOOP3")
                    end)
		    	    anim:on_complete(function()
                        if ref.loops > 1 then
                            anim:set_playback(Playback.Loop)
                            ref.loops = ref.loops - 1
                        else
                            anim:set_state("OLDWOOD_DELETE")
                            anim:set_playback(Playback.Once)
                            anim:refresh(ref.navi:sprite())
                            anim:on_complete(function()
                                anim:set_state("DELAY2")
                                anim:refresh(ref.navi:sprite())
                                anim:on_complete(function()
                                    ref.navi:erase()
                                    step1:complete_step()
                                end)
                            end)
                        end
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_flash(user, props, team, field, tile)
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Flash)
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_frame(2, function()
        create_woodytower(user, props, team, field, tile)
    end)
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    field:spawn(spell, tile)

    print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_woodytower(user, props, team, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Shake, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
    spell.attacking = false
    local sprite = spell:sprite()
    sprite:set_texture(WOODYTOWER_TEXTURE, true)
    sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(WOODYTOWER_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_complete(function() spell:erase() end)
    local do_once = true
    local do_once_2 = true

    spell.update_func = function(self, dt)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if anim:get_state() == "0" then
            anim:on_frame(5, function()
                self.attacking = true
            end)
            anim:on_frame(6, function()
                self.attacking = false
            end)
        end
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    Engine.play_audio(WOODYTOWER_AUDIO, AudioPriority.Highest)

    field:spawn(spell, tile)

	return spell
end

function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function woodytower_spawner(field, user, props, team, direction, tile, attacked, navi, ow_spr)
    local spell = Battle.Spell.new(team)
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("1")
    anim:on_complete(function() spell:erase() end)
    local do_once = true

    local targets = {}
    local trg_count = 1
    for i = 1, 6 do
        for j = 1, 3 do
            if field:tile_at(i,j):get_team() ~= team and not field:tile_at(i,j):is_hole() then
                targets[trg_count] = field:tile_at(i,j)
                trg_count = trg_count + 1
            end
        end
    end
    
    shuffle(targets)
    for i = 1, trg_count - 1 do
        anim:on_frame(i, function()
            create_flash(user, props, team, field, field:tile_at(targets[i]:x(),targets[i]:y()))
        end)
    end

    spell.update_func = function(self, dt)
        anim:on_frame(trg_count, function()
            attacked = true
        end)
        if attacked then
            navi:get_animation():on_complete(function()
                spell:erase()
                navi:get_animation():set_state("OLDWOOD_LOOP3")
                navi:get_animation():set_playback(Playback.Loop)
                navi:get_animation():refresh(ow_spr)
            end)
        end
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    field:spawn(spell, tile)

    print("Spawner ready")

	return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end