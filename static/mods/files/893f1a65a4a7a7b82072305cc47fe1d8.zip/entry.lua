nonce = function() end


local BASSGS_ATTACK = Engine.load_texture(_modpath.."attack.png")
local BASSGS_ATTACK_ANIMATION_PATH = _modpath.."PrimaryAttack.animation"
local BASSGS_EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."explosion.png")
local BASSGS_EXPLOSION_ANIMATION_PATH = _modpath.."explosion.animation"
local BASSGS_FLASH_TEXTURE = Engine.load_texture(_modpath.."flash.png")
local BASSGS_FLASH_ANIMATION_PATH = _modpath.."flash.animation"

local BASSGS_WATER_TEXTURE = Engine.load_texture(_modpath.."water.png")
local BASSGS_WATER_ANIMATION_PATH = _modpath.."water.animation"

local BASSGS_APPEAR = Engine.load_audio(_modpath.."appear.ogg") 
local BASSGS_APPEAR_GS = Engine.load_audio(_modpath.."appear_gs.ogg") 
local BASSGS_IMPACT = Engine.load_audio(_modpath.."impact.ogg") 




function package_init(package) 
    package:declare_package_id("com.alrysc.card.BBassGS")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'X'})
  
    local props = package:get_card_props()
    props.shortname = "BBassGS"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.None
    props.card_class = CardClass.Giga
    props.description = "BBass's secret weapon"
    props.limit = 1
  
  end


  function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")

    local whole = {1, 5}

    local FRAMES = make_frame_data({whole})

    action:set_lockout(make_animation_lockout())
    action:override_animation_frames(FRAMES)
    local artifact_list = {}
    local spell_list = {}
    local tile_list = {}

    local artifact_counter = 0
    local spell_counter = 0
    local tile_counter = 0
    local explosion_counter = 1

    local function cleanup()
        if spell_counter > 0 then 
            for i=1, spell_counter, 1
            do
                spell_list[i]:delete() -- I had these both as erase. Swap them back if console still talks about a spell needing to be on the field to attack
            end
            spell_counter = 0
        end

    end

    function nextExplosion(number)
        if tile_list[1] then 
        if number < 13 then 
            local tile = (number % tile_counter) + 1
            create_explosion(tile_list[tile])
        end
    end
    end

    function create_explosion(tile)
        if tile then
        local offsetY = 20
        local explosion = Battle.Artifact.new()
        explosion:sprite():set_layer((-1*explosion_counter))
        explosion:set_facing(user:get_facing())
        explosion:set_texture(BASSGS_EXPLOSION_TEXTURE, true)
        explosion:set_offset(0, offsetY)
        explosion:get_animation():load(BASSGS_EXPLOSION_ANIMATION_PATH)
        explosion:get_animation():set_state("EXPLOSION")

        explosion:get_animation():refresh(explosion:sprite())

        explosion:get_animation():on_complete(function()
            explosion:erase()
        end)
       
        explosion:get_animation():on_frame(6, function()
            explosion_counter = explosion_counter+1
            nextExplosion(explosion_counter)
        end)
        user:get_field():spawn(explosion, tile)

        --artifact_counter = artifact_counter + 1
       -- artifact_list[artifact_counter] = explosion  
        
        
        end
    end

    local function create_beam(tile, number)
        if tile then
            local offsetX = -80
            if user:get_facing() == Direction.Left then offsetX = offsetX * -1 end
            local offsetY = -54
            local beam = Battle.Artifact.new()
            beam:sprite():set_layer((-1))
            beam:set_facing(user:get_facing())
            beam:set_texture(BASSGS_WATER_TEXTURE, true)
            beam:set_offset(offsetX, offsetY)
            beam:get_animation():load(BASSGS_WATER_ANIMATION_PATH)
            beam:get_animation():set_state("WATER")
    
            beam:get_animation():refresh(beam:sprite())
    
            beam:get_animation():on_complete(function()
                beam:erase()
            end)
           
            user:get_field():spawn(beam, tile:get_tile(user:get_facing(), 1))
            
        end

    end


    local function create_flash()
        local color = Color.new(0, 0, 0, 0)
        local field = user:get_field()
        local offsetX = 0
        local offsetY = 0
        local flash = Battle.Artifact.new()
        flash:sprite():set_layer(10)
        flash:set_facing(user:get_facing())
        flash:set_texture(BASSGS_FLASH_TEXTURE, true)
        flash:set_offset(offsetX, offsetY)
        flash:get_animation():load(BASSGS_FLASH_ANIMATION_PATH)
        flash:get_animation():set_state("FLASH")

        flash:get_animation():refresh(flash:sprite())

        flash:get_animation():on_complete(function()
            flash:erase()
        end)

        flash:get_animation():on_frame(2, function()
            color.a = 64
        end)

        flash:get_animation():on_frame(3, function()
            color.a = 128
        end)

        flash:get_animation():on_frame(4, function()
            color.a = 191
        end)

        flash:get_animation():on_frame(5, function()
            color.a = 255
        end)

        flash:get_animation():on_frame(6, function()
            color.a = 219
        end)

        flash:get_animation():on_frame(7, function()
            color.a = 182
        end)

        flash:get_animation():on_frame(8, function()
            color.a = 147
        end)

        flash:get_animation():on_frame(9, function()
            color.a = 110
        end)

        flash:get_animation():on_frame(10, function()
            color.a = 75
        end)

        flash:get_animation():on_frame(11, function()
            color.a = 38
        end)

        flash:get_animation():on_frame(12, function()
            color.a = 0
        end)
        
        flash.update_func = function()
            flash:set_color(color)


        end

       field:spawn(flash, field:tile_at(3, 2))



    end

    local function create_spell(user, curX, curY, X, Y)
        if user:get_facing() == Direction.Left then 
            X = X * -1
        end

        local tile = user:get_field():tile_at(curX+X, curY+Y)

        if tile and (tile:x() > 0 and tile:x() < 7) and (tile:y() < 4 and tile:y() > 0) then 
        local hasHit = false
        local spell = Battle.Spell.new(user:get_team())

        spell:set_hit_props(
            HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Breaking | Hit.Impact | Hit.Pierce,
            props.element,
            user:get_context(),
            Drag.None
            )
        )

        
        spell.can_move_to_func = function()
            return true
        end

        spell.update_func = function(self)
            if not hasHit then
                spell:get_current_tile():attack_entities(self)
            end

        end

        spell.collision_func = function()
            --     Engine.play_audio(NAVI_ATTACK_HIT_SOUND, AudioPriority.High)
                 hasHit = true
             end

        spell.attack_func = function()
       --     Engine.play_audio(NAVI_ATTACK_HIT_SOUND, AudioPriority.High)
            hasHit = true
        end

        user:get_field():spawn(spell, tile)

        spell_counter = spell_counter + 1
        spell_list[spell_counter] = spell

        tile_counter = tile_counter+1
        tile_list[tile_counter] = tile
    end
    end

    action.update_func = function()
        

    end

    action.execute_func = function(self)
        local actor = self:get_actor()
        actor:hide()
        local bass = Battle.Artifact.new()
        bass:sprite():set_layer(-2)
        bass:set_facing(user:get_facing())
        bass:set_texture(BASSGS_ATTACK, true)
        bass:set_offset(0, 0)
        bass:get_animation():load(BASSGS_ATTACK_ANIMATION_PATH)
        bass:get_animation():set_state("DEFAULT")

        bass:get_animation():refresh(bass:sprite())

        local on_hole = user:get_current_tile():get_state() == TileState.Empty or user:get_current_tile():get_state() == TileState.Broken


        local color = Color.new(0, 0, 255, 0)
        bass:set_color(color)

        local transparent_time = 6
        local transparent_counter = 0

        local blue_time = 26
        local blue_counter = 26


        local extra_counter = 0
        local wait = 14

        bass.update_func = function()
            if transparent_counter ~= transparent_time+1 then
                color.a = math.floor(255 * (transparent_counter / transparent_time))
                transparent_counter = transparent_counter+1

            else              
            
                if extra_counter == wait then 
                    if blue_counter ~= -1 then 
                    color.b = math.floor(255 * (blue_counter / blue_time))
                    blue_counter = blue_counter-1

                    else
                        bass.update_func = function()
                        end
                    end
                else
                    extra_counter = extra_counter+1
                end
            end

            bass:set_color(color)


        end

        bass:get_animation():on_frame(1, function()
            Engine.play_audio(BASSGS_APPEAR, AudioPriority.High)

        end)

        bass:get_animation():on_frame(9, function()
            Engine.play_audio(BASSGS_APPEAR_GS, AudioPriority.High)

        end)

        bass:get_animation():on_frame(8, function()
            if on_hole then 
                bass:get_animation():set_state("DISAPPEAR")
                bass:get_animation():on_frame(1, function()
                    transparent_counter = transparent_time
                    blue_counter = 0
                    extra_counter = 0
        
                    bass.update_func = function()
                        if blue_counter ~= blue_time+1 then 
                            color.b = math.floor(255 * (blue_counter / blue_time))
                            blue_counter = blue_counter+1
        
                        else
        
                            if extra_counter == wait then 
                                if transparent_counter ~= -1 then
                                    color.a = math.floor(255 * (transparent_counter / transparent_time))
                                    transparent_counter = transparent_counter-1
                                end
                            else
                                extra_counter = extra_counter+1
                            end
                        end
            
                        bass:set_color(color)
            
            
                    end
                end)

                bass:get_animation():on_complete(function() 
                    cleanup()
                    bass:erase()
                    action:end_action()
                end)
            else
                bass:get_animation():on_frame(23, function()
                    create_beam(user:get_current_tile():get_tile(user:get_facing(), 1), 2)
        
                end)
        
                
        
                bass:get_animation():on_frame(26, function()
                --    create_flash()
                end)
        
                bass:get_animation():on_frame(27, function()
                    Engine.play_audio(BASSGS_IMPACT, AudioPriority.High)
        
                end)
        
                bass:get_animation():on_frame(28, function()
                    Engine.play_audio(BASSGS_IMPACT, AudioPriority.High)
        
                   -- bass:get_animation():set_state("DEFAULT2")
                   -- bass:get_animation():refresh(bass:sprite())
        
                   
                   local currentX = user:get_current_tile():x()
                   local currentY = user:get_current_tile():y()
                    
                    --local tile = user:get_current_tile():get_tile(user:get_facing(), 2)
                    create_spell(user, currentX, currentY, 2, 0)
                    
                   
                end)
        
                bass:get_animation():on_frame(41, function()
                    transparent_counter = transparent_time
                    blue_counter = 0
                    extra_counter = 0
        
                    bass.update_func = function()
                        if blue_counter ~= blue_time+1 then 
                            color.b = math.floor(255 * (blue_counter / blue_time))
                            blue_counter = blue_counter+1
        
                        else
        
                            if extra_counter == wait then 
                                if transparent_counter ~= -1 then
                                    color.a = math.floor(255 * (transparent_counter / transparent_time))
                                    transparent_counter = transparent_counter-1
                                end
                            else
                                extra_counter = extra_counter+1
                            end
                        end
            
                        bass:set_color(color)
            
            
                    end
                end)
        
                bass:get_animation():on_complete(function() 
                    cleanup()
                    bass:erase()
                
                end)
            end

        end)

        
       
        user:get_field():spawn(bass, user:get_current_tile())

       




        


    end

    return action
  end