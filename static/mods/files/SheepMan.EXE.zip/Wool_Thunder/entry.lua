local card = {}

card.card_create_action = function(player, props)
    local action = Battle.CardAction.new(player, "CLOUD_CHARGE")
    local cannonshot = create_pulse(player, props)
    action.execute_func = function(self, user)
        self:add_anim_action(4, function()
            local tile = user:get_tile(user:get_facing(), 1)
            player:get_field():spawn(cannonshot, tile)
        end)
    end
    return action
end

function create_pulse(user, props)
    local spell = Battle.Spell.new(user:get_team())
	spell:highlight_tile(Highlight.Solid)
	local direction = user:get_facing()
	spell:set_facing(direction)
    spell:set_hit_props(props)
	spell.slide_started = false
    spell.update_func = function(self, dt)
		if not spell:get_tile() or spell:get_tile():is_edge() then self:delete() end
		spell:get_tile():attack_entities(self)
		local dest = self:get_tile(direction, 1)
		local ref = self
		self:slide(dest, frames(24), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
    end
	
	local TEXTURE = Engine.load_texture(_folderpath.."Wool_Thunder.png", true)
	spell:set_texture(TEXTURE, true)
	local fx_anim = spell:get_animation()
	fx_anim:load(_folderpath.."Wool_Thunder.animation")
	fx_anim:set_state("DEFAULT")
	fx_anim:set_playback(Playback.Loop)
	
	spell:set_offset(spell:sprite():get_offset().x, spell:sprite():get_offset().y-40.0)
	
	spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other)
    end

    spell.can_move_to_func = function(tile)
        return true
    end
	
	spell.on_spawn_func = function(self)
		Engine.play_audio(Engine.load_audio(_modpath.."cloud.ogg"), AudioPriority.Low)
	end

spell.attack_func = function(self, other) 
        Engine.play_audio(Engine.load_audio(_folderpath.."hitsound.ogg"), AudioPriority.High)
end

    return spell
end

return card