local quaker_texture = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local quaker_anim = _folderpath .. "battle.animation"
local hit_effects = Engine.load_texture(_folderpath .. "effect.png")
local hit_effect_anim = _folderpath .. "effect.animation"


local shockwave_sprite = Engine.load_texture(_folderpath .. 'shockwave.png')
local shockwave_anim = _folderpath .. 'shockwave.animation'
local shockwave_sound = Engine.load_audio(_folderpath .. 'shockwave.ogg')
local impact_audio = Engine.load_audio(_folderpath .. 'impact.ogg')



library = {}
library.create_quaker = function(user, damage, cascade_frame_index)
    local quaker = Battle.Obstacle.new(user:get_team())
    local spawn_tile = user:get_tile(user:get_facing(), 1)
    quaker:set_facing(user:get_facing())
    quaker:set_texture(quaker_texture, true)
    local anim = quaker:get_animation()
    anim:load(quaker_anim)
    quaker:set_shadow(Shadow.Small)
    quaker:set_facing(user:get_facing())
    quaker:show_shadow(true)
    quaker:set_palette(Engine.load_texture(_folderpath .. "V1.png"))

    -- QUAKER DEFENSE
    quaker.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    quaker.defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
            --cant block breaking hits
            return
        end
        judge:block_impact()
        judge:block_damage()

    end
    quaker:add_defense_rule(quaker.defense_rule)
    anim:set_state("JUMP")
    anim:on_complete(function()
        anim:set_state("LAND")
    end)
    anim:refresh(quaker:sprite())
    user:get_field():spawn(quaker, spawn_tile)
    quaker:set_elevation(200)
    quaker:set_health(1)
    quaker:toggle_hitbox(false)
    quaker:set_hit_props(HitProps.new(damage, Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, Element.None,
        user:get_context(),
        Drag.None))
    local do_once = true
    local wait_time = 50
    quaker.update_func = function(self, dt)
        local remoElevation = quaker:get_elevation()
        if (remoElevation > 0) then
            quaker:set_elevation(remoElevation - 8)
            if (remoElevation < 20) then
                quaker:set_elevation(remoElevation - 8)
                quaker:toggle_hitbox(true)
                quaker:get_current_tile():attack_entities(quaker)
            end
            return
        end

        if (do_once) then
            local tile = quaker:get_tile()
            if (not tile:is_walkable()) then
                quaker:delete()
            end
            Engine.play_audio(impact_audio, AudioPriority.High)
            spawn_shockwave(quaker, quaker:get_tile():get_tile(user:get_facing(), 1), user:get_facing(), damage,
                shockwave_sprite, shockwave_anim,
                shockwave_sound, cascade_frame_index)
            quaker:shake_camera(5, 2)
            root_all_enemies(quaker:get_team(), quaker:get_field())
            do_once = false
        else
            wait_time = wait_time - 1
            if (wait_time < 0) then
                quaker.do_once = true
            end
            if (wait_time < -40) then
                quaker:delete()
            end
        end
    end

    quaker.collision_func = function(self, other)
        self:delete()
        do_once = false
    end

    quaker.delete_func = function(self)
        local fx = Battle.Explosion.new(1, 1.0)
        self:get_field():spawn(fx, self:get_current_tile())
        self:erase()
    end

    return quaker
end

---function to create a spell to root all enemies
---@param team #The team of the attacker.
function root_all_enemies(team, field)
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    for index, entity in ipairs(target_list) do
        local spell = Battle.Spell.new(team)
        spell:set_hit_props(HitProps.new(0, Hit.Root, Element.None, 0, Drag.new()))
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
            spell:erase()
        end
        entity:get_field():spawn(spell, entity:get_tile())
    end
end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end

---Used by quaker to shockwave
---@param owner Entity
function spawn_shockwave(owner, tile, direction, damage, wave_texture, wave_animation, wave_sfx, cascade_frame_index)
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local cascade_frame = cascade_frame_index
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(wave_sfx, AudioPriority.Low)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact | Hit.Flash | Hit.Flinch, Element.None, owner_id, Drag.new()))

        local sprite = spell:sprite()
        sprite:set_texture(wave_texture)
        sprite:set_layer(-1)

        local animation = spell:get_animation()
        animation:load(wave_animation)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)

        animation:on_frame(cascade_frame_index, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

return library
