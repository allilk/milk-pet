function package_init(block)
    block:declare_package_id("com.alrysc.block.undershot")
    block:set_name("UnderSht")
    block:as_program()
    block:set_description("Keep 1HP even on hard hit")
    block:set_color(Blocks.White)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

-- I set max HP by taking damage variable away again on line 40. I guess it could make more sense
    -- to set back to a previously stored value? But it's working, so probably fine.
function modify(player)
    local hit = false;
    local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
    local damage
    local component = Battle.Component.new(player, Lifetimes.Scene)
    local prevHP = player:get_health()


    undershirt.can_block_func = function(judge, attacker, defender)
        damage = attacker:copy_hit_props().damage

        if prevHP > 1 and (player:get_health() - damage) <= 0 then 
            player:mod_max_health(damage)
            hit = true
        end

        
    end

    component.update_func = function()
        if hit then 
            player:mod_max_health(damage*-1) 
            player:set_health(1)
            hit = false 

        end
        prevHP = player:get_health()

    end
        
    player:register_component(component)
    player:add_defense_rule(undershirt)
end
