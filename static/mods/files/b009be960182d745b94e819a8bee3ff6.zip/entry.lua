function package_init(block)
    block:declare_package_id("hoov.block.greenheal")
    block:set_name("GrenHeal")
    block:as_program()
    block:set_description("Recover HP while on grass")
    block:set_color(Blocks.Green)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local field = player:get_field()
    local component = Battle.Component.new(player, Lifetimes.Battlestep) --at < 10 HP, heal slows down to every 180 frames. Use a variable for the frame count that changes at low HP.
    local healtimer = 0
    local heallimit = 0
    local function selfheal(player)
        player:set_health(player:get_health() + 1)
        healtimer = 0
    end
    component.update_func = function ()

        local tile = player:get_tile()
        if tile:get_state() ==  TileState.Grass then
            healtimer = healtimer + 1
            if player:get_health() < 10 then
                if healtimer % 180 == 0 then
                selfheal(player)
                end
            else
                if healtimer % 20 == 0 then
                selfheal(player)
                end
            end
        else
            healtimer = 0
        end
    end

    player:register_component(component)
end