function package_init(package) 
    package:declare_package_id("com.alrysc.player.YumekoEXE")
    package:set_special_description("Mayumi Shinki's navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")

end

function player_init(player)
    player:set_name("Yumeko")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(62.0)
    player:set_animation(_modpath.."yumeko.animation")
    player:set_texture(Engine.load_texture(_modpath.."yumeko.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -28)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        sword = Engine.load_audio(_modpath.."swing_sword.ogg"),
        guard = Engine.load_audio(_modpath.."tink.ogg"),
        heal = Engine.load_audio(_modpath.."heal.ogg"),
        shine = Engine.load_audio(_modpath.."bright.ogg")
    }


    player.swords = {
        normal = 1,
        wood = 2,
        freeze = 3,
        paralyze = 4,
        poison = 5
    }

    player.standby_swords = {
        player.swords.wood,
        player.swords.freeze,
        player.swords.paralyze,
        player.swords.poison
    }

    player.ready_sword = player.swords.normal
    


    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.normal_attack_func = base_normal_attack


    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function charge_attack(player)
        local action = Battle.CardAction.new(player, "PLAYER_SWORD")
        local facing = nil
        local field = player:get_field()

        local function create_hitbox(tile, spell_list, reflect_list, moving)
            moving = moving or false
            if not tile or tile:is_edge() then 
                return
            end

            local spell = nil
            if not moving then 
                spell = Battle.Spell.new(player:get_team())
            else
                spell = graphic_init("spell", 0, 0, "slashes.png", "effects.animation", -5, "SONIC_BOOM", player, facing)

            end
            local poison = false
            local damage = 60 + player:get_attack_level()*20
            local flags = Hit.Impact | Hit.Flinch | Hit.Flash
            local element = Element.None
            local sword = player.ready_sword

            local should_heal = false
            local should_poison = false
        
            if sword == player.swords.wood then 
                flags = Hit.Impact | Hit.Flinch
                element = Element.Wood
                should_heal = true

            elseif sword == player.swords.paralyze then 
                flags = Hit.Impact | Hit.Flinch
                flags = flags | Hit.Root
                element = Element.Elec

            elseif sword == player.swords.freeze then 
                flags = Hit.Impact | Hit.Flinch
                flags = flags | Hit.Root
                element = Element.Aqua

            elseif sword == player.swords.poison then 
                spell:set_name("Element.Poison")
                should_poison = true

            end

            if moving then 
                damage = math.floor(damage/2)
            end

            local hit_props = HitProps.new(
                damage,
                flags,
                element, 
                player:get_context(), 
                Drag.None
            )

            spell:set_hit_props(hit_props)
            spell:set_facing(facing)
            
            local lifetime = 9
            spell.has_hit = false

            spell.update_func = function(self, dt)
                local can_hit = true
                self:get_tile():highlight(Highlight.Solid)

                if not moving then 
                    for i=1, #spell_list
                    do
                        if not spell_list[i]:is_deleted() then 
                            can_hit = can_hit and not spell_list[i].has_hit
                            if not can_hit then 
                                break
                            end
                        end
                    end
    

                    lifetime = lifetime - 1
                    if lifetime == 0 then 
                        self:delete()
                    end

                    if not can_hit then 
                        return 
                    end
                else
                    if self:is_sliding() == false then
                        if self:get_current_tile():is_edge() and self.slide_started then 
                            self:delete()
            
                        end 
                        
                        local dest = self:get_tile(facing, 1)
                        self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary,
                            function()
                                self.slide_started = true 
                            end
                        )
                    end

                end


                self:get_tile():attack_entities(self)
        
            end

            spell:set_float_shoe(true)
            spell.can_move_to_func = function()
                return true
            end

            spell.delete_func = function()
                if not moving then 
                    for i=1, #reflect_list
                    do
                        if not reflect_list[i]:is_deleted() then 
                            reflect_list[i]:delete()
                        end

                    end
                end
            end
        
            spell.can_move_to_func = function(tile)
                return true
            end
        
            spell.attack_func = function(self, other)
                Engine.play_audio(player.sounds.hit, AudioPriority.Low)


                -- Need to figure out interaction with Medicine poison
                    -- Maybe name different and search for Medicine, so I defer to that?
                if should_poison then 
                    -- Use find spells and get rid of health later
                  --  local list = field:find_entities(function(e) return e:get_name() == "POISON_CONTROLLER"..other:get_id() end)        
                    --if list[1] then 
                      --  list[1]:set_name("RESET")

                       -- return
                    --end

                    local list = field:find_entities(function(e) return e:get_name() == "POISON_CONTROLLER_WEAK"..other:get_id() end)        
                    if list[1] then 
                        list[1]:set_name("RESET")
                        return
                    end

                    local artifact = Battle.Spell.new(other:get_team())
                    artifact:set_name("POISON_CONTROLLER_WEAK"..other:get_id())
                    artifact:set_health(1)
                    -- artifact:toggle_hitbox(true)
                    local time_remaining = 299

                    local colored = false
                    local poison_component = Battle.Component.new(other, Lifetimes.Local)
                    local mode = other:sprite():get_color_mode()

                    poison_component.update_func = function()
                        if artifact:get_name() == "RESET" then
                            time_remaining = 299
                            artifact:set_name("POISON_CONTROLLER_WEAK"..other:get_id())
                        end
                        if time_remaining % 8 == 0 then 
                            other:set_health(other:get_health()-1)
                        end

                        if time_remaining == 0 then 
                            artifact:delete()
                            poison_component:eject()
                            other:sprite():set_color_mode(mode)

                        end
                        time_remaining = time_remaining - 1

                        if time_remaining % 3 == 1 then 
                            other:sprite():set_color_mode(ColorMode.Multiply)

                        end
                        if time_remaining % 3 == 0 then 
                            local color = Color.new(30, 20, 170, 255)
                            other:set_color(color)
                            other:sprite():set_color_mode(mode)

                            colored = true
                        end
                        
                    end

                    other:register_component(poison_component)
                    field:spawn(artifact, field:tile_at(1, 1))

                end

                if should_heal then 
                    player:set_health(player:get_health()+30)
                    player:get_field():spawn(
                        graphic_init("artifact", 0, 0, "spell_heal.png", "spell_heal.animation", -10, "DEFAULT", player, player:get_facing(), true),
                        player:get_current_tile())
        
                    Engine.play_audio(player.sounds.heal, AudioPriority.Low)
                end

            end
        
            spell.collision_func = function(self, other)
                self.has_hit = true
                if moving then 
                    field:spawn(graphic_init("artifact", 0, 0, "effects.png", "effects.animation", -6, "NORMAL_HIT", player, facing, true), self:get_current_tile())
                    self:delete()
                end
            end

            if not moving then 
                table.insert(spell_list, spell)
            end
            field:spawn(spell, tile)
        end


        local function reflect_attack(user, id)
            local spell = Battle.Spell.new(user:get_team())
            spell:set_facing(user:get_facing())
            local facing = spell:get_facing()
            local field = user:get_field()
        
            local function create_effect()
                local spell2 = graphic_init("spell", 0, 0, "effects.png", "effects.animation", -3, "REFLECT", spell, spell:get_facing(), true)
        
            end
        
            local hit_props = HitProps.new(
                (20 * player:get_attack_level() + 60),
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.None, 
                id, 
                Drag.None
            )
        
            spell:set_hit_props(hit_props)
        
            spell.update_func = function(self)
                self:get_tile():attack_entities(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        self:delete()
                    end 
                    
                    local dest = self:get_tile(facing, 1)
                    local ref = self
                    self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
                        function()                           
                            ref.slide_started = true 
                            field:spawn(graphic_init("spell", 0, 0, "effects.png", "effects.animation", -3, "REFLECT", spell, spell:get_facing(), true), ref:get_current_tile())
                        end)
                end
            end
        
            spell.can_move_to_func = function()
                return true
            end

            spell.attack_func = function()
                Engine.play_audio(player.sounds.hit, AudioPriority.Low)

            end
        
        
            field:spawn(spell, user:get_current_tile())
        end



        local function create_reflect(tile, list)
            local reflector = Battle.Obstacle.new(player:get_team())
            reflector:set_facing(player:get_facing())

            reflector.guarding = true
            reflector.should_reflect = false
            reflector.guarded = false

            local comp = Battle.Component.new(reflector, Lifetimes.Local)
            comp.update_func = function()
                reflector:toggle_hitbox(true)
                if reflector.should_reflect then 
                    print("Reflecting")
                    reflect_attack(reflector, player:get_id())
                    reflector.should_reflect = false

                    for i=1, #list
                    do
                        if not list[i]:is_deleted() and not list[i].should_reflect then
                            list[i]:delete()
                            print("####")
                            print("Deleted "..i)
                        end
                    end
                end
        
            end

            reflector:register_component(comp)

            local defense = Battle.DefenseRule.new(0,DefenseOrder.Always)

            defense.can_block_func = function(judge, attacker, defender)
                local attacker_hit_props = attacker:copy_hit_props()
                if attacker_hit_props.damage > 0 then
                    print("Defense activated")

                    judge:block_impact()
                    judge:block_damage()
                    reflector.guarded = true
                    reflector.should_reflect = true

                    reflector:get_field():spawn(graphic_init("spell", 0, -32, "effects.png", "effects.animation", -4, "GUARD", reflector, reflector:get_facing(), true), reflector:get_current_tile())
                    Engine.play_audio(player.sounds.guard, AudioPriority.Low)

                end


            end

            reflector:add_defense_rule(defense)
            reflector:set_health(9999)
            reflector:share_tile(true)


        --    reflector.delete_func = function()
          --      print("Reflector was deleted")
            --end

            table.insert(list, reflector)
            player:get_field():spawn(reflector, tile)
        end

        local function wide_attack(user, tile)
            local facing = user:get_facing()
            local slash = graphic_init("spell", 0, 0, "slashes.png", "effects.animation", -5, "SWORD_"..user.ready_sword, user, facing, true)
            Engine.play_audio(player.sounds.sword, AudioPriority.Low)

            local list = {}
            local list2 = {}

            local tiles = {
                tile,
                tile:get_tile(Direction.Up, 1),
                tile:get_tile(Direction.Down, 1)
            }

            for i=1, #tiles
            do
                create_hitbox(tiles[i], list, list2)
                create_reflect(tiles[i], list2)

            end
            field:spawn(slash, tile)
        end

        local function long_attack(user, tile)
            local facing = user:get_facing()
            local slash = graphic_init("spell", 0, 0, "slashes.png", "effects.animation", -5, "LANCE", user, facing, true)
            Engine.play_audio(player.sounds.sword, AudioPriority.Low)

            local list = {}
            local list2 = {}

            local tiles = {
                tile,
                tile:get_tile(user:get_facing(), 1),
            }

            create_hitbox(tiles[1], list, list2)
            create_hitbox(tiles[2], list, list2)

            create_reflect(tiles[1], list2)
            create_reflect(tiles[2], list2)

            create_hitbox(tiles[2], list, list2, true)


            field:spawn(slash, tile)
        end


        action.execute_func = function(self)
            action:add_anim_action(2, function()
                facing = player:get_facing()
                if player.ready_sword == player.swords.normal then 
                    long_attack(player, player:get_tile(facing, 1))
                else
                    wide_attack(player, player:get_tile(facing, 1))
                end
                local hilt = self:add_attachment("HILT")
                local hilt_sprite = hilt:sprite()
                hilt_sprite:set_texture(player:get_texture())
                hilt_sprite:set_layer(-2)
                hilt_sprite:enable_parent_shader(true)
                
                local hilt_anim = hilt:get_animation()
                hilt_anim:copy_from(player:get_animation())
                hilt_anim:set_state("HILT")

                local blade = hilt:add_attachment("ENDPOINT")
                local blade_sprite = blade:sprite()
                blade_sprite:set_texture(Engine.load_texture(_modpath.."swords.png", false))
                blade_sprite:set_layer(-3)

                local blade_anim = blade:get_animation()
                blade_anim:load(_modpath.."swords.animation")
                blade_anim:set_state("SWORD_"..player.ready_sword)
            
            end)

        end

        return action

    end

    

    player.charged_attack_func = charge_attack

    local function create_move_action(player)
        local action = Battle.CardAction.new(player, "PLAYER_IDLE")
        action:set_lockout(make_sequence_lockout())

        --[[
            Pixels away from player that each icon will be at
            That's up, left, down, then right
            Adjust as needed
        ]]
        local offsets = {
            {x = -16, y = -120},
            {x = 48, y = -64},
            {x = -16, y = 8},
            {x = -64, y = -64}

        }   
             
        
        local icons = {}
        local has_selected = false

        local select_step = Battle.Step.new()
        local pose_step = Battle.Step.new()
        local first = true
        local pose_step_first = true


        local function icon_cleanup(selected)
            for i=1, #icons
            do
                local g = icons[i]
                if selected > 0 then
                    if i == selected then  
                        local anim = g:get_animation()
                        anim:set_state("ICON_"..player.standby_swords[i])
                        anim:refresh(g:sprite())
                        g.flashing =  true

                    end

                    g.lifetime = 18
                    local color = Color.new(255, 255, 255, 255)
                    g.update_func = function(self)
                        self.lifetime = self.lifetime - 1
                        
                        if self.flashing and (self.lifetime-2) % 5  <= 1 then 
                            self:set_color(color)
                        end

                        if self.lifetime == 0 then 
                            self:delete()
                        end
                    end
                    
                    
                else

                    if not g:is_deleted() then 
                        g:delete()
                    end
                end
            end

        end

        local function create_icons(player)
            local field = player:get_field()
            local facing = player:get_facing()
            local t = player:get_current_tile()

            local function spawn_icon(off_x, off_y, user, facing, num)
                local graphic = Battle.Artifact.new()
                graphic:set_facing(facing)
                graphic:sprite():set_layer(-999)
                graphic:never_flip(true)
                graphic:set_texture(Engine.load_texture(_modpath.."swords.png"), false)
                
                if facing == Direction.Left then 
                    off_x = off_x * -1
                end
                graphic:set_offset(off_x, off_y)
                local anim = graphic:get_animation()
                anim:load(_modpath.."swords.animation")
        
                local state = "ICON_"..num

                anim:set_state(state)
                anim:refresh(graphic:sprite())
        
                field:spawn(graphic, t)
                table.insert(icons, graphic)
            end


            

            for i=1, #player.standby_swords
            do
                spawn_icon(offsets[i].x, offsets[i].y, player, facing, player.standby_swords[i])
            end


        end

        --[[
            Return move index based on input.

            Up is move1, left is move2, down is move3, right is move4

            If no input on this call, return 0
            If special pressed, return -1 as an exit check
        ]]
        local function selection(player)
            if player:input_has(Input.Released.Special) then 
                return -1
            elseif player:input_has(Input.Pressed.Up) then 
                return 1
            elseif player:input_has(Input.Pressed.Right) then 
                return 2
            elseif player:input_has(Input.Pressed.Down) then 
                return 3
            elseif player:input_has(Input.Pressed.Left) then 
                return 4
            else 
                return 0
            end

        end


        select_step.update_func = function()
            if first then 
                create_icons(player)
                first = false
            end

            local select = selection(player)

            -- Player pressed a button we are looking for, so queue related action
                -- We also check to make sure they selected a move that exists
                -- Ex. If they only have two moves, we don't count it if they select the third slot
            if select ~= 0 or select == -1 then 
                has_selected = true

                select_step:complete_step()
                if select ~= -1 then 
                    Engine.play_audio(player.sounds.shine, AudioPriority.Low)
                    local temp = player.standby_swords[select]
                    player.standby_swords[select] = player.ready_sword
                    player.ready_sword = temp
                    action:add_step(pose_step)
                end

                icon_cleanup(select)

            end

        end

        pose_step.update_func = function()
            if pose_step_first then 
                local anim = action:get_actor():get_animation()
                anim:set_state("PLAYER_SWORD")

                anim:on_frame(2, function()
                    local hilt = action:add_attachment("HILT")
                    local hilt_sprite = hilt:sprite()
                    hilt_sprite:set_texture(player:get_texture())
                    hilt_sprite:set_layer(-2)
                    hilt_sprite:enable_parent_shader(true)
                    local hilt_anim = hilt:get_animation()
                    hilt_anim:copy_from(player:get_animation())
                    hilt_anim:set_state("HAND")
                    hilt_anim:refresh(hilt_sprite)
                end)
                
                anim:on_complete(function()
                    pose_step:complete_step()
                end)
                pose_step_first = false
            end

        

        end

        action.execute_func = function()
            action:add_step(select_step)

        end

        action.action_end_func = function()
            if not has_selected then 
                icon_cleanup(0)
            end
        end

        return action
    end

    player.special_attack_func = create_move_action

end