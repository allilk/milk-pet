nonce = function() end

local WINDRACK_SWIPE_TEXTURE = Engine.load_texture(_folderpath.."wind.png")
local BLADE_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_blades.png")
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")

local wind = {}

function package_init(package) 
    package:declare_package_id("com.alrysc.card.WindRack")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'F','J','R','*'})

    local props = package:get_card_props()
    props.shortname = "WindRack"
    props.damage = 140
    props.time_freeze = false
    props.element = Element.Wind
    props.description = "Blow enmy in front! Range:3"
end

wind.card_create_action = function(actor, props)
	local spawned = false
	local counter = 0
    local spell_list = {}
    local spell_counter = 0
	-- Since I don't return spells, I gather them in that spell_list and remove them all with this function
	local function cleanup()
        if spell_counter > 0 then 
            for i=1, spell_counter, 1 do spell_list[i]:delete() end
            spell_counter = 0
        end
    end

	local function create_wind(user, tile)
		local facing = actor:get_facing()
		local spell = Battle.Spell.new(actor:get_team())
		spell:set_hit_props(
			HitProps.new(
				0,
				Hit.Drag,
				Element.Wind,
				user:get_context(),
				Drag.new(facing, user:get_field():width()) -- This shouldn't actually be drag. But I think not having Hit.Impact puts us in the clear?
			)
		)
		spell.update_func = function(self, dt)
			self:get_tile():attack_entities(self)
			self:get_current_tile():attack_entities(self)
			if self:is_sliding() == false then
				if self:get_current_tile():is_edge() and self.slide_started then self:delete() end 
				local dest = self:get_tile(facing, 1)
				local ref = self
				self:slide(dest, frames(3), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
			end
		end

		spell.attack_func = function(self, other) self:delete() end

		spell.can_move_to_func = function(tile) return true end

		user:get_field():spawn(spell, tile)
	end

	local function create_slash(user, tile)
		local spell = Battle.Spell.new(user:get_team())
		spell:set_facing(user:get_facing())
		spell.slide_started = false
		local direction = spell:get_facing()
		spell:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact | Hit.Flinch | Hit.Drag,
				Element.Wind,
				user:get_context(),
				Drag.new(direction, user:get_field():width()) -- Pushes all the way across. This is more than it needs, but it'll probably be fine
			)
		)
		
		spell.update_func = function(self)
			self:get_tile():attack_entities(self)
		end


		-- If the attack hits, we should delete every spell
		spell.collision_func = function(self, other) cleanup() end

		spell.can_move_to_func = function(tile) return true end

		spell_counter = spell_counter + 1
        spell_list[spell_counter] = spell

		Engine.play_audio(AUDIO, AudioPriority.Low)
		user:get_field():spawn(spell, tile)
	end

    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HILT")

			local blade = hilt:add_attachment("ENDPOINT")
			local blade_sprite = blade:sprite()
			blade_sprite:set_texture(BLADE_TEXTURE)
			blade_sprite:set_layer(-1)

			local blade_anim = blade:get_animation()
			blade_anim:load(_folderpath.."spell_sword_blades.animation")
			blade_anim:set_state("RACKET")
		end)
		-- Yes, this is also frame 2
		self:add_anim_action(2, function()
			spawned = true
			--local sword = create_slash(user, props)
			local tile = user:get_current_tile()
			local facing = user:get_facing()

			create_slash(user, tile:get_tile(facing, 1))
			create_slash(user, tile:get_tile(Direction.join(facing, Direction.Up), 1))
			create_slash(user, tile:get_tile(Direction.join(facing, Direction.Down), 1))
			
			create_wind(user, user:get_field():tile_at(tile:x()+1, 1))
			create_wind(user, user:get_field():tile_at(tile:x()+1, 2))
			create_wind(user, user:get_field():tile_at(tile:x()+1, 3))
		end)

		self:add_anim_action(3, function()
			local tile = user:get_current_tile()
			local facing = user:get_facing()
			local fx = Battle.Spell.new(user:get_team())
			fx:set_facing(user:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(WINDRACK_SWIPE_TEXTURE, true)
			anim:load(_folderpath.."wind.animation")
			anim:set_state("WIND")
			anim:on_complete(function()
				fx:erase()
			end)
			actor:get_field():spawn(fx, tile:get_tile(facing, 1))
		end)
	end

	-- Handles attack active frames
	action.update_func = function()
		if spawned then
			counter = counter + 1
			if counter == 9 then cleanup() end
		end
	end
	-- Destroys the spells if we get interrupted
		-- Should also do so at the end, but if all goes well the spells are already deleted
	action.action_end_func = cleanup
	return action
end

return wind