
function package_init(package)
    package:declare_package_id("com.Dawn.ChargedShots.Windman")
    package:set_special_description("God of Scissor Island")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."windman_OW.animation")
    package:set_overworld_texture_path(_modpath.."windmanOW.png")
    package:set_icon_texture(Engine.load_texture(_modpath.."windman_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    --package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Windman")
    player:set_health(1000)
    player:set_element(Element.Wind)
    player:set_height(70.0)
    player:set_shadow(Shadow.Small)
    player:show_shadow(true)

    local WindRack = include("Chips/WindRack/entry.lua")
    local AirShot = include("Chips/AirShot/entry.lua")

    local base_texture = Engine.load_texture(_modpath.."windman_EXE4.5.png")
    local base_animation_path = _modpath.."windman.animation"
    local base_charge_color = Color.new(255, 0, 255, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -35)

    player.normal_attack_func = function(player)
        local props = Battle.CardProperties:new()
        props.damage = 10 + (player:get_attack_level()*5)
        return AirShot.card_create_action(player, props)
    end

    player.charged_attack_func = function(player)
        local props = Battle.CardProperties:new()
        props.damage = 90 + (player:get_attack_level() * 10)
        return WindRack.card_create_action(player, props)
    end
end
