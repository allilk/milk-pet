function package_init(package) 
    package:declare_package_id("com.alrysc.player.Saber")
    package:set_special_description("Excalibur!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Saber")
    player:set_health(1000)
    player:set_element(Element.Sword)
    player:set_height(50)
    player:set_animation(_modpath.."Saber.animation")
    player:set_texture(Engine.load_texture(_modpath.."Saber.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(-4, -22)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        shine = Engine.load_audio(_modpath.."shine.ogg"),
        sword = Engine.load_audio(_modpath.."sword.ogg"),
        heal = Engine.load_audio(_modpath.."heal.ogg")

    }

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

   

    
    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())

    end
    
    local function charge_attack(player)
        local action = Battle.CardAction.new(player, "CHARGE_ATTACK")

        return action
    end

    

    local function expend_spell(player)
        if player.command_spells == 0 then 
            return false
        end
        Engine.play_audio(player.sounds.shine, AudioPriority.Low)
        local offset = player.command_spell:sprite():get_offset()
        local x = offset.x
        local y = offset.y
        local artifact = graphic_init("artifact", 0, -56, "Command2.png", "Saber.animation", -10, "COMMAND_EFFECT_"..player.command_spells, player, player:get_facing())
        local sprite = artifact:sprite()
        sprite:set_width(0)
        sprite:set_height(0)

        local color = Color.new(0, 0, 0, 255)
        local max_time = 30
        local time = 0

        local d_color = 255/max_time
        local alpha = 255
        artifact.update_func = function()
            time = time + 1
            if time == max_time/2 then 
                player.command_spells = math.max(0, player.command_spells - 1)
                
            end

            sprite:set_color(color)
            color.a = math.floor(alpha)
            alpha = alpha - d_color
            sprite:set_width(sprite:get_width()+(600 * time/600))
            sprite:set_height(sprite:get_width())

            if time == max_time then 
                artifact:delete()
            end
        end



        player:get_field():spawn(artifact, player.command_spell:get_current_tile())

        return true
    end

    local function command_defense(player)
        if not expend_spell(player) then return end

        player.command_defense = Battle.DefenseRule.new(27,DefenseOrder.CollisionOnly)

        player.command_defense.can_block_func = function(judge, attacker, defender)
            judge:block_damage()
            judge:block_impact()

        end

        player:add_defense_rule(player.command_defense)
    end


    player.command_spells = 3
    player.command_spell = Battle.Artifact.new()
    player.artifact_counter = 0
    player.component_counter = 0
    player.command_defense = nil

    local function spawn_artifact(player)
        player.artifact = Battle.Artifact.new()
        player.artifact_counter = 0
        local green = Color.new(0, 140, 0, 255)
        player.artifact.update_func = function()
            player.artifact_counter = player.artifact_counter+1

            if player.artifact_counter > player.component_counter+15 then 
                if player:input_has(Input.Pressed.Special) then 
                    command_defense(player)
                    player.artifact_counter = -9999
                end
            end

            if player.command_defense then
                player:sprite():set_color(green)
            end
        end


        
        player:get_field():spawn(player.artifact, 0, 0)
    end

    local function Excalibur(player)
        local action2 = Battle.CardAction.new(player, "EXCALIBUR")
        action2:set_lockout(make_sequence_lockout())
        local field = player:get_field()
        local target_list = {}


        local step = Battle.Step.new()

        local meta = action2:copy_metadata()
        meta.time_freeze = true
        meta.skip_time_freeze_intro = true
        meta.shortname = ""
        action2:set_metadata(meta)
        local function create_attack(tile)
            local spell = Battle.Spell.new(player:get_team())

            spell:set_hit_props(
                HitProps.new(
                    15+player:get_attack_level()*5, 
                    Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake, 
                    Element.None, 
                    player:get_id(),
                    Drag.None
                )
            )


            spell.update_func = function(self, dt) 
                self:get_current_tile():attack_entities(self)
                self:erase()
            end

            spell.attack_func = function(self, other)
                Engine.play_audio(player.sounds.hit, AudioPriority.Low)
                table.insert(target_list, other)
            end

            field:spawn(spell, tile)

        end

        action2.execute_func = function()
            expend_spell(player)
            action2:add_step(step)
            local offset_dir = 1
            if player:get_facing() == Direction.Left then 
                offset_dir = -1
            end

            local extra_offset = 0

            local start
            local head
            local trail
            
     
            start = graphic_init("artifact", 0, 0, "Exucaliba.png", "Saber.animation", -3, "EXCALIBUR_START", player, player:get_facing())
            head = graphic_init("artifact", 0, 0, "Exucaliba.png", "Saber.animation", -1, "EXCALIBUR_END", player, player:get_facing())
            trail = graphic_init("artifact", 0, 0, "Exucaliba.png", "Saber.animation", -2, "EXCALIBUR_LASER", player, player:get_facing())

            trail:set_offset(118*offset_dir, 0)
            head:set_offset(42*offset_dir, 0)

            head:get_animation():set_playback(Playback.Loop)
            trail:get_animation():set_playback(Playback.Loop)

            local distance = 0

            start:get_animation():on_complete(function()
                start:get_animation():set_state("EXCALIBUR_START_LOOP")
                start:get_animation():set_playback(Playback.Loop)


                field:spawn(head, player:get_current_tile():get_tile(player:get_facing(), 1))
                field:spawn(trail, player:get_current_tile())
                
                local shake_artifact = Battle.Artifact.new()
                local time = 0
                shake_artifact.update_func = function(self)
                        
                    self:shake_camera(50, 0.016)
                    if time == 110 then 
                        self:delete()
                    end
                
                    time = time+1
                end

                field:spawn(shake_artifact, player:get_current_tile())

                local hits = 6
                start.update_func = function()
                    head:set_offset((distance+42)*offset_dir, 0)
                    if distance % 320 == 0 then 
                        if hits == 0 then return end
                        local tile = player:get_current_tile():get_tile(player:get_facing(), 1)
                        while not tile:is_edge()
                        do
                            create_attack(tile)
                            tile = tile:get_tile(player:get_facing(), 1)
                        end
                        
                        hits = hits - 1
                    end
                    distance = distance + 20
                    trail:sprite():set_width(distance*offset_dir)

                end
            end)



            local facing = player:get_facing()
            local user_tile = player:get_current_tile():get_tile(player:get_facing(), 1)

            -- Return all tiles in front of the player that are not edges and that are within 1 tile up or down from the player
            local tile_filter = function(tile)
                return not tile:is_edge() and (tile:x() - user_tile:x()) * offset_dir >= 0 and math.abs(tile:y() - user_tile:y()) <= 1
            end

            tile_list = field:find_tiles(tile_filter)

            action2:add_anim_action(14, function()
                field:spawn(start, player:get_current_tile())

            end)

            local function create_whiteout(d_a)
                local field = player:get_field()
                local whiteout = graphic_init("artifact", 0, 0, "ExcaliburEnding.png", "Saber.animation", -99, "WHITEOUT", player, player:get_facing())
                local white = whiteout:sprite()
                white:set_width(2000)
                white:set_height(2000)
                local starting_a = 0
                if d_a <  0 then 
                    starting_a = 255
                end
                local color = Color.new(0, 0, 0, starting_a)
                white:set_color(color)
                white:set_offset(-90, -100)

                whiteout.update_func = function()
                    white:set_color(color)
                    new_a = color.a + d_a
                    if new_a > 255 then 
                        new_a = 255
                    end

                    if new_a < 0 then 
                        new_a = 0
                    end
                    color.a = new_a

                end

                field:spawn(whiteout, field:tile_at(7, 4))

                return whiteout
            end

            

            local ending = graphic_init("artifact", 0, 0, "ExcaliburEnding.png", "Saber.animation", -99, "ENDING", player, player:get_facing())


            
            local whiteout1
            local whiteout2
            local whiteout3
            local whiteout4

            local target_deleted = false
            
            

            action2:add_anim_action(18, function()
                whiteout1 = create_whiteout(5)
            end)

            
            action2:add_anim_action(20, function()
                
                whiteout2:delete()
            end)

            

            action2:add_anim_action(19, function()
                start:delete()
                head:delete()
                trail:delete()
                whiteout2 = create_whiteout(-5)


                for i=1, #target_list
                do
                    if Battle.Character.from(target_list[i]) then 
                        if target_list[i]:get_health() == 0 then 
                            target_deleted = true 
                            break
                        end
                    end
                end

                if target_deleted then 
                    local actor = action2:get_actor()
                    actor:get_animation():set_state("EXCALIBUR_DYNAMIC")
                    field:spawn(ending, field:tile_at(7, 4))
                    --actor:get_animation():refresh(player:sprite())

                    actor:get_animation():on_frame(2, function()
                        whiteout3 = create_whiteout(5)
        
                    end)
        
                    actor:get_animation():on_frame(3, function()
                        whiteout1:delete()
                        whiteout2:delete()
                        whiteout3:delete()
                        ending:delete()

                        whiteout4 = create_whiteout(-5)
        
        
                    end)
        
                    actor:get_animation():on_frame(4, function()
                        whiteout4:delete()

                    end)

                    actor:get_animation():on_complete(function()
                        step:complete_step()
                    end)

                else
                    whiteout1:delete()
                    action2:add_anim_action(21, function()
                
                        step:complete_step()
                    end)
                end


            end)

            
        end

        return action2

    end



    local function dodge(player)
        local action = Battle.CardAction.new(player, "DODGE_START")
        action:set_lockout(make_sequence_lockout())
        local step = Battle.Step.new()
        local first = true
        local t = player:get_tile(player:get_facing_away(), 1)
        local facing = player:get_facing()
        local anim = action:get_actor():get_animation()
        local moved = 0
        local interrupted = false
        local move_tile = nil
        local start_tile = nil


        local move_component = nil
        local action_ended = false

        step.update_func = function()
            if first then 
                
                local move = MoveEvent.new() 
                    move.delta_frames = frames(32)
                    move.delay_frames = frames(0)
                    move.endlag_frames = frames(0)
                    move.height = 0
                    move.dest_tile = t
                    move.on_begin_func = function() end


                anim:on_complete(function()
                    local can_move = player:raw_move_event(move, ActionOrder.Immediate)
                    if not can_move then 
                        step:complete_step()
                    else
                        player:toggle_hitbox(false)
                        
                        anim:set_state("DODGE")
                        t:reserve_entity_by_id(player:get_id())
                        move_tile = t
                        local component = Battle.Component.new(player, Lifetimes.Local)
                        local actor = action:get_actor()

                        local duration = 15
                        local time = duration
                        local height = -(time+15)*time

                        local d_x = t:width()/duration

                        if player:get_facing() == Direction.Right then 
                            d_x = d_x *-1
                        end 

                        local x = 0
                        local already_moved = false
                        player:show_shadow(true)
                        player:set_shadow(Engine.load_texture(_modpath.."shadow.png"))
                        component.update_func = function()
                            height = ((time-duration)*time)/(duration/2)
                            x = x + d_x

                            
                            if moved ~= 0 and not already_moved then 
                                already_moved = true
                                start_tile = player:get_current_tile()
                                t:add_entity(player)
                                start_tile:remove_entity_by_id(player:get_id())

                                move_component = Battle.Component.new(player, Lifetimes.Scene)

                                local really_eject = false
                                move_component.update_func = function()
                                    if interrupted then 
                                        move_tile:add_entity(player)
                                        start_tile:remove_entity_by_id(player:get_id())
                                        move_component:eject()
                                        return
                                    elseif action_ended then 
                                        move_component:eject()
                                    end

                                end

                                player:register_component(move_component)

                            end

                            if time <= duration/2 and moved == 0 then 
                                moved = 1
                                if player:get_facing() == Direction.Left then 
                                    moved = -1
                                end
                            end
                            
                            actor:set_elevation(-1*height/2)
                            actor:set_offset(x+(moved*t:width()), 0)

                            if time == 0 then 
                                component:eject()
                                actor:set_offset(0, 0)
                                actor:set_elevation(0)


                            end

                            time = time - 1

                        end

                        player:register_component(component)
                        
                        anim:on_frame(2, function()
                            player:show_shadow(false)

                            player:toggle_hitbox(true)
                            anim:on_interrupt(function()
                                interrupted = true
                            end)
                        end)

                        

                        anim:on_complete(function()
                            local component = Battle.Component.new(player, Lifetimes.Scene)
                            component.update_func = function()
                                move_tile:add_entity(player)
                                start_tile:remove_entity_by_id(player:get_id())
                                component:eject()
                            end

                            player:register_component(component)

                            step:complete_step()
                        end)

                    end
                end)

                anim:on_frame(2, function()
                    step:complete_step()
                end)

                anim:on_frame(4, function()
                    player:toggle_hitbox(true)
                end)

                first = false
            end

        end


        action.execute_func = function()
            action:add_step(step)
        end

        action.action_end_func = function()
           action_ended = true
        end

        return action
    end

-- UP_SLASH
-- STAB
-- TURN_SLASH
-- SLASH
-- BACK_TURN_SLASH
-- SPIN_SLASH
-- OVERHEAD_SLASH
-- BIG_SPIN_SLASH
    local function charged_attack(player, from_normal)
        from_normal = from_normal or false
        local action = Battle.CardAction.new(player, "READY_SLASH")
        action:set_lockout(make_sequence_lockout())
        local anim = player:get_animation()
        local input = 0
        local first_step_added = false
        local field = player:get_field()
        local spells = {}
        

        
        -- data will include fields on damage, lifetime, and ender or not
        local function hit_tiles(data)

            local function create_attack(data)
                if not data.tile then return end
                local spell = Battle.Spell.new(player:get_team())
                spell:highlight_tile(Highlight.Solid)
                spell.has_hit = false

                local flags = Hit.Impact | Hit.Flinch
                if data.ender then 
                    flags = Hit.Impact | Hit.Flinch | Hit.Flash
                end

                local hit_props = HitProps.new(
                    data.damage,
                    flags,
                    Element.Sword, 
                    player:get_id(), 
                    Drag.None
                )

                spell:set_hit_props(hit_props)

                spell.lifetime = data.lifetime

                local can_hit = true

                spell.update_func = function(self)

                    for i=1, #spells
                    do
                        can_hit = not spell.has_hit
                    end
                                        
                    if can_hit then 
                        self:get_current_tile():attack_entities(self)
                    end

                    self.lifetime = self.lifetime - 1
                    if self.lifetime == 0 then 
                        self:delete()
                    end
                    
                end


                spell.collision_func = function(self)
                    self.has_hit = true
                end

                spell.attack_func = function()
                    Engine.play_audio(player.sounds.hit, AudioPriority.Low)
                end


                field:spawn(spell, data.tile)

                table.insert(spells, spell)
            end


           -- print("Attacking ", #data, " tiles")
            for i=1, #data
            do
                create_attack(data[i])
            end

        end

        local function check_inputs(i)

            if player:input_has(Input.Held.Left) then 
                i = 4
            end

            if player:input_has(Input.Held.Up) then 
                i = 3
            end

            if player:input_has(Input.Held.Right) then 
                i = 2
            end

            if player:input_has(Input.Held.Down) then 
                i = 1
            end

            if player:input_has(Input.Pressed.Use) then 
                i = 5
            end

            return i
        end

        action.update_func = function()
            if not first_step_added then 
                input = check_inputs(input)
            end
        end
    

        local low_slash

        local function up_slash()
            local step = Battle.Step.new()
            local first = true
            local input = 0
            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = player:get_attack_level()*10

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 4, ender = false}
            }

            step.update_func = function()
                if first then 
                    anim:set_state("UP_SLASH")
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    anim:on_frame(1, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(2, function()
                        hit_tiles(attacks)
                    end)

                    --[[
                    anim:on_frame(4, function()
                        print("input is ", input)
                        if input > 0 then
                            step:complete_step()

                            if input == 3 then
                                turn_slash()
                            elseif input == 2 then 
                                overhead_slash() 
                            else
                                low_slash()
                            end

                        end
                    end)
                    ]]
                    first = false
                end

              --  input = check_inputs(input)
            end

            action:add_step(step)
        end

        local function stab()
            local step = Battle.Step.new()
            local first = true
            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = 20 + player:get_attack_level()*20

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 10, ender = true},
                {tile = t:get_tile(facing, 2), damage = dmg, lifetime = 10, ender = true}

            }

            step.update_func = function()
                if first then 
                    anim:set_state("STAB")

                    anim:on_frame(2, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(3, function()
                        hit_tiles(attacks)
                    end)
                    anim:on_complete(function()
                        step:complete_step()
                    end)
                    first = false
                end

            end

            action:add_step(step)
        end

        local function turn_slash()
            local step = Battle.Step.new()
            local first = true

            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = 20+player:get_attack_level()*10

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 8, ender = true}
            }

            step.update_func = function()
                if first then 
                    anim:set_state("TURN_SLASH")
                    anim:on_frame(3, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)
                    anim:on_frame(5, function()
                        hit_tiles(attacks)
                    end)
                    anim:on_complete(function()
                        step:complete_step()
                    end)
                    first = false
                end

            end

            action:add_step(step)
        end

        local function slash()
            local step = Battle.Step.new()
            local first = true

            local facing = player:get_facing()
            local t = player:get_tile(facing, 1)
            local dmg = 30 + player:get_attack_level()*10

            local attacks = {
                {tile = t, damage = dmg, lifetime = 6, ender = true},
                {tile = t:get_tile(Direction.Up, 1), damage = dmg, lifetime = 6, ender = true},
                {tile = t:get_tile(Direction.Down, 1), damage = dmg, lifetime = 6, ender = true}

            }

            step.update_func = function()
                if first then 
                    anim:set_state("SLASH")

                    anim:on_frame(2, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(3, function()
                        hit_tiles(attacks)
                    end)
                    anim:on_complete(function()
                        step:complete_step()
                    end)
                    first = false
                end

            end

            action:add_step(step)
        end

        local function back_turn_slash()
            local step = Battle.Step.new()
            local first = true

            step.update_func = function()
                if first then 
                    anim:set_state("BACK_TURN_SLASH")
                    anim:on_complete(function()
                        step:complete_step()
                    end)
                    first = false
                end

            end

            action:add_step(step)
        end

        local function spin_slash()
            local step = Battle.Step.new()
            local first = true
            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = player:get_attack_level()*10

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 6, ender = false}
            }

            step.update_func = function()
                if first then 
                    anim:set_state("SPIN_SLASH")
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    anim:on_frame(2, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(3, function()
                        hit_tiles(attacks)
                    end)

                    first = false
                end

            end

            action:add_step(step)
        end

        local function overhead_slash()
            local step = Battle.Step.new()
            local first = true
            local input = 0

            local facing = player:get_facing()
            local t = player:get_tile(facing, 1)
            local dmg = player:get_attack_level()*10
            local state = "OVERHEAD_SLASH"
            local change = 0
            if from_normal then 
                change = 1
                state = "OVERHEAD_SLASH_NORMAL"
            end
            

            local attacks = {
                {tile = t, damage = dmg, lifetime = 6, ender = from_normal}
            }

            step.update_func = function()
                if first then 
                    anim:set_state(state)
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    anim:on_frame(2+2*change, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(3+2*change, function()
                        hit_tiles(attacks)
                    end)
                    
                    if not from_normal then 
                        anim:on_frame(5, function()
                            step:complete_step()
                        end)
                    end

                    --[[
                    anim:on_frame(5, function()
                        if input > 0 then
                            step:complete_step()

                            if input == 3 then
                                turn_slash()
                            elseif input == 2 then 
                                slash() 
                            else
                                up_slash()
                            end

                        end
                    end)
                    ]]
                    first = false
                end

              --  input = check_inputs(input)

            end

            action:add_step(step)
        end

        local function big_spin_slash()
            local step = Battle.Step.new()
            local first = true
            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = player:get_attack_level()*10

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 6, ender = true},
            }

            step.update_func = function()
                if first then 
                    anim:set_state("BIG_SPIN_SLASH")
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    anim:on_frame(3, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(4, function()
                        hit_tiles(attacks)
                    end)

                    first = false
                end

            end

            action:add_step(step)
        end

        low_slash = function()
            local step = Battle.Step.new()
            local first = true
            local input = 0

            local t = player:get_current_tile()
            local facing = player:get_facing()
            local dmg = player:get_attack_level()*5

            local attacks = {
                {tile = t:get_tile(facing, 1), damage = dmg, lifetime = 4, ender = false}
            }

            step.update_func = function()
                if first then 
                    anim:set_state("LOW_SLASH")
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    anim:on_frame(1, function()
                        Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                    end)

                    anim:on_frame(2, function()
                        hit_tiles(attacks)
                    end)
                    anim:on_frame(4, function()
                        step:complete_step()
                    end)
                    --[[
                    anim:on_frame(4, function()
                        print("input is ", input)
                        if input > 0 then
                            step:complete_step()

                            if input == 3 then
                                turn_slash()
                            elseif input == 2 then 
                                overhead_slash() 
                            else
                                up_slash()
                            end

                        end
                    end)
                    ]]
                    first = false
                end

               -- input = check_inputs(input)

            end

            action:add_step(step)
        end



        -- Low, stab, turn
        local function start_attack()
            local step = Battle.Step.new()
            local first = true
            anim:set_state("READY_SLASH")
            step.update_func = function()
                if first then 
                    anim:on_complete(function()
                        step:complete_step()
                    end)

                    first = false
                end

                input = check_inputs(input)

                if from_normal then 
                    overhead_slash()
                    step:complete_step()
                elseif input > 0 then
                    step:complete_step()

                    if input == 3 then
                        up_slash()
                        spin_slash()
                        big_spin_slash()
                    elseif input == 2 then 
                        stab() 
                    elseif input == 1 then 
                        low_slash()
                        overhead_slash()
                        slash()
                    elseif input == 5 then 
                        anim:set_state("FINISH")
                        anim:on_complete(function()
                            step:complete_step()
                        end)
                    end

                end
            end

            action:add_step(step)
        end


        action.execute_func = function()
            anim = action:get_actor():get_animation()
            first_step_added = true
            start_attack()
        end

        action.action_end_func = function()
            for i=1, #spells
            do
                if not spells[i]:is_deleted() then 
                    spells[i]:delete()
                end
            end
        end

        return action
    end

    local function heal(player)
        local action = Battle.CardAction.new(player, "PLAYER_IDLE")
        action:set_lockout(make_sequence_lockout())


        action.execute_func = function()
            expend_spell(player)
            player:set_health(player:get_health() + math.floor(player:get_max_health()*1/4))
            player:get_field():spawn(
                graphic_init("artifact", 0, 0, "spell_heal.png", "spell_heal.animation", -10, "DEFAULT", player, player:get_facing(), true),
                player:get_current_tile())

            Engine.play_audio(player.sounds.heal, AudioPriority.Low)


        end

        return action
    end


    local function create_special_action(player)
        local action = Battle.CardAction.new(player, "")
        action:set_lockout(make_sequence_lockout())

        local step = Battle.Step.new()
        local start_step = Battle.Step.new()
        local start_step_first = true
       

        step.update_func = function()
            if not player:input_has(Input.Held.Special) then 
                step:complete_step()

            end
      --      print("In special", player.step_time)
        --    print("Special pre-input is", player.special_pre_input)

            if player.command_spells ~= 0 and player:input_has(Input.Pressed.Right or player.special_pre_input == Input.Pressed.Right) then 
                player:card_action_event(Excalibur(player), ActionOrder.Voluntary)
                step:complete_step()

            end

            if player:input_has(Input.Pressed.Left or player.special_pre_input == Input.Pressed.Left) then 
                player:card_action_event(dodge(player), ActionOrder.Voluntary)
                step:complete_step()

            end

            if player.command_spells ~= 0 and player:input_has(Input.Pressed.Down or player.special_pre_input == Input.Pressed.Down) then 
                player:card_action_event(heal(player), ActionOrder.Voluntary)
                step:complete_step()

            end

            

            player.step_time = player.step_time + 1
            if player.step_time == 25 then
                step:complete_step()

            end
        end


        action.execute_func = function()
            action:add_step(step)
        end

        

        
        action.action_end_func = function()
            player.step_time = 0
            --cleanup(player)
           -- player.transforming = false

        end

        player:card_action_event(action, ActionOrder.Voluntary)

    end

   
    local function normal_attack(player)
        return charged_attack(player, true)
    end

    player.normal_attack_func = normal_attack
    player.charged_attack_func = charged_attack

    local first = true

    player.special_attack_func = function()
        
    end

    player.update_func = function(self)
        if first then 
            self.special_action_queued = false
            self.special_queue_counter = 0
            self.special_pre_input = nil
            self.action_queue_counter = 0
            self.step_time = 0

            self.command_spell:sprite():set_layer(-5)
            self.command_spell:set_texture(Engine.load_texture(_modpath.."Command.png"), true)
            local offsetX = 0
            if self:get_facing() == Direction.Left then 
                offsetX = offsetX * -1
            end
            self.command_spell:set_offset(offsetX, -56)
            self.command_spell:get_animation():load(_modpath.."Saber.animation")
            self.command_spell:get_animation():set_state("COMMAND_"..self.command_spells)
            self.command_spell:get_animation():refresh(self.command_spell:sprite())
            if self:get_facing() == Direction.Left then 
                self:get_field():spawn(self.command_spell, self:get_field():tile_at(6, 0))
            else self:get_field():spawn(self.command_spell, self:get_field():tile_at(1, 0))
            end



            local activate_component = Battle.Component.new(self, Lifetimes.Battlestep)
        
            activate_component.update_func = function()
                self.component_counter = self.component_counter+1
                if self.component_counter ~= self.artifact_counter then 
                    
                  --  print("They weren't equal anymore", self.component_counter, self.artifact_counter)

                    self.artifact_counter = self.component_counter
                    if self.command_defense then 
                        self:remove_defense_rule(self.command_defense)
                        self.command_defense = nil
                    end                

                   -- blocked = false
                   -- cooling = false
                   -- current_window = 0
                   -- cooldown = 0
        
                end
            end

            self.special_component = Battle.Component.new(self, Lifetimes.Battlestep)

            self.special_component.update_func = function()
                if self:input_has(Input.Released.Use) or self:input_has(Input.Released.Shoot) then 
                    self.action_queue_counter = 5
                end

                if self.action_queue_counter > 0 then 
                    self.action_queue_counter = self.action_queue_counter - 1
                end


                if not self.special_action_queued and (self:input_has(Input.Pressed.Special) and (self:get_animation():get_state() == "PLAYER_IDLE" or self:is_moving())) and self.action_queue_counter == 0 then
                    if not self.overdrive_during_action then
                        create_special_action(self)
                        self.special_action_queued = true
                    end
                end


                -- Accepts player input before action is processed
                    -- It was really annoying trying to special and inputting before the special action began, so this should help
                if self.special_action_queued and self.special_queue_counter < 6 and not self.special_pre_input then 
                    if self:input_has(Input.Pressed.Up) then 
                        self.special_pre_input = Input.Pressed.Up
                    elseif self:input_has(Input.Pressed.Right) then 
                        self.special_pre_input = Input.Pressed.Right
                    elseif self:input_has(Input.Pressed.Down) then 
                        self.special_pre_input = Input.Pressed.Down
                    elseif self:input_has(Input.Pressed.Left) then 
                        self.special_pre_input = Input.Pressed.Left
                    elseif self:input_has(Input.Pressed.Use) then 
                        self.special_pre_input = Input.Pressed.Use
                    end


                    if self.special_pre_input then 
                        --print("Received input before special update")
                    end
                end

                if self.special_action_queued then 
                    self.special_queue_counter = self.special_queue_counter + 1
                    if self.special_queue_counter == 6 then 
                        self.special_action_queued = nil
                        self.special_pre_input = nil
                        self.special_queue_counter = 0

                    end
                end                
            end

            self:register_component(self.special_component)
            self:register_component(activate_component)



            spawn_artifact(self)



            first = false
        end

        self.command_spell.update_func = function()
            self.command_spell:get_animation():set_state("COMMAND_"..self.command_spells)
        end

    end
end