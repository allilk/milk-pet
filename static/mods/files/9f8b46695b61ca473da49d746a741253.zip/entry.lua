
function package_init(package)
    package:declare_package_id("rune.legacy.uninstll")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"G","L","R"})
 
    local props = package:get_card_props()
    props.shortname = "Uninstll"
    props.damage = 40
    props.time_freeze = false
    props.element = Element.Plus
    props.description = "Destroy certain enemy Navi Cust Parts"
	props.card_class = CardClass.Standard
	props.limit = 1
	props.can_boost = false
end




function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_modpath.."spread_buster.png"), true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."spread_buster.animation")
		buster_anim:set_state("DEFAULT")

        local projectile = spawn_fireball(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		user:get_field():spawn(projectile, tile)
	end
	return action
end








function spawn_fireball(character)
	print("started fireball action")
    local action_name = "fireball"
    local facing = character:get_facing()
    debug_print('action ' .. action_name)
	local damage = 40
    local action = Battle.CardAction.new(character, "ATTACK")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2,function ()
            character:toggle_counter(true)
        end)
		self:add_anim_action(4,function()
            local tile = character:get_tile(facing,1)
            spawn_fireball(character, tile, facing, damage, fireball_texture, fireball_sfx, character.cascade_frame_index)
        end)
        self:add_anim_action(6,function ()
            character:toggle_counter(false)
        end)
	end
	character.ai_taken_turn = true
    return action
end

function is_tile_free_for_movement(tile,character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if tile:get_team() ~= character:get_team() then return false end
    if not tile:is_walkable() then return false end
    local occupants = tile:find_characters(function(other_character)
        return true
    end)
    if #occupants > 0 then 
        return false
    end
    return true
end

function spawn_visual_artifact(tile,character,texture,animation_path,animation_state,position_x,position_y)
    local field = character:get_field()
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture,true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x,position_y)
    field:spawn(visual_artifact, tile:x(), tile:y())
end

function spawn_fireball(owner, tile, direction, damage, fireball_texture, fireball_sfx, cascade_frame_index)
	print("in spawn fireball")
    local fireball_texture = Engine.load_texture(_modpath.."projectile.png")
    local fireball_sfx = Engine.load_audio(_modpath.."sfx.ogg")    
    local team = owner:get_team()
    local field = owner:get_field()
    Engine.play_audio(fireball_sfx, AudioPriority.Low)
	local spell = Battle.Spell.new(team)
    local direction = owner:get_facing()
	spell:set_texture(fireball_texture)
	spell:set_facing(direction)
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			40, 
			Hit.Impact | Hit.Flash, 
			Element.None, 
			owner:get_context(), 
			Drag.None
		)
	)
	local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil and not ent:is_team(spell:get_team()) or Battle.Character.from(ent) ~= nil and not ent:is_team(spell:get_team())
	end
	local sprite = spell:sprite()
	sprite:set_layer(-1)
	local animation = spell:get_animation()
	animation:load(_modpath .. "projectile.animation")
	animation:set_state("DEFAULT")
	animation:refresh(sprite)
	
	spell.has_hit = false
	
	spell.update_func = function(self, dt)
		spell:get_current_tile():attack_entities(spell)
		if self:get_current_tile():is_edge() and self.slide_started then 
			self:delete()
		end 
		
		local dest = self:get_tile(spell:get_facing(), 1)
		local ref = self
		if not self.has_hit then
			self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, 
				function()
					ref.slide_started = true 
				end
			)
		end
	end
	spell.collision_func = function(self, other)
		self.has_hit = true
		local fx1 = Battle.Artifact.new()
        local explosion_texture = Engine.load_texture(_modpath.."attack.png")
		fx1:set_texture(explosion_texture, true)
		local fx1_anim = fx1:get_animation()
		fx1_anim:load(_modpath.."attack.animation")
		fx1_anim:set_state("DEFAULT")
		fx1_anim:refresh(fx1:sprite())
		fx1:sprite():set_layer(-2)
		fx1_anim:on_complete(function()
			fx1:erase()
		end)
		field:spawn(fx1, self:get_tile())
		self:erase()
	end
    spell.attack_func = function(self, other) 
		local uninstll = Battle.Component.new(other, Lifetimes.Battlestep)
		local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
		local super_armor2 = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
		local super_armor3 = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
		local antifreeze = Battle.DefenseRule.new(913, DefenseOrder.CollisionOnly)
        local sunglasses = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
        local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
        uninstll.update_func = function(self, dt)
            local owner = self:get_owner()
            owner:set_air_shoe(false)
            owner:set_float_shoe(false)
            owner:add_defense_rule(super_armor)
            owner:remove_defense_rule(super_armor)
			owner:add_defense_rule(super_armor2)
            owner:remove_defense_rule(super_armor2)
			owner:add_defense_rule(super_armor3)
            owner:remove_defense_rule(super_armor3)
            owner:add_defense_rule(sunglasses)
            owner:remove_defense_rule(sunglasses)
            owner:add_defense_rule(undershirt)
            owner:remove_defense_rule(undershirt)
            owner:add_defense_rule(antifreeze)
            owner:remove_defense_rule(antifreeze)
            self:eject()
        end
        other:register_component(uninstll)
        self:delete()
    end    spell.delete_func = function(self)
		self:erase()
    end

	spell.can_move_to_func = function(tile)
		return true
	end
    return spell
end