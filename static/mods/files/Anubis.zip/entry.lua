nonce = function() end
 
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
local TEXTURE = Engine.load_texture(_modpath.."present.png")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."spell_explosion.png")
local MOB_MOVE_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
 
function package_init(package)
    package:declare_package_id("rune.legacy.anubis")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'P'})
 
    local props = package:get_card_props()
    props.shortname = "Anubis"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Summon
    props.secondary_element = Element.None
    props.description = "Anubis poisons enemies."
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local present = Battle.Obstacle.new(user:get_team())
		present:set_facing(user:get_facing())
		present:set_texture(TEXTURE, true)
		present_anim = present:get_animation()
		present_anim:load(_modpath.."present.animation")
		present_anim:set_state("SPAWN")
		present_anim:refresh(present:sprite())
		present_anim:on_complete(function()
			present_anim:set_state("DEFAULT")
			present_anim:refresh(present:sprite())
			present_anim:set_playback(Playback.Loop)
		end)
		present:sprite():set_layer(-2)
		present:set_health(100)
		local query = function(ent)
			if ent == present then
				return false
			else
				return ent and not ent:is_deleted() and #ent:get_name() > 0
			end
		end
		present.can_move_to_func = function(tile)
			if not tile then
				return false
			end
			if not tile:is_walkable() or tile:is_edge() or #tile:find_entities(query) > 0 then
				return false
			end
			return true
		end
		present.delete_func = function(self)
			local fx = Battle.Artifact.new()
			fx:set_texture(MOB_MOVE_TEXTURE, true)
			local fx_anim = fx:get_animation()
			fx_anim:load(_modpath.."mob_move.animation")
			fx_anim:set_state("DEFAULT")
			fx_anim:refresh(fx:sprite())
			fx_anim:on_complete(function()
				fx:erase()
			end)
			user:get_field():spawn(fx, self:get_tile())
			self:erase()
		end
		present.update_func = function(self, dt)
			local tile = present:get_current_tile()
			if not tile then
				self:delete()
			end
			if not tile:is_walkable() or tile:is_edge() then
				self:delete()
			end
			if self:get_health() <= 0 then
				self:delete()
			end
		end
		local cooldown = 6
		local delete_cooldown = 3000
		local original_cooldown = cooldown
		local field = user:get_field()
		local do_once = true
		local shake = true
		local shake_cooldown = 30
		local tile_query = function(t)
			return t and t:get_team() ~= user:get_team() and not t:is_edge()
		end
		present.gas = nil
		local tile_array = field:find_tiles(tile_query)
		present.update_func = function(self, dt)
			if self:get_offset().y >= 0 then
				if shake then
					if not self:get_tile():is_walkable() or self:get_tile():is_edge() then
						self:delete()
					elseif #self:get_tile():find_characters(query) > 0 or #self:get_tile():find_obstacles(query) > 0 then
						self:shake_camera(5.0, 0.5)
						local hitbox = Battle.Hitbox.new(user:get_team())
						hitbox:set_hit_props(
							HitProps.new(
								100,
								Hit.Impact | Hit.Breaking,
								Element.None,
								user:get_context(),
								Drag.None
							)
						)
						field:spawn(hitbox, self:get_tile())
						self:delete()
					else
						self:shake_camera(5.0, 0.5)
					end
					shake = false
				end
				if shake_cooldown <= 0 then
					if present.gas == nil then
						local gas_spawn_index = math.random(1, #tile_array)
						present.gas = create_gas(user, tile_array[gas_spawn_index], present)
					end
					if delete_cooldown <= 0 then
						self:delete()
					else
						delete_cooldown = delete_cooldown - 1
					end
					if cooldown <= 0 then
						local character_query = function(ent)
							return ent and not ent:is_deleted() and ent:get_team() ~= user:get_team() and ent:get_team() ~= Team.Other
						end
						local target_list = field:find_characters(character_query)
						for c = 1, #target_list, 1 do
							local explosion = create_boom(user, present)
							field:spawn(explosion, target_list[c]:get_tile())
						end
						cooldown = original_cooldown
					else
						cooldown = cooldown - 1
					end
				else
					shake_cooldown = shake_cooldown - 1
				end
			else
				self:set_offset(self:get_offset().x, self:get_offset().y + 16.0)
			end
		end
		present:set_offset(0.0, -192.0)
		present.battle_end_func = function(self)
			self:delete()
		end
		user:get_field():spawn(present, user:get_tile(user:get_facing(), 1))
	end
    return action
end

function create_gas(user, tile, anubis)
	local spell = Battle.Artifact.new()
	spell:set_texture(EXPLOSION_TEXTURE)
	spell:set_facing(user:get_facing())
	local anim = spell:get_animation()
    anim:load(_modpath.."spell_explosion.animation")
    anim:set_state("Default")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:delete()
	end)
	spell:sprite():set_layer(-2)

	spell.update_func = function(self, dt)
		if anubis:get_health() <= 0 or anubis:is_deleted() then
			self:delete()
		end
	end

	spell.delete_func = function(self)
		anubis.gas = nil
		self:erase()
	end
	user:get_field():spawn(spell, tile)
	return spell
end

function create_boom(user, anubis)
	local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(
        HitProps.new(
            1,
            Hit.Pierce, 
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
		self:erase()
    end
	
	spell.attack_func = function(self, other)
	end

	spell.collision_func = function(self, other)
	end
	spell.can_move_to_func = function(self, other)
		return true
	end
	return spell
end