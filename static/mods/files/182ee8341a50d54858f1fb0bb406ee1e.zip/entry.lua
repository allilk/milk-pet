function package_init(block)
    block:declare_package_id("com.Dawn.Official.BN6SuperArmor")
    block:set_name("SuprArmr")
    block:as_program()
    block:set_description("Do not flinch when hit")
    block:set_color(Blocks.Red)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
	super_armor.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flinch
		return statuses
	end
	player:add_defense_rule(super_armor)
end