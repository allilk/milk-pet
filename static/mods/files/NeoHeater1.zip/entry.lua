local BUSTER_TEXTURE = Engine.load_texture(_modpath.."spread_buster.png")
local BURST_TEXTURE = Engine.load_texture(_modpath.."spread_impact.png")
local AUDIO = Engine.load_audio(_modpath.."heatShotImpact.ogg")

--PREVIOUS Bugs: (think most are fixed now)
--code for some reason creates attacks at tiles from both the create attack and the create explosion, resulting in multi hits. Possible solution: remove all damage from the blast and make a third "impact" attack.
--for some reason tile2B doesn't spread properly, and will often appear at the end of the field or not appear at all. No clue what could be causing this.
--Hitting enemies in certain states with this chip just straight up crashes the game. Think this may have something to do with the target moving?

function package_init(package)
    package:declare_package_id("hoov.cards.neohetr1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"B","C","D","*"})
 
    local props = package:get_card_props()
    props.shortname = "NeoHetr1"
    props.damage = 50
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Powerful blast behind!"
    props.limit = 4
end

function card_create_action(actor, props) --Shot properties
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."spread_buster.animation")
		buster_anim:set_state("DEFAULT")
		
		local cannonshot = create_attack(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
	end
    return action
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage, --originally props.damage
            Hit.Impact, 
            Element.Fire,
            user:get_context(),
            Drag.None
        )
    )
	
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    local blast = create_explosion(user, props)
    local blast2 = create_explosion(user, props)
    spell.collision_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(BURST_TEXTURE, true)
		fx:get_animation():load(_modpath.."spread_impact.animation")
		fx:get_animation():set_state("DEFAULT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
		local tile = self:get_current_tile()
        local rightend = false
		if tile and not tile:is_edge() then
			spell:get_field():spawn(fx, tile)
		end
        local tile2A = self:get_current_tile():get_tile(direction, 1) 
		if tile2A and not tile2A:is_edge() then
            spell:get_field():spawn(blast, tile2A)
            rightend = true
        end
        if rightend == true then
        local tile2B = self:get_current_tile():get_tile(direction, 2) 
		if tile2B and not tile2B:is_edge() then
            spell:get_field():spawn(blast2, tile2B)
        end
        end
        self:delete()
	end



    spell.delete_func = function(self)
        self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    Engine.play_audio(AUDIO, AudioPriority.Low) --was high
    return spell
end


function create_explosion(user, props) --Spread Properties
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local attack_once = true
    spell:set_texture(BURST_TEXTURE, true)
    spell:set_hit_props(
        HitProps.new(
            props.damage + 20,
            Hit.Impact,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."spread_impact.animation")
    anim:set_state("DEFAULT")
    anim:refresh(spell:sprite())
    local attack_once = true
    anim:on_complete(function()
      
        spell:erase()
    end)
    spell:sprite():set_layer(-1)
    local query = function(ent)
        if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
            return true
        end
    end
    spell.update_func = function(self, dt)
       if attack_once then
        self:get_current_tile():attack_entities(self)
        attack_once = false
       end
    end

    spell.collision_func = function(self, other)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    --Engine.play_audio(AUDIO, AudioPriority.Low)
    return spell
end