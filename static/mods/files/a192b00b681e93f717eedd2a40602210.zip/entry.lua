nonce = function() end

local DAMAGE = 120
local TANKCAN_TEXTURE = Engine.load_texture(_modpath .. "tankcan.png")
local TANKCAN_ANIM = _modpath .. "tankcan.animation"
local BLAST_TEXTURE = Engine.load_texture(_modpath .. "blast.png")
local BLAST_ANIM = _modpath .. "blast.animation"
local BACKROW_BLAST = Engine.load_texture(_modpath .. "backrow_blast.png")
local BACKROW_BLAST_ANIM = _modpath .. "backrow_blast.animation"
local AUDIO = Engine.load_audio(_modpath .. "tankcan.ogg")
local CANNON = Engine.load_audio(_modpath .. "cannon.ogg")


function package_init(package)
	package:declare_package_id("com.louise.card.tankcan1")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ "A", "G", 'R' })

	local props = package:get_card_props()
	props.shortname = "TankCan1"
	props.damage = DAMAGE
	props.time_freeze = false
	props.element = Element.None
	props.description = "3sq blast if hits end row"
	props.long_description = "3square blast if hits end row"
end

local frame1 = { 1, 0.646 }
local frame_data = make_frame_data({
	frame1
})

---@param actor Entity
---@param props any
---@return unknown
function card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TANKCAN_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TANKCAN_ANIM)
		buster_anim:set_state("DEFAULT")

        buster_anim:on_frame(7, function()
			local blast = create_attack(user, props)
            actor:get_field():spawn(blast, actor:get_tile(actor:get_facing(), 1))
            user:shake_camera(10, 0.5)

            Engine.play_audio(CANNON, AudioPriority.Low)

		end)
		buster_anim:on_frame(8, function()
			offset = -12
			if (user:get_facing() == Direction.Left) then
				offset = 12
			end
			actor:set_offset(offset, 0)

            

		end)
		
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end

	action.action_end_func = function(self)
		actor:set_offset(0, 0)
	end

	return action
end


function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
	local fx = Battle.Artifact.new()
	fx:set_texture(hit_texture, true)
	local fx_sprite = fx:sprite()
	fx_sprite:set_layer(-3)
	local fx_anim = fx:get_animation()
	fx_anim:load(hit_anim_path)
	fx_anim:set_state(hit_anim_state)
	fx_anim:refresh(fx_sprite)
	fx_anim:on_complete(function()
		fx:erase()
	end)
	field:spawn(fx, tile)
	return fx
end

--filter function to only consider characters or obstacles
function filter(ent)
	if ent:get_health() <= 0 then return false end
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end
end

function create_back_attack(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)


    spell.update_func = function(self)
        local sprite = Battle.Artifact.new()
        sprite:set_texture(BLAST_TEXTURE)
        local animation = sprite:get_animation()
        animation:load(BLAST_ANIM)
        animation:set_state("DEFAULT")
        animation:refresh(sprite:sprite())
        animation:on_complete(function()
            sprite:delete()
        end)

        user:get_field():spawn(sprite, self:get_current_tile())

        self:get_current_tile():attack_entities(self)


        self:delete()
    end


    return spell
    
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Drag | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.new(direction, user:get_field():width())
		)
	)
	spell.do_once = true
	spell.update_func = function(self, dt)
        spell:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                user:shake_camera(22, 0.5)
                Engine.play_audio(AUDIO, AudioPriority.Highest)

                local t = self:get_tile(Direction.reverse(direction), 1)
                local blast = create_back_attack(user, props)
                user:get_field():spawn(blast, t)
				local tile_up = t:get_tile(Direction.Up, 1)
				local tile_down = t:get_tile(Direction.Down, 1)
                
                if t:get_state() == TileState.Cracked then 
                    t:set_state(TileState.Broken)
                else
				    t:set_state(TileState.Cracked)
                end

				if (not tile_up:is_edge()) then
					local blast = create_back_attack(user, props)
					user:get_field():spawn(blast, tile_up)
                    if tile_up:get_state() == TileState.Cracked then 
                        tile_up:set_state(TileState.Broken)
                    else
                        tile_up:set_state(TileState.Cracked)
                    end
				end
				if (not tile_down:is_edge()) then
					local blast = create_back_attack(user, props)
					user:get_field():spawn(blast, tile_down)
                    if tile_down:get_state() == TileState.Cracked then 
                        tile_down:set_state(TileState.Broken)
                    else
                        tile_down:set_state(TileState.Cracked)
                    end
				end

                create_basic_effect(user:get_field(), t, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")

                self:delete()

            end 
            
            local dest = self:get_tile(direction, 1)
            -- v2.0 makes this take 2f per tile. Change to actually this someday in the future, or use different slide code
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary,
                function()
                    self.slide_started = true 
                end
            )
        end
			
	
	end
    
	spell.collision_func = function(self, other)
        local sprite = Battle.Artifact.new()
        sprite:set_texture(BLAST_TEXTURE)
        local animation = sprite:get_animation()
        animation:load(BLAST_ANIM)
        animation:set_state("DEFAULT")
        animation:refresh(sprite:sprite())
        animation:on_complete(function()
            sprite:delete()
        end)
        user:get_field():spawn(sprite, other:get_current_tile())

        Engine.play_audio(AUDIO, AudioPriority.Highest)
        self:delete()
	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	spell.attack_func = function()

	end

	return spell
end
