local thunderbolt_texture = Engine.load_texture(_modpath .. "bolt.png")
local thunderbolt_anim = _modpath .. "bolt.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"
local THUNDERBOLT_SFX = Engine.load_audio(_modpath .. "thunderBolt.ogg")

function package_init(package)
    package:declare_package_id("com.D3stroy3d.player.Elecman")
    package:set_special_description("The power of electricity is the greatest power!")
    package:set_speed(5.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_modpath .. "elecman_face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_overworld_animation_path(_modpath .. "elecmanOW.animation")
    package:set_overworld_texture_path(_modpath .. "elecmanOW.png")
    package:set_mugshot_texture_path(_modpath .. "mug.png")
    package:set_mugshot_animation_path(_modpath .. "mug.animation")
end

function player_init(player)
    player:set_name("Elecman")
    player:set_health(1000)
    player:set_element(Element.Elec)
    player:set_height(65.0)
    player:set_animation(_modpath .. "elecman.animation")
    player:set_texture(Engine.load_texture(_modpath .. "elecman_atlas.png"), true)
    player:set_fully_charged_color(Color.new(255, 0, 0, 255))

    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack

    --[[zap_ring_texture = Engine.load_texture(_modpath.."thunder.png")
    modpath = _modpath]] --
    player.update_func = function(self, dt)
        -- nothing in particular
    end
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
    local anim = player:get_animation()
    local targets = find_targets(player)
    local action = Battle.CardAction.new(player, "CHARGE_BOLT")
    local highlight = true
    action.update_func = function()
        if (highlight) then
            for index, value in ipairs(targets) do
                value:highlight(Highlight.Flash)
            end
        end
    end
    action.execute_func = function(self)
        self:add_anim_action(6, function()
            highlight = false
            for index, value in ipairs(targets) do
                create_thunderbolt(player, value, 40 + (player:get_attack_level() * 20))
            end
        end)
    end
    return action
end

function create_thunderbolt(owner, target, damage)
    local tile = target
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local spell = Battle.Spell.new(team)
    Engine.play_audio(THUNDERBOLT_SFX, AudioPriority.High)
    spell:set_hit_props(HitProps.new(damage, Hit.Flash | Hit.Flinch | Hit.Impact, Element.Elec, owner_id, Drag.new()))
    spell:set_texture(thunderbolt_texture)
    local spell_animation = spell:get_animation()
    spell:set_facing(owner:get_facing())
    spell_animation:load(thunderbolt_anim)
    spell_animation:set_state("1")
    spell_animation:refresh(spell:sprite())
    spell_animation:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-2)
    spell.update_func = function()
        spell:get_current_tile():attack_entities(spell)
        spell:get_current_tile():set_state(TileState.Cracked)
    end
    spell.collision_func = function(self, other)
        local artifact = Battle.Artifact.new()
        artifact:set_texture(HIT_TEXTURE)
        artifact:set_animation(HIT_ANIM_PATH)
        --FX
        local anim = artifact:get_animation()
        anim:set_state("ELEC")
        artifact:get_animation():refresh(artifact:sprite())
        anim:on_complete(function()
            artifact:erase()
        end)
        field:spawn(artifact, tile)
    end
    field:spawn(spell, tile)
    return spell

end

--find target tiles
function find_targets(self)
    local field = self:get_field()
    local team = self:get_team()
    local result = {}
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        return
    end
    for index, value in ipairs(target_list) do
        table.insert(result, value:get_tile())
    end
    return result
end
