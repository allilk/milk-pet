local DAMAGE = 50
local SHOTS_COUNT = 3
local NEEDLE_TYPE = "1"

local TEXTURE_BUSTER = Engine.load_texture(_modpath.."buster.png")
local TEXTURE_NEEDLE = Engine.load_texture(_modpath.."needle.png")
local ANIMPATH_BUSTER = _modpath.."buster.animation"
local ANIMPATH_NEEDLE = _modpath.."needle.animation"

local AUDIO_SHOOT = Engine.load_audio(_modpath.."shoot.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE1-037-TripleSpear")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F","G","H","I","J"})

    local props = package:get_card_props()
    props.shortname = "TriSpear"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "Fires a 3-spear burst"
    props.long_description = "Fires a 3-shot spear"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    action.hits = SHOTS_COUNT

    local frame1 = {1, 0.033}
    local frame2 = {1, 0.305}
    action.frames = {frame1,frame1,frame1,frame2}

    action.before_exec = function(action)
        local frame3 = {1, 0.017}
        local frame4 = {1, 0.033}
        local frame5 = {1, 0.118}
        local frame6 = {1, 0.067}
        for i = 1, action.hits do
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame5)
        end
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame4)
        table.insert(action.frames,frame4)
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    action.before_exec(action)

    action.execute_func = function(self, user)
        local field = user:get_field()
        local direction = user:get_facing()

        local attacking = false

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TEXTURE_BUSTER, true)
		buster:sprite():set_layer(-2)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(ANIMPATH_BUSTER)
		buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())
        
        self:add_anim_action(2, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(5, function()
            buster_anim:set_state("1")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Loop)
        end)

        for i = 0, action.hits, 1 do
            self:add_anim_action(5+(i*6),function()
                if attacking then
                    Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                    create_needle(user, props, field, user:get_tile(direction, 1))
                end
            end)
        end

        self:add_anim_action(6, function()
            user:toggle_counter(false)
        end)

        self:add_anim_action(#action.frames-5,function()
            attacking = false
            buster_anim:set_state("2")
            buster_anim:refresh(buster:sprite())
        end)
        
	end
    action.action_end_func = function ()
        user:toggle_counter(false)
    end
    return action
end

function create_needle(user, props, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(user:get_team())
        local direction = user:get_facing()
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_height(78.0)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact, 
                props.element, 
                user:get_context(), 
                Drag.None
            )
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_NEEDLE)
        sprite:set_layer(2)

        local anim = spell:get_animation()
        anim:load(ANIMPATH_NEEDLE)
        anim:set_state(NEEDLE_TYPE)
        anim:refresh(sprite)
        anim:on_complete(function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
            spell:erase()
        end, true)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end

        spell.collision_func = function(self, other)
            spell:erase()
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end