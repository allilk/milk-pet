local DAMAGE = 170

local KINGMAN_TEXTURE = Engine.load_texture(_modpath.."kingman.png")
local KINGMAN_ANIMPATH = _modpath.."kingman.animation"
local TOWER_TEXTURE = Engine.load_texture(_modpath.."tower.png")
local TOWER_ANIMPATH = _modpath.."tower.animation"
local WARP_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local WARP_ANIMPATH = _modpath.."mob_move.animation"
local AUDIO_EARTHQUAKE = Engine.load_audio(_modpath.."earthquake.ogg")
local AUDIO_ATTACK1 = Engine.load_audio(_modpath.."attack1.ogg")
local AUDIO_ATTACK2 = Engine.load_audio(_modpath.."attack2.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
	package:declare_package_id("com.k1rbyat1na.card.EXE3-267-KingManV2")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"K"})

	local props = package:get_card_props()
	props.shortname = "KingManV2"
	props.damage = DAMAGE
	props.time_freeze = true
	props.can_boost = true
	props.element = Element.None
	props.description = "Move up 3sq,atk 4 ways!"
	props.long_description = "Jumps to an empty square 3 squares ahead and attacks up, down, left and right!"
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		local actor = self:get_actor()
		actor:hide()

		local NOT_HOLE_1 = nil
		local NOT_HOLE_2 = nil

		local VOICEACTING = false
        local input_time = 50
        local voiceline_number = 0

		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local self_tile = user:get_current_tile()
		local target_tile = user:get_tile(direction, 3)

		local query = function(ent)
			if ent:get_health() > 0 then
				if not user:is_team(ent:get_team()) then
					return true
				end
			end
		end
		local dark_query = function(o)
			return o:get_health() > 0
		end

		local step1 = Battle.Step.new()

		self.kingman = nil

		local ref = self

		local do_once = true
		local do_once_part_two = true
		step1.update_func = function(self, dt)
			if input_time > 0 then
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
            end
			if self_tile ~= nil or not self_tile:is_hole() then
                NOT_HOLE_1 = true
            else
                NOT_HOLE_1 = false
            end
			if target_tile ~= nil or not target_tile:is_hole() then
				if #target_tile:find_obstacles(query) <= 0 and #target_tile:find_characters(query) <= 0 then
                	NOT_HOLE_2 = true
				else
					NOT_HOLE_2 = false
				end
            else
                NOT_HOLE_2 = false
            end
			if do_once then
				do_once = false
				ref.kingman = Battle.Artifact.new()
				ref.kingman:set_facing(direction)
				local boss_sprite = ref.kingman:sprite()
				boss_sprite:set_layer(-5)
				boss_sprite:set_texture(KINGMAN_TEXTURE, true)
				local boss_anim = ref.kingman:get_animation()
				boss_anim:load(KINGMAN_ANIMPATH)
				if NOT_HOLE_1 then
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
				else
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
				end
				if NOT_HOLE_2 then
					print("Tile ("..target_tile:x()..";"..target_tile:y()..") is NOT a hole!")
				else
					print("Tile ("..target_tile:x()..";"..target_tile:y()..") IS a hole!")
				end
				if NOT_HOLE_1 and NOT_HOLE_2 then
					boss_anim:set_state("1")
					boss_anim:refresh(boss_sprite)
				elseif NOT_HOLE_1 and not NOT_HOLE_2 then
					boss_anim:set_state("2")
					boss_anim:refresh(boss_sprite)
				else
					boss_anim:set_state("3")
					boss_anim:refresh(boss_sprite)
				end
				boss_anim:on_frame(21, function()
					if NOT_HOLE_1 then
						Engine.play_audio(AUDIO_EARTHQUAKE, AudioPriority.High)
						ref.kingman:shake_camera(15, 0.3)
					else
						create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -32, field, target_tile)
					end
				end)
				boss_anim:on_frame(66, function()
					if NOT_HOLE_2 then
						ref.kingman:shake_camera(15, 0.3)
						if target_tile:get_tile(Direction.Up, 1):is_hole() and target_tile:get_tile(Direction.Down, 1):is_hole() and target_tile:get_tile(Direction.Left, 1):is_hole() and target_tile:get_tile(Direction.Right, 1):is_hole() then
							Engine.play_audio(AUDIO_ATTACK1, AudioPriority.High)
						else
							Engine.play_audio(AUDIO_ATTACK2, AudioPriority.High)
							create_tower(user, props, target_tile:get_tile(Direction.Up, 1), team, field)
							create_tower(user, props, target_tile:get_tile(Direction.Down, 1), team, field)
							create_tower(user, props, target_tile:get_tile(Direction.Left, 1), team, field)
							create_tower(user, props, target_tile:get_tile(Direction.Right, 1), team, field)
						end
					else
						create_effect(WARP_TEXTURE, WARP_ANIMPATH, "4", 0, -32, field, target_tile)
					end
				end)
				boss_anim:on_complete(function()
					ref.kingman:erase()
                    step1:complete_step()
				end)
				field:spawn(ref.kingman, self_tile)
			end
		end
		self:add_step(step1)
	end
	action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_flash(team, direction, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_facing(direction)
	spell:highlight_tile(Highlight.Flash)
	local animation = spell:get_animation()
    animation:load(_modpath.."attack.animation")
    animation:set_state("0")
    animation:on_complete(function()
        spell:erase()
    end)

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

	field:spawn(spell, tile)

	return spell
end

function create_tower(owner, props, tile, team, field)
    local spawn_tower
    spawn_tower = function()
        if tile == nil or tile:is_edge() or tile:is_hole() then return end

        local spell = Battle.Spell.new(team)
        spell:set_hit_props(HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            owner:get_id(),
            Drag.new())
        )
		local sprite = spell:sprite()
		sprite:set_texture(TOWER_TEXTURE, true)
		sprite:set_layer(-99)
        local anim = spell:get_animation()
        anim:load(TOWER_ANIMPATH)
        anim:set_state("0")
        anim:on_complete(function()
            spell:erase()
        end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
			create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "AQUA", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_tower()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end