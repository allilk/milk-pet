function package_init(block)
    block:declare_package_id("com.alrysc.block.airshoes")
    block:set_name("Airshoes")
    block:as_program()
    block:set_description("Move ovr hole")
    block:set_color(Blocks.White)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 0, 1, 0,
        0, 1, 0, 1, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_air_shoe(true)

end