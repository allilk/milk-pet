
local HIT = Engine.load_audio(_modpath.."hit.ogg")
local HIT2 = Engine.load_audio(_modpath.."break.ogg")
local SHOOT = Engine.load_audio(_modpath.."cannon.ogg")

function package_init(package) 
    package:declare_package_id("com.alrysc.card.Railgun3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'I','M','R','Z'})

    local props = package:get_card_props()
    props.shortname = "Railgun3"
    props.damage = 200
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Railgun destroys panels ahead!"
    props.limit = 2
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local FRAME1 = {1, 0.033} -- This should be 3f, but of course ONB makes that 4 right now
    local FRAME2 = {2, 0.05}
    local FRAME3 = {2, 0.033}
    local FRAME4 = {2, 0.266}
    local field = user:get_field()

    
-- shake 6f

    local FRAMES = make_frame_data({FRAME1, FRAME2, FRAME3, FRAME4})
    action:override_animation_frames(FRAMES)


    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end
    
    local function create_shot(tile, facing)
        local spell = Battle.Spell.new(user:get_team())
        local has_hit = false

		spell:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact | Hit.Flash | Hit.Flinch,
				props.element,
				user:get_context(),
				Drag.None
			)
		)

        spell.update_func = function(self, dt)        
			self:get_tile():attack_entities(self)
			if self:is_sliding() == false then
				if self:get_current_tile():is_edge() and self.slide_started then 
					self:delete()
				end 
				
				local dest = self:get_tile(facing, 1)
				local ref = self
				self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
					function()                           
                        ref.slide_started = true 
					end
				)

                if self.slide_started and not has_hit then 
                    if tile:get_state() == TileState.Cracked then
                        tile:set_state(TileState.Broken)
                    else
                        tile:set_state(TileState.Cracked)
                    end
                    tile = tile:get_tile(facing, 1)


                    local hit_effect = graphic_init("artifact", 0, 0, "railgun.png", "railgun.animation", -3, "EFFECT", user, facing, true)

                    field:spawn(hit_effect, self:get_current_tile())
                end
			end
		end

        spell.collision_func = function(self, other)
            has_hit = true
            self:delete()
            Engine.play_audio(HIT2, AudioPriority.Low)
            local shake_artifact = Battle.Artifact.new()
            local time = 0
            shake_artifact.update_func = function(self)
                    
                self:shake_camera(200, 0.016)
                if time == 6 then 
                    self:delete()
                end
            
                time = time+1
            end

            field:spawn(shake_artifact, tile)

        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)

        end

        spell.can_move_to_func = function()
            return true
        end

        field:spawn(spell, tile:get_tile(facing, 1))

    end

    action.execute_func = function(self)
        action:add_anim_action(2, function()
            local gun = self:add_attachment("Buster")
            local gun_sprite = gun:sprite()
            gun_sprite:set_texture(Engine.load_texture(_modpath.."railgun.png"), false)
            gun_sprite:set_layer(-2)
            gun_sprite:enable_parent_shader(true)
            
            local gun_anim = gun:get_animation()
            gun_anim:load(_modpath.."railgun.animation")
            gun_anim:set_state("GUN")
        
        end)

        action:add_anim_action(3, function()
            Engine.play_audio(SHOOT, AudioPriority.Low)

        end)
        action:add_anim_action(4, function()
            create_shot(user:get_current_tile(), user:get_facing())

        end)
    end


    return action
end