function package_init(package)
    package:declare_package_id("com.alrysc.player.Yorihime")
    package:set_special_description("Yorihime.EXE from Gensou Network!")
  --  package:set_speed(1.0)
    package:set_attack(1)
   -- package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."yorihime_ow.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
 --   package:set_icon_texture(Engine.load_texture(_modpath.."NormalNavi_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."yorihime_mug.png")
  --  package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Yorihime")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(60.0)

    local base_texture = Engine.load_texture(_modpath.."yorihime.png")
    local base_animation_path = _modpath.."yorihime.animation"

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(4, -23)

    player.cycle = 1
    player.special_cooldown_MAX = 90
    player.special_cooldown = 0 

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.update_func = function()
        player.special_cooldown = player.special_cooldown - 1
    end

    local common = {
        sword_slash = Engine.load_audio(_modpath.."sfx.ogg"),
        slash_texture = Engine.load_texture(_modpath.."slashes.png"),
        tink = Engine.load_audio(_modpath.. "tink.ogg"),
        hit = Engine.load_audio(_modpath.. "hit.ogg")
    }

    function graphic_init(type, x, y, texture, animation, layer, state, user, facing, flip)
        flip = flip or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type =="spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        graphic:get_animation():load(_folderpath..animation)

        graphic:get_animation():set_state(state)
        graphic:get_animation():refresh(graphic:sprite())

        return graphic
    end
    
    -- Return a certain action based on given integer/enum cycle
    function create_charge_attack(player, cycle)
        local action = Battle.CardAction.new(player, "PLAYER_CHARGE")
        local sword
        local lifetime = 10
        if cycle == 4 then 
            lifetime = 8
        elseif cycle == 1 then 
            lifetime = -1
        end
        local has_hit = false
        local current_tile
        local above_tile
        local below_tile
        local far_tile1 
        local far_tile2 
        local far_above 
        local far_below 
        local adjacent_above 
        local adjacent_below 

        local attack_details = {}

        local function create_slash(player, cycle)
            local spell = Battle.Spell.new(player:get_team())
            spell:set_facing(player:get_facing())

            local damage = 15 + player:get_attack_level()*15
            local flags = Hit.Impact | Hit.Flash | Hit.Flinch
            local element = Element.Sword

            spell:set_hit_props(
                HitProps.new(
                    damage,
                    flags,
                    element,
                    player:get_context(),
                    Drag.None
                )
	        )
            local current_attack = attack_details[cycle]
            local cross_attack = Battle.Spell.new(player:get_team())
            local tile
            cross_attack:set_facing(player:get_facing())
            player:get_field():spawn(cross_attack, player:get_current_tile())

            cross_attack:set_hit_props(
                HitProps.new(
                    damage*2,
                    flags,
                    element,
                    player:get_context(),
                    Drag.None
                )
            )

            spell.update_func = function(self)
                if not has_hit then 
                    for i=3, current_attack[1]+2, 1
                    do
                        tile = current_attack[i]
                        if cycle == 1 then 
                            tile = spell:get_current_tile()
                        end

                        -- This can probably be deleted. Was just making sure the cross attack was happening
                        if i == 5 and current_attack[2] == "CROSS" then 
                            --print("Cross")
                        else
                            if tile then 
                                tile:attack_entities(self)
                                --tile:highlight(Highlight.Solid)
                            end
                        end

                    end

                    if cycle == 1 then 
                        --self:get_current_tile():attack_entities(self)
                        if self:is_sliding() == false then
                            if self:get_current_tile():is_edge() and self.slide_started then 
                                self:delete()
                            end 
                            
                            local dest = self:get_tile(self:get_facing(), 1)
                        --   local ref = self
                            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                                function()
                                    self.slide_started = true 
                                end
                            )
                        end
                    end
                end

                lifetime = lifetime - 1
                if lifetime == 0 then 
                    has_hit = true
                    if cycle == 1 then 
                        spell:delete()
                    end
                end
            end

            local function collision_function()
                has_hit = true
                lifetime = 10
            end

            local function attack_function()
                Engine.play_audio(common.hit, AudioPriority.Low)
            end

            spell.collision_func = collision_function
            cross_attack.collision_func = collision_function
            spell.attack_func = attack_function
            cross_attack.attack_func = attack_function
            spell.can_move_to_func = function()
                return true
            end

            cross_attack.update_func = function()
                if cycle == 4 and not has_hit then
                    current_attack[5]:attack_entities(cross_attack)
                  --  current_attack[5]:highlight(Highlight.Solid)
                end
                if spell:is_deleted() then 
                    cross_attack:delete()
                end

                if lifetime == 3 then 
                    cross_attack:delete()
                end
            end
            return spell
        end


        action.execute_func = function()
            action:add_anim_action(6,function()
                current_tile = player:get_current_tile():get_tile(player:get_facing(), 1)
                above_tile = current_tile:get_tile(Direction.Up, 1)
                below_tile = current_tile:get_tile(Direction.Down, 1)
                far_tile1 = current_tile:get_tile(player:get_facing(), 1)
                far_tile2 = current_tile:get_tile(player:get_facing(), 2)
                far_above = current_tile:get_tile(player:get_facing(), 1):get_tile(Direction.Up, 1)
                far_below = current_tile:get_tile(player:get_facing(), 1):get_tile(Direction.Down, 1)
                adjacent_above = player:get_current_tile():get_tile(Direction.Up, 1)
                adjacent_below = player:get_current_tile():get_tile(Direction.Down, 1)

                -- First number indicates how many panels this attack hits
                    -- If I hadd more attacks here, make sure to check action.action_end_func for the CS to make sure player.cycle accounts for it
                attack_details = {
                    {1, "SWORDBEAM", current_tile},
                    {3, "WIDESWORD", current_tile, above_tile, below_tile},
                    --{2, "LONGSWORD", current_tile, far_tile1},
                    {3, "FIGHTERSWORD", current_tile, far_tile1, far_tile2},
                    {5, "CROSS", adjacent_above, adjacent_below, current_tile, far_above, far_below},
                    {6, "LIFESWORD", current_tile, above_tile, below_tile, far_tile1, far_above, far_below}
                    
                }
                sword = create_slash(player, cycle)
                Engine.play_audio(common.sword_slash, AudioPriority.Low)

                player:get_field():spawn(sword, current_tile)
                local anim = sword:get_animation()
                sword:set_texture(common.slash_texture, true) 
                anim:load(_modpath.."slashes.animation")
                anim:set_state("SWORD"..cycle)
                anim:on_complete(function()
                    if not sword:is_deleted() then 
                        sword:erase()
                    end
                end)
			end)

        end

        action.action_end_func = function()
            player.cycle = player.cycle + 1
            if player.cycle > 5 then
                player.cycle = 1
            end

            if sword and (player.cycle-1 ~= 1) and not sword:is_deleted() then 
                sword:delete()
            end
        end

        return action
    end

    player.charged_attack_func = function(player)

        local action = create_charge_attack(player, player.cycle)

        return action
    end


    function create_special_attack(player, target)
        if target then 
            local tile
            if target:is_deleted() then 
                local enemy_filter = function(character)
                    return character:get_team() ~= player:get_team()
                end
            
                local enemy_list = nil
                enemy_list = player:get_field():find_nearest_characters(player, enemy_filter)
                tile = enemy_list[1]:get_current_tile()

            else
                tile = target:get_tile()
            end
            if not tile then 
                return nil
            end
          --  print("They're on", tile:x(), tile:y())
            local count = 0
            local attacking = false
            local starting = false

            local spell = Battle.Spell.new(player:get_team())
            spell:set_facing(player:get_facing())
            spell:set_texture(base_texture, true)
            local anim = spell:get_animation()
            anim:load(_modpath.."Yorihime.animation")
            anim:set_state("BLADE_WAIT")
            spell:sprite():set_layer(-5)
            anim:refresh(spell:sprite())
            anim:on_complete(function()
            
            end)

            spell:set_hit_props(
                HitProps.new(
                    10 + player:get_attack_level()*10,
                    Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Breaking,
                    Element.Sword,
                    player:get_context(),
                    Drag.None
                )
            )

            spell.update_func = function()
                if count < 15 and not attacking then 
                    tile:highlight(Highlight.Flash)
                elseif not starting then 
                    spell:get_animation():set_state("BLADE_ATTACK")
                    spell:get_animation():on_frame(2, function()
                        attacking = true
                    
                    end)

                    spell:get_animation():on_complete(function()
                        spell:delete()

                    end)

                    spell:get_animation():on_frame(6, function()
                        attacking = false
                    end)

                    starting = true
                end

                if attacking then 
                    tile:attack_entities(spell)
                end

                count = count + 1
            end

            spell.attack_func = function()
                Engine.play_audio(common.hit, AudioPriority.Low)
            end
            player:get_field():spawn(spell, tile)
        else
            return nil
        end
    end

    player.special_attack_func = function(player)
        local action = nil
        local blocked = false
        local extra_duration = 5

        if player.special_cooldown < 1 then 
            action = Battle.CardAction.new(player, "PLAYER_IDLE")
            local IDLE = {0, 0.6 }
            local FRAMES = make_frame_data({IDLE})
        
            action:set_lockout(make_animation_lockout())
            action:override_animation_frames(FRAMES)

            local blade = Battle.Obstacle.new(player:get_team())
            local duration = 30
            blocked = false

            local blade_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
            blade_defense_rule.can_block_func = function(judge, attacker, defender)
                local attacker_hit_props = attacker:copy_hit_props()
                if attacker_hit_props.damage > 0 and duration ~= 0 then
                --    judge:block_impact()
                    judge:block_damage()
                    if not blocked then 
                        Engine.play_audio(common.tink, AudioPriority.Highest)
                        local guard_effect = graphic_init("artifact", 0, -30, "guard_hit.png", "guard_hit.animation", -2, "DEFAULT", player, player:get_facing())
                        guard_effect:get_animation():on_complete(function()
                            guard_effect:delete()
                        end)
                        player:get_field():spawn(guard_effect, blade:get_current_tile())
                    --   local direction = player:get_facing()
                        
                        blade:get_animation():set_state("BLADE_BLOCK")
                        blade:get_animation():on_complete(function()
                            blade:delete()
                        end)

                        create_special_attack(player, player:get_field():get_entity(attacker_hit_props.aggressor))
                        blocked = true
                    else
                        blade:toggle_hitbox(false)
                    end
                end

            end

            blade:add_defense_rule(blade_defense_rule)

            action.update_func = function()
                if blocked then 
                    extra_duration = extra_duration - 1
                    if extra_duration == 0 then 
                        action:end_action()
                    end
                end

            end

            action.execute_func = function()
                blade.update_func = function()
                    if not blocked then 
                        if duration == 0 and not blocked then 
                            blade:delete()
                        end
                        duration = duration - 1
                    end
                end

                blade:set_facing(player:get_facing())
                blade:set_texture(base_texture, true)
                local anim = blade:get_animation()
                anim:load(_modpath.."Yorihime.animation")
                anim:set_state("BLADE_WAIT")
                anim:refresh(blade:sprite())
                anim:on_complete(function()
                
                end)
                blade:set_health(1)

                player:get_field():spawn(blade, player:get_current_tile():get_tile(player:get_facing(), 1))
            end

            player.special_cooldown = player.special_cooldown_MAX
        end
        return action
    end

end
