local HIT
local APPEAR
local EXPLODE
local STARTUP
local SUCCESS
local SHOOT
local VULCAN

function package_init(package) 
    package:declare_package_id("com.alrysc.card.TankManX")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'T','X'})

    local props = package:get_card_props()
    props.shortname = "TankMX"
    props.damage = 200
    props.time_freeze = true
    props.element = Element.None
    props.description = "Mchngun, then Tank Cannon!"
    props.limit = 1
    props.card_class = CardClass.Mega

end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true
    

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local tankman
    local count = 0
    local b_count = 0
    local accept_input = false
    local actor
    step.update_func = function()
        if count == 9 then 
            actor:hide()
            field:spawn(tankman, user:get_current_tile())
            Engine.play_audio(APPEAR, AudioPriority.Low)

            step_first = false
        end

        if accept_input then 
            if user:input_has(Input.Pressed.Shoot) then 
                b_count = b_count + 1
            end

        end

        count = count + 1
    end


    local tiles = {}
    local tiles_iter = 1

    local function search_tiles(user, facing, command)
        if command then 
            Engine.play_audio(SUCCESS, AudioPriority.Low)
        end
        local x = user:get_current_tile():x()
        local y = 1
        local iter_x = 1
        local iter_y = 1
        local team = user:get_team()
        local initial_x

        if not command then 
            if facing == Direction.Left then 
                iter_x = -1
            end

            local i = x
            while(i > 0 and i < 7)
            do
                if field:tile_at(i, y):get_team() ~= team then 
                    x = i
                    initial_x = x
                    break
                end

                y = y+1
                if y == 4 then 
                    y = 1
                    i = i+iter_x
                end

            end

            initial_x = x - iter_x

            local tile_iter = 1
            for i=1, 9
            do
                tiles[tile_iter] = field:tile_at(x, y)
                tile_iter = tile_iter+1

                y = y+iter_y
                if y == 4 or y == 0 then 
                    x = x + iter_x
                    iter_y = iter_y * -1
                    y = y+iter_y
                    if x == 0 or x == 7 or x == initial_x then 
                        iter_x = iter_x * -1
                        x = x + iter_x

                    end
                end
            end
        else
            local enemy_filter = function(character)
                return character:get_team() ~= team 
            end
            local enemy_list = user:get_field():find_nearest_characters(user, enemy_filter)
            local enemy_tile

            if not enemy_list[1] then 
                if facing == Direction.Right then 
                    enemy_tile = field:tile_at(user:get_tile():y(), 6)
                else
                    enemy_tile = field:tile_at(user:get_tile():y(), 1)
                end

            else
                enemy_tile = enemy_list[1]:get_current_tile()
            end

            local tile_iter = 1
            for i=1,9
            do
                tiles[tile_iter] = enemy_tile
                tile_iter = tile_iter+1
            end
        end


    end


    local function shoot(command)
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        local lifetime = 3

        local damage = 50 
        if command then 
            damage = 10
        end

        local hit_props = HitProps.new(damage,
                                   Hit.Impact | Hit.Flinch | Hit.Breaking | Hit.Shake,
                                   Element.None, user:get_context(), Drag.None)

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_tile():attack_entities(self)
            lifetime = lifetime - 1
            if lifetime == 0 then 
                self:delete()
            end
        end


        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)

        end


        local offset = {
            y = -80,
            x = 30
        }   

        local height = 40
        local facing = user:get_facing()
        local facing_offset = 1
        if facing == Direction.Left then 
            facing_offset = facing_offset * -1
        end

        create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "_small")

        offset.x = offset.x - 48
        create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "_small")

        local artifact = graphic_init("artifact", 0, 0, "shot_hit.png", "tankman.animation", -3, "SHOT_HIT", user, user:get_facing_away())

        field:spawn(spell, tiles[tiles_iter])
        field:spawn(artifact, tiles[tiles_iter])
        tiles_iter = tiles_iter + 1

        Engine.play_audio(VULCAN, AudioPriority.Low)

    end

    local function shoot_cannon()
        local facing = user:get_facing()

        local spell = graphic_init("spell", 0, -50, "tankman.png", "tankman.animation", -3, "BULLET", user, user:get_facing())
        spell:highlight_tile(Highlight.Solid)

        local hit_props = HitProps.new(props.damage,
                                   Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking | Hit.Shake,
                                   Element.None, user:get_context(), Drag.None)

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_tile():attack_entities(self)
            if self:is_sliding() == false then
				if self:get_current_tile():is_edge() and self.slide_started then 
					self:delete()
				end 
				
				local dest = self:get_tile(facing, 1)
				local ref = self
				self:slide(dest, frames(2), frames(0), ActionOrder.Voluntary, 
					function()                           
                        ref.slide_started = true 
					end)
            end
        end


        spell.collision_func = function(self, other)
            field:spawn(graphic_init("artifact", 0, 0, "tankman.png", "tankman.animation", -3, "EXPLOSION", user, facing, true), other:get_current_tile())
            Engine.play_audio(EXPLODE, AudioPriority.Low)

            local shake_artifact = Battle.Artifact.new()
                local time = 0
                shake_artifact.update_func = function(self)
                        
                    self:shake_camera(200, 0.016)
                    if time == 17 then 
                        self:delete()
                    end
                
                    time = time+1
                end

                field:spawn(shake_artifact, user:get_current_tile())


            self:delete()

        end
        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)

        end

        spell.can_move_to_func = function()
            return true
        end

        
        local offset = {
            y = -100,
            x = -20
        }   

        local height = 40
        local facing_offset = 1
        if facing == Direction.Left then 
            facing_offset = facing_offset * -1
        end

        create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "")

        field:spawn(spell, user:get_tile(facing, 1))

    end

    action.execute_func = function()
        actor = action:get_actor()

        action:add_step(step)
        accept_input = true

        HIT = Engine.load_audio(_modpath .. "hit.ogg")
        APPEAR = Engine.load_audio(_modpath .. "appear.ogg")
        EXPLODE = Engine.load_audio(_modpath .. "bombmiddle.ogg")
        STARTUP = Engine.load_audio(_modpath .. "machineRunning.ogg")
        SUCCESS = Engine.load_audio(_modpath .. "CommandSuccess.ogg")
        SHOOT = Engine.load_audio(_modpath .. "cannon.ogg")
        VULCAN = Engine.load_audio(_modpath .. "vulcan.ogg")


        local facing = user:get_facing()
        tankman = graphic_init("artifact", 0, 0, "tankman.png", "tankman.animation", -3, "DEFAULT", user, facing)
        
        local anim = tankman:get_animation()
        anim:on_complete(function()
            tankman:delete()
            step:complete_step()
            user:reveal()
        end)

        anim:on_frame(8, function()
            accept_input = false
            search_tiles(user, facing, (b_count >= 3))
            Engine.play_audio(STARTUP, AudioPriority.Low)
        end)

        anim:on_frame(52, function()
            Engine.play_audio(SHOOT, AudioPriority.Low)
            shoot_cannon()
        end)

        for i=1, 9
        do
            anim:on_frame((6+4*i), function()
                shoot((b_count >= 3))
            end)
        end
        
    end

    return action
end 

function create_bullet_shell(sound, user, start_pos, pX, pY, pZ, facing, time, count, spin, tile, type, spell, spell_anim)
    spell = nil or spell
    spell_anim = nil or spell_anim
    local called_with_spell = false
    if spell then called_with_spell = true end
    local plusY = 0.0
    local speedY = 3*2 -- 2 is the scale

    local offset_facing = 1

    if facing == Direction.Left then 
        offset_facing = offset_facing * -2
    end

    local end_pos = {
        x = (start_pos.x - (8 + 16 * count * offset_facing)),
        y = start_pos.y + 1.8*pZ
    }

  --  local end_pos = {
    --    x = (start_pos.x - (8*4 + 8*2 * count * offset_facing)),
      --  y = start_pos.y + 1.5*pZ
   -- }

    local moveX = (start_pos.x - end_pos.x) / time
    local moveY = (start_pos.y - end_pos.y) / time
    local plusing = speedY / (time / 2) 


    local real_offset = {
        x = start_pos.x,
        y = start_pos.y
    }


    local function update(pX, pY, time)

        local new_offset = {}
    
        new_offset[1] = pX - moveX
        new_offset[2] = pY - moveY
        plusY = plusY + speedY
        speedY = speedY - plusing
    
        return new_offset
    end
    

    if not spell then 
        spell = Battle.Artifact.new()
        spell_anim = spell:get_animation()
        spell:set_offset(start_pos.x, start_pos.y)


        spell:sprite():set_layer(-3)


        spell:set_texture(Engine.load_texture(_modpath.."shell"..type..".png"), true)
        spell:set_animation(_modpath.."shell"..type..".animation")
    end
    spell.time = time

    spell_anim:set_state("shell"..spin)
    spell_anim:refresh(spell:sprite())


    spell.update_func = function(self)
        self:get_animation():set_state("shell"..spin)
        self:get_animation():refresh(self:sprite())


        spin = spin+1
        if spin > 9 then 
            spin = 0 
        end

        self.time = self.time - 1
        if self.time == 0 then 
            if count > 0 then 
                create_bullet_shell(sound, user, self:get_offset(), pX, pY, 0, facing, math.floor(time/2), count-1, spin, self:get_current_tile(), type, spell, spell_anim)
            else
                self:delete()
            end
        end

        local new_offset = update(pX, pY, self.time)
        pX = new_offset[1]
        pY = new_offset[2]
        self:set_offset(pX, (pY - plusY))
    end


    if not called_with_spell then 
        user:get_field():spawn(spell, tile)
    end

end