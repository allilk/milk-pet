local noop = function () end
local animation_path = _modpath.."targetdummy.animation"

local regen = false

-- entry.lua

local idle_update
local healtimer = 0

idle_update = function(dummy, dt)
  --local y = canodumb:get_tile():y()
  local team = dummy:get_team()

  local field = dummy:get_field()
  if dummy:get_rank() == Rank.V2 then
    --while dummy:get_health() < 1000 do
    if dummy:get_health() < 1000 then
      healtimer = healtimer + 1
      --print("count") --remove afterwards
      if healtimer % 250 == 0 then
        dummy:set_health(dummy:get_health() + 1000) --handles v2 variant life recovery
        Engine.play_audio(AUDIO, AudioPriority.Low)
        healtimer = 0
        print("healed!")
      end
    end
      if dummy:get_health() >= 1000 then
        healtimer = 0
        --print ("timer reset")
      --end
      end
     
    end



end


function package_init(dummy)
    AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

  -- private variables

  dummy._idle_state = "IDLE1"

  -- meta
  dummy:set_name("TrgtDmy")
  dummy:set_height(44)

  local rank = dummy:get_rank()

  if rank == Rank.V1 then
    dummy:set_health(1000)
    --regen = false
  elseif rank == Rank.V2 then
    dummy._idle_state = "IDLE2"
    --regen = true
    dummy:set_name("TrgtDmy")
    dummy:set_health(1000)
  else
    --safeguard
    dummy:set_health(200)
    --regen = false
  end

  dummy:set_texture(Engine.load_texture(_modpath.."targetdummy.png"))

  local anim = dummy:get_animation()
  anim:load(animation_path)
  anim:set_state(dummy._idle_state)
  --anim:set_playback(Playback.Once)

  -- setup defense rules
  dummy.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
  dummy:add_defense_rule(dummy.defense)

  -- setup event hanlders
  dummy.update_func = idle_update
  dummy.battle_start_func = noop
  dummy.battle_end_func = noop
  dummy.on_spawn_func = noop
  --canodumb.delete_func = delete_func
end
