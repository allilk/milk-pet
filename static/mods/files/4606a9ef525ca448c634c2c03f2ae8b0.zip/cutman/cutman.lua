local DAMAGE = 150
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")

local CUTMAN_TEXTURE = Engine.load_texture(_folderpath.."cutman.png")
local CUTMAN_ANIMPATH = _folderpath.."cutman.animation"
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe1-spawn.ogg")
local AUDIO_CHOKKIN = Engine.load_audio(_folderpath.."chokkin.ogg")

local cutman = {
    codes = {"C"},
	shortname = "CutMan",
	damage = DAMAGE,
	time_freeze = true,
	element = Element.None,
	description = "Scissor attacks 1 square!",
	long_description = "Snip attack to 1 square in front of you!",
	can_boost = true,
	card_class = CardClass.Mega,
	memory = 20,
	limit = 1
}

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-209-CutMan")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes(cutman.codes)

    local props = package:get_card_props()
    props.shortname = cutman.shortname
    props.damage = cutman.damage
    props.time_freeze = cutman.time_freeze
    props.element = cutman.element
    props.description = cutman.description
    props.long_description = cutman.long_description
    props.can_boost = cutman.can_boost
	props.card_class = cutman.card_class
	props.limit = cutman.limit
end

cutman.card_create_action = function(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
		actor:hide()

        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

		local step1 = Battle.Step.new()

        self.cutman = nil
        self.tile   = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.cutman = Battle.Artifact.new()
                ref.cutman:set_facing(facing)
                local cut_sprite = ref.cutman:sprite()
		    	cut_sprite:set_layer(-5)
		    	cut_sprite:set_texture(CUTMAN_TEXTURE, true)
                local cut_anim = ref.cutman:get_animation()
                cut_anim:load(CUTMAN_ANIMPATH)
                cut_anim:set_state("SPAWN")
		    	cut_anim:refresh(cut_sprite)
                cut_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.Highest)
                end)
		    	cut_anim:on_complete(function()
		    		cut_anim:set_state("ATTACK")
		    		cut_anim:refresh(cut_sprite)
		    	end)
                field:spawn(ref.cutman, ref.tile)
            end
            local anim = ref.cutman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local tile = user:get_tile(facing, 1)
                    local chokkin = create_chokkin(user, props, team, facing, tile)
                    anim:on_frame(3, function()
                        print("CutMan: Surprise Chokkin!")
                        Engine.play_audio(AUDIO_CHOKKIN, AudioPriority.Highest)
                        field:spawn(chokkin, tile)
                    end)
                    anim:on_complete(function()
                        chokkin:erase()
                        anim:set_state("END")
                        anim:refresh(ref.cutman:sprite())
                        anim:on_complete(function()
                            ref.cutman:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_chokkin(user, props, team, facing, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.delete_func = function(self)
		spell:erase()
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end

    print("Chokkin attacked tile ("..tile:x()..";"..tile:y()..")")

	return spell
end

return cutman