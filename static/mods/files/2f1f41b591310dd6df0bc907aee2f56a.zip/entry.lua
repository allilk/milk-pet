local DAMAGE = 180

local TOADMAN_TEXTURE = Engine.load_texture(_modpath.."toadman.png")
local TOADMAN_ANIMPATH = _modpath.."toadman.animation"
local SHOCKINGMELODY_TEXTURE = Engine.load_texture(_modpath.."shockingmelody.png")
local SHOCKINGMELODY_ANIMPATH = _modpath.."shockingmelody.animation"
local SHOCKINGMELODY_AUDIO = Engine.load_audio(_modpath.."shockingmelody.ogg")
local AUDIO_SPAWN = Engine.load_audio(_modpath.."exe2-spawn.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-229-ToadManV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"T"})

    local props = package:get_card_props()
    props.shortname = "ToadManV3"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Elec
    props.description = "Shocking Melody paralyzes!"
    props.long_description = "Shocking Melody tracks the enemy and paralyzes them!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 40
        local voiceline_number = 0

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)

		local step1 = Battle.Step.new()

        self.toadman = nil
        self.tile    = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                --print("READING")
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    --print("VOICE")
                    VOICEACTING = true
                end
            end

            if do_once then
                do_once = false
                ref.toadman = Battle.Artifact.new()
                ref.toadman:set_facing(direction)
                local toad_sprite = ref.toadman:sprite()
		    	toad_sprite:set_texture(TOADMAN_TEXTURE, true)
		    	toad_sprite:set_layer(-2)
                local toad_anim = ref.toadman:get_animation()
                toad_anim:load(TOADMAN_ANIMPATH)
                --[[if self_tile ~= nil or not self_tile:is_hole() then
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
                    toad_anim:set_state("0")
		    	    toad_anim:refresh(toad_sprite)
				else
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
                    toad_anim:set_state("1")
		    	    toad_anim:refresh(toad_sprite)
				end]]
                toad_anim:set_state("0")
		    	toad_anim:refresh(toad_sprite)
                toad_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                toad_anim:on_frame(10, function()
                    --[[if self_tile ~= nil or not self_tile:is_hole() then
                        print("ToadMan: ShockingMelody!")
                        Engine.play_audio(SHOCKINGMELODY_AUDIO, AudioPriority.High)
                        spawn_shockingmelody(user, props, user:get_tile(direction,1), team, direction, field, self_Y, enemy_list[1]:get_current_tile():y())
                    end]]
                    print("ToadMan: ShockingMelody!")
                    Engine.play_audio(SHOCKINGMELODY_AUDIO, AudioPriority.High)
                    spawn_shockingmelody(user, props, user:get_tile(direction,1), team, direction, field, self_Y, enemy_list[1]:get_current_tile():y())
                end)
		    	toad_anim:on_complete(function()
		    		ref.toadman:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.toadman, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function diag_dir(user_facing, spell_Y, enemy_Y, tile)
    local next_tile
    local direction_U
    local direction_D
    if user_facing == Direction.Right then
        direction_U = Direction.UpRight
        direction_D = Direction.DownRight
    else
        direction_U = Direction.UpLeft
        direction_D = Direction.DownLeft
    end
    if     spell_Y == 1 then
        if     enemy_Y == 1 then
            next_tile = tile:get_tile(user_facing, 1)
        elseif enemy_Y == 2 then
            next_tile = tile:get_tile(direction_D, 1)
        elseif enemy_Y == 3 then
            next_tile = tile:get_tile(direction_D, 1)
        end
    elseif spell_Y == 2 then
        if     enemy_Y == 1 then
            next_tile = tile:get_tile(direction_U, 1)
        elseif enemy_Y == 2 then
            next_tile = tile:get_tile(user_facing, 1)
        elseif enemy_Y == 3 then
            next_tile = tile:get_tile(direction_D, 1)
        end
    elseif spell_Y == 3 then
        if     enemy_Y == 1 then
            next_tile = tile:get_tile(direction_U, 1)
        elseif enemy_Y == 2 then
            next_tile = tile:get_tile(direction_U, 1)
        elseif enemy_Y == 3 then
            next_tile = tile:get_tile(user_facing, 1)
        end
    end
    return next_tile
end

function spawn_shockingmelody(owner, props, tile, team, direction, field, user_Y, enemy_Y)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() or tile == nil then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(Direction.Right)
        spell:set_hit_props(HitProps.new(
            props.damage,
            Hit.Impact | Hit.Stun | Hit.Flinch,
            props.element,
            owner:get_id(),
            Drag.None)
        )

        local sprite = spell:sprite()
        sprite:set_texture(SHOCKINGMELODY_TEXTURE)
        sprite:set_layer(-3)
        --sprite:never_flip(true)

        local animation = spell:get_animation()
        animation:load(SHOCKINGMELODY_ANIMPATH)
        animation:set_state("0")
        animation:refresh(sprite)

        animation:on_frame(4, function()
            tile = diag_dir(direction, spell:get_current_tile():y(), enemy_Y, tile)
            spawn_next()
        end, true)
        animation:on_complete(function() 
            spell:erase()
        end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function(self)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "ELEC", math.random(-10,10), math.random(-10,10), -99999, field, self:get_current_tile())
        end

        spell.collision_func = function(self)
            self:erase()
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end