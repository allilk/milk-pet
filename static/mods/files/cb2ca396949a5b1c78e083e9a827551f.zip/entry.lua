function package_init(block)
    block:declare_package_id("com.ipc.bodypack")
    block:set_name("Bodypack")
    block:as_program()
    block:set_description("Armr,Sht Flot,Air 4-pc set")
    block:set_color(Blocks.Pink)
    block:set_shape({
        0, 0, 1, 0, 0,
        1, 1, 1, 1, 1,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    player:set_air_shoe(true)
    player:set_float_shoe(true)
    local hit = false;
    local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
    local damage
    local component = Battle.Component.new(player, Lifetimes.Scene)
    local prevHP = player:get_health()


    undershirt.can_block_func = function(judge, attacker, defender)
        damage = attacker:copy_hit_props().damage

        if prevHP > 1 and (player:get_health() - damage) <= 0 then 
            player:mod_max_health(damage)
            hit = true
        end

        
    end

    component.update_func = function()
        if hit then 
            player:mod_max_health(damage*-1) 
            player:set_health(1)
            hit = false 

        end
        prevHP = player:get_health()

    end
        
    player:register_component(component)
    player:add_defense_rule(undershirt)
    local super_armor = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
	super_armor.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Flinch
		return statuses
	end
	player:add_defense_rule(super_armor)
end