nonce = function() end

local frame_data = make_frame_data({
	{ 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})

local DAMAGE = 100

local AUDIO = Engine.load_audio(_modpath.."roll.ogg")
local AUDIO_FIRE = Engine.load_audio(_modpath .. "roll.ogg")
local AUDIO_HIT = Engine.load_audio(_modpath .. "hitsound.ogg")

function package_init(package) 
    package:declare_package_id("DJ.bowling.1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"B", "L", "P"})

    local props = package:get_card_props()
    props.shortname = "Bowling1"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Break
    props.description = "Knock em down!"
	props.long_description ="Knock em down like pins!"
end

function card_create_action(player, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(player, "PLAYER_SWORD")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HAND")
		end)
		self:add_anim_action(3, function()
			local cannonshot = create_zap(player, props)
			local tile = user:get_tile(user:get_facing(), 1)
			player:get_field():spawn(cannonshot, tile)
		end)
	end
	return action

end

function create_zap(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:highlight_tile(Highlight.Solid)
	local direction = user:get_facing()
	spell:set_facing(direction)
	local actual_props = HitProps.new(
		props.damage,
		Hit.Impact | Hit.Flinch | Hit.Breaking,
		Element.Break,
		user:get_context(),
		Drag.None
        )
    
		spell:set_hit_props(actual_props)
		spell.slide_started = false
		spell.update_func = function(self, dt)
			if not spell:get_tile() or spell:get_tile():is_edge() then self:delete() end
			if not spell:get_tile():is_walkable() then self:delete() end
			spell:get_tile():attack_entities(self)
			local dest = self:get_tile(direction, 1)
			local ref = self
			self:slide(dest, frames(9), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
		end
	
		local TEXTURE = Engine.load_texture(_modpath .. "spell_zapring.png", true)
		spell:set_texture(TEXTURE, true)
		local fx_anim = spell:get_animation()
		fx_anim:load(_modpath .. "spell_zapring.animation")
		fx_anim:set_state("DEFAULT")
		fx_anim:set_playback(Playback.Loop)
	
		spell:set_offset(spell:sprite():get_offset().x, spell:sprite():get_offset().y - 10.0)
	

    spell.attack_func = function(self, other) 
        
    
    end
	
	spell.collision_func = function(self, other)
		Engine.play_audio(AUDIO_HIT, AudioPriority.Highest)
		
	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
		Engine.play_audio(AUDIO, AudioPriority.High)
        return true
    end

    
	
	

    return spell
end