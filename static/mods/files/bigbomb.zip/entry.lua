local bomb = include('bomb.lua')

bomb.name="Bigbomb"
bomb.damage=140
bomb.element=Element.None
bomb.description = "Throws a 9 panl bomb 3panl fwd"
bomb.codes = {"O","P","V"}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = bomb.name
    props.damage = bomb.damage
    props.time_freeze = false
    props.element = bomb.element
    props.description = bomb.description

    package:declare_package_id("com.ipc.card."..props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(bomb.codes)
end

card_create_action = bomb.card_create_action