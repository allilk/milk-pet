local DAMAGE = 80

local AUDIO = Engine.load_audio(_modpath.."elecshock.ogg")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster.png")
local BUSTER_ANIMPATH = _modpath.."buster.animation"
local ATTACK_TEXTURE = Engine.load_texture(_modpath.."attack.png")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE4-029-ElecShock")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"J","L","S","*"})

    local props = package:get_card_props()
    props.shortname = "ElecShok"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Cracker Electric blast"
    props.long_description = "Radial discharge attack! Cracks panels"
    props.can_boost = true
    props.card_class = CardClass.Standard
	props.limit = 4
end

local frame1 = {1, 0.04}
local frame2 = {1, 0.05}
local frame3 = {1, 0.06}
local frame4 = {1, 0.04}
local frame_data = make_frame_data({
    frame1, frame2, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4
}) 

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
 
        local elec_2 = nil
        local elec_3 = nil
        local elec_4 = nil

        if user:get_facing() == Direction.Right then
            elec_2 = Direction.UpRight
            elec_3 = Direction.Right
            elec_4 = Direction.DownRight
        elseif user:get_facing() == Direction.Left then
            elec_2 = Direction.UpLeft
            elec_3 = Direction.Left
            elec_4 = Direction.DownLeft
        end

        local field = user:get_field()
        local tile = user:get_tile(user:get_facing(), 1)
        local tile2 = tile:get_tile(elec_2, 1)
        local tile3 = tile:get_tile(elec_3, 1)
        local tile4 = tile:get_tile(elec_4, 1)

        self.elec1 = create_attack(user, props)
        self.elec2 = create_attack(user, props)
        self.elec3 = create_attack(user, props)
        self.elec4 = create_attack(user, props)

        local point = user:get_animation():point("BUSTER")
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
		buster_sprite:set_layer(-2)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster_sprite)

        self:add_anim_action(1, function()
            buster_sprite:set_texture(BUSTER_TEXTURE, true)
			buster_sprite:set_layer(-2)

			buster_anim:load(ANIMPATH_EFFECT, true)
			buster_anim:set_state("0")
            buster_anim:refresh(buster_sprite)
        end)
				
		self:add_anim_action(3, function()
            user:toggle_counter(true)
			if not tile:is_edge() and tile:get_state() ~= TileState.Broken and tile:get_state() ~= TileState.Empty then
                field:spawn(self.elec1, tile)
                Engine.play_audio(AUDIO, AudioPriority.High)
            end
		end) 

		self:add_anim_action(5, function()
			user:toggle_counter(false)
            if self.elec1.has_spawned then
                self.elec1:get_animation():on_frame(8, function()
                    if not tile3:is_edge() and tile3:get_state() ~= TileState.Broken and tile3:get_state() ~= TileState.Empty then
                        field:spawn(self.elec3, tile3)
                    end
                    if not tile2:is_edge() and tile2:get_state() ~= TileState.Broken and tile2:get_state() ~= TileState.Empty then
                        field:spawn(self.elec2, tile2)
                    end
                    if not tile4:is_edge() and tile4:get_state() ~= TileState.Broken and tile4:get_state() ~= TileState.Empty then
                        field:spawn(self.elec4, tile4)
                    end
                end)
            end
		end)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function create_attack(user, props)
    local spell = Battle.Spell.new(user:get_team())
    local field = user:get_field()
    spell:set_facing(user:get_facing())
    spell:set_texture(ATTACK_TEXTURE, true)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
            )
        )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("ATTACK")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-1)
    
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if tile:is_walkable() then
            tile:set_state(TileState.Cracked)
        end
    end

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end
    return spell
end