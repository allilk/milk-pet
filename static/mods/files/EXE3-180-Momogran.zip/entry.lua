local DAMAGE = 0

local TEXTURE_MOMOGRAN = Engine.load_texture(_modpath.."momogran.png")
local ANIMPATH_MOMOGRAN = _modpath .. "momogran.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SWING = Engine.load_audio(_modpath.."swing.ogg")

local TEXTURE_BUTTON = Engine.load_texture(_modpath.."button.png")
local ANIMPATH_BUTTON = _modpath .. "button.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath .. "effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE3-180-Momogran")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G","M","O","R","U"})

    local props = package:get_card_props()
    props.shortname = "Momogran"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Summons a Momogran to fight!"
	props.long_description = "Summons a Momogran to attack!"
	props.can_boost = false
    props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local step1 = Battle.Step.new()
		local momogran = Battle.Artifact.new()
		local do_once0 = true
		local do_once = true
        local do_once1 = true
		local do_once2 = true
		local momogran_type = 1
		local attacked = false
        local time_over = false
		step1.update_func = function(self, dt)
			if do_once0 then
                do_once0 = false
                local query = function() return true end
                local tile = user:get_tile(direction, 1)
				momogran:set_facing(direction)
                momogran:set_offset(0, -7)
				momogran:set_texture(TEXTURE_MOMOGRAN, true)
				local momogran_sprite = momogran:sprite()
				momogran_sprite:set_layer(-3)
                local momogran_anim = momogran:get_animation()
                momogran_anim:load(ANIMPATH_MOMOGRAN)
                momogran_anim:set_state("START")
		    	momogran_anim:refresh(momogran_sprite)
		    	momogran_anim:on_complete(function()
                    if not tile:is_walkable() or #tile:find_characters(query)~= 0 then
		    		    momogran_anim:set_state("END")
                    else
                        momogran_anim:set_state("SPAWN")
                    end
                    momogran_anim:refresh(momogran_sprite)
		    	end)
                field:spawn(momogran, tile)
            end
			local anim = momogran:get_animation()
            if anim:get_state() == "SPAWN" then
                if do_once then
					do_once = false
                    anim:on_frame(1, function()
                        Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                        print("ROULETTE START")
                        anim:set_state("SELECT")
                        anim:refresh(momogran:sprite())
                        anim:set_playback(Playback.Loop)
                    end)
                end
            end
            if anim:get_state() == "SELECT" then
				if do_once1 then
					do_once1 = false

                    local tile1 = user:get_tile(direction, 1)
					local tile2 = user:get_tile(direction, 2)

					local button_gui = Battle.Artifact.new()
					button_gui:set_facing(Direction.Right)
                    button_gui:set_offset(0, 30)
		    		button_gui:set_texture(TEXTURE_BUTTON, true)
					local button_sprite = button_gui:sprite()
					button_sprite:set_layer(-9999999)
					local button_anim = button_gui:get_animation()
					button_anim:load(ANIMPATH_BUTTON)
					button_anim:set_state("0")
					button_anim:set_playback(Playback.Loop)
		    		button_anim:refresh(button_sprite)
					field:spawn(button_gui, tile1)

                    local momogran_sprite = momogran:sprite()

                    local frames = {1,2,4,2,3,4,3,1,2,3,4,2,1,4,2,4,1,4,3,
                                    4,3,4,3,1,2,3,1,2,4,3,1,4,1,3,4,3,2,1}

                    for f = 1, 38, 1 do
                        anim:on_frame(f,function()
                            if      frames[f] == 1 then
                                momogran_type=1
                            elseif  frames[f] == 2 then
                                momogran_type=2
                            elseif  frames[f] == 3 then
                                momogran_type=3
                            else
                                momogran_type=4
                            end
                        end)
                    end
                    anim:on_complete(function()
                        time_over=true
                    end)

					momogran.update_func = function(self, dt)
						if not attacked then
						    if user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot) or time_over then
						    	if do_once2 then
						    		button_gui:erase()
						    		anim:set_state("V"..momogran_type.."_ATTACK")
						    		anim:refresh(momogran_sprite)
                                    anim:set_playback(Playback.Once)
                                    anim:on_frame(1, function()
                                        if      momogran_type == 1 then
                                            print("RESULT: Momogran")
                                        elseif  momogran_type == 2 then
                                            print("RESULT: Momogrow")
                                        elseif  momogran_type == 3 then
                                            print("RESULT: Momogreo")
                                        else
                                            print("RESULT: Momogran SP")
                                        end
                                    end)
						    		anim:on_frame(11,function()
                                        print("Momogran: Mogu!")
                                        Engine.play_audio(AUDIO_SWING, AudioPriority.High)
                                        create_attack(user, team, direction, field, tile2, momogran_type)
						    		end)
                                    anim:on_complete(function()
                                        anim:set_state("END")
                                        anim:refresh(momogran_sprite)
                                    end)
						    		attacked = true
						    		do_once2=false
						    	end
						    end
					    end
				    end
			    end
			end
            if anim:get_state() == "END" then
                anim:on_complete(function()
                    momogran:erase()
                    step1:complete_step()
                end)
            end
		end
		self:add_step(step1)
	end
    return action
end

function getDamageForMomogranType(momogran_type) 
    if momogran_type==1 then
		return 90
	elseif momogran_type==2 then
        return 120
    elseif momogran_type==3 then
        return 150
    end
	return 200
end

function create_attack(owner, team, direction, field, tile, momogran_type)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        getDamageForMomogranType(momogran_type),
        Hit.Impact | Hit.Flash | Hit.Flinch,
        Element.None,
        owner:get_id(),
        Drag.new())
    )

    local animation = spell:get_animation()
    animation:load(_folderpath.."attack.animation")
    animation:set_state("0")
    animation:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "8", math.random(-20,20), math.random(-20,20), field, tile)
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-9)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end