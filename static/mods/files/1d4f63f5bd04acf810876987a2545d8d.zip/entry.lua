local rockArmCode = include("Quaker/rockarm.lua")
local cascade_frame_index = 3
local summon_sfx = Engine.load_audio(_folderpath .. "sfx.ogg")

function package_init(package)
	package:declare_package_id("com.louise.chip.Rockarm3")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ "C", "I", "L", "T", "Z" })

	local props = package:get_card_props()
	props.shortname = "RockArm3"
	props.damage = 200
	props.time_freeze = false
	props.element = Element.None
	props.description = "Paralyzes enemy w/ erthquake"
	props.long_description = "Paralyzes enemy with earthquake"
	props.can_boost = false
	props.limit = 1
end

local frame_data = make_frame_data({
	{ 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})

function card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
			Engine.play_audio(summon_sfx, AudioPriority.Highest)
			rockArmCode.create_quaker(actor, props.damage, cascade_frame_index)
		end)

	end
	return action
end
