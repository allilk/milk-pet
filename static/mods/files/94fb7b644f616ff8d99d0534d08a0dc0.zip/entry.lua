local HIT_SFX = nil
local APPEAR_SFX = nil
local ACTIVATE_SFX = nil
local ATTACK_SFX = nil



function package_init(package) 
    package:declare_package_id("com.alrysc.card.HakutakuManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'H','K'})

    local props = package:get_card_props()
    props.shortname = "HkuTkuMV2"
    props.damage = 90
    props.time_freeze = true
    props.element = Element.Wood
    props.description = "Claw Atk! But on grass...?"
    props.card_class = CardClass.Mega
    props.limit = 2
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local facing = nil
    local team = nil
    local id = nil
    local tile = nil

    local step = nil
    local step_first = true

    local actor = nil
    local hakutakuman = nil
    local beast = 0
    local anim = nil
    local attack_count = 0

    local target_tiles = {}
    local spell_list = {}

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end



    action.execute_func = function()
        actor = action:get_actor()
        facing = user:get_facing()
        team = user:get_team()
        id = user:get_id() 
        tile = user:get_current_tile()

        local realtime_controller = Battle.Artifact.new()

        if tile == TileState.Grass then 
            beast = 1
        end

        hakutakuman = graphic_init("spell", 0, 0, "hakutakuman.png", "hakutakuman.animation", -5, "START_"..beast, user, facing)
        hakutakuman:set_float_shoe(true)

        anim = hakutakuman:get_animation()

        local count = 0
        local finish_delay = 10
        local can_end = false

        if props.time_freeze then 
            step = Battle.Step.new()
        else
            step = Battle.Component.new(realtime_controller, Lifetimes.Local)
        end

        step.update_func = function()
            if count == 3 then 
                if props.time_freeze then 
                    actor:hide()
                end
                
                field:spawn(hakutakuman, tile)
                if beast == 1 then
                    Engine.play_audio(ACTIVATE_SFX, AudioPriority.Low)
                end

                Engine.play_audio(APPEAR_SFX, AudioPriority.Low)


            end

            if can_end then 
                finish_delay = finish_delay - 1
                if finish_delay == 0 then 
                    if props.time_freeze then 
                        step:complete_step()
                    end
                end
            end
            

            count = count + 1
        end

        if not props.time_freeze then 
            realtime_controller:register_component(step)
        else
            action:add_step(step)
        end

        actor = action:get_actor()
        facing = user:get_facing()
        local enemies = nil

        local function check_obstacles(tile, self)
            local ob = tile:find_obstacles(function(o)
                return o:get_health() > 0
            end)
        
            return #ob > 0 
        end

        local function check_characters(tile)
            local char = tile:find_characters(function(c)
                return c:get_team() ~= hakutakuman:get_team() and c:get_health() > 0 
            end)
        
            return #char > 0 
        end

        
        local function check_enemies()
            for i=1, #enemies
            do
                if enemies[i] then
                    local t = enemies[i]:get_tile(Direction.reverse(facing), 1)
                    enemies[i] = nil
                    if t and not t:is_edge() and t:is_walkable() and not check_obstacles(t) and not check_characters(t) then 
                        return t
                    end
                end
            end
        end

        local function create_hitbox(tile)
            if not tile or tile:is_edge() then 
                return
            end

            local spell = Battle.Spell.new(hakutakuman:get_team())

            local damage = props.damage

            if beast == 1 then 
                damage = props.damage*2
            end
    
            local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Wood, 
                id, 
                Drag.None
            )

            spell:set_hit_props(hit_props)
            spell:set_facing(facing)
            
            local lifetime = 15
            spell.has_hit = false
            spell.update_func = function(self, dt)
                local can_hit = true
                for i=1, #spell_list
                do
                    -- This is really bad, because for every enemy, I add an extra 1-3 iterations
                        -- If we had a million enemies, it would be bad
                    if not spell_list[i]:is_deleted() then 
                        can_hit = can_hit and not spell_list[i].has_hit

                        if not can_hit then 
                            break
                        end
                    end
                end

                self:get_tile():highlight(Highlight.Solid)
                if lifetime == 0 then 
                    self:delete()
                end
                lifetime = lifetime - 1

                if not can_hit then 
                    return 
                end
                self:get_tile():attack_entities(self)
        
        
            end
        
            spell.can_move_to_func = function(tile)
                return true
            end
        
            spell.attack_func = function(self, other)
                Engine.play_audio(HIT_SFX, AudioPriority.Low)

                if beast == 1 then 
                    field:spawn(graphic_init("artifact", 0, 0, "effect.png", "effect.animation", -2, "DEFAULT", hakutakuman, facing, true), other:get_current_tile())
                end
            end
        
            spell.collision_func = function(self, other)
                self.has_hit = true
            end

            table.insert(spell_list, spell)
            field:spawn(spell, tile)
        end

        local function attack(tile)
            local slash = graphic_init("spell", 0, 0, "hakutakuman.png", "hakutakuman.animation", -5, "SWORD_"..beast, hakutakuman, facing)
            Engine.play_audio(ATTACK_SFX, AudioPriority.Low)
            create_hitbox(tile)
            if beast == 1 then 
                create_hitbox(tile:get_tile(Direction.Up, 1))
                create_hitbox(tile:get_tile(Direction.Down, 1))
            end

            field:spawn(slash, tile)
        end

        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
        ACTIVATE_SFX = Engine.load_audio(_folderpath.."docking.ogg")
        ATTACK_SFX = Engine.load_audio(_folderpath.."break.ogg")

        local function next_attack()
            local state = beast * (beast + attack_count % 2)
            attack_count = attack_count + 1
            anim:set_state("ATTACK_LOOP_"..state)
            local target = check_enemies()


            anim:on_frame(3, function()
                if target then 
                    hakutakuman:get_current_tile():remove_entity_by_id(hakutakuman:get_id())
                    target:add_entity(hakutakuman)
                else
                    hakutakuman:delete()
                    realtime_controller:delete()
                    can_end = true
                end

            end)

            anim:on_frame(10, function()
                attack(hakutakuman:get_tile(facing, 1))
            end)

            anim:on_complete(function()
                next_attack()
            end)
        

            anim:refresh(hakutakuman:sprite())

        end
   
        anim:on_complete(function()
            enemies = field:find_nearest_characters(user, function(c)
                return c:get_team() ~= team and c:get_health() > 0
            end) 
            next_attack()
            
        end)

        field:spawn(realtime_controller, tile)

    end


    return action
end