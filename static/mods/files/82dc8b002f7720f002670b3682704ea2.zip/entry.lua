local DAMAGE = 0

local TEXTURE_DREAMBIT = Engine.load_texture(_modpath.."dreambit.png")
local ANIMPATH_DREAMBIT = _modpath .. "dreambit.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local TEXTURE_FLAMETOWER = Engine.load_texture(_modpath.."flametower.png")
local ANIMPATH_FLAMETOWER = _modpath .. "flametower.animation"
local AUDIO_FLAMETOWER = Engine.load_audio(_modpath.."flametower.ogg")
local TEXTURE_ICECUBE = Engine.load_texture(_modpath.."cubes.png")
local ANIMPATH_ICECUBE = _modpath .. "cubes.animation"
local AUDIO_ICECUBE = Engine.load_audio(_modpath.."icecube.ogg")
local TEXTURE_ICECUBE_PIECE_1 = Engine.load_texture(_modpath.."icecube_piece_1.png")
local ANIMPATH_ICECUBE_PIECE_1 = _modpath .. "icecube_piece_1.animation"
local TEXTURE_ICECUBE_PIECE_2 = Engine.load_texture(_modpath.."icecube_piece_2.png")
local ANIMPATH_ICECUBE_PIECE_2 = _modpath .. "icecube_piece_2.animation"
local TEXTURE_THUNDERBOLT = Engine.load_texture(_modpath.."thunderbolt.png")
local ANIMPATH_THUNDERBOLT = _modpath .. "thunderbolt.animation"
local AUDIO_THUNDERBOLT = Engine.load_audio(_modpath.."thunderbolt.ogg")
local TEXTURE_GREENROPE = Engine.load_texture(_modpath.."greenrope.png")
local ANIMPATH_GREENROPE = _modpath .. "greenrope.animation"
local AUDIO_GREENROPE = Engine.load_audio(_modpath.."greenrope.ogg")
local TEXTURE_LASER = Engine.load_texture(_modpath.."laser.png")
local ANIMPATH_LASER = _modpath .. "laser.animation"
local AUDIO_LASER = Engine.load_audio(_modpath.."laser.ogg")
local TEXTURE_BUTTON = Engine.load_texture(_modpath.."button.png")
local ANIMPATH_BUTTON = _modpath .. "button.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath .. "effect.animation"
local TEXTURE_SMOKE = Engine.load_texture(_modpath.."smoke.png")
local ANIMPATH_SMOKE = _modpath .. "smoke.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE3-182-DreamBit")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A","D","E","M","R"})

    local props = package:get_card_props()
    props.shortname = "DreamBit"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Summons a DreamBit to fight!"
	props.long_description = "Summons a Dream Bit to attack!"
	props.can_boost = false
    props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local step1 = Battle.Step.new()
		local dreambit = Battle.Artifact.new()
		local do_once0 = true
		local do_once = true
        local do_once1 = true
		local do_once2 = true
		local dreambit_type = 1
        local dreambit_timer = 17
		local attacked = false
        --local time_over = false
        local tile_array = {}
        local query = function(ent)
			if not user:is_team(ent:get_team()) then
				return true
			end
		end
		for i = 1, 6, 1 do
			for j = 1, 3, 1 do
				local tile = field:tile_at(i, j)
                if #tile:find_characters(query) > 0 then
					table.insert(tile_array, tile)
				end
			end
		end
		step1.update_func = function(self, dt)
			if do_once0 then
                do_once0 = false
                local query = function() return true end
                local tile = user:get_tile(direction, 1)
				dreambit:set_facing(direction)
				dreambit:set_texture(TEXTURE_DREAMBIT, true)
				local dreambit_sprite = dreambit:sprite()
				dreambit_sprite:set_layer(-3)
                local dreambit_anim = dreambit:get_animation()
                dreambit_anim:load(ANIMPATH_DREAMBIT)
                dreambit_anim:set_state("START")
		    	dreambit_anim:refresh(dreambit_sprite)
		    	dreambit_anim:on_complete(function()
                    if not tile:is_walkable() or #tile:find_characters(query)~= 0 then
		    		    dreambit_anim:set_state("END")
                    else
                        dreambit_anim:set_state("SPAWN")
                    end
                    dreambit_anim:refresh(dreambit_sprite)
		    	end)
                field:spawn(dreambit, tile)
            end
			local anim = dreambit:get_animation()
            if anim:get_state() == "SPAWN" then
                if do_once then
					do_once = false
                    anim:on_frame(1, function()
                        Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                        print("ROULETTE START")
                        anim:set_state("SELECT")
                        anim:refresh(dreambit:sprite())
                        anim:set_playback(Playback.Loop)
                    end)
                end
            end
            if anim:get_state() == "SELECT" then
				if do_once1 then
					do_once1 = false

                    local tile1 = user:get_tile(direction, 1)
					local tile2 = user:get_tile(direction, 2)
                    local tile3 = user:get_tile(direction, 3)
                    local tile4 = user:get_tile(direction, 4)
                    local tile5 = user:get_tile(direction, 5)
                    local tile6 = user:get_tile(direction, 6)

					local button_gui = Battle.Artifact.new()
					button_gui:set_facing(Direction.Right)
		    		button_gui:set_texture(TEXTURE_BUTTON, true)
					local button_sprite = button_gui:sprite()
					button_sprite:set_layer(-9999999)
					local button_anim = button_gui:get_animation()
					button_anim:load(ANIMPATH_BUTTON)
					button_anim:set_state("0")
					button_anim:set_playback(Playback.Loop)
		    		button_anim:refresh(button_sprite)
					field:spawn(button_gui, tile1)

                    local dreambit_sprite = dreambit:sprite()

                    anim:on_frame(1,function()
                        dreambit_timer=dreambit_timer-1
                        dreambit_type=1
                        --anim:refresh(dreambit_sprite)
                    end)
                    anim:on_frame(2,function()
                        dreambit_type=2
                        --anim:refresh(dreambit_sprite)
                    end)
                    anim:on_frame(3,function()
                        dreambit_type=3
                        --anim:refresh(dreambit_sprite)
                    end)
                    anim:on_frame(4,function()
                        dreambit_type=4
                        --anim:refresh(dreambit_sprite)
                    end)
                    anim:on_frame(5,function()
                        dreambit_type=5
                        --anim:refresh(dreambit_sprite)
                    end)
                    anim:on_frame(6,function()
                        dreambit_type=6
                        --anim:refresh(dreambit_sprite)
                    end)

					dreambit.update_func = function(self, dt)
						if not attacked then
						    if user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot) or dreambit_timer<=0 then
						    	if do_once2 then
                                    print("ROULETTE END")
						    		button_gui:erase()
						    		anim:set_state("V"..dreambit_type.."_ATTACK")
						    		anim:refresh(dreambit_sprite)
                                    anim:set_playback(Playback.Once)
                                    anim:on_frame(1, function()
                                        if      dreambit_type == 1 then
                                            print("RESULT: Dream Bit")
                                        elseif  dreambit_type == 2 then
                                            print("RESULT: Dream Meraru")
                                        elseif  dreambit_type == 3 then
                                            print("RESULT: Dream Rapia")
                                        elseif  dreambit_type == 4 then
                                            print("RESULT: Dream Bolt")
                                        elseif  dreambit_type == 5 then
                                            print("RESULT: Dream Moss")
                                        else
                                            print("RESULT: Dream Bit SP")
                                        end
                                    end)
						    		anim:on_frame(5, function()
                                        if      dreambit_type == 2 then
                                            spawn_flametower(user, tile2, team, direction, field, dreambit_type)
                                        elseif  dreambit_type == 3 then
                                            spawn_icecube(user, team, direction, field, tile2, dreambit_type)
                                        elseif  dreambit_type == 4 then
                                            for k = 1, #tile_array, 1 do
                                                spawn_thunderbolt(user, team, direction, field, tile_array[k], dreambit_type)
                                            end
                                        elseif  dreambit_type == 5 then
                                            for k = 1, #tile_array, 1 do
                                                spawn_greenrope_1(user, team, direction, field, tile_array[k], dreambit_type)
                                            end
                                        else
                                            spawn_laser(user, team, direction, field, tile2, tile3, tile4, tile5, tile6, dreambit_type)
                                        end
						    		end)
                                    anim:on_complete(function()
                                        anim:set_state("END")
                                        anim:refresh(dreambit_sprite)
                                    end)
						    		attacked = true
						    		do_once2=false
						    	end
						    end
					    end
				    end
			    end
			end
            if anim:get_state() == "END" then
                anim:on_complete(function()
                    dreambit:erase()
                    step1:complete_step()
                end)
            end
		end
		self:add_step(step1)
	end
    return action
end

function getDamageForDreamBitType(dreambit_type) 
    if      dreambit_type==1 then
		return 100
	elseif  dreambit_type==2 then
        return 150
    elseif  dreambit_type==3 then
        return 200
    elseif  dreambit_type==4 then
        return 130
    elseif  dreambit_type==5 then
        return 100
    end
	return 200
end

function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        debug_print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

function getNextTile(direction, spell) 
    local target_character = find_target(spell)
    local target_character_tile = target_character:get_current_tile()
    local tile = spell:get_current_tile():get_tile(direction, 1)
    local target_movement_tile = tile
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down,1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up,1)
    end
    return target_movement_tile;
end

function spawn_laser(owner, team, direction, field, tile1, tile2, tile3, tile4, tile5, dreambit_type)
    local laserfx = Battle.Artifact.new()
    laserfx:set_facing(direction)
    laserfx:set_texture(TEXTURE_LASER, true)
    if direction == Direction.Right then 
        laserfx:set_offset(-50, 0)
    else
        laserfx:set_offset(50, 0)
    end

    local laserfx_sprite = laserfx:sprite()
    laserfx_sprite:set_layer(-9)
    local laserfx_anim = laserfx:get_animation()
	laserfx_anim:load(ANIMPATH_LASER)
	laserfx_anim:set_state("0")
	laserfx_anim:refresh(laserfx_sprite)
    laserfx_anim:on_frame(6, function()
        laser_hitbox(owner, tile1, team, direction, field, dreambit_type)
    end)
    laserfx_anim:on_frame(8, function()
        laser_hitbox(owner, tile2, team, direction, field, dreambit_type)
    end)
    laserfx_anim:on_frame(10,function()
        laser_hitbox(owner, tile3, team, direction, field, dreambit_type)
    end)
    laserfx_anim:on_frame(12,function()
        laser_hitbox(owner, tile4, team, direction, field, dreambit_type)
    end)
    laserfx_anim:on_frame(14,function()
        laser_hitbox(owner, tile5, team, direction, field, dreambit_type)
    end)
    laserfx_anim:on_complete(function()
        laserfx:erase()
    end)

    Engine.play_audio(AUDIO_LASER, AudioPriority.High)

    field:spawn(laserfx, tile3)

    return laserfx
end

function laser_hitbox(owner, tile, team, direction, field, dreambit_type)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            getDamageForDreamBitType(dreambit_type), 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.None, 
            owner:get_id(), 
            Drag.new())
        )

        local animation = spell:get_animation()
        animation:load(_modpath .. "attack.animation")
        animation:set_state("1")
        animation:on_complete(function()
            spell:erase()
        end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn()
end

function spawn_flametower(owner, tile, team, direction, field, dreambit_type)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(AUDIO_FLAMETOWER, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(
            getDamageForDreamBitType(dreambit_type), 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.Fire, 
            owner:get_id(), 
            Drag.new())
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_FLAMETOWER)
        sprite:set_layer(-3)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_FLAMETOWER)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)

        animation:on_frame(22, function()
            tile = getNextTile(direction, spell)
            spawn_next()
        end, true)
        animation:on_complete(function() 
            spell:erase()
        end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function spawn_icecube(owner, team, direction, field, tile, dreambit_type)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        getDamageForDreamBitType(dreambit_type), 
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        Element.Aqua, 
        owner:get_id(), 
        Drag.new())
    )
    spell.slide_started = false

    Engine.play_audio(AUDIO_ICECUBE, AudioPriority.High)

    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE_ICECUBE)
    sprite:set_layer(-3)

    local animation = spell:get_animation()
    animation:load(ANIMPATH_ICECUBE)
    animation:set_state("4")
    animation:refresh(sprite)

    local icecube = Battle.Artifact.new()
    icecube:set_facing(direction)
    icecube:set_texture(TEXTURE_ICECUBE, true)
    local icecube_sprite = icecube:sprite()
    icecube_sprite:set_layer(-3)
    local icecube_anim = icecube:get_animation()
	icecube_anim:load(ANIMPATH_ICECUBE)
	icecube_anim:set_state("0")
	icecube_anim:refresh(icecube_sprite)
    icecube_anim:on_complete(function()
        icecube:erase()
        field:spawn(spell, tile)
    end)

    local icecube_piece_1 = Battle.Artifact.new()
    icecube_piece_1:set_facing(Direction.Right)
    icecube_piece_1:set_texture(TEXTURE_ICECUBE_PIECE_1, true)
    local piece_1_sprite = icecube_piece_1:sprite()
    piece_1_sprite:set_layer(-9)
    local piece_1_anim = icecube_piece_1:get_animation()
	piece_1_anim:load(ANIMPATH_ICECUBE_PIECE_1)
	piece_1_anim:set_state("0")
	piece_1_anim:refresh(piece_1_sprite)
    piece_1_anim:on_frame(18, function()
        create_effect(TEXTURE_SMOKE, ANIMPATH_SMOKE, "1", 32, 36, field, icecube_piece_1:get_current_tile())
    end)
    piece_1_anim:on_complete(function()
        icecube_piece_1:erase()
    end)

    local icecube_piece_2 = Battle.Artifact.new()
    icecube_piece_2:set_facing(Direction.Right)
    icecube_piece_2:set_texture(TEXTURE_ICECUBE_PIECE_2, true)
    local piece_2_sprite = icecube_piece_2:sprite()
    piece_2_sprite:set_layer(-9)
    local piece_2_anim = icecube_piece_2:get_animation()
	piece_2_anim:load(ANIMPATH_ICECUBE_PIECE_2)
	piece_2_anim:set_state("0")
	piece_2_anim:refresh(piece_2_sprite)
    piece_2_anim:on_frame(21, function()
        create_effect(TEXTURE_SMOKE, ANIMPATH_SMOKE, "1", -36, 73, field, icecube_piece_2:get_current_tile())
    end)
    piece_2_anim:on_complete(function()
        icecube_piece_2:erase()
    end)

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.collision_func = function(self, other)
		self:erase()
        create_effect(TEXTURE_SMOKE, ANIMPATH_SMOKE, "1", 0, 0, field, self:get_current_tile())
        field:spawn(icecube_piece_1, self:get_current_tile())
        field:spawn(icecube_piece_2, self:get_current_tile())
	end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "AQUA", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(icecube, tile)

    return spell
end

function spawn_thunderbolt(owner, team, direction, field, tile, dreambit_type)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(HitProps.new(
        getDamageForDreamBitType(dreambit_type),
        Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Breaking,
        Element.Elec,
        owner:get_id(),
        Drag.new())
    )

    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE_THUNDERBOLT)
    sprite:set_layer(-3)

    local animation = spell:get_animation()
    animation:load(ANIMPATH_THUNDERBOLT)
    animation:set_state("0")
    animation:refresh(sprite)

    spell.update_func = function(self, dt)
        if animation:get_state() == "0" then
            animation:on_complete(function()
                animation:set_state("1")
                animation:refresh(sprite)
            end)
        end
        if animation:get_state() == "1" then
            self:get_current_tile():attack_entities(self)
            animation:on_frame(1,function()
                Engine.play_audio(AUDIO_THUNDERBOLT, AudioPriority.High)
                if not tile:is_cracked() and not tile:is_hole() then
                    tile:set_state(TileState.Cracked)
                else
                    tile:set_state(TileState.Broken)
                end
            end)
            animation:on_complete(function()
                spell:erase()
            end)
        end
    end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "ELEC", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

    return spell
end

function spawn_greenrope_1(owner, team, direction, field, tile, dreambit_type)
    local spell = Battle.Spell.new(team)
    spell:set_facing(Direction.Right)
    spell:set_hit_props(HitProps.new(
        getDamageForDreamBitType(dreambit_type),
        Hit.Impact | Hit.Flinch | Hit.Stun | Hit.Breaking,
        Element.Wood,
        owner:get_id(),
        Drag.new())
    )

    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE_GREENROPE, true)
    sprite:set_layer(-999999)

    local animation = spell:get_animation()
    animation:load(ANIMPATH_GREENROPE)
    animation:set_state("0")
    animation:refresh(sprite)

    spell.update_func = function(self, field, dt)
        if animation:get_state() == "0" then
            animation:on_frame(6, function()
                spell:get_current_tile():attack_entities(spell)
            end)
            animation:on_complete(function()
                spell:erase()
            end)
        end
    end

    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "WOOD", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
        spawn_greenrope_2(owner, team, direction, field, tile)

        local rope_component = Battle.Component.new(other, Lifetimes.Battlestep) --Battlestep so it doesn't animate during time freeze
        --create the colors once instead of every time in the update function
        rope_component.green_color = Color.new(0, 255, 0, 255)
        rope_component.regular_color = Color.new(0, 0, 0, 0)
        --240 frame countdown.
        rope_component.removal_count = 250
        rope_component.update_func = function(self, dt)
          --assign owner and sprite once so we don't have to call the function every time
          if not self.owner then self.owner = self:get_owner(); self.sprite = self.owner:sprite(); end
          --if they move, they're not trapped by the spell. eject.
          if self.owner:is_moving() then self:eject() return end
          --tick removal.
          self.removal_count = self.removal_count - 1
          --at zero frames remaining, eject.
          if self.removal_count <= 0 then self:eject() return end
          --on even frames, turn them green.
          if self.removal_count % 2 == 0 then
            self.owner:set_color(self.green_color)
            self.sprite:set_color_mode(ColorMode.Multiply)
          else
            --on odd frames, turn them normal color.
            self.owner:set_color(self.regular_color)
            self.sprite:set_color_mode(ColorMode.Additive)
          end
        end
        other:register_component(rope_component)
    end

    Engine.play_audio(AUDIO_GREENROPE, AudioPriority.High)

    field:spawn(spell, tile)

    return spell
end

function spawn_greenrope_2(owner, team, direction, field, tile)
    local rope2 = Battle.Artifact.new()
    rope2:set_facing(Direction.Right)
    rope2:set_texture(TEXTURE_GREENROPE, true)
    local rope2_sprite = rope2:sprite()
    rope2_sprite:set_layer(-999999)
    local rope2_anim = rope2:get_animation()
	rope2_anim:load(ANIMPATH_GREENROPE)
	rope2_anim:set_state("1")
	rope2_anim:refresh(rope2_sprite)
    rope2_anim:on_frame(1+3,  function()
        greenrope_attack2(owner, team, direction, field, tile)
        auto_stun(owner, team, direction, field, tile)
    end)
    rope2_anim:on_frame(6+3,  function()
        auto_stun(owner, team, direction, field, tile)
    end)
    rope2_anim:on_frame(21+3, function()
        greenrope_attack2(owner, team, direction, field, tile)
    end)
    rope2_anim:on_frame(26+3, function()
        auto_stun(owner, team, direction, field, tile)
    end)
    rope2_anim:on_frame(41+3, function()
        greenrope_attack2(owner, team, direction, field, tile)
        auto_stun(owner, team, direction, field, tile)
    end)
    rope2_anim:on_frame(60+3, function()
        greenrope_attack2(owner, team, direction, field, tile)
    end)
    rope2_anim:on_complete(function()
        rope2:erase()
    end)

    field:spawn(rope2, tile)

    return rope2
end

function auto_stun(owner, team, direction, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        0,
        Hit.Impact | Hit.Pierce | Hit.Breaking | Hit.Stun,
        Element.None,
        owner:get_id(),
        Drag.new())
    )

    local animation = spell:get_animation()
    animation:load(_modpath .. "attack.animation")
    animation:set_state("0")
    animation:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    field:spawn(spell, tile)

    return spell
end

function greenrope_attack2(owner, team, direction, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        30,
        Hit.Impact,
        Element.Wood,
        owner:get_id(),
        Drag.new())
    )

    local animation = spell:get_animation()
    animation:load(_modpath .. "attack.animation")
    animation:set_state("0")
    animation:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-9)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end