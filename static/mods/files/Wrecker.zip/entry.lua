local bomb = include('bomb/bomb.lua')
 
bomb.name="Wrecker"
bomb.damage=80
bomb.element=Element.Break
bomb.description = "Breaks 3rd panel ahead"
bomb.codes = {"O","Q","S","U","W","*"}

function package_init(package)
    package:declare_package_id("rune.legacy.wrecker")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"O","Q","S","U","W","*"})

    local props = package:get_card_props()
    props.shortname = "Wrecker"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Break
    props.secondary_element = Element.None
    props.description = "Breaks 3rd panel ahead"
   end

   card_create_action = bomb.card_create_action
