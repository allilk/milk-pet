local DAMAGE = 150
--local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
--local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local BLUES_TEXTURE = Engine.load_texture(_folderpath.."blues.png")
local BLUES_ANIMPATH = _folderpath.."blues.animation"
local SWORD_SLASH_TEXTURE = Engine.load_texture(_folderpath.."sword_slash.png")
local SWORD_SLASH_ANIMPATH = _folderpath.."sword_slash.animation"
local SWORD_SLASH_AUDIO = Engine.load_audio(_folderpath.."sword_slash.ogg")
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe6-spawn.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local blues = {
    codes = {"B","*"},
    shortname = "Blues",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.Sword,
    description = "Warp in and slice the enemy",
    long_description = "Warp in front of the enemy and slice it, even where you can't warp",
    can_boost = true,
    card_class = CardClass.Mega,
    limit = 2
}

blues.card_create_action = function(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local team = user:get_team()
        local field = user:get_field()
        local facing = user:get_facing()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local team_check = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
        
        local targeted = false
        local tile1_check = false
        local tile2_check = false
        local tile_array1 = {}
        local enemy_tile
        if facing == Direction.Right then
            for i = 1, 6, 1 do
                for j = 1, 3, 1 do
                    if i > self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                            tile2_check = tile2 and tile2 ~= nil and not tile2:is_hole() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        else
            for i = 6, 1, -1 do
                for j = 1, 3, 1 do
                    if i < self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                            tile2_check = tile2 and tile2 ~= nil and not tile2:is_hole() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        end

		local step1 = Battle.Step.new()

        self.blues = nil
        self.tile  = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_2 = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.blues = Battle.Artifact.new()
                ref.blues:set_facing(facing)
                local blues_sprite = ref.blues:sprite()
		    	blues_sprite:set_texture(BLUES_TEXTURE, true)
		    	blues_sprite:set_layer(-3)
                local blues_anim = ref.blues:get_animation()
                blues_anim:load(BLUES_ANIMPATH)
                if ref.tile ~= nil and not ref.tile:is_hole() and targeted then
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") is NOT a hole!")
                    blues_anim:set_state("SPAWN")
		    	    blues_anim:refresh(blues_sprite)
				else
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") IS a hole!")
                    blues_anim:set_state("SPAWN_HOLE")
		    	    blues_anim:refresh(blues_sprite)
				end
                blues_anim:set_playback(Playback.Once)
                blues_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                blues_anim:on_frame(22, function()
                    if targeted then
                        spawn_blues_copy(user, props, team, facing, "COPY", field, enemy_tile, team_check, dark_query, ref.blues, 1)
                    else
                        blues_anim:set_state("DELAY")
                        blues_anim:refresh(blues_sprite)
                    end
                end)
                field:spawn(ref.blues, ref.tile)
            end
            local anim = ref.blues:get_animation()
            if anim:get_state() == "DELAY" then
                if do_once_2 then
                    do_once_2 = false
                    anim:on_complete(function()
                        ref.blues:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function spawn_blues_copy(user, props, team, facing, state, field, tile, team_check, dark_query, blues, number)
    local spawn_next
    spawn_next = function()
        local targeted = false
        local tile1_check = false
        local tile2_check = false
        local tile_array1 = {}
        local enemy_tile

        local self_X = tile:x()

        local blues_copy = Battle.Artifact.new()
        blues_copy:set_facing(facing)
        local copy_sprite = blues_copy:sprite()
        copy_sprite:set_texture(BLUES_TEXTURE, true)
        copy_sprite:set_layer(-3)
        local copy_anim = blues_copy:get_animation()
        copy_anim:load(BLUES_ANIMPATH)
        copy_anim:set_state(state)
        copy_anim:refresh(copy_sprite)
        copy_anim:on_frame(5, function()
            Engine.play_audio(SWORD_SLASH_AUDIO, AudioPriority.Highest)
            print("WideSword attack tile: ("..tile:get_tile(facing, 1):get_tile(Direction.Up, 1):x()..";"..tile:get_tile(facing, 1):get_tile(Direction.Up, 1):y()..")")
            print("WideSword attack tile: ("..tile:get_tile(facing, 1):x()..";"..tile:get_tile(facing, 1):y()..")")
            print("WideSword attack tile: ("..tile:get_tile(facing, 1):get_tile(Direction.Down, 1):x()..";"..tile:get_tile(facing, 1):get_tile(Direction.Down, 1):y()..")")
            create_effect(facing, SWORD_SLASH_TEXTURE, SWORD_SLASH_ANIMPATH, "WIDE", 0, 0, -9, field, tile:get_tile(facing, 1))
            create_attack(user, props, team, facing, field, tile:get_tile(facing, 1):get_tile(Direction.Up, 1),   number)
            create_attack(user, props, team, facing, field, tile:get_tile(facing, 1),                             number)
            create_attack(user, props, team, facing, field, tile:get_tile(facing, 1):get_tile(Direction.Down, 1), number)
        end)
        copy_anim:on_frame(7, function()
            if facing == Direction.Right then
                for i = 1, 6, 1 do
                    for j = 1, 3, 1 do
                        if i > self_X then
                            if not targeted then
                                local tile1 = field:tile_at(i,j)
                                local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                                tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                                tile2_check = tile2 and tile2 ~= nil and not tile2:is_hole() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0 and tile1 ~= tile:get_tile(facing, 1)
                                if tile1_check and tile2_check then
                                    print("target found at tile ("..i..";"..j..")")
                                    table.insert(tile_array1, tile1)
                                    enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                    targeted = true
                                    break
                                end
                            end
                        end
                    end
                end
            else
                for i = 6, 1, -1 do
                    for j = 1, 3, 1 do
                        if i < self_X then
                            if not targeted then
                                local tile1 = field:tile_at(i,j)
                                local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                                tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                                tile2_check = tile2 and tile2 ~= nil and not tile2:is_hole() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0 and tile1 ~= tile:get_tile(facing, 1)
                                if tile1_check and tile2_check then
                                    print("target found at tile ("..i..";"..j..")")
                                    table.insert(tile_array1, tile1)
                                    enemy_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                                    targeted = true
                                    break
                                end
                            end
                        end
                    end
                end
            end
        end)
        copy_anim:on_frame(10, function()
            if not targeted then
                copy_anim:set_state("COPY_LAST")
                copy_anim:refresh(copy_sprite)
                copy_anim:on_complete(function()
                    blues:get_animation():set_state("DELAY")
                    blues:get_animation():refresh(blues:sprite())
                    blues_copy:erase()
                end)
            end
        end)
        copy_anim:on_complete(function()
            if targeted then
                if number == 3 then
                    number = 1
                else
                    number = number + 1
                end
                tile = enemy_tile
                spawn_next()
            else
                blues:get_animation():set_state("DELAY")
                blues:get_animation():refresh(blues:sprite())
            end
            blues_copy:erase()
        end)

        field:spawn(blues_copy, tile)
    end

    spawn_next()
end

function create_attack(user, props, team, facing, field, tile, number)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )

    local anim = spell:get_animation()
    anim:load(_folderpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..number..".ogg"), AudioPriority.High)
			end
		else
			Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..number.."_obs.ogg"), AudioPriority.High)
		end
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    spell.delete_func = function(self)
        self:erase()
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return blues