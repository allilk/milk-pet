nonce = function() end

local SLASH_TEXTURE = Engine.load_texture(_modpath.."spell_sword_slashes.png")
local BLADE_TEXTURE = Engine.load_texture(_modpath.."spell_sword_blades.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.Dawn.programadvance.EvilCut")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'E'})

    local props = package:get_card_props()
    props.shortname = "Evil Cut"
    props.damage = 150
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Slashes of Evil!"
	props.long_description = "Step forward and execute three slashes!"
    props.limit = 1
    props.card_class = CardClass.Giga
	props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local actor_tile = actor:get_current_tile()
	local warp_tile = actor:get_current_tile():get_tile(actor:get_facing(), 2)
	local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
	end
	if warp_tile and not warp_tile:is_reserved({actor:get_id()}) and #warp_tile:find_entities(query) == 0 then
		local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
		local do_once = true
		action:set_lockout(make_animation_lockout())
		action.execute_func = function(self, user)
			print("in custom card action execute_func()!")
			if warp_tile and not warp_tile:is_edge() and not warp_tile:is_reserved({actor:get_id()}) and #warp_tile:find_entities(query) == 0 then
				warp_tile:add_entity(actor)
				action:add_anim_action(2, function()
					local hilt = action:add_attachment("HILT")
					local hilt_sprite = hilt:sprite()
					hilt_sprite:set_texture(actor:get_texture())
					hilt_sprite:set_layer(-2)
					hilt_sprite:enable_parent_shader(true)
					
					local hilt_anim = hilt:get_animation()
					hilt_anim:copy_from(actor:get_animation())
					hilt_anim:set_state("HILT")

					local blade = hilt:add_attachment("ENDPOINT")
					local blade_sprite = blade:sprite()
					blade_sprite:set_texture(BLADE_TEXTURE)
					blade_sprite:set_layer(-1)

					local blade_anim = blade:get_animation()
					blade_anim:load(_modpath.."spell_sword_blades.animation")
					blade_anim:set_state("DEFAULT")
				end)
				action:add_anim_action(3, function()
					local sword = create_slashwide(actor, props)
					local tile = actor:get_tile(actor:get_facing(), 1)
					local fx = Battle.Artifact.new()
					fx:set_facing(sword:get_facing())
					local anim = fx:get_animation()
					fx:set_texture(SLASH_TEXTURE, true)
					anim:load(_modpath.."spell_sword_slashes.animation")
					anim:set_state("WIDE")
					anim:on_complete(function()
						fx:erase()
						sword:erase()
					end)
					local field = actor:get_field()
					field:spawn(fx, tile)
					field:spawn(sword, tile)
				end)
				action.action_end_func = function(self)
					local action2 = Battle.CardAction.new(actor, "PLAYER_SWORD")
					action2.can_move_to_func = function(tile)
						return true
					end
					action2:set_lockout(make_animation_lockout())
					action2:add_anim_action(2, function()
						local hilt = action2:add_attachment("HILT")
						local hilt_sprite = hilt:sprite()
						hilt_sprite:set_texture(actor:get_texture())
						hilt_sprite:set_layer(-2)
						hilt_sprite:enable_parent_shader(true)
						
						local hilt_anim = hilt:get_animation()
						hilt_anim:copy_from(actor:get_animation())
						hilt_anim:set_state("HILT")

						local blade = hilt:add_attachment("ENDPOINT")
						local blade_sprite = blade:sprite()
						blade_sprite:set_texture(BLADE_TEXTURE)
						blade_sprite:set_layer(-1)

						local blade_anim = blade:get_animation()
						blade_anim:load(_modpath.."spell_sword_blades.animation")
						blade_anim:set_state("DEFAULT")
					end)
					action2:add_anim_action(3, function()
						local sword = create_heroslash(actor, props)
						local tile = actor:get_tile(actor:get_facing(), 1)
						local fx = Battle.Artifact.new()
						fx:set_facing(sword:get_facing())
						local anim = fx:get_animation()
						fx:set_texture(SLASH_TEXTURE, true)
						anim:load(_modpath.."spell_sword_slashes.animation")
						anim:set_state("BIG")
						anim:on_complete(function()
							fx:erase()
							sword:erase()
						end)
						local field = actor:get_field()
						field:spawn(fx, tile)
						field:spawn(sword, tile)
					end)
					actor:card_action_event(action2, ActionOrder.Involuntary)
					action2.action_end_func = function(self)
						local action3 = Battle.CardAction.new(actor, "PLAYER_SWORD")
						action3.can_move_to_func = function(tile)
							return true
						end
						action3:set_lockout(make_animation_lockout())
						action3:add_anim_action(2, function()
							local hilt = action3:add_attachment("HILT")
							local hilt_sprite = hilt:sprite()
							hilt_sprite:set_texture(actor:get_texture())
							hilt_sprite:set_layer(-2)
							hilt_sprite:enable_parent_shader(true)
							
							local hilt_anim = hilt:get_animation()
							hilt_anim:copy_from(actor:get_animation())
							hilt_anim:set_state("HILT")

							local blade = hilt:add_attachment("ENDPOINT")
							local blade_sprite = blade:sprite()
							blade_sprite:set_texture(BLADE_TEXTURE)
							blade_sprite:set_layer(-1)

							local blade_anim = blade:get_animation()
							blade_anim:load(_modpath.."spell_sword_blades.animation")
							blade_anim:set_state("DEFAULT")
						end)
						
						action3:add_anim_action(3, function()
							local sword = create_slash(user, props)
							local sword2 = create_slash(user, props)
							local tile = user:get_tile(user:get_facing(), 1)
							local props2 = sword:copy_hit_props()
							props2.damage = props.damage * 2
							sword2:set_hit_props(props2)
							
							local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
							sharebox1:set_hit_props(sword:copy_hit_props())
							
							local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
							sharebox2:set_hit_props(sword:copy_hit_props())
							
							local sharebox3 = Battle.SharedHitbox.new(sword, 0.15)
							sharebox3:set_hit_props(sword:copy_hit_props())
							
							local sharebox4 = Battle.SharedHitbox.new(sword, 0.15)
							sharebox4:set_hit_props(sword:copy_hit_props())
							
							local hitboxbox5 = Battle.SharedHitbox.new(sword, 0.15)
							sharebox4:set_hit_props(sword:copy_hit_props())
							
							actor:get_field():spawn(sword2, tile)
							
							actor:get_field():spawn(sharebox1, tile:get_tile(Direction.UpLeft, 1))
							actor:get_field():spawn(sharebox2, tile:get_tile(Direction.DownLeft, 1))
							actor:get_field():spawn(sharebox3, tile:get_tile(Direction.UpRight, 1))
							actor:get_field():spawn(sharebox4, tile:get_tile(Direction.DownRight, 1))
							
							local fx = Battle.Artifact.new()
							fx:set_facing(sword:get_facing())
							actor:get_field():spawn(fx, tile)
							local anim = fx:get_animation()
							fx:set_texture(SLASH_TEXTURE)
							anim:load(_modpath.."spell_sword_slashes.animation")
							anim:set_state("CROSS")
							anim:on_complete(function()
								fx:erase()
								sword:erase()
								sword2:erase()
							end)
							
						end)
						action3.action_end_func = function(self)
							warp_tile:remove_entity_by_id(actor:get_id())
							actor_tile:remove_entity_by_id(actor:get_id())
							local step_back = Battle.Component.new(actor, Lifetimes.Local)
							local cooldown = 1
							step_back.update_func = function(self, dt)
								if cooldown <= 0 then
									actor_tile:add_entity(actor)
									self:eject()
								else
									cooldown = cooldown - 1
								end
							end
							actor:register_component(step_back)
						end
						actor:card_action_event(action3, ActionOrder.Involuntary)
					end
				end
			end
		end
		return action
	end
	return Battle.CardAction.new(actor, "PLAYER_MOVE")
end

function create_slashwide(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell.update_func = function(self, dt)
		if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
			self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
		end
		if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
			self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
		end
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

function create_heroslash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch,
			props.element,
			user:get_context(),
			Drag.None
		)
	)

	spell.update_func = function(self, dt) 
		if self:get_tile():get_tile(user:get_facing(), 1) and not self:get_tile():get_tile(user:get_facing(), 1):is_edge() then
			self:get_tile():get_tile(user:get_facing(), 1):highlight(Highlight.Flash)
			self:get_tile():get_tile(user:get_facing(), 1):attack_entities(self)
		end
		if self:get_tile():get_tile(user:get_facing(), 2) and not self:get_tile():get_tile(user:get_facing(), 2):is_edge() then
			self:get_tile():get_tile(user:get_facing(), 2):highlight(Highlight.Flash)
			self:get_tile():get_tile(user:get_facing(), 2):attack_entities(self)
		end
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell.update_func = function(self, dt)
		if not self:get_tile():is_edge() then
			self:get_tile():highlight(Highlight.Flash)
		end
		if spell:get_current_tile():get_tile(Direction.UpLeft, 1) and not spell:get_current_tile():get_tile(Direction.UpLeft, 1):is_edge() then	
			spell:get_current_tile():get_tile(Direction.UpLeft, 1):highlight(Highlight.Flash)
		end
		if spell:get_current_tile():get_tile(Direction.DownLeft, 1) and not spell:get_current_tile():get_tile(Direction.DownLeft, 1):is_edge() then	
			spell:get_current_tile():get_tile(Direction.DownLeft, 1):highlight(Highlight.Flash)
		end
		if spell:get_current_tile():get_tile(Direction.UpRight, 1) and not spell:get_current_tile():get_tile(Direction.UpRight, 1):is_edge() then	
			spell:get_current_tile():get_tile(Direction.UpRight, 1):highlight(Highlight.Flash)
		end
		if spell:get_current_tile():get_tile(Direction.DownRight, 1) and not spell:get_current_tile():get_tile(Direction.DownRight, 1):is_edge() then	
			spell:get_current_tile():get_tile(Direction.DownRight, 1):highlight(Highlight.Flash)
		end
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end