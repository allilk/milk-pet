function package_init(block)
  block:declare_package_id("com.discord.Konstinople#7692.block.Debug")
  block:set_name("Debug")
  block:set_description("Dev Tool")
  block:set_color(Blocks.White)
  block:set_shape({
      0, 0, 0, 0, 0,
      0, 0, 0, 0, 0,
      0, 0, 1, 0, 0,
      0, 0, 0, 0, 0,
      0, 0, 0, 0, 0
  })
  block:set_mutator(modify)
end

local DEFAULT_CHARACTER_COLOR = Color.new(255, 0, 255, 100)
local COUNTERABLE_COLOR = Color.new(255, 255, 0, 100)

local DEFAULT_TILE_COLOR = Color.new(0, 0, 0, 0)
local TILE_RESERVED_COLOR = Color.new(50, 50, 50, 100)

function modify(player)
  local component = Battle.Component.new(player, Lifetimes.Scene)
  local tracked_entities = {}

  local field
  local texture = Engine.load_texture(_modpath.."bg.png")

  local function attach_to_entity(e)
    local id = e:get_id()

    tracked_entities[id] = true

    field:callback_on_delete(id, function()
      tracked_entities[id] = false
    end)

    local node = e:sprite():create_node()
    node:set_texture(texture)
    node:set_width(32)
    node:set_height(e:get_height())
    node:set_offset(-16, -e:get_height())
    node:set_color(DEFAULT_CHARACTER_COLOR)
    node:set_layer(999998)

    local component = Battle.Component.new(e, Lifetimes.Scene)
    local counter_counter = 0

    component.update_func = function()
      if e:is_deleted() then
        component:eject()
        return
      end

      node:set_height(e:get_height())
      node:set_offset(-16, -e:get_height())

      if e:is_counterable() then
        node:set_color(COUNTERABLE_COLOR)
        counter_counter = counter_counter + 1
      else
        node:set_color(DEFAULT_CHARACTER_COLOR)

        if counter_counter > 0 then
          print(e:get_name() .. " was counterable for " .. counter_counter .. " frames")
          counter_counter = 0
        end
      end
    end

    e:register_component(component)
  end

  local function add_tile_marker(tile)
    if tile:get_state() == TileState.Hidden then
      return
    end

    local node = Battle.Artifact.new()
    node:set_texture(texture)
    node:sprite():set_layer(999999)
    node:set_color(DEFAULT_TILE_COLOR)
    node:set_offset(-80 / 2, -30) -- tiles are not centered :(, defining separately for now

    local component = Battle.Component.new(node, Lifetimes.Scene)

    component.update_func = function()
      local sprite = node:sprite()
      sprite:set_width(80)
      sprite:set_height(50)

      if tile:is_reserved({}) then
        sprite:set_color(TILE_RESERVED_COLOR)
      else
        sprite:set_color(DEFAULT_TILE_COLOR)
      end
    end

    node:register_component(component)
    field:spawn(node, tile)
  end

  component.update_func = function()
    if not field then
      field = player:get_field()

      field:find_tiles(function(tile)
        add_tile_marker(tile)
        return false
      end)
    end

    field:find_entities(function(e)
      if tracked_entities[e:get_id()] then
        return false
      end

      local character = Battle.Character.from(e)
      if character then
        attach_to_entity(character)
        return false
      end

      local obstacle = Battle.Obstacle.from(e)
      if obstacle then
        attach_to_entity(obstacle)
        return false
      end

      return false
    end)
  end

  player:register_component(component)
end
