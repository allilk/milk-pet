local DAMAGE = 200
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local FORTE_TEXTURE = Engine.load_texture(_folderpath.."forte.png")
local FORTE_ANIMPATH = _folderpath.."forte.animation"
local FORTE_AUDIO_CHARGE = Engine.load_audio(_folderpath.."exe1-forte-charge.ogg")
local EXPLOSION_AUDIO = Engine.load_audio(_folderpath.."exe1-explosion.ogg")
local EXPLOSION_TEXTURE = Engine.load_texture(_folderpath.."explosion.png")
local EXPLOSION_ANIMPATH = _folderpath.."explosion.animation"
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe1-spawn.ogg")

local forte = {
    codes = {"F"},
    shortname = "Forte",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.None,
    description = "Explosion on entire area!",
    long_description = "Explosion attack on the entire area!",
    can_boost = true,
    card_class = CardClass.Giga,
    limit = 1
}

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE1-180-Forte")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes(forte.codes)

    local props = package:get_card_props()
    props.shortname = forte.shortname
    props.damage = forte.damage
    props.time_freeze = forte.time_freeze
    props.element = forte.element
    props.description = forte.description
    props.long_description = forte.long_description
    props.can_boost = forte.can_boost
	props.card_class = forte.card_class
	props.limit = forte.limit
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
		actor:hide()

        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset = nil

        if facing == Direction.Right then
            X_offset = X + 1
        else
            X_offset = X - 1
        end

		local step1 = Battle.Step.new()

        self.forte = nil
        self.tile  = user:get_current_tile()
        
        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.forte = Battle.Artifact.new()
                ref.forte:set_facing(facing)
                local forte_sprite = ref.forte:sprite()
		    	forte_sprite:set_layer(-3)
		    	forte_sprite:set_texture(FORTE_TEXTURE, true)
                local forte_anim = ref.forte:get_animation()
                forte_anim:load(FORTE_ANIMPATH)
                forte_anim:set_state("SPAWN")
		    	forte_anim:refresh(forte_sprite)
                forte_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.Highest)
		    	end)
                forte_anim:on_frame(9, function()
		    		Engine.play_audio(FORTE_AUDIO_CHARGE, AudioPriority.Highest)
		    	end)
		    	forte_anim:on_complete(function()
		    		forte_anim:set_state("ATTACK")
		    		forte_anim:refresh(forte_sprite)
		    	end)
                field:spawn(ref.forte, ref.tile)
            end
            local anim = ref.forte:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_frame(1, function()
                        print("Forte: Explosion!")
                        Engine.play_audio(EXPLOSION_AUDIO, AudioPriority.Highest)
                    end)
                    anim:on_frame(9, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 1))
                    end)
                    anim:on_frame(21, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_frame(37, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 2))
                    end)
                    anim:on_frame(45, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_frame(57, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 2))
                    end)
                    anim:on_frame(73, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 1))
                    end)
                    anim:on_frame(93, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_frame(109, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 2))
                    end)
                    anim:on_frame(117, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_frame(129, function()
                        create_explosion(user, props, team, facing, field, field:tile_at(X_offset, 1))
                    end)
                    anim:on_frame(145, function()
                        create_explosion(user, props, team, facing, field, field:tile_at(X_offset, 2))
                    end)
                    anim:on_frame(153, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_frame(165, function()
                        create_explosion_nodamage(user, props, team, facing, field, field:tile_at(X_offset, 3))
                    end)
                    anim:on_complete(function()
                        create_explosion(user, props, team, facing, field, field:tile_at(X_offset, 3))
                        anim:set_state("END")
                        anim:refresh(ref.forte:sprite())
                        anim:on_complete(function()
                            ref.forte:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_explosion(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_layer(-4)
    sprite:set_texture(EXPLOSION_TEXTURE)
    local anim = spell:get_animation()
    anim:load(EXPLOSION_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_frame(7, function()
        tile = spell:get_tile(facing, 1)
        create_explosion_2(user, props, team, facing, field, tile)
    end, true)
    anim:on_complete(function() spell:erase() end)
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
        end
    end
    
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)
    
	print("Explosion (with damage) created at tile ("..tile:x()..";"..tile:y()..")")

    return spell
end

function create_explosion_2(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch,
                props.element, 
                user:get_id(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-4)
        sprite:set_texture(EXPLOSION_TEXTURE)
        local anim = spell:get_animation()
        anim:load(EXPLOSION_ANIMPATH)
        anim:set_state("1")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(facing, 1)
            spawn_next()
        end, true)
        anim:on_complete(function() spell:erase() end)
        
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
            end
        end
        
	    spell.collision_func = function(self, other)
	    end
        
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_explosion_nodamage(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            0, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_layer(-4)
    sprite:set_texture(EXPLOSION_TEXTURE)
    local anim = spell:get_animation()
    anim:load(EXPLOSION_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_frame(7, function()
        tile = spell:get_tile(facing, 1)
        create_explosion_2_nodamage(user, props, team, facing, field, tile)
    end, true)
    anim:on_complete(function() spell:erase() end)
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
        end
    end
    
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

	print("Explosion (without damage) created at tile ("..tile:x()..";"..tile:y()..")")

    return spell
end

function create_explosion_2_nodamage(user, props, team, facing, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new(
                0, 
                Hit.Impact | Hit.Flash | Hit.Flinch,
                props.element, 
                user:get_id(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-4)
        sprite:set_texture(EXPLOSION_TEXTURE)
        local anim = spell:get_animation()
        anim:load(EXPLOSION_ANIMPATH)
        anim:set_state("1")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(facing, 1)
            spawn_next()
        end, true)
        anim:on_complete(function() spell:erase() end)
        
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
                end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
            end
        end
        
	    spell.collision_func = function(self, other)
	    end
        
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end