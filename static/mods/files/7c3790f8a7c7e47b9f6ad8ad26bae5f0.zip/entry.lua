local DAMAGE = 130

local WOODYSEED_TEXTURE = Engine.load_texture(_modpath.."woodyseed.png")
local WOODYSEED_ANIMPATH = _modpath.."woodyseed.animation"
local WOODYSEED_AUDIO = Engine.load_audio(_modpath.."woodyseed.ogg")
local WOODYNOSE_TEXTURE = Engine.load_texture(_modpath.."woodynose.png")
local WOODYNOSE_ANIMPATH = _modpath.."woodynose.animation"
local WOODYNOSE_AUDIO = Engine.load_audio(_modpath.."woodynose.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-103-WoodyNose2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"J","T","Z"})

    local props = package:get_card_props()
    props.shortname = "WoodNos2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Branch grows out from side"
    props.long_description = "When a seed is planted in front, a branch grows out 2 squares from the screen's edge"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.017},{2,0.033},{3,0.033},{4,0.271}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local query = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil
			elseif user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return Battle.Obstacle.from(ent) ~= nil
            end
        end

        self:add_anim_action(2, function()
            create_seed(user, props, team, direction, field, user:get_tile(direction, 1), self_Y)
        end)
    end
    return action
end

function create_seed(owner, props, team, direction, field, tile, owner_y)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            10, 
            Hit.Impact | Hit.Flinch, 
            props.element,
            owner:get_context(),
            Drag.None
        )
    )

    local tile1 = nil
    local tile2 = nil
    local tile3 = nil
	if team == Team.Red then
		if direction == Direction.Right then
            tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
		else
            tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
		end
	else
		if direction == Direction.Left then
			tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
		else
            tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
		end
	end

    local sprite = spell:sprite()
    sprite:set_layer(-5)
    sprite:set_texture(WOODYSEED_TEXTURE, true)
	
    local anim = spell:get_animation()
    anim:load(WOODYSEED_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                target_finder(owner, props, team, direction, field, tile2, owner_y)
                self:delete()
            end

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end
	
	spell.collision_func = function(self, other)
		self:erase()
	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(WOODYSEED_AUDIO, AudioPriority.High)

    field:spawn(spell, tile)

    return spell
end

function create_seed(owner, props, team, direction, field, tile, owner_y)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            10, 
            Hit.Impact | Hit.Flinch, 
            props.element,
            owner:get_context(),
            Drag.None
        )
    )

    local tile1 = nil
    local tile2 = nil
    local tile3 = nil
	if team == Team.Red then
		if direction == Direction.Right then
            tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
		else
            tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
		end
	else
		if direction == Direction.Left then
			tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
		else
            tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
		end
	end

    local sprite = spell:sprite()
    sprite:set_layer(-5)
    sprite:set_texture(WOODYSEED_TEXTURE, true)
	
    local anim = spell:get_animation()
    anim:load(WOODYSEED_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                target_finder(owner, props, team, direction, field, tile2, owner_y)
                self:delete()
            end

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-10,10), math.random(-10,10), field, self:get_current_tile())
    end
	
	spell.collision_func = function(self, other)
		self:erase()
	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(WOODYSEED_AUDIO, AudioPriority.High)

    field:spawn(spell, tile)

    return spell
end

function target_finder(owner, props, team, direction, field, tile, owner_y)
    local finder1 = Battle.Spell.new(team)
    finder1:set_facing(Direction.reverse(direction))
    local anim1 = finder1:get_animation()
    anim1:load(_modpath.."attack.animation")
    anim1:set_state("0")

    local targeted = false
    local targeted_1 = false
    local targeted_2 = false
    local targeted_3 = false

    local tile1 = nil
    local tile2 = nil
    local tile3 = nil
    local nose_x = nil
	if team == Team.Red then
		if direction == Direction.Right then
            tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
            nose_x = 6
		else
            tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
            nose_x = 1
		end
	else
		if direction == Direction.Left then
			tile1 = field:tile_at(6, 1)
			tile2 = field:tile_at(6, 2)
            tile3 = field:tile_at(6, 3)
            nose_x = 1
		else
            tile1 = field:tile_at(1, 1)
			tile2 = field:tile_at(1, 2)
            tile3 = field:tile_at(1, 3)
            nose_x = 6
		end
	end
    local tile_front = nil
	local check_front = false

    local team_check = function(ent)
        if not owner:is_team(ent:get_team()) then
            return true
        end
    end

    for i = 0, 3, 1 do
        if i <= 3 then
             
            tile_front = tile1:get_tile(Direction.reverse(direction), i)
             
            check_front = tile_front and #tile_front:find_characters(team_check) > 0
             
            if check_front then
                print("Y1 TARGETED")
                targeted = true
                targeted_1 = true
            end
        else
            break
        end
    end
    for i = 0, 3, 1 do
        if i <= 3 then
             
            tile_front = tile2:get_tile(Direction.reverse(direction), i)
             
            check_front = tile_front and #tile_front:find_characters(team_check) > 0
             
            if check_front then
                print("Y2 TARGETED")
                targeted = true
                targeted_2 = true
            end
        else
            break
        end
    end
    for i = 0, 3, 1 do
        if i <= 3 then
             
            tile_front = tile3:get_tile(Direction.reverse(direction), i)
    
            check_front = tile_front and #tile_front:find_characters(team_check) > 0
             
            if check_front then
                print("Y3 TARGETED")
                targeted = true
                targeted_3 = true
            end
        else
            break
        end
    end

    anim1:on_frame(2, function()
        if targeted then
            if targeted_1 then
                create_woodynose(owner, props, team, direction, field, tile1)
            end
            if targeted_2 then
                create_woodynose(owner, props, team, direction, field, tile2)
            end
            if targeted_3 then
                create_woodynose(owner, props, team, direction, field, tile3)
            end
        else
            create_woodynose(owner, props, team, direction, field, field:tile_at(nose_x,owner_y))
        end
    end)
    anim1:on_complete(function()
        finder1:erase()
    end)

    field:spawn(finder1, tile)

    return finder1
end

function create_woodynose(owner, props, team, direction, field, tile)
    local spell = Battle.Artifact.new()
    spell:set_facing(Direction.reverse(direction))
    local spell_sprite = spell:sprite()
    spell_sprite:set_layer(-9)
    spell_sprite:set_texture(WOODYNOSE_TEXTURE, true)

    local spell_anim = spell:get_animation()
    spell_anim:load(WOODYNOSE_ANIMPATH)
    spell_anim:set_state("0")
    spell_anim:refresh(spell_sprite)
    spell_anim:on_frame(1, function()
        create_attack(owner, props, team, direction, 2, field, tile, "NOSE1")
    end)
    spell_anim:on_frame(2, function()
        create_attack(owner, props, team, direction, 1, field, tile:get_tile(Direction.reverse(direction), 1), "NOSE2")
    end)
    spell_anim:on_complete(function()
        spell:erase()
    end)

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

	Engine.play_audio(WOODYNOSE_AUDIO, AudioPriority.High)

    field:spawn(spell, tile)

    print("WoodyNose spawned at tile ("..tile:x()..";"..tile:y()..")")

    return spell
end

function create_attack(owner, props, team, direction, drag, field, tile, state)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Drag, 
            props.element, 
            owner:get_context(), 
            Drag.new(Direction.reverse(direction), drag)
        )
    )

    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state(state)
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end