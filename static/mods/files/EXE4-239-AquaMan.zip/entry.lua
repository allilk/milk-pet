local DAMAGE = 70

local TEXTURE_AQUAMAN = Engine.load_texture(_modpath.."aquaman.png")
local ANIMPATH_AQUAMAN = _modpath.."aquaman.animation"
local TEXTURE_SUIDOUKAN = Engine.load_texture(_modpath.."suidoukan.png")
local ANIMPATH_SUIDOUKAN = _modpath.."suidoukan.animation"
local TEXTURE_WARP = Engine.load_texture(_modpath.."mob_move.png")
local ANIMPATH_WARP = _modpath.."mob_move.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SPAWN2 = Engine.load_audio(_modpath.."spawn2.ogg")
local AUDIO_SUIDOUKAN = Engine.load_audio(_modpath.."suidoukan.ogg")
local ANIMPATH_ATTACK = _modpath.."attack.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-239-AquaMan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A"})

    local props = package:get_card_props()
    props.shortname = "AquaMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Aqua
    props.description = "WaterPipe sprays 2 sq ahead!"
    props.long_description = "Place a water pipe and spray water attack to 2 squares in front of it!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local offset_tile_1 = self_tile:get_tile(direction, 1)
        local offset_tile_2 = self_tile:get_tile(direction, 2)
        local offset_tile_3 = self_tile:get_tile(direction, 3)

        local check = function(c)
            return Battle.Character.from(c) ~= nil or Battle.Player.from(c) ~= nil or Battle.Obstacle.from(c) ~= nil
        end

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
		    	ref.navi:set_texture(TEXTURE_AQUAMAN, true)
		    	ref.navi:sprite():set_layer(-1)

                local navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_AQUAMAN)
                navi_anim:set_state("SPAWN")
		    	navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	navi_anim:on_complete(function()
                    local entity = offset_tile_1:find_entities(check)
                    local obstacle = offset_tile_1:find_obstacles(check)
                    if not offset_tile_1:is_edge() and not offset_tile_1:is_hole() and #entity <= 0 and #obstacle <= 0 then
		    		    navi_anim:set_state("ATTACK")
		    		    navi_anim:refresh(ref.navi:sprite())
                    else
                        navi_anim:set_state("END")
		    		    navi_anim:refresh(ref.navi:sprite())
                    end
		    	end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local fx = Battle.Artifact.new()
                    fx:set_facing(direction)
                    fx:set_texture(TEXTURE_SUIDOUKAN, true)
                    local fx_sprite = fx:sprite()
                    fx_sprite:set_layer(-2)
                    local fx_anim = fx:get_animation()
                    fx_anim:load(ANIMPATH_SUIDOUKAN)
                    fx_anim:set_state("0")
                    fx_anim:refresh(fx_sprite)
                    fx_anim:on_complete(function()
                        fx:erase()
                    end)
                    anim:on_frame(1, function()
                        print("AquaMan: Suidoukan!")
                        Engine.play_audio(AUDIO_SPAWN2, AudioPriority.High)
                        field:spawn(fx, offset_tile_1)
                    end)
                    fx_anim:on_frame(17, function()
                        Engine.play_audio(AUDIO_SUIDOUKAN, AudioPriority.High)
                        create_attack(user, direction, props, field, offset_tile_2)
                    end)
                    fx_anim:on_frame(19, function()
                        create_attack(user, direction, props, field, offset_tile_3)
                    end)
                    fx_anim:on_frame(22, function()
                        create_attack(user, direction, props, field, offset_tile_3)
                    end)
                    fx_anim:on_frame(35, function()
                        create_warp(field, offset_tile_1)
                    end)
                    anim:on_complete(function()
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
            if anim:get_state() == "END" then
                anim:on_frame(1, function()
                    create_warp(field, offset_tile_1)
                end)
                anim:on_complete(function()
                    ref.navi:erase()
                    step1:complete_step()
                end)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action    
end

function create_attack(user, direction, props, field, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(direction) 
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local attack_anim = spell:get_animation()
    attack_anim:load(ANIMPATH_ATTACK)
    attack_anim:set_state("0")
    attack_anim:on_complete(function() spell:erase() end)
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_hit_effect(field, tile)
    end
    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
		spell:erase()
	end
    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

    return spell
end

function create_hit_effect(field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(TEXTURE_EFFECT, true)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    hitfx_sprite:set_offset(math.random(-10,10), math.random(-10,10))
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(ANIMPATH_EFFECT)
	hitfx_anim:set_state("0")
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
end

function create_warp(field, tile)
    local warp = Battle.Artifact.new()
    warp:set_facing(Direction.Right)
    warp:set_texture(TEXTURE_WARP, true)
    local warp_sprite = warp:sprite()
    warp_sprite:set_layer(-3)
    local warp_anim = warp:get_animation()
	warp_anim:load(ANIMPATH_WARP)
	warp_anim:set_state("2")
	warp_anim:refresh(warp_sprite)
    warp_anim:on_complete(function()
        warp:erase()
    end)
    field:spawn(warp, tile)
end