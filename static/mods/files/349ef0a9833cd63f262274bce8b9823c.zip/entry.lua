nonce = function() end

AUDIO = nil
END_AUDIO = nil

function package_init(package)
    package:declare_package_id("hoov.card.lowroad")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"*"})

    local props = package:get_card_props()
    props.shortname = "LowRoad"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Shift foes downwards!"

    AUDIO = Engine.load_audio(_modpath.."sfx.OGG")
    END_AUDIO = Engine.load_audio(_modpath.."finish_sfx.OGG")
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in create_card_action()!")
        local ref = self
		local tile = user:get_tile(user:get_facing(), 3)
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)
		local k = 0
		local cooldown = 0
		local previous_state = nil
        local previous_state2 = nil
        local previous_state3 = nil

        local step1 = Battle.Step.new()

        --tile = ref.tile:get_tile(ref.dir, 2)
        --tile = user:get_current_tile(user:get_facing(), 2)

        step1.update_func = function(self, dt) 
			if cooldown <= 0 then
				k = k + 1
				cooldown = 5
				Engine.play_audio(AUDIO, AudioPriority.Low)
                --tile1
                if tile and tile:get_state() ~= TileState.DirectionDown then
                    previous_state = tile:get_state()
                end
                if tile and not tile:is_edge() then
                    if tile:get_state() == TileState.DirectionDown and previous_state ~= nil then
                        tile:set_state(previous_state)
                    else
                        tile:set_state(TileState.DirectionDown)
                    end
                end
                --tile2
                if tile2 and tile2:get_state() ~= TileState.DirectionDown then
                    previous_state2 = tile2:get_state()
                end
                if til2e and not tile2:is_edge() then
                    if tile2:get_state() == TileState.DirectionDown and previous_state ~= nil then
                        tile2:set_state(previous_state2)
                    else
                        tile2:set_state(TileState.DirectionDown)
                    end
                end
                --tile3
                if tile3 and tile3:get_state() ~= TileState.DirectionDown then
                    previous_state3 = tile3:get_state()
                end
                if tile3 and not tile3:is_edge() then
                    if tile3:get_state() == TileState.DirectionDown and previous_state ~= nil then
                        tile3:set_state(previous_state3)
                    else
                        tile3:set_state(TileState.DirectionDown)
                    end
                end
            else
                cooldown = cooldown - 1
            end
            if k == 14 then
                tile:set_state(TileState.DirectionDown)
                tile2:set_state(TileState.DirectionDown)
                tile3:set_state(TileState.DirectionDown)
                Engine.play_audio(END_AUDIO, AudioPriority.Low)
                self:complete_step()
            end
        end
        self:add_step(step1)
    end
    return action
end