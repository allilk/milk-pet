local DAMAGE = 100
local SLASH_TEXTURE = Engine.load_texture(_modpath .. "spell_sword_slashes.png")
local BLADE_TEXTURE = Engine.load_texture(_modpath .. "spell_sword_blades.png")
local AUDIO = Engine.load_audio(_modpath .. "sfx.ogg")

function package_init(package)
	package:declare_package_id("com.EXE2.Card256-FighterSword")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'A', 'I', 'L', 'S', 'Y' })

	local props = package:get_card_props()
	props.shortname = "FtrSword"
	props.damage = DAMAGE
	props.time_freeze = false
	props.element = Element.None
	props.description = "Normal sword. 3 sqrs fwd"
	props.long_description = "A normal Sword slash, 3 squares deep."
	props.limit = 5
end

local frame_data = make_frame_data({
	{ 1, 0.017 }, { 2, 0.066 }, { 3, 0.066 }, { 4, 0.27 }
})

local idle_data = make_frame_data({
	{1, 0.14},
})

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:override_animation_frames(idle_data)
	action:set_lockout(make_animation_lockout())
	local field = actor:get_field()
	action.animation_end_func = function()
		local tile = actor:get_tile(actor:get_facing(), 1)
		local fx = Battle.Spell.new(actor:get_team())
		fx:set_facing(actor:get_facing())
		local anim = fx:get_animation()
		fx:set_texture(SLASH_TEXTURE, true)
		anim:load(_modpath .. "spell_sword_slashes.animation")
		anim:set_state("BIG")
		anim:on_complete(function()
			fx:erase()
		end)
		field:spawn(fx, tile)
		local action_2 = Battle.CardAction.new(actor, "PLAYER_SWORD")
		action_2:override_animation_frames(frame_data)
		action_2:set_lockout(make_animation_lockout())
		action_2.execute_func = function(self, user)
			self:add_anim_action(1, function()
				local hilt = self:add_attachment("HILT")
				local hilt_sprite = hilt:sprite()
				hilt_sprite:set_texture(actor:get_texture())
				hilt_sprite:set_layer(-2)
				hilt_sprite:enable_parent_shader(true)

				local hilt_anim = hilt:get_animation()
				hilt_anim:copy_from(actor:get_animation())
				hilt_anim:set_state("HILT")

				local blade = hilt:add_attachment("ENDPOINT")
				local blade_sprite = blade:sprite()
				blade_sprite:set_texture(BLADE_TEXTURE)
				blade_sprite:set_layer(-1)

				local blade_anim = blade:get_animation()
				blade_anim:load(_modpath .. "spell_sword_blades.animation")
				blade_anim:set_state("DEFAULT")
				self.sword = create_slash(user, props)
				local tile = user:get_tile(user:get_facing(), 1)
				field:spawn(self.sword, tile)
			end)
		end
		action_2.animation_end_func = function(self)
			self:end_action()
		end
		action_2.action_end_func = function(self)
			if self.sword and not self.sword:is_deleted() then self.sword:erase() end
		end
		actor:card_action_event(action_2, ActionOrder.Immediate)
	end
	return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)

	spell.update_func = function(self, dt)
		if not self:get_tile():get_tile(user:get_facing(), 1):is_edge() then
			self:get_tile():get_tile(user:get_facing(), 1):highlight(Highlight.Flash)
			self:get_tile():get_tile(user:get_facing(), 1):attack_entities(self)
		end
		if not self:get_tile():get_tile(user:get_facing(), 2):is_edge() then
			self:get_tile():get_tile(user:get_facing(), 2):highlight(Highlight.Flash)
			self:get_tile():get_tile(user:get_facing(), 2):attack_entities(self)
		end
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end
