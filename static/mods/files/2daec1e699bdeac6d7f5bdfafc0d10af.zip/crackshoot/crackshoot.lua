local DAMAGE = 60
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local CRACKSHOOT_TEXTURE = Engine.load_texture(_folderpath.."spell_panel_shot.png")
local CRACKSHOOT_ANIMPATH = _folderpath.."spell_panel_shot.animation"
local CRACKSHOOT_AUDIO_YES = Engine.load_audio(_folderpath.."crackshoot_yes.ogg")
local CRACKSHOOT_AUDIO_NO = Engine.load_audio(_folderpath.."crackshoot_no.ogg")
local DUST_TEXTURE = Engine.load_texture(_folderpath.."dust.png")
local DUST_ANIMPATH = _folderpath.."dust.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local crackshoot = {
	type = 1,

	codes = {"A","G","T","*"},
	shortname = "CrakShot",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Throw a panel at an enemy!",
	long_description = "Attack by throwing the panel in front of you forward!",
	can_boost = true,
	card_class = CardClass.Standard,
	limit = 5
}

crackshoot.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
	local char_query = function(o)
		return Battle.Character.from(o) ~= nil or Battle.Player.from(o) ~= nil
	end
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		local field = user:get_field()
		local team = user:get_team()
		local facing = user:get_facing()
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
		end)
		
		self:add_anim_action(3, function()
			if 	   crackshoot.type == 1 then
				local tile1 = user:get_tile(facing, 1)
				local check1 = (#tile1:find_entities(char_query) > 0 or #tile1:find_entities(dark_query) > 0 or not tile1:is_walkable())
				if check1 then
					Engine.play_audio(CRACKSHOOT_AUDIO_NO, AudioPriority.High)
				else
					Engine.play_audio(CRACKSHOOT_AUDIO_YES, AudioPriority.High)
				end
				--[[if tile1:is_reserved({}) then
					print("tile1 - RESERVED")
				else
					print("tile1 - NOT reserved")
				end
				if tile1:is_walkable() then
					print("tile1 - WALKABLE")
				else
					print("tile1 - NOT walkable")
				end
				if tile1:is_hole() then
					print("tile1 - HOLE")
				else
					print("tile1 - NOT hole")
				end]]
				create_attack(user, props, team, facing, field, tile1, char_query, dark_query)
			elseif crackshoot.type == 2 then
				local tile1 = user:get_tile(facing, 1)
				local tile2 = user:get_tile(facing, 2)
				local check1 = (#tile1:find_entities(char_query) > 0 or #tile1:find_entities(dark_query) > 0 or not tile1:is_walkable())
				local check2 = (#tile2:find_entities(char_query) > 0 or #tile2:find_entities(dark_query) > 0 or not tile2:is_walkable())
				if check1 and check2 then
					Engine.play_audio(CRACKSHOOT_AUDIO_NO, AudioPriority.High)
				else
					Engine.play_audio(CRACKSHOOT_AUDIO_YES, AudioPriority.High)
				end
				create_attack(user, props, team, facing, field, tile1, char_query, dark_query)
				create_attack(user, props, team, facing, field, tile2, char_query, dark_query)
			elseif crackshoot.type == 3 then
				local tile1 = user:get_tile(facing, 1):get_tile(Direction.Up, 1)
				local tile2 = user:get_tile(facing, 1)
				local tile3 = user:get_tile(facing, 1):get_tile(Direction.Down, 1)
				local check1 = (#tile1:find_entities(char_query) > 0 or #tile1:find_entities(dark_query) > 0 or not tile1:is_walkable())
				local check2 = (#tile2:find_entities(char_query) > 0 or #tile2:find_entities(dark_query) > 0 or not tile2:is_walkable())
				local check3 = (#tile3:find_entities(char_query) > 0 or #tile3:find_entities(dark_query) > 0 or not tile3:is_walkable())
				if check1 and check2 and check3 then
					Engine.play_audio(CRACKSHOOT_AUDIO_NO, AudioPriority.High)
				else
					Engine.play_audio(CRACKSHOOT_AUDIO_YES, AudioPriority.High)
				end
				create_attack(user, props, team, facing, field, tile1, char_query, dark_query)
				create_attack(user, props, team, facing, field, tile2, char_query, dark_query)
				create_attack(user, props, team, facing, field, tile3, char_query, dark_query)
			end
		end)
	end
    return action
end

function create_attack(user, props, team, facing, field, tile, char_query, dark_query)
	local spell = Battle.Spell.new(team)
	spell.can_move_to_func = function(self, tile)
		if tile then
			return true
		end
		return false
	end
	spell:set_facing(facing)
	if tile then
		--[[local dust_fx = Battle.Artifact.new()
		dust_fx:set_texture(DUST_TEXTURE, true)
		dust_fx:set_facing(facing)
		local dust_anim = dust_fx:get_animation()
		dust_anim:load(DUST_ANIMPATH)
		dust_anim:set_state("DEFAULT")
		dust_anim:refresh(dust_fx:sprite())
		dust_anim:on_complete(function()
			dust_fx:erase()
		end)]]
		if not tile:is_edge() then
			--field:spawn(dust_fx, tile)
			create_effect(facing, DUST_TEXTURE, DUST_ANIMPATH, "DEFAULT", 0, 0, -3, field, tile)
		end
		if (#tile:find_entities(char_query) > 0 or #tile:find_entities(dark_query) > 0) and tile:is_walkable() then
			tile:set_state(TileState.Cracked)
		elseif (#tile:find_entities(char_query) <= 0 or #tile:find_entities(dark_query) <= 0) and tile:is_walkable() then
			tile:set_state(TileState.Broken)
			spell:set_texture(CRACKSHOOT_TEXTURE, true)
			spell.slide_started = false
			spell:set_hit_props(
				HitProps.new(
					props.damage, 
					Hit.Impact | Hit.Flinch,
					props.element,
					user:get_context(),
					Drag.None
				)
			)
			spell:get_animation():load(CRACKSHOOT_ANIMPATH)
			if tile:get_team() == Team.Blue then
				spell:get_animation():set_state("BLUE_TEAM")
			else
				spell:get_animation():set_state("RED_TEAM")
			end
			spell:set_offset(0, 24)
			spell:get_animation():refresh(spell:sprite())
			spell:get_animation():on_complete(function()
				spell:get_animation():set_playback(Playback.Loop)
			end)
			spell.update_func = function(self, dt) 
				self:get_current_tile():attack_entities(self)
				if self:get_offset().y <= 0 then
					if self:is_sliding() == false then
						if self:get_current_tile():is_edge() and self.slide_started then 
							self:delete()
						end 
						
						local dest = self:get_tile(spell:get_facing(), 1)
						local ref = self
						self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, function()
							ref.slide_started = true 
						end)
					end
				else
					self:set_offset(self:get_offset().x, self:get_offset().y - 4)
				end
			end
		end
		field:spawn(spell, tile)
	end
	spell.collision_func = function(self, other)
		self:delete()
	end
	spell.delete_func = function(self)
		self:erase()
    end
	spell.can_move_to_func = function(self, tile)
        return true
    end
    spell.attack_func = function(self, ent)
		if facing == Direction.Right then
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", -20, -15, -999999, field, self:get_current_tile())
		else
			create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", 20, -15, -999999, field, self:get_current_tile())
		end
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
		end
	end
	print("CrackShoot created at tile ("..tile:x()..";"..tile:y()..")")
	return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return crackshoot