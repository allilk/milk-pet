local crackshoot = include("crackshoot/crackshoot.lua")

local DAMAGE = 60

crackshoot.type = 2

crackshoot.codes = {"C","R","U","*"}
crackshoot.shortname = "DublShot"
crackshoot.damage = DAMAGE
crackshoot.time_freeze = false
crackshoot.element = Element.None
crackshoot.description = "Throw 2 panels at an enemy!"
crackshoot.long_description = "Attack by throwing 2 panels in front of you forward!"
crackshoot.can_boost = true
crackshoot.card_class = CardClass.Standard
crackshoot.limit = 5

function package_init(package) 
    package:declare_package_id("com.Dawn.k1rbyat1na.card.EXE6-089-DoubleShoot")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(crackshoot.codes)

    local props = package:get_card_props()
    props.shortname = crackshoot.shortname
    props.damage = crackshoot.damage
    props.time_freeze = crackshoot.time_freeze
    props.element = crackshoot.element
    props.description = crackshoot.description
    props.long_description = crackshoot.long_description
    props.can_boost = crackshoot.can_boost
	props.card_class = crackshoot.card_class
	props.limit = crackshoot.limit
end

card_create_action = crackshoot.card_create_action