local DAMAGE = 300

local TEXTURE_BLUEMOON = Engine.load_texture(_modpath.."redsun.png")
local ANIMPATH_BLUEMOON = _modpath.."redsun.animation"
local AUDIO_SPAWN2 = Engine.load_audio(_modpath.."spawn2.ogg")
local AUDIO_CHARGE = Engine.load_audio(_modpath.."charge.ogg")
local AUDIO_METEOR = Engine.load_audio(_modpath.."meteor.ogg")
local AUDIO_FALL = Engine.load_audio(_modpath.."fall.ogg")
local AUDIO_CRACK = Engine.load_audio(_modpath.."crack.ogg")

local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")
local TEXTURE_BOOM1 = Engine.load_texture(_modpath.."boom1.png")
local ANIMPATH_BOOM1 = _modpath.."boom1.animation"
local TEXTURE_BOOM2 = Engine.load_texture(_modpath.."boom2.png")
local ANIMPATH_BOOM2 = _modpath.."boom2.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-277-MeteorRedSun")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"R"})

    local props = package:get_card_props()
    props.shortname = "RedSun"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "RedSun bombards 3 ahead!"
    props.long_description = "Red Sun rains down meteors 3 squares ahead!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local offset_tile = user:get_tile(direction, 3)

		local step1 = Battle.Step.new()

        self.redsun = nil
        self.tile   = user:get_current_tile()
		
        local field = user:get_field()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.redsun = Battle.Artifact.new()
                ref.redsun:set_facing(direction)
                ref.redsun:sprite():set_layer(-3)
		    	ref.redsun:set_texture(TEXTURE_BLUEMOON, true)

                red_anim = ref.redsun:get_animation()
                red_anim:load(ANIMPATH_BLUEMOON)
                red_anim:set_state("SPAWN")
		    	red_anim:refresh(ref.redsun:sprite())
                red_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN2, AudioPriority.High)
                end)
                red_anim:on_frame(8, function()
                    Engine.play_audio(AUDIO_CHARGE, AudioPriority.High)
                end)
		    	red_anim:on_complete(function()
		    		red_anim:set_state("ATTACK")
		    		red_anim:refresh(ref.redsun:sprite())
		    	end)
                field:spawn(ref.redsun, ref.tile)
            end
            local anim = ref.redsun:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_frame(1, function()
                        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
			        end)
                    anim:on_frame(16, function()
                        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
			        end)
                    anim:on_frame(17, function()
                        if not offset_tile:get_state() == TileState.Broken or not offset_tile:is_hole() or not offset_tile:is_edge() then
                            ref.redsun:shake_camera(9, 0.25)
                        end
                        create_attack(user, team, props, offset_tile, field)
			        end)
                    anim:on_frame(32, function()
                        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
			        end)
                    anim:on_frame(33, function()
                        if not offset_tile:get_state() == TileState.Broken or not offset_tile:is_hole() or not offset_tile:is_edge() then
                            ref.redsun:shake_camera(9, 0.25)
                        end
                        create_attack(user, team, props, offset_tile, field)
			        end)
                    anim:on_frame(48, function()
                        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
			        end)
                    anim:on_frame(49, function()
                        if not offset_tile:get_state() == TileState.Broken or not offset_tile:is_hole() or not offset_tile:is_edge() then
                            ref.redsun:shake_camera(9, 0.25)
                        end
                        create_attack(user, team, props, offset_tile, field)
			        end)
                    anim:on_frame(64, function()
                        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
			        end)
                    anim:on_frame(65, function()
                        if not offset_tile:get_state() == TileState.Broken or not offset_tile:is_hole() or not offset_tile:is_edge() then
                            ref.redsun:shake_camera(9, 0.25)
                        end
                        create_attack(user, team, props, offset_tile, field)
			        end)
                    anim:on_frame(81, function()
                        if not offset_tile:get_state() == TileState.Broken or not offset_tile:is_hole() or not offset_tile:is_edge() then
                            ref.redsun:shake_camera(9, 0.25)
                        end
                        create_attack(user, team, props, offset_tile, field)
			        end)
                    anim:on_frame(94, function()
                        Engine.play_audio(AUDIO_FALL, AudioPriority.Highest)
			        end)
                    anim:on_frame(103, function()
                        if not offset_tile:is_edge() then
                            ref.redsun:shake_camera(30, 1)
                            local redsunfall = create_attack2(user, team, props, offset_tile, field)
                            field:spawn(redsunfall, offset_tile)
                        end
			        end)
                    anim:on_complete(function()
                        ref.redsun:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
	action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_attack(actor, team, props, tile, field)
    local spawn_boom
    spawn_boom = function()
        if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:get_facing(Direction.Left)
        spell:set_hit_props(
            HitProps.new(
                40,
                Hit.Flinch | Hit.Flash | Hit.Impact,
                props.element,
                actor:get_id(),
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(TEXTURE_BOOM1)
        boom_sprite:set_layer(-3)

        local boom_anim = spell:get_animation()
        boom_anim:load(ANIMPATH_BOOM1)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_complete(function() spell:erase() end)

        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.can_move_to_func = function(tile)
	    	return true
	    end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.attack_func = function(self, other)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end

        spell.delete_func = function(self)
	    	self:erase()
        end

        Engine.play_audio(AUDIO_BOOM, AudioPriority.Highest)

        field:spawn(spell, tile)
    end

    spawn_boom()
end

function create_attack2(actor, team, props, tile, field)
    local spell = Battle.Spell.new(team)
    spell:get_facing(Direction.Left)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact | Hit.Breaking,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )
    local boomfx1 = Battle.Artifact.new()
	boomfx1:set_facing(Direction.Left)
    boomfx1:set_texture(TEXTURE_BOOM2, true)
    boomfx1:set_offset(0,-70)
	local fx1_anim = boomfx1:get_animation()
	fx1_anim:load(ANIMPATH_BOOM2)
	fx1_anim:set_state("0")
    fx1_anim:on_complete(function()
        boomfx1:erase()
    end)

    local boom_sprite = spell:sprite()
    boom_sprite:set_texture(TEXTURE_BOOM1, true)
    boom_sprite:set_layer(-3)

    local boom_anim = spell:get_animation()
    boom_anim:load(ANIMPATH_BOOM1)
    boom_anim:set_state("0")
    boom_anim:refresh(boom_sprite)
    boom_anim:on_frame(1, function()
        local tile_U  = tile:get_tile(Direction.Up, 1)
        local tile_UR = tile:get_tile(Direction.UpRight, 1)
        local tile_R  = tile:get_tile(Direction.Right, 1)
        local tile_DR = tile:get_tile(Direction.DownRight, 1)
        local tile_D  = tile:get_tile(Direction.Down, 1)
        local tile_DL = tile:get_tile(Direction.DownLeft, 1)
        local tile_L  = tile:get_tile(Direction.Left, 1)
        local tile_UL = tile:get_tile(Direction.UpLeft, 1)
        if not tile:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile:set_state(TileState.Broken)
        end
        if not tile_U:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_U:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_U:set_state(TileState.Broken)
        end
        if not tile_UR:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_UR:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_UR:set_state(TileState.Broken)
        end
        if not tile_R:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_R:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_R:set_state(TileState.Broken)
        end
        if not tile_DR:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_DR:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_DR:set_state(TileState.Broken)
        end
        if not tile_D:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_D:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_D:set_state(TileState.Broken)
        end
        if not tile_DL:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_DL:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_DL:set_state(TileState.Broken)
        end
        if not tile_L:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_L:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_L:set_state(TileState.Broken)
        end
        if not tile_UL:is_cracked() then
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_UL:set_state(TileState.Cracked)
        else
            Engine.play_audio(AUDIO_CRACK, AudioPriority.High)
            tile_UL:set_state(TileState.Broken)
        end
    end, true)
    boom_anim:on_frame(2, function()
        field:spawn(boomfx1, tile)
    end)
    boom_anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    
    spell.delete_func = function(self)
		self:erase()
    end

    return spell
end