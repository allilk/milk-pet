local DAMAGE = 140

local TEXTURE_TOMAHAWKMAN = Engine.load_texture(_modpath.."tomahawkman.png")
local ANIMPATH_TOMAHAWKMAN = _modpath.."tomahawkman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_TOMAHAWKSWING = Engine.load_audio(_modpath.."tomahawkswing.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-227-TomahawkMan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"T","*"})

    local props = package:get_card_props()
    props.shortname = "TmhkMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Wood
    props.description = "Slice 2sq side, 3sq vertical"
    props.long_description = "Tomahawk Swing cuts a range of 2 horizontal and 3 vertical"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local self_tile = user:get_tile()
        local x = self_tile:x()
        local y = self_tile:y()

		local step1 = Battle.Step.new()

        self.tomahawkman = nil
        self.tile     = user:get_current_tile()
		
        local field = user:get_field()
        local direction = user:get_facing()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.tomahawkman = Battle.Artifact.new()
                ref.tomahawkman:set_facing(direction)
		    	ref.tomahawkman:set_texture(TEXTURE_TOMAHAWKMAN, true)
		    	ref.tomahawkman:sprite():set_layer(-1)

                local tomahawk_anim = ref.tomahawkman:get_animation()
                tomahawk_anim:load(ANIMPATH_TOMAHAWKMAN)
                tomahawk_anim:set_state("SPAWN")
		    	tomahawk_anim:refresh(ref.tomahawkman:sprite())
                tomahawk_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
		    	tomahawk_anim:on_complete(function()
		    		tomahawk_anim:set_state("ATTACK")
		    		tomahawk_anim:refresh(ref.tomahawkman:sprite())
		    	end)
                field:spawn(ref.tomahawkman, ref.tile)
            end
            local anim = ref.tomahawkman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local tomahawkswing = create_tomahawkswing(user, props)
                    local tile = user:get_tile(direction, 1)
				    local sharebox1 = Battle.SharedHitbox.new(tomahawkswing, 0.15)
				    sharebox1:set_hit_props(tomahawkswing:copy_hit_props())
                    local sharebox2 = Battle.SharedHitbox.new(tomahawkswing, 0.15)
				    sharebox2:set_hit_props(tomahawkswing:copy_hit_props())
                    local sharebox3 = Battle.SharedHitbox.new(tomahawkswing, 0.15)
				    sharebox3:set_hit_props(tomahawkswing:copy_hit_props())
                    local sharebox4 = Battle.SharedHitbox.new(tomahawkswing, 0.15)
				    sharebox4:set_hit_props(tomahawkswing:copy_hit_props())
                    local sharebox5 = Battle.SharedHitbox.new(tomahawkswing, 0.15)
				    sharebox5:set_hit_props(tomahawkswing:copy_hit_props())
                    anim:on_frame(4, function()
                        print("TomahawkMan: TomahawkSwing!")
                        Engine.play_audio(AUDIO_TOMAHAWKSWING, AudioPriority.High)
                    end)
                    anim:on_frame(5, function()
                        ref.tomahawkman:shake_camera(15, 0.5)
                        field:spawn(tomahawkswing, tile)
                        field:spawn(sharebox1, tile:get_tile(Direction.Up, 1))
                        field:spawn(sharebox2, tile:get_tile(Direction.Down, 1))
                        if direction == Direction.Right then
                            field:spawn(sharebox3, tile:get_tile(Direction.UpRight, 1))
                            field:spawn(sharebox4, tile:get_tile(Direction.Right, 1))
                            field:spawn(sharebox5, tile:get_tile(Direction.DownRight, 1))
                        else
                            field:spawn(sharebox3, tile:get_tile(Direction.UpLeft, 1))
                            field:spawn(sharebox4, tile:get_tile(Direction.Left, 1))
                            field:spawn(sharebox5, tile:get_tile(Direction.DownLeft, 1))
                        end
                    end)
                    anim:on_frame(8, function()
                        tomahawkswing:erase()
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
                        anim:refresh(ref.tomahawkman:sprite())
                        anim:on_complete(function()
                            ref.tomahawkman:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_tomahawkswing(user, props)
    local spell = Battle.Spell.new(user:get_team())
    local direction = user:get_facing()
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end

	return spell
end