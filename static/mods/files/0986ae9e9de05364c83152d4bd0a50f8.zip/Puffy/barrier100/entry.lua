nonce = function() end

local BARRIER100_TEXTURE = Engine.load_texture(_folderpath .. "barrier100.png")
local BARRIER100_ANIMATION_PATH = _folderpath .. "barrier.animation"
local BARRIER_UP_SOUND = Engine.load_audio(_folderpath .. "Barrier.ogg") -- Normalized -0.1

local chip = {}

function package_init(package)
    package:declare_package_id("com.alrysc.card.barrier100")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon2.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview2.png"))
    package:set_codes({ 'H', 'O', 'Y' })

    local props = package:get_card_props()
    props.shortname = "Barr100"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Nullifies 100 HP of damage"
    props.limit = 3

end

chip.card_create_action = function(user, props)
    local props = Battle.CardProperties.new()
    props.damage = 0
    props.shortname = "Barrier 100"
    props.time_freeze = true

    local PRESTEP = { 0, 0.05 }
    local END = { 0, 0.5 }
    local FRAMES = make_frame_data({ PRESTEP, END })

    local action = Battle.CardAction.new(user, "LEVEL1_IDLE")
    action:set_metadata(props)
    action:set_lockout(make_animation_lockout())
    action:override_animation_frames(FRAMES)

    action:add_anim_action(2, function()
        Engine.play_audio(BARRIER_UP_SOUND, AudioPriority.High)
        create_barrier(user)
    end)


    return action
end


function create_barrier(user)
    local offsetY = -2 * (user:get_height() - 48) -- MegaMan is 48 and I built around that, so I'm just offsetting for different heights by a bit
    if offsetY > 0 then offsetY = 0 end
    local fading = false
    local isWind = false

    local barrier = Battle.Artifact.new()
    barrier.HP = 100
    barrier:sprite():set_layer(3)
    barrier:set_texture(BARRIER100_TEXTURE, true)
    barrier:set_offset(0, offsetY)
    barrier:get_animation():load(BARRIER100_ANIMATION_PATH)
    barrier:get_animation():set_state("BARRIER_IDLE")
    barrier:get_animation():refresh(barrier:sprite())
    barrier:get_animation():set_playback(Playback.Loop)
    barrier:set_float_shoe(true)

    user:get_field():spawn(barrier, user:get_current_tile())

    local barrier_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always) -- Keristero's Guard is 0

    barrier_defense_rule.can_block_func = function(judge, attacker, defender)

        local attacker_hit_props = attacker:copy_hit_props()

        if attacker_hit_props.flags & Hit.Impact == Hit.Impact then
            barrier.HP = barrier.HP - attacker_hit_props.damage
            judge:block_damage()
        end

        if attacker_hit_props.element == Element.Wind then
            isWind = true
        end

    end

    user:add_defense_rule(barrier_defense_rule)
    barrier.can_move_to_func = function()
        return true
    end

    local function remove_barrier()
        fading = true
        user:remove_defense_rule(barrier_defense_rule)

        barrier:get_animation():set_state("BARRIER_FADE")
        barrier:get_animation():refresh(barrier:sprite())

        barrier:get_animation():on_complete(function()
            barrier:delete()
        end)


        if isWind then
            local initialX = barrier:get_offset().x
            local initialY = barrier:get_offset().y
            local facing_check = 1
            if user:get_facing() == Direction.Left then
                facing_check = -1
            end


            barrier:get_animation():on_frame(1, function()
                barrier:set_offset(facing_check * (-24 - initialX), -10 + initialY)

            end)

            barrier:get_animation():on_frame(3, function()
                barrier:set_offset(facing_check * (-44 - initialX), -20 + initialY)

            end)

            barrier:get_animation():on_frame(5, function()
                barrier:set_offset(facing_check * (-84 - initialX), -36 + initialY)

            end)

            barrier:get_animation():on_frame(7, function()
                barrier:set_offset(facing_check * (-120 - initialX), -50 + initialY)

            end)

            barrier:get_animation():on_frame(9, function()
                barrier:set_offset(facing_check * (-156 - initialX), -66 + initialY)

            end)

            barrier:get_animation():on_frame(11, function()
                barrier:set_offset(facing_check * (-192 - initialX), -80 + initialY)

            end)

            barrier:get_animation():on_frame(13, function()
                barrier:set_offset(facing_check * (-228 - initialX), -96 + initialY)

            end)
        end

    end

    barrier.update_func = function()
        if user:is_deleted() then
            remove_barrier()
        end
        if barrier:get_current_tile() ~= user:get_current_tile() then
            barrier:teleport(user:get_current_tile(), ActionOrder.Immediate, nil)
        end

        if isWind and not fading then
            remove_barrier()
        end

        if barrier.HP <= 0 and not fading then
            remove_barrier()

        end

        if barrier_defense_rule:is_replaced() then
            barrier:delete()
        end
    end

end

return chip
