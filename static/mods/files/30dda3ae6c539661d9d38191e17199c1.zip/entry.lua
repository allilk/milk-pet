
function package_init(package)
    package:declare_package_id("com.churger.navi.sonicthehedgehog")
    package:set_special_description("Just a guy that loves adventure!")
    package:set_speed(5.0)
    package:set_attack(5)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."/sprites/preview.png"))
    package:set_overworld_animation_path(_modpath.."/animations/sonic_ow.animation")
    package:set_overworld_texture_path(_modpath.."/sprites/sonic_ow.png")
    package:set_icon_texture(Engine.load_texture(_modpath.."/sprites/sonic_face.png"))
    package:set_mugshot_animation_path(_modpath.."/animations/mug.animation")
    package:set_mugshot_texture_path(_modpath.."/sprites/mug.png")
    package:set_emotions_texture_path(_modpath.."/sprites/emotions.png")
end

function player_init(player)
    player:set_name("Sonic")
    player:set_health(1500)
    player:set_element(Element.None)
    player:set_height(36.0)

    local base_texture = Engine.load_texture(_modpath.."/sprites/sonic.png")
    local base_animation_path = _modpath.."/animations/sonic.animation"
    local base_charge_color = Color.new(0, 64, 232, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(5, -10)

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end

end
