nonce = function() end

local gunhilt = Engine.load_texture(_modpath .. "gunhilt.png")
local sunray = Engine.load_texture(_modpath .. "sun_ray.png")

function package_init(package)

    package:declare_package_id("com.Rework.X.Chip06")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'C', 'U', 'T' })

    local props = package:get_card_props()
    props.shortname = "Cutter"
    props.time_freeze = false
    props.element = Element.None
    props.limit = 3
    props.card_class = CardClass.Standard
    props.can_boost = false
    props.description = "Hits 2pnl w/solar swrd atk!"

end

local function spell_damage_summon(user)
    local spell_damage = Battle.Spell.new(user:get_team())
    spell_damage:set_hit_props(
        HitProps.new(
            4,
            Hit.Pierce | Hit.Retangible,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell_damage.update_func = function(self, dt)
        local own_tile = self:get_tile() --Dawn: get the tile this entity is on
        if not own_tile or own_tile and own_tile:is_edge() then
            self:delete()
            return
        else
            own_tile:attack_entities(self)
        end
        self:erase()
    end
    return spell_damage
end

local function summon_sun(user)
    local spell = Battle.Spell.new(user:get_team())
    local framedata = 0

    spell:set_facing(user:get_facing())
    spell:set_texture(sunray)

    local anim = spell:get_animation()
    anim:load(_modpath .. "sun_ray.animation")
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    anim:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    local sun_noise_countdown = 0
    local sun_noise = Engine.load_audio(_modpath.."song329.ogg", true)
    local field = user:get_field()
    local tile = user:get_tile(user:get_facing(), 1)
    local tile_2 = user:get_tile(user:get_facing(), 2)
    spell.update_func = function(self, dt)
        if framedata >= 91 then
            self:delete()
        else
            if framedata > 0 then
                local call_hit_1 = spell_damage_summon(self)
                local call_hit_2 = spell_damage_summon(self)
                field:spawn(call_hit_1, tile)
                field:spawn(call_hit_2, tile_2)
                tile:highlight(Highlight.Flash)
                tile_2:highlight(Highlight.Flash)
                if sun_noise_countdown <= 0 then
                    Engine.play_audio(sun_noise, AudioPriority.High)
                    sun_noise_countdown = 2
                end
                sun_noise_countdown = sun_noise_countdown - 1
            end
        end
        framedata = framedata + 1
    end

    spell.can_move_to_func = function(self, other)
        return true
    end

    return spell
end

function card_create_action(actor)
    local STARTUP = { 1, 0.1 } -- Wait 6 frames, yes I counted again and it sounds like you got it
    local THE_REST = { 1, 1.73 } -- Stay posed for 104 frames.

    local FRAMES = make_frame_data({ STARTUP, THE_REST })

    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    action:override_animation_frames(FRAMES)

    action.execute_func = function(self, user)

        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(gunhilt, true)
        buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "player_fx3B_animations.animation")
        buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        buster_anim:set_state("1")
        buster_anim:set_playback(Playback.Loop)
        buster_anim:refresh(buster:sprite())

        action:add_anim_action(2, function()
            self.ray_of_sun = summon_sun(user)
            local tile = user:get_tile(user:get_facing(), 1)
            if tile and not tile:is_edge() then
                actor:get_field():spawn(self.ray_of_sun, tile)
            else
                Engine.play_audio(Engine.load_audio(_modpath.."song248.ogg", true), AudioPriority.High)
                buster_anim:set_state("0")
                buster_anim:refresh(buster:sprite())
                buster_anim:set_playback(Playback.Reverse)
                buster_anim:on_complete(function()
                    self:end_action()
                end)
            end
        end)
    end
    action.action_end_func = function(self)
        if self.ray_of_sun and not self.ray_of_sun:is_deleted() then self.ray_of_sun:erase() end
    end
    return action
end