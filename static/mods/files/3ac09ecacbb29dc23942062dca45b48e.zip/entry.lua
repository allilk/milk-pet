local DAMAGE = 50

local HAKUSHAKU_TEXTURE = Engine.load_texture(_modpath.."hakushaku.png")
local HAKUSHAKU_ANIMPATH = _modpath.."hakushaku.animation"
local BLOODRAIN_TEXTURE = Engine.load_texture(_modpath.."bloodrain.png")
local BLOODRAIN_ANIMPATH = _modpath.."bloodrain.animation"
local BLOODRAIN_AUDIO = Engine.load_audio(_modpath.."bloodrain.ogg")
local BLOODLANCE_TEXTURE = Engine.load_texture(_modpath.."bloodlance.png")
local BLOODLANCE_ANIMPATH = _modpath.."bloodlance.animation"
local BLOODLANCE_AUDIO = Engine.load_audio(_modpath.."bloodlance.ogg")
local AUDIO_SPAWN = Engine.load_audio(_modpath.."exe6-spawn.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-278-HakushakuSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"H"})

    local props = package:get_card_props()
    props.shortname = "CountSP"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Rain on enmy then lance atk"
    props.long_description = "Blood Rain on enemy area, then lance attack"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 29

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        
        local self_tile = user:get_current_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local targets = {}
        local trg_count = 1
        for i = 1, 6 do
            for j = 1, 3 do
                if field:tile_at(i,j):get_team() ~= team and field:tile_at(i,j):get_state() == TileState.Normal then
                    targets[trg_count] = field:tile_at(i,j)
                    trg_count = trg_count + 1
                end
            end
        end

        local loops = nil

        self.hakushaku = nil
        self.loops0    = 30
        self.loops1    = 34
        self.loops2    = 38
        self.loops3    = 40
        self.tile      = user:get_current_tile()

        local ref = self

		local step1 = Battle.Step.new()

        local do_once = true
        local do_once_2 = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                --print("READING")
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    --print("VOICE")
                    VOICEACTING = true
                end
            end

            if do_once then
                do_once = false
                ref.hakushaku = Battle.Artifact.new()
                ref.hakushaku:set_facing(direction)
                local hakushaku_sprite = ref.hakushaku:sprite()
		    	hakushaku_sprite:set_texture(HAKUSHAKU_TEXTURE, true)
		    	hakushaku_sprite:set_layer(-9)
                local hakushaku_anim = ref.hakushaku:get_animation()
                hakushaku_anim:load(HAKUSHAKU_ANIMPATH)
                if not ref.tile:is_hole() then
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") is NOT a hole!")
                    hakushaku_anim:set_state("SPAWN")
		    	    hakushaku_anim:refresh(hakushaku_sprite)
                    hakushaku_anim:on_complete(function()
                        hakushaku_anim:set_state("ATTACK")
                        hakushaku_anim:refresh(hakushaku_sprite)
                    end)
				else
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") IS a hole!")
                    hakushaku_anim:set_state("SPAWN_HOLE")
		    	    hakushaku_anim:refresh(hakushaku_sprite)
                    hakushaku_anim:on_complete(function()
                        ref.hakushaku:erase()
                        step1:complete_step()
                    end)
				end
                hakushaku_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                    if     trg_count - 1 >= 3 then
                        loops = 3
                    elseif trg_count - 1 == 2 then
                        loops = 2
                    elseif trg_count - 1 == 1 then
                        loops = 1
                    elseif trg_count - 1 == 0 then
                        loops = 0
                    end
                    shuffle(targets)
                end)
                field:spawn(ref.hakushaku, ref.tile)
            end
            local anim = ref.hakushaku:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_2 then
                    do_once_2 = false
                    anim:on_frame(1, function()
                        if     loops == 3 then
                            if ref.loops3 == 34 then
                                create_bloodrain(field, team, direction, user, props)
                            end
                            if ref.loops3 == 4 then
                                create_bloodlance(user, props, team, field, targets[2])
                            end
                        elseif loops == 2 then
                            if ref.loops2 == 32 then
                                create_bloodrain(field, team, direction, user, props)
                            end
                            if ref.loops2 == 4 then
                                create_bloodlance(user, props, team, field, targets[1])
                            end
                        elseif loops == 1 then
                            if ref.loops1 == 28 then
                                create_bloodrain(field, team, direction, user, props)
                            end
                        else
                            if ref.loops0 == 24 then
                                create_bloodrain(field, team, direction, user, props)
                            end
                        end
                    end)
                    anim:on_frame(2, function()
                        if     loops == 3 then
                            if ref.loops3 == 8 then
                                create_bloodlance(user, props, team, field, targets[1])
                            end
                            if ref.loops3 == 2 then
                                create_bloodlance(user, props, team, field, targets[3])
                            end
                        elseif loops == 2 then
                            if ref.loops2 == 2 then
                                create_bloodlance(user, props, team, field, targets[2])
                            end
                        elseif loops == 1 then
                            if ref.loops1 == 2 then
                                create_bloodlance(user, props, team, field, targets[1])
                            end
                        end
                    end)
                    anim:on_complete(function()
                        if     loops == 3 then
                            if ref.loops3 <= 40 and ref.loops3 > 0 then
                                anim:set_playback(Playback.Loop)
                                ref.loops3 = ref.loops3 - 1
                                --print("loops3="..ref.loops3)
                            else
                                anim:set_state("END")
                                anim:refresh(ref.hakushaku:sprite())
                                anim:on_complete(function()
                                    ref.hakushaku:erase()
                                    step1:complete_step()
                                end)
                            end
                        elseif loops == 2 then
                            if ref.loops2 <= 38 and ref.loops2 > 0 then
                                anim:set_playback(Playback.Loop)
                                ref.loops2 = ref.loops2 - 1
                                --print("loops2="..ref.loops2)
                            else
                                anim:set_state("END")
                                anim:refresh(ref.hakushaku:sprite())
                                anim:on_complete(function()
                                    ref.hakushaku:erase()
                                    step1:complete_step()
                                end)
                            end
                        elseif loops == 1 then
                            if ref.loops1 <= 34 and ref.loops1 > 0 then
                                anim:set_playback(Playback.Loop)
                                ref.loops1 = ref.loops1 - 1
                                --print("loops1="..ref.loops1)
                            else
                                anim:set_state("END")
                                anim:refresh(ref.hakushaku:sprite())
                                anim:on_complete(function()
                                    ref.hakushaku:erase()
                                    step1:complete_step()
                                end)
                            end
                        else
                            if ref.loops0 <= 30 and ref.loops0 > 0 then
                                anim:set_playback(Playback.Loop)
                                ref.loops0 = ref.loops0 - 1
                                --print("loops0="..ref.loops0)
                            else
                                anim:set_state("END")
                                anim:refresh(ref.hakushaku:sprite())
                                anim:on_complete(function()
                                    ref.hakushaku:erase()
                                    step1:complete_step()
                                end)
                            end
                        end
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_bloodrain(field, team, direction, user, props)
    local fx = Battle.Artifact.new()
    fx:set_facing(direction)
    local tile = nil
    if direction == Direction.Right then
        tile = field:tile_at(6,4)
    else
        tile = field:tile_at(1,4)
    end
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-9)
    fx_sprite:set_texture(BLOODRAIN_TEXTURE, true)
    local fx_anim = fx:get_animation()
    fx_anim:load(BLOODRAIN_ANIMPATH)
    fx_anim:set_state("0")
    fx_anim:refresh(fx_sprite)
    fx_anim:on_frame(2, function()
        if direction == Direction.Right then
            print("BloodRain attack range: from ("..tile:get_tile(Direction.UpLeft, 2):get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.UpLeft, 2):get_tile(Direction.Up, 1):x()..") to ("..tile:get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.Up, 1):y()..")")
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Right, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.UpRight, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Up, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.UpLeft, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Left, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.DownLeft, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Down, 1), 0)
        else
            print("BloodRain attack range: from ("..tile:get_tile(Direction.UpRight, 2):get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.UpRight, 2):get_tile(Direction.Up, 1):x()..") to ("..tile:get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.Up, 1):y()..")")
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Left, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.UpLeft, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Up, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.UpRight, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Right, 1), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.DownRight, 0), 0)
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Down, 1), 0)
        end
    end)
    for i = 1, 4, 1 do
        fx_anim:on_frame(12*i, function()
            if direction == Direction.Right then
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Right, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.UpRight, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Up, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.UpLeft, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Left, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.DownLeft, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpLeft, 1):get_tile(Direction.Down, 1), i)
            else
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Left, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.UpLeft, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Up, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.UpRight, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Right, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.DownRight, 1), i)
                create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1):get_tile(Direction.UpRight, 1):get_tile(Direction.Down, 1), i)
            end
        end)
    end
    for i = 1, 5, 1 do
        fx_anim:on_frame(1+15*i, function()
            Engine.play_audio(BLOODRAIN_AUDIO, AudioPriority.Highest)
        end)
    end
    fx_anim:on_complete(function() fx:erase() end)
    field:spawn(fx, tile)

    return fx
end

function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function create_bloodlance(user, props, team, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Shake, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
    spell.attacking = false
    local sprite = spell:sprite()
    sprite:set_texture(BLOODLANCE_TEXTURE, true)
    sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(BLOODLANCE_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if anim:get_state() == "0" then
            anim:on_frame(3, function()
                self.attacking = true
            end)
            anim:on_frame(6, function()
                self.attacking = false
            end)
        end
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self)
        Engine.play_audio(Engine.load_audio(_modpath.."hitsound0.ogg"), AudioPriority.Highest)
    end

    Engine.play_audio(BLOODLANCE_AUDIO, AudioPriority.Highest)

    field:spawn(spell, tile)

    print("BloodLance attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_attack(user, props, team, field, tile, number)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact | Hit.Shake,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(Engine.load_audio(_modpath.."hitsound"..number..".ogg"), AudioPriority.High)
    end

    field:spawn(spell, tile)

    --print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end