function package_init(package) 
    package:declare_package_id("com.alrysc.card.Pawn")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'B', 'E', 'N', 'R', 'Y'})
  
    local props = package:get_card_props()
    props.shortname = "Pawn"
    props.damage = 90
    props.time_freeze = true
    props.element = Element.None
    props.card_class = CardClass.Standard
    props.description = "Attack by pressing A Button"
    props.limit = 2

end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "")
    action:set_lockout(make_sequence_lockout())
    local field = user:get_field()
    print("This is when the card is called")

    local function spawn_pawn(user, props)
        local spawn_tile = user:get_current_tile():get_tile(user:get_facing(), 1)
        local pawn = Battle.Obstacle.new(user:get_team())
        local spawn_graphic = graphic_init("spell", 0, -30, "move.png", "move.animation", -2, "1", user, user:get_facing())
        
		pawn:set_facing(user:get_facing())
        pawn:set_name("Pawn") -- Needed this for the query. Hope it doesn't become a problem for anything later
		pawn:set_texture(Engine.load_texture(_modpath.."pawn.png"), true)
		local pawn_anim = pawn:get_animation()
		pawn_anim:load(_modpath.."pawn.animation")
		pawn_anim:set_state("0")
		pawn_anim:refresh(pawn:sprite())
		pawn_anim:on_complete(function()
			pawn_anim:set_state("0")
			pawn_anim:refresh(pawn:sprite())
			pawn_anim:set_playback(Playback.Loop)
		end)
		pawn:sprite():set_layer(-2)
		pawn:set_health(1)

        pawn.slash_sfx = Engine.load_audio(_modpath.."sfx.ogg")
        pawn.tink = Engine.load_audio(_modpath.."tink.ogg")
        pawn.hit_sfx = Engine.load_audio(_modpath.."hit.ogg")

        pawn.lifetime = 1200
        pawn.fadetime = 180

        pawn.attack_delay = 5
        pawn.wait_delay = 0
        pawn.attack_queued = false
        pawn.props = props
        pawn.context = user:get_context()

        -- Taken from RockCube. Since it checks for names, it will still spawn if the entity does not have one. Maybe that's bad
		local query = function(ent)
		--	if ent == pawn then
			--	return false
			--else
			return ent and not ent:is_deleted() and #ent:get_name() > 0
			--end
		end
		pawn.can_move_to_func = function(tile)
			if not tile then
				return false
			end
			if not tile:is_walkable() or tile:is_edge() or #tile:find_entities(query) > 0 then
				return false
			end
			return true
		end

        local pawn_defense = Battle.DefenseRule.new(1, DefenseOrder.Always)
        pawn_defense.can_block_func = function(judge, attacker, defender)
            print("Pawn defense")
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then
                -- Hit by breaking
                if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then 
                    local explosion = graphic_init("artifact", 0, 0, "explosion.png", "explosion.animation", -2, "0", user, user:get_facing())
                    Engine.play_audio(Engine.load_audio(_modpath.."break.ogg"), AudioPriority.Low)
                    explosion:get_animation():on_complete(function()
                        explosion:delete()
                    end)
                    field:spawn(explosion, pawn:get_current_tile())
                    return 
                end
                judge:block_damage()
                Engine.play_audio(pawn.tink, AudioPriority.Low)
                local guard_effect = graphic_init("artifact", 0, -30, "guard_hit.png", "guard_hit.animation", -2, "DEFAULT", user, user:get_facing())
                guard_effect:get_animation():on_complete(function()
                    guard_effect:delete()
                end)
                user:get_field():spawn(guard_effect, pawn:get_current_tile())
            end

        end

        local function pawn_attack(user, props, context)
            pawn:get_animation():set_state("1")
            pawn:get_animation():on_complete(function()
                pawn:get_animation():set_state("2")
                pawn:get_animation():on_frame(1, function()
                    Engine.play_audio(pawn.slash_sfx, AudioPriority.Low)
                    local spell = graphic_init("spell", -16, 0, "spell_sword_slashes.png", "spell_sword_slashes.animation", -2, "LONG", user, pawn:get_facing())
                    local attacked = false
                    spell:set_hit_props(
                        HitProps.new(
                        props.damage,
                        Hit.Impact | Hit.Flinch | Hit.Flash,
                        props.element, -- I need to add secondary sword someday
                        context,
                        Drag.None
                        )
                    )

                    spell.update_func = function(self)
                        if not attacked then 
                            self:get_current_tile():attack_entities(self)
                            self:get_current_tile():get_tile(self:get_facing(), 1):attack_entities(self)
                            attacked = true
                        end

                    end

                    spell.attack_func = function()
                        Engine.play_audio(pawn.hit_sfx, AudioPriority.Low)

                    end

                    spell:get_animation():on_complete(function()
                        spell:delete()
                    end)

                
                    field:spawn(spell, pawn:get_current_tile():get_tile(pawn:get_facing(), 1))
                end)
                pawn:get_animation():on_complete(function()
                    pawn:get_animation():set_state("0")
                end)
        
            end)

        end

        pawn.delete_func = function(self)
            self:erase()
            self.pawn_component:eject()
            self.handler:delete()
        end

        spawn_graphic:get_animation():on_complete(function()
            -- I stole this slightly from RockCube, but the == 0 thing was true even though the query found things.
            if not spawn_tile:find_entities(query)[1] and spawn_tile:is_walkable() and not spawn_tile:is_edge() then
                field:spawn(pawn, spawn_tile)
                -- The state I use here doesn't exist; just wanted an "empty" state
                pawn.handler = graphic_init("artifact", 0, 0, "pawn.png", "pawn.animation", -2, "-1", user, user:get_facing())
                pawn.handler.attack_delay = 0
                pawn.handler.update_func = function()
                    if pawn.attack_queued then 
                        pawn.handler.attack_delay = pawn.handler.attack_delay + 1
                        -- If this is true, we know that we entered time freeze before the attack came out. So I stop the attack
                        if pawn.handler.attack_delay > pawn.wait_delay then 
                            pawn.attack_queued = false
                        end
                    end
                end
                field:spawn(pawn.handler, spawn_tile)
            else
                local gone_graphic = graphic_init("spell", 0, -30, "move.png", "move.animation", -2, "0", user, user:get_facing())
                field:spawn(gone_graphic, spawn_tile)
                gone_graphic:get_animation():on_complete(function()
                    gone_graphic:delete()
                end)

                spawn_graphic:delete()

                return
            end
            pawn:add_defense_rule(pawn_defense)

            pawn.pawn_component = Battle.Component.new(user, Lifetimes.Battlestep)
            pawn.pawn_component.update_func = function(self, dt)
                pawn.lifetime = pawn.lifetime - 1
                if pawn.lifetime == 0 then 
                    pawn:delete()
                    local gone_graphic = graphic_init("spell", 0, -30, "move.png", "move.animation", -2, "0", user, pawn:get_facing())
                    field:spawn(gone_graphic, pawn:get_current_tile())
                    gone_graphic:get_animation():on_complete(function()
                        gone_graphic:delete()
                    end)
               --     pawn_component:eject()
                    return
                end

                -- Go transparent every other two frames
                if pawn.lifetime <= pawn.fadetime then 
                    if pawn.lifetime % 4 < 2 then 
                        pawn:hide()
                    else
                        pawn:reveal()
                    end
                end

                if user:input_has(Input.Pressed.Use) and pawn:get_animation():get_state() == "0" then 
                    pawn.attack_queued = true

                end

                -- Taking into account action delay
                if pawn.attack_queued then 
                    pawn.wait_delay = pawn.wait_delay + 1
                    if pawn.wait_delay == pawn.attack_delay then 
                        pawn_attack(user, pawn.props, pawn.context)
                        pawn.wait_delay = 0
                        pawn.attack_queued = false
                        
                    end
                else
                    pawn.wait_delay = 0
                    pawn.handler.attack_delay = 0
                end
            end

            user:register_component(pawn.pawn_component)
			spawn_graphic:delete()
		end)
        
        field:spawn(spawn_graphic, spawn_tile)

    end

    local step = Battle.Step.new()
    local count = 0
    step.update_func = function()
        count = count+1
        
        if count == 10 then 
            spawn_pawn(user, props)
            Engine.play_audio(Engine.load_audio(_modpath.."appear.ogg"), AudioPriority.Low)
        end

        if count == 45 then 
            step:complete_step()
        end
    end

    action.execute_func = function()
        action:add_step(step)
    end


    return action
end

-- Example use: local thing = graphic_init("artifact", 0, -30, "picture.png", "animation.animation", -2, "STATE", user, user:get_facing())
function graphic_init(type, x, y, texture, animation, layer, state, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type =="spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    graphic:get_animation():load(_folderpath..animation)

    graphic:get_animation():set_state(state)
    graphic:get_animation():refresh(graphic:sprite())

    return graphic
end