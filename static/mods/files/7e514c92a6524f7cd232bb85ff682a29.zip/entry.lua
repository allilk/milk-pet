local DAMAGE = 400

local TEXTURE_DARKLANCE = Engine.load_texture(_modpath.."darklance.png")
local TEXTURE_ATTACK = Engine.load_texture(_modpath.."attack.png")
local ANIMPATH_DARKLANCE = _modpath.."darklance.animation"
local ANIMPATH_ATTACK = _modpath.."attack.animation"
local AUDIO_SLASH = Engine.load_audio(_modpath.."slash.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-284-DarkLance")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"W"})

    local props = package:get_card_props()
    props.shortname = "DarkLanc"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "ATK ENMY FROM BEHIND"
    props.long_description = "HIT THE ENEMY FROM BEHIND WHILE IT IS FEELING SAFE"
    props.can_boost = true
	props.card_class = CardClass.Dark
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    --action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local lance1 = create_darklance_1(user, props)
        local lance2 = create_darklance_2(user, props)
        local lance3 = create_darklance_3(user, props)
        local team = actor:get_team()
        local field = actor:get_field()
		local lancefx1 = Battle.Artifact.new()
		lancefx1:set_facing(lance1:get_facing())
		local lanceanim1 = lancefx1:get_animation()
		lancefx1:set_texture(TEXTURE_DARKLANCE, true)
		lanceanim1:load(ANIMPATH_DARKLANCE)
		lanceanim1:set_state("DEFAULT")
        lanceanim1:on_frame(4,
            function()
                if team == 2 then
                    field:spawn(lance1, 6, 1)
                else
                    field:spawn(lance1, 1, 1)
                end
            end
        )
		lanceanim1:on_complete(
			function()
				lancefx1:erase()
			end
		)
        local lancefx2 = Battle.Artifact.new()
		lancefx2:set_facing(lance2:get_facing())
		local lanceanim2 = lancefx2:get_animation()
		lancefx2:set_texture(TEXTURE_DARKLANCE, true)
		lanceanim2:load(ANIMPATH_DARKLANCE)
		lanceanim2:set_state("DEFAULT")
        lanceanim2:on_frame(4,
            function()
                if team == 2 then
                    field:spawn(lance2, 6, 2)
                else
                    field:spawn(lance2, 1, 2)
                end
            end
        )
		lanceanim2:on_complete(
			function()
				lancefx2:erase()
			end
		)
        local lancefx3 = Battle.Artifact.new()
		lancefx3:set_facing(lance3:get_facing())
		local lanceanim3 = lancefx3:get_animation()
		lancefx3:set_texture(TEXTURE_DARKLANCE, true)
		lanceanim3:load(ANIMPATH_DARKLANCE)
		lanceanim3:set_state("DEFAULT")
        lanceanim3:on_frame(4,
            function()
                if team == 2 then
                    field:spawn(lance3, 6, 3)
                else
                    field:spawn(lance3, 1, 3)
                end
            end
        )
		lanceanim3:on_complete(
			function()
				lancefx3:erase()
			end
		)
		if team == 2 then
            field:spawn(lancefx1, 6, 1)
            field:spawn(lancefx2, 6, 2)
            field:spawn(lancefx3, 6, 3)
        else
            field:spawn(lancefx1, 1, 1)
            field:spawn(lancefx2, 1, 2)
            field:spawn(lancefx3, 1, 3)
        end
    end

    return action
end

function create_darklance_1(actor, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellanim = spell:get_animation()
    spellanim:load(ANIMPATH_ATTACK)
    spellanim:set_state("DEFAULT")
    local direction = actor:get_facing()
    local backdirection = nil
    if direction == Direction.Right then
        backdirection = Direction.Left
    else
        backdirection = Direction.Right
    end
    spell:highlight_tile(Highlight.Solid)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Flinch | Hit.Impact | Hit.Drag,
            props.element,
            actor:get_id(),
            Drag.new(backdirection, 1)
        )
    )

    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_current_tile():attack_entities(self)
        spellanim:on_complete(function()
            spell:erase()
        end)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(direction)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

	Engine.play_audio(AUDIO_SLASH, AudioPriority.High)

    return spell
end

function create_darklance_2(actor, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellanim = spell:get_animation()
    spellanim:load(ANIMPATH_ATTACK)
    spellanim:set_state("DEFAULT")
    local direction = actor:get_facing()
    local backdirection = nil
    if direction == Direction.Right then
        backdirection = Direction.Left
    else
        backdirection = Direction.Right
    end
    spell:highlight_tile(Highlight.Solid)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Flinch | Hit.Impact | Hit.Drag,
            props.element,
            actor:get_id(),
            Drag.new(backdirection, 1)
        )
    )

    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_current_tile():attack_entities(self)
        spellanim:on_complete(function()
            spell:erase()
        end)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(direction)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

	Engine.play_audio(AUDIO_SLASH, AudioPriority.High)

    return spell
end

function create_darklance_3(actor, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellanim = spell:get_animation()
    spellanim:load(ANIMPATH_ATTACK)
    spellanim:set_state("DEFAULT")
    local direction = actor:get_facing()
    local backdirection = nil
    if direction == Direction.Right then
        backdirection = Direction.Left
    else
        backdirection = Direction.Right
    end
    spell:highlight_tile(Highlight.Solid)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Flinch | Hit.Impact | Hit.Drag,
            props.element,
            actor:get_id(),
            Drag.new(backdirection, 1)
        )
    )

    spell.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_current_tile():attack_entities(self)
        spellanim:on_complete(function()
            spell:erase()
        end)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(direction)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

	Engine.play_audio(AUDIO_SLASH, AudioPriority.High)

    return spell
end