nonce = function() end

local BARRIER100_TEXTURE = Engine.load_texture(_modpath.."regenbarrier.png") 
local BARRIER100_ANIMATION_PATH = _modpath.."PrimaryAttack.animation" 
local BARRIER_UP_SOUND = Engine.load_audio(_modpath.."Barrier.ogg") -- Normalized -0.1

function package_init(package)
    package:declare_package_id("rune.legacy.blakbarr")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"A"})
 
    local props = package:get_card_props()
    props.shortname = "BlakBarr"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "A dark barrier respawns"
    props.card_class = CardClass.Giga
    props.limit = 1
end

function card_create_action(user, props)
    local PRESTEP = {1, 0.05} --Frame 1 of a player Idle animation for half of half a second.
    local END = {1, 0.5} --Frame 1 of a player Idle animation for a half-second.
    local FRAMES = make_frame_data({PRESTEP, END})
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_animation_lockout()) --Lockout player input until the action's animation is finished.
    action:override_animation_frames(FRAMES) --Override animation of the action. Combines with lockout listed above to prevent player input for extended periods.
	action:add_anim_action(2, function()
		Engine.play_audio(BARRIER_UP_SOUND, AudioPriority.High)
		create_barrier(user, action)
	end)
    return action
end

function create_barrier(user, act)
    local offsetY = -2*(user:get_height()-48) -- MegaMan is 48 and I built around that, so I'm just offsetting for different heights by a bit
    if offsetY > 0 then offsetY = 0 end
    local fading = false
    local isWind = false
	local remove_barrier = false

    local barrier = user:create_node()
    local HP = 150
    barrier:set_layer(3)
    barrier:set_texture(BARRIER100_TEXTURE, false)
	local barrier_animation = Engine.Animation.new(BARRIER100_ANIMATION_PATH)
    barrier_animation:set_state("BARRIER IDLE")
    barrier_animation:refresh(barrier)
    if offsetY < 0 then
		barrier:set_offset(0, offsetY+(user:get_height()-barrier_animation:point("origin").y))
	end
    barrier_animation:set_playback(Playback.Loop)

    local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly) -- Keristero's Guard is 0
	local barrier_heal_ratelimit = 60

	barrier_defense_rule.do_once = true
    barrier_defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
		if HP > 0 then
			if attacker_hit_props.element == Element.Wind then
				print("wind attack found")
				isWind = true
				judge:block_damage()
			else
				if attacker_hit_props.flags & Hit.Impact == Hit.Impact then
					HP = HP - attacker_hit_props.damage
					barrier_heal_ratelimit = 60
					judge:block_damage()
				end
			end
		end
    end
	
	local barrier_heal_component = Battle.Component.new(user, Lifetimes.Battlestep)
	barrier_heal_component.update_func = function(self, dt)
		if barrier_heal_ratelimit <= 0 and HP <= 0 and not isWind then
			barrier:show()
			barrier_animation:set_state("BARRIER IDLE")
			barrier_animation:set_playback(Playback.Loop)
			Engine.play_audio(BARRIER_UP_SOUND, AudioPriority.High)
			HP = 150
		else
			barrier_heal_ratelimit = barrier_heal_ratelimit - 1
		end
	end
	
    local aura_animate_component = Battle.Component.new(user, Lifetimes.Scene)
	
	aura_animate_component.update_func = function(self, dt)
		if HP <= 0 then
			barrier:hide()
		end
		barrier_animation:update(dt, barrier)
	end
	
	local aura_destroy_component = Battle.Component.new(user, Lifetimes.Scene)
	local destroy_aura = false
	aura_destroy_component.update_func = function(self, dt)
		local user = self:get_owner()
		if isWind and not fading then
            remove_barrier = true
        end
		
		if destroy_aura and not fading then
			remove_barrier = true
		end
		
        if HP <= 0 and not fading then
            remove_barrier = true
        end
        
        if barrier_defense_rule:is_replaced() then
			user:sprite():remove_node(barrier)
			user:remove_defense_rule(barrier_defense_rule)
			aura_destroy_component:eject()
			barrier_heal_component:eject()
			aura_animate_component:eject()
        end
		
		if remove_barrier and not fading then
			fading = true

			if isWind then
				user:sprite():remove_node(barrier)
				user:remove_defense_rule(barrier_defense_rule)
				aura_destroy_component:eject()
				barrier_heal_component:eject()
				aura_animate_component:eject()
				isWind = false
			end
		end
	end
	act.battle_end_func = function(self)
		user:remove_defense_rule(barrier_defense_rule)
		aura_destroy_component:eject()
	end
    user:add_defense_rule(barrier_defense_rule)
	user:register_component(barrier_heal_component)
	user:register_component(aura_destroy_component)
	user:register_component(aura_animate_component)
end