local DAMAGE = 120

local TEXTURE_PROTOMAN = Engine.load_texture(_modpath .. "protoman.png")
local ANIMPATH_PROTOMAN = _modpath .. "protoman.animation"

local TEXTURE_SLASH = Engine.load_texture(_modpath .. "spell_sword_slashes.png")
local ANIMPATH_SLASH = _modpath .. "spell_sword_slashes.animation"

local AUDIO_SLASH = Engine.load_audio(_modpath .. "slash.ogg")
local AUDIO_NAVI = Engine.load_audio(_modpath .. "navispawn.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.protomanv1")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "B", "*" })

    local props = package:get_card_props()
    props.shortname = "ProtoMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Sword
    props.description = "Move in and slice the enemy "
    props.long_description = "Move in and slice the enemy"
    props.can_boost = true
    props.card_class = CardClass.Mega
    props.limit = 1
end

--returns the panels which protoman will warp to.
function find_warp_panels(protoman)
    local field = protoman:get_field()
    local team = protoman:get_team()
    local result = {}
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team and other_character:get_health() > 0
    end)
    --Sonic will appear in front of enemys so reverse the tile
    local reverse_dir = Direction.reverse(protoman:get_facing())
    for key, value in pairs(target_list) do

        local tile = value:get_tile(reverse_dir, 1)
        local query = function(other_character)
            return true

        end
        if tile == protoman:get_tile() or
            (tile:is_walkable() and #tile:find_characters(query) == 0 and #tile:find_obstacles(query) == 0) then
            table.insert(result, tile)
        end

    end
    return result
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        local actor = self:get_actor()
        actor:hide()
        local self_tile = user:get_tile()
        local self_Y = self_tile:y()
        local step1 = Battle.Step.new()
        local field = actor:get_field()

        self.navi = nil
        self.tile = user:get_current_tile()
        local ref = self
        local frames = 0
        local do_once = true
        --finds protomans next warps
        local warp_panels = find_warp_panels(actor)
        --stores what attack protoman is on
        local warp_index = 1
        local state = "default"
        step1.update_func = function(self, dt)
            if (do_once) then
                ---create the navi artifact..
                ---@type Entity
                ref.navi = Battle.Artifact.new()
                ref.navi:set_float_shoe(true)
                ref.navi:set_facing(user:get_facing())
                ref.navi:set_texture(TEXTURE_PROTOMAN, true)
                ref.navi:sprite():set_layer(-1)
                navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_PROTOMAN)
                navi_anim:set_state("SPAWN_IN")
                navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                end)

                navi_anim:on_complete(function()
                    navi_anim:set_state("WARP_OUT")
                    navi_anim:refresh(ref.navi:sprite())
                    state = "attacking"
                    frames = 0
                end)
                do_once = false
                ref.navi.can_move_to_func = function()
                    return true
                end
                field:spawn(ref.navi, ref.tile)
            end
            --states
            if (state == "attacking") then
                if (frames == 1) then
                    if (warp_index <= #warp_panels) then
                        ref.navi:teleport(warp_panels[warp_index], ActionOrder.Involuntary, nil)
                    else
                        state = "end"
                    end
                elseif (frames == 4) then
                    navi_anim:set_state("SLASH")
                elseif (frames == 11) then
                    local slash = create_slash(ref.navi, field)
                elseif (frames == 24) then
                    navi_anim:set_state("WARP_OUT")
                elseif (frames == 28) then
                    navi_anim:set_state("WARP_IN")
                    warp_index = warp_index + 1
                    frames = 0
                end
            end
            if (state == "end") then
                ref.navi:erase()
                step1:complete_step()
            end
            frames = frames + 1
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        actor:reveal()
    end
    return action
end

function spawn_wide_hitbox(field, spell, desired_tile)
    local hitbox = Battle.Spell.new(spell:get_team())
    hitbox:set_hit_props(spell:copy_hit_props())
    field:spawn(hitbox, desired_tile)
    return hitbox
end

function create_slash(user, field)
    Engine.play_audio(AUDIO_SLASH, AudioPriority.Highest)
    local spell = Battle.Spell.new(user:get_team())
    local direction = user:get_facing()

    local spell_animation = spell:get_animation()
    spell.frames = 0
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            Element.Sword,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    spell_animation:load(ANIMPATH_SLASH)
    spell_animation:set_state("WIDE")
    spell:set_texture(TEXTURE_SLASH)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    spell_animation:on_complete(function()
        spell:erase()
    end)
    field:spawn(spell, user:get_tile(user:get_facing(), 1))
    local hitbox1 = spawn_wide_hitbox(field, spell, spell:get_tile(Direction.Up, 1))
    local hitbox2 = spawn_wide_hitbox(field, spell, spell:get_tile(Direction.Down, 1))

    spell.update_func = function(self, dt)
        spell.frames = spell.frames + 1
        self:get_current_tile():attack_entities(self)
        hitbox1:get_current_tile():attack_entities(hitbox1)
        hitbox2:get_current_tile():attack_entities(hitbox2)
        if (spell.frames > 60) then
            spell:erase()
        end
    end



    spell.collision_func = function(self, other)
    end

    spell.can_move_to_func = function(self, other)
        return true
    end

    spell.battle_end_func = function(self)
        spell:erase()
    end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end


end
