
local HUB_TEXTURE = Engine.load_texture(_modpath .. "animation.png")
local HUB_ANIMATION_PATH = _modpath .. "hubbatch.animation"
local HUBSOUND = Engine.load_audio(_modpath .. "hub.ogg")

local shield_texture = Engine.load_texture(_modpath .. "guard_attachment.png")
local shield_sfx = Engine.load_audio(_modpath .. "shield.ogg")
local sheild_animation_path = (_modpath.. "guard_attachment.animation")


function package_init(package)
    package:declare_package_id("com.isabelle.card.re.hubbatch")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'J' })

    local props = package:get_card_props()
    props.shortname = "Hub Batch"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Blend Hub DNA Data w/MegaMan"
    props.limit = 1
    props.can_boost = false
    props.card_class = CardClass.Giga

end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")

    local artifact = Battle.Artifact.new()
    artifact:sprite():set_layer(-2)
    artifact:set_facing(user:get_facing())
    artifact:set_texture(HUB_TEXTURE, true)
    artifact:set_offset(0, -50)
    artifact:get_animation():load(HUB_ANIMATION_PATH)
    artifact:get_animation():set_state("DEFAULT")

    artifact:get_animation():refresh(artifact:sprite())

    artifact:get_animation():on_complete(function()
        artifact:delete()

    end)

    action.execute_func = function()
        Engine.play_audio(HUBSOUND, AudioPriority.High)
        user:get_field():spawn(artifact, user:get_current_tile())

        local player = Battle.Player.from(user)

        if player then
            modify(player)

        end

    end

    return action

end

local recipes = { { name = "activate", pattern = { "b" }, { "left" } } } -- Can probably get rid of all this stuff

local function deep_clone(t)
    if type(t) ~= "table" then
        return t
    end

    local o = {}
    for k, v in pairs(t) do
        o[k] = deep_clone(v)
    end
    return o
end

local function contains(t, value)
    for k, v in ipairs(t) do
        if v == value then
            return true
        end
    end
    return false
end

local function get_first_completed_recipe(matching)
    for _, recipe in ipairs(matching) do
        if recipe.current_step > #recipe.pattern then
            return recipe.name
        end
    end

    return nil
end

function shield_create_action(actor)

    print("In shield")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")

    action:set_lockout(make_animation_lockout())
    local GUARDING = { 1, 1.024 }
    local POST_GUARD = { 1, 0.224 }
    local FRAMES = make_frame_data({ GUARDING, POST_GUARD })
    action:override_animation_frames(FRAMES)



    action.execute_func = function(self)
        local guarding = false
        local guard_attachment = self:add_attachment("BUSTER")
        local guard_sprite = guard_attachment:sprite()
        guard_sprite:set_texture(shield_texture)
        guard_sprite:set_layer(-2)

        local guard_animation = guard_attachment:get_animation()
        guard_animation:load(sheild_animation_path)
        guard_animation:set_state("GUARD3")

        local guarding_defense_rule = Battle.DefenseRule.new(464186341,DefenseOrder.Always)



        self:add_anim_action(1, function()
            guarding = true
            Engine.play_audio(shield_sfx, AudioPriority.Highest)
        end)
        self:add_anim_action(2, function()
            guard_animation:set_state("FADE")
            guarding = false
            actor:remove_defense_rule(guarding_defense_rule)
        end)

        guarding_defense_rule.can_block_func = function(judge, attacker, defender)
            if not guarding then
                return
            end
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then
                if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                    --cant block breaking hits with guard
                    return
                end
                judge:block_impact()
                judge:block_damage()
                local reflected_damage = 50
                local direction = actor:get_facing()
                -- This might be needed. I commented out those other parts because they're for a reflect. If you want to reflect, you need to make a few changes to that, though
                if not guarding_defense_rule.has_reflected then
                    --       battle_helpers.spawn_visual_artifact(actor,actor:get_current_tile(),guard_hit_effect_texture,guard_hit_effect_animation_path,"DEFAULT",0,-30)
                    --     spawn_shockwave(actor, actor:get_team(),actor:get_field(),actor:get_tile(direction, 1), direction,reflected_damage, wave_texture,wave_sfx,0.2)
                    guarding_defense_rule.has_reflected = true
                end
            end
        end
        print("Added defense rule")
        actor:add_defense_rule(guarding_defense_rule)
    end

    actor:card_action_event(action, ActionOrder.Immediate)

end

function modify(player)

    player:set_air_shoe(true)
    player:set_float_shoe(true)
    player:set_attack_level(5)
    player:set_charge_level(5)
    --player:set_chip_select(8) uh once like cust+ actually matters i guess

    local hit = false;
    local undershirt = Battle.DefenseRule.new(61044, DefenseOrder.CollisionOnly)
    local damage
    local component = Battle.Component.new(player, Lifetimes.Scene)
    local prevHP = player:get_health()
    local shield_component = Battle.Component.new(player, Lifetimes.Battlestep)

    undershirt.can_block_func = function(judge, attacker, defender)
        damage = attacker:copy_hit_props().damage

        if prevHP > 1 and (player:get_health() - damage) <= 0 then
            player:mod_max_health(damage)
            hit = true
        end


    end

    function create_idle_action(actor)
        local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
        action:set_lockout(make_sequence_lockout())

        -- I have no idea what the window here is, but seems easy. Maybe easier than BN6
        action.execute_func = function()
            if actor:input_has(Input.Pressed.Left) or actor:input_has(Input.Held.Left) then
                shield_create_action(actor)
            end

        end

        actor:card_action_event(action, ActionOrder.Immediate)

    end

    component.update_func = function()
        if hit then
            player:mod_max_health(damage * -1)
            player:set_health(1)
            hit = false

        end
        prevHP = player:get_health()

    end

    local back_direction = nil
    local back_input
    shield_component.update_func = function()
        back_direction = Direction.reverse(player:get_facing())
        if player:input_has(Input.Pressed.Shoot) then
            create_idle_action(player)

        end

    end

    player:register_component(component)
    player:add_defense_rule(undershirt)
    player:register_component(shield_component)

end



