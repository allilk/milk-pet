local card = {}



card.card_create_action = function(player, props)
    local leo_buster_texture = Engine.load_texture(_folderpath.."LeoBurner.png")
    local leo_buster_animation_path = _folderpath.."LeoBurner.animation"
    local frame1 = {1, 0.033}
    local frame2 = {2, 0.033}
    local frame3 = {3, 0.05}
    local frame4 = {4, 0.05}
    local frames = make_frame_data(
        {
            frame1,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2
        }
    )
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    action:override_animation_frames(frames)
    action:set_lockout(make_animation_lockout())
    local audio = Engine.load_audio(_folderpath.."firearm.ogg")
    action.execute_func = function(self, user)
        self.spell_table = {}
        self.tile_table = {}
        local tile = user:get_tile()
        for x = 1, 6, 1 do
            local check_tile = tile:get_tile(user:get_facing(), x)
            if check_tile and not check_tile:is_edge() then table.insert(self.tile_table, check_tile) end
        end

        local field = player:get_field()
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(leo_buster_texture)
        buster_sprite:set_layer(-2)
        local buster_anim = buster:get_animation()
        buster_anim:load(leo_buster_animation_path)
        buster_anim:set_state("BUSTER")
        self:add_anim_action(4, function()
            for i = 1, #self.tile_table, 1 do
                local spell = create_leoburner(player, props, audio, leo_buster_animation_path, leo_buster_texture)
                table.insert(self.spell_table, spell)
                field:spawn(spell, self.tile_table[i])
            end
        end)
    end
    action.action_end_func = function(self)
        for i = 1, #self.spell_table, 1 do
            if not self.spell_table[i]:is_deleted() then self.spell_table[i]:erase() end
        end
    end
    return action
end

function create_leoburner(player, props, audio, leo_buster_animation_path, leo_buster_texture)
	local spell = Battle.Spell.new(player:get_team())
	spell:set_texture(leo_buster_texture)
	local direction = player:get_facing()
	spell:set_facing(direction)
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Fire,
			nil,
			Drag.None
))
	local sprite = spell:sprite()
	sprite:set_layer(-2)
	local animation = spell:get_animation()
	animation:load(leo_buster_animation_path)
	animation:set_state("FLAME")
	animation:refresh(sprite)
	spell:set_offset(-8, -54)
	animation:set_playback(Playback.Loop)
    spell.cooldown = 0
	spell.update_func = function(self, dt)
		self:get_tile():attack_entities(self)
        if self.cooldown <= 0 then
            Engine.play_audio(audio, AudioPriority.Low)
            self.cooldown = 12
        else
            self.cooldown = self.cooldown - 1
        end
	end
	return spell
end

return card