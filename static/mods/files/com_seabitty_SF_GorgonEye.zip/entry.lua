local DAMAGE = 450

local TEXTURE_OPHUICA = Engine.load_texture(_modpath.."ophuica.png")
local TEXTURE_GEYE = Engine.load_texture(_modpath.."geye.png")
local ANIMPATH_OPHUICA = _modpath.."ophuica.animation"
local ANIMPATH_GEYE = _modpath.."geye.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_INPUT = Engine.load_audio(_modpath.."input.ogg")
local AUDIO_GEYE = Engine.load_audio(_modpath.."GorgonEye.ogg")

local TEXTURE_ATTACK = Engine.load_texture(_modpath.."attack.png")
local ANIMPATH_ATTACK = _modpath.."attack.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"

function package_init(package)
    package:declare_package_id("com.seabitty.sfgorgoneye")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"O"})

    local props = package:get_card_props()
    props.shortname = "GorgnEye"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Shoot para laser."
    props.long_description = "Shoot a paralysing laser beam down a column."
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local input_1 = false
        local input_success = false
        local success_played = false

        local VOICEACTING = false

        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

		local step1 = Battle.Step.new()
        local step2 = Battle.Step.new()

        self.fireman = nil
        self.tile    = user:get_current_tile()

        local ref = self

        local remaining_time = 0

        local input_once = true
        local do_once = true
        local do_once_part_two = true
        local do_once_part_three = true
        step1.update_func = function(self, dt)
            remaining_time = remaining_time - 1
            if remaining_time > 0 and remaining_time < 20 then
                --print("read")
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
                if user:input_has(Input.Pressed.Down) and not input_1 then
                    --print("PRESSED")
                    input_1 = true
                end
                if user:input_has(Input.Pressed.Right) and input_1 then
                    --print("PRESSED")
                    input_success = true
                end
                if input_success then
                    if not success_played then
                        success_played = true
                    end
                end
            end
            if remaining_time <= 1 then
                --print("read_input: OFF")
                step1:complete_step()
            end
            if do_once then
                do_once = false
                ref.fireman = Battle.Artifact.new()
                ref.fireman:set_facing(direction)
		    	ref.fireman:set_texture(TEXTURE_OPHUICA, true)
		    	ref.fireman:sprite():set_layer(-1)

                Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)

                fire_anim = ref.fireman:get_animation()
                fire_anim:load(ANIMPATH_OPHUICA)
                fire_anim:set_state("SPAWN")
		    	fire_anim:refresh(ref.fireman:sprite())
                fire_anim:on_complete(function()
                    fire_anim:set_state("MID")
                    fire_anim:refresh(ref.fireman:sprite())
		    	end)
                field:spawn(ref.fireman, ref.tile)
            end
        end
        self:add_step(step1)

        step2.update_func = function(self, dt)
            local anim = ref.fireman:get_animation()
            if anim:get_state() == "MID" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_complete(function()
                        anim:set_state("ATTACK")
		    		    anim:refresh(ref.fireman:sprite())
                    end)
                end
            end
            if anim:get_state() == "ATTACK" then
                if do_once_part_three then
                    do_once_part_three = false
                    local firearm1 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm2 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm3 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm4 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm5 = create_firearm(user, ANIMPATH_ATTACK, props)

                    local firefx1 = Battle.Artifact.new()
				    firefx1:set_facing(direction)
                    firefx1:set_texture(TEXTURE_GEYE, true)
				    local fx1_anim = firefx1:get_animation()
				    fx1_anim:load(ANIMPATH_GEYE)
				    fx1_anim:set_state("0")
                    fx1_anim:on_complete(function()
                        firefx1:erase()
                    end)

                    anim:on_frame(10, function()
                        print("GorgonEye!")
                        
                        if input_success then
                            field:spawn(firearm1, user:get_tile(direction, 1))
                        else
                            field:spawn(firearm1, user:get_tile(direction, 1))
                        end
                    end)
                    anim:on_frame(10, function()
                        
                        if input_success then
                            field:spawn(firearm2, user:get_tile(direction, 2))
                        else
                            field:spawn(firearm2, user:get_tile(direction, 2))
                        end
                    end)
                    anim:on_frame(10, function()
                   
                        if input_success then
                            field:spawn(firearm3, user:get_tile(direction, 3))
                        else
                            field:spawn(firearm3, user:get_tile(direction, 3))
                        end
                    end)
                    anim:on_frame(10, function()
                        Engine.play_audio(AUDIO_GEYE, AudioPriority.High)
                        field:spawn(firefx1, user:get_tile(direction, 1))
                        if input_success then
                            field:spawn(firearm4, user:get_tile(direction, 4))
                        else
                            field:spawn(firearm4, user:get_tile(direction, 4))
                        end
                    end)
                    anim:on_frame(13, function()
                
                        if input_success then
                            field:spawn(firearm5, user:get_tile(direction, 5))
                        else
                            field:spawn(firearm5, user:get_tile(direction, 5))
                        end
                    end)
                    anim:on_complete(function()
                        ref.fireman:erase()
                        step2:complete_step()
                    end)
                end
            end
        end
        self:add_step(step2)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_firearm(actor, animpath, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    spell:get_facing(direction)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Impact | Hit.Stun | Hit.Pierce | Hit.Flinch,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(animpath)
    anim:set_state("0")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

    return spell
end