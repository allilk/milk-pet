function package_init(package)
    package:declare_package_id("com.Dawn.Wandering.Shiren")
    package:set_special_description("Eternal Wanderer...")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(20)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
end

function player_init(player)
	player:set_name("Shiren")
	player:set_health(1000)
	player:set_element(Element.Summon)
    player:set_height(40.0)
    player:set_animation(_modpath.."battle.animation")
    player:set_texture(Engine.load_texture(_modpath.."battle.png"), false)
	local base_charge_color = Color.new(200, 200, 200, 255)
	player:set_fully_charged_color(base_charge_color)
	player:set_charge_position(0, -20)
    local arrow_regen_timer = 120
    local current_regen_timer = 0
    local special_regen_timer = 240
    local current_special_regen_timer = 0
    local arrows = 24
    local can_use_special = true
    player.update_func = function(self, dt)
        if not can_use_special then
            if current_special_regen_timer < special_regen_timer then current_special_regen_timer = current_special_regen_timer + 1 else can_use_special = true end 
        end
		if current_regen_timer >= arrow_regen_timer then
            arrows = arrows + 1
            if arrows > 24 then arrows = 24 end
            current_regen_timer = current_regen_timer - 40
        else
            current_regen_timer = current_regen_timer + 1
        end
    end
	player.normal_attack_func = function(player)
        current_regen_timer = 0
		local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
        action.execute_func = function(self, user)
            if arrows > 1 then
                arrows = arrows - 1
                self:add_anim_action(1, function()
                    Engine.play_audio(AudioType.BusterPea, AudioPriority.High)
                    local props = HitProps.new(
                        player:get_attack_level() * 3,
                        Hit.Impact | Hit.Flash | Hit.Pierce,
                        Element.None,
                        user:get_context(),
                        Drag.None
                    )
                    local t1 = player:get_tile(player:get_facing(), 1)
                    local arrow = create_arrow(player, props)
                    player:get_field():spawn(arrow, t1)
                end)
            else
                Engine.play_audio(AudioType.ChipError, AudioPriority.High)
            end
        end
        return action
	end
	
	player.charged_attack_func = function(player)
		local action = Battle.CardAction.new(player, "PLAYER_SWORD")
        local tile = player:get_tile(player:get_facing(), 1)
        local up_tile = tile:get_tile(Direction.Up, 1)
        local down_tile = tile:get_tile(Direction.Down, 1)
        action.execute_func = function(self, user)
            local props = HitProps.new(
                (player:get_attack_level()*20) - 10,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Sword,
                user:get_context(),
                Drag.new(user:get_facing(), 1)
            )
            local slash1 = create_slash(user, props)
            local slash2 = create_slash(user, props)
            local slash3 = create_slash(user, props)
            self:add_anim_action(1, function()
                tile:highlight(Highlight.Flash)
                if up_tile and not up_tile:is_edge() then
                    up_tile:highlight(Highlight.Flash)
                end
                if down_tile and not down_tile:is_edge() then
                    down_tile:highlight(Highlight.Flash)
                end
                user:toggle_counter(true)
            end)
            self:add_anim_action(3, function()
                Engine.play_audio(AudioType.SwordSwing, AudioPriority.High)
                user:get_field():spawn(slash1, tile)
                if up_tile and not up_tile:is_edge() then
                    user:get_field():spawn(slash2, up_tile)
                end
                if down_tile and not down_tile:is_edge() then
                    user:get_field():spawn(slash3, down_tile)
                end
            end)
            self:add_anim_action(5, function()
                tile:highlight(Highlight.None)
                up_tile:highlight(Highlight.None)
                down_tile:highlight(Highlight.None)
                if not slash1:is_deleted() then slash1:erase() end
                if not slash2:is_deleted() then slash2:erase() end
                if not slash3:is_deleted() then slash3:erase() end
                user:toggle_counter(false)
            end)
        end
        return action
	end

    player.special_attack_func = function(player)
        if can_use_special then
            local action = Battle.CardAction.new(player, "PLAYER_SWORD")
            local tile = player:get_tile(player:get_facing(), 1)
            action.execute_func = function(self, user)
                local props = HitProps.new(
                    player:get_attack_level()*5,
                    Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Drag,
                    Element.Sword,
                    user:get_context(),
                    Drag.new(user:get_facing(), 1)
                )
                local slash = create_slash(user, props)
                self:add_anim_action(1, function()
                    tile:highlight(Highlight.Flash)
                    user:toggle_counter(true)
                end)
                self:add_anim_action(3, function()
                    Engine.play_audio(AudioType.SwordSwing, AudioPriority.High)
                    user:get_field():spawn(slash, tile)
                end)
                self:add_anim_action(5, function()
                    if not slash:is_deleted() then
                        slash:erase()
                    end
                    user:toggle_counter(false)
                end)
                action.action_end_func = function(self)
                    can_use_special = false
                end
            end
            return action
        else
            return Battle.CardAction.new(player, "PLAYER_IDLE")
        end
    end

end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(props)

	spell.update_func = function(self, dt) 
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	return spell
end

function create_arrow(user, props)
    local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_offset(-30.0, -82.0)
	spell:set_texture(user:get_texture())
    spell:sprite():set_layer(-2)
    local anim = spell:get_animation()
    anim:copy_from(user:get_animation())
    anim:set_state("ARROW")
    anim:refresh(spell:sprite())
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(props)
    spell:set_offset(0.0, -30.0)
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
		if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    return spell
end