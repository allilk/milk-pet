
local TEXTURE = Engine.load_texture(_modpath.."willowisp.png")
local START_AUDIO = Engine.load_audio(_modpath.."wisp.ogg")
local END_AUDIO = Engine.load_audio (_modpath.."wisphit.ogg")
local ANIMATION_PATH = _modpath.."default.animation"
local HIT_ANIMATION_PATH = nil
local target_tile = nil
local ScriptedSpell = nil
local VERTICAL_OFFSET = -30

function package_init(package)
  package:declare_package_id("entropy.floodwisp")
  package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
  package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"C","R","S",})

  local props = package:get_card_props()
  props.shortname = "FloodWisp"
  props.damage = 10
  props.time_freeze = false
  props.element = Element.Aqua
  props.description = "3 Ghosts sht fwd and frz"
	props.limit = 2
end

function card_create_action(actor, props)
  local spell1 = Battle.Spell.new(actor:get_team())
  local spell2 = Battle.Spell.new(actor:get_team())
  local spell3 = Battle.Spell.new(actor:get_team())

  spell1:set_texture(TEXTURE, true)
  spell1:highlight_tile(Highlight.Solid)
  spell2:set_texture(TEXTURE, true)
  spell2:highlight_tile(Highlight.Solid)
  spell3:set_texture(TEXTURE, true)
  spell3:highlight_tile(Highlight.Solid)
  local anim1 = spell1:get_animation()
    anim1:load(ANIMATION_PATH)
    anim1:set_state("DEFAULT")
    anim1:set_playback(Playback.Loop)
    local anim2 = spell2:get_animation()
    anim2:load(ANIMATION_PATH)
    anim2:set_state("DEFAULT")
    anim2:set_playback(Playback.Loop)
    local anim3 = spell3:get_animation()
    anim3:load(ANIMATION_PATH)
    anim3:set_state("DEFAULT")
    anim3:set_playback(Playback.Loop)

  Engine.play_audio(START_AUDIO, AudioPriority.High)

  spell1:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Freeze| Hit.Impact,
      props.element,
      actor:get_context(),
      Drag.None
    )
  )
  spell2:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Freeze | Hit.Impact,
      props.element,
      actor:get_context(),
      Drag.None
    )
  )
  spell3:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Freeze | Hit.Impact,
      props.element,
      actor:get_context(),
      Drag.None
    )
  )
  local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
  -- action:set_lockout(make_async_lockout(0.67))
  -- action:override_animation_frames(FRAMES)

  

  local facing_direction = actor:get_facing()
  local field = actor:get_field()
  local spawn_tile = actor:get_tile(facing_direction, 1)
  spell1.slide_started = false
  spell2.slide_started = false
  spell3.slide_started = false
  field:spawn(spell1, spawn_tile:x(), 1)
  field:spawn(spell2, spawn_tile:x(), 2)
  field:spawn(spell3, spawn_tile:x(), 3)
  spell1.can_move_to_func =
    function ()
      return true
    end
  spell2.can_move_to_func =
    function ()
      return true
    end
  spell3.can_move_to_func =
    function ()
      return true
    end

  --This bit runs forever as long as the spell exists
  --spell == self? i think?


local my_update_func = function(self, dt)
  self.wait_frames = self.wait_frames - 1
   if self.wait_frames > 0 then return end
    self:get_current_tile():attack_entities(self)

    self:highlight_tile(Highlight.Flash)
    --If you've reached the edge and slide_started is true, kill the spell immediately
    --this should only ever happen if the spell's gone offscreen?
    local ref = self
    local dest = self:get_tile(facing_direction, 1)
    if self:is_sliding() == false then
      if self:get_current_tile():is_edge() and self.slide_started then
         self:delete()
      end


     self:slide(dest, frames(20), frames(0), ActionOrder.Voluntary,
       function()
        ref.slide_started = true

       end
      )

    end
  end
spell1.update_func = my_update_func
spell2.update_func = my_update_func
spell3.update_func = my_update_func
spell1.wait_frames = 30
spell2.wait_frames = 90
spell3.wait_frames = 150

action.execute_func = function()
  local buster = action:add_attachment("Buster")
  buster:sprite():set_texture(actor:get_texture(), true)
  buster:sprite():set_layer(-1)
  buster:sprite():enable_parent_shader(true)

  local buster_anim = buster:get_animation()
  buster_anim:copy_from(actor:get_animation())
  buster_anim:set_state("BUSTER")

  actor:get_animation():on_frame(1, function()
    execute(action, actor)
  end, false)
end
return action 
end 


