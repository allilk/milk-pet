function package_init(package)
    package:declare_package_id("com.player.D3str0y3d.DawnEd.ProgsBomber")
    package:set_special_description("Progsbomber")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."progsman_OW.animation")
    package:set_overworld_texture_path(_modpath.."progmanOW_needs_edits.png")
end

function player_init(player)
    local progsbomb = include("bomb/bomb.lua")
    player:set_name("Progsman")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(75.0)

    local base_charge_color = Color.new(255, 0, 255, 0)

    local base_animation_path = _modpath.."progsman.animation"
    local base_texture = Engine.load_texture(_modpath.."mob_progsman_atlas.png")


    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -20)

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        local props = Battle.CardProperties.new()
        props.damage = player:get_attack_level() * 10
        props.element = Element.None
        local action = progsbomb.card_create_action(player, props)
        player:card_action_event(action, ActionOrder.Involuntary)
    end

end
