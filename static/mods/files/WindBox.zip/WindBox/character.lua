local character_animation = _folderpath .. "battle.animation"
local anim_speed = 1
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local WINDGUST_TEXTURE = Engine.load_texture(_folderpath .. "windgust.png")
local WINDGUST_ANIMATION = _folderpath .. "windgust.animation"

local wind_sfx = Engine.load_audio(_folderpath .. "windy.ogg")

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta

    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:set_explosion_behavior(4, 1, false)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.damage = character_info.damage
    self.pull = character_info.pull
    self.animation:set_state("SPAWN")
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.started = false
    self.currentY = 1
    self.update_func = function()
        if not self.started then
            self.current_direction = self:get_facing()
            self.enemy_dir = self:get_facing()
            self.started = true
            self.animation:set_state("DEFAULT")
            self.animation:set_playback(Playback.Loop)
            Engine.play_audio(wind_sfx, AudioPriority.Highest)
        end
        if (self.frame_counter == 12) then
            spawn_wind_gust(self, self.currentY, self.damage, self.pull)
            self.currentY = self.currentY + 1

            if (self.currentY <= 0 or self.currentY >= 4) then
                self.currentY = 1;
            end
            self.frame_counter = 0
        end
        self.frame_counter = self.frame_counter + 1
    end
end

---Get the position to spawn a wind gust
---@param y_pos number y position this gust will spawn at
---@param user Entity caster of the spell
---@return Tile tile target tile to spawn the gust at.
function get_gust_pos(y_pos, user, pull_dir)
    local field = user:get_field()
    local userTeam = user:get_team()
    local startPos = 1
    local endPos = 6
    local next = 1
    if (pull_dir == Direction.Left) then
        startPos = 6
        next = -1
        endPos = 1
    end
    for current = startPos, endPos, next do
        local current_tile = field:tile_at(current, y_pos)
        if (current_tile:get_team() ~= userTeam) then
            return current_tile
        end
    end

end

function spawn_wind_gust(user, y_pos, damage, pull)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())
    local damage = damage
    local direction = user:get_facing()
    local pull_dir = user:get_facing()
    local anim_state = "WIND"
    if (pull) then
        pull_dir = user:get_facing_away()
        anim_state = "FAN"
    end

    local speed = 4
    local start_tile = get_gust_pos(y_pos, user, pull_dir)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.None,
            Element.Wind,
            user:get_context(),
            Drag.new()
        )
    )
    -- Setup sprite of the spell
    local sprite = spell:sprite()
    sprite:set_texture(WINDGUST_TEXTURE)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(WINDGUST_ANIMATION)
    anim:set_state(anim_state)
    anim:refresh(sprite)

    spell.attack_func = function(self, character)
        local slide_tile = get_edge(character, pull_dir)
        local dist = slide_tile:get_distance_to_tile(character:get_tile())
        character:slide(slide_tile, frames(4 * dist), frames(0), ActionOrder.Immediate, nil)
    end

    spell.update_func = function(self, dt)
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(pull_dir, 1)
        if (tile == nil or tile:get_team() == user:get_team()) then
            -- Spell will be erased once it reaches the end of the field or allied area
            spell:erase()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        spell:slide(tile, frames(speed), frames(0), ActionOrder.Voluntary, nil)
        --- Attacks the entities this spell collides with.
        self:get_current_tile():attack_entities(self)
    end

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, start_tile)
    return spell
end

function get_edge(entity, direction)
    local field = entity:get_field()
    local tile = entity:get_tile()
    local last_tile = entity:get_tile()
    while is_tile_free_for_movement(tile, entity) do
        last_tile = tile
        tile = tile:get_tile(direction, 1)
    end
    return last_tile
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() or tile:is_reserved({ character:get_id(), character._reserver }) then
        return false
    end
    if (tile:is_edge() or not tile:is_walkable()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (ent:get_health() <= 0) then
            return false
        end
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

return package_init
