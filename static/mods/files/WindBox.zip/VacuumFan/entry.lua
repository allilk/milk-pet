local shared_package_init = include("../WindBox/character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "VacuumFan",
        hp = 130,
        damage = 0,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 200,
        element = Element.None,
        pull = true
    }
    if character:get_rank() == Rank.V2 then
        character_info.palette = _folderpath .. "V2.png"
        character_info.hp = 160
    end
    if character:get_rank() == Rank.V3 then
        character_info.palette = _folderpath .. "V3.png"
        character_info.hp = 190
    end
    if character:get_rank() == Rank.SP then
        character_info.palette = _folderpath .. "SP.png"
        character_info.hp = 300
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 300
        character_info.palette = _folderpath .. "NM.png"
        character_info.hp = 500
        character_info.frames_between_actions = 10
    end
    shared_package_init(character, character_info)
end
