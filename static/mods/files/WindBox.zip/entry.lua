--ID of the package
local package_id = "com.louise.WindBox"
-- prefix of the character id
local character_id = "com.louise.enemy."

function package_requires_scripts()
  --Define characters here.
  Engine.define_character(character_id .. "WindBox", _modpath .. "WindBox")
  Engine.define_character(character_id .. "VacuumFan", _modpath .. "VacuumFan")
end

--package init.
function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("WindBox")
  package:set_description("The WindBox/VacuumFan series.")
  package:set_speed(1)
  package:set_attack(0)
  package:set_health(130)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

-- setup the test package
function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "WindBox", Rank.SP)
  spawner:spawn_at(6, 1)
  --   local spawner = mob:create_spawner(character_id .. "VacuumFan", Rank.SP)
  -- spawner:spawn_at(6, 3)
end
