nonce = function() end

function package_init(package)
	package:declare_package_id("com.EXE4.Card082-CircGun1")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'H', 'T', 'Z' })

	local props = package:get_card_props()
	props.shortname = "CircGun1"
	props.damage = 80
	props.time_freeze = true
	props.element = Element.None
	props.description = "Stop site w/ Button and attck"
	props.card_class = CardClass.Standard
	props.limit = 4
	props.long_description = "Circle the enemy and shoot with A!"
end

function card_create_action(player, props)
	local finish_delay = 20
	local lockon_audio = Engine.load_audio(_folderpath .. "lockon.ogg")
	local gun_audio = Engine.load_audio(_folderpath .. "gun.ogg")
	local move_audio = Engine.load_audio(_folderpath .. "move.ogg")
	local action = Battle.CardAction.new(player, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	local tile_array = {}
	action.execute_func = function(self, user)
		local step1 = Battle.Step.new()
		local step2 = Battle.Step.new()
		local do_once = true
		local ref = self
		local field = user:get_field()
		local frame_count = 360
		local direction = Direction.Down
		local slide_cooldown = { 8, 7 }
		local slide_cooldown_index = 1
		local current_slide_cooldown = slide_cooldown[slide_cooldown_index]
		local erase_array = {}
		local has_attacked = false
		local erase_index = 1
		local step2_wait = 20
		local cursor_spawn_wait = 0
		local desired_cursors = 4
		step1.update_func = function(self, dt)
			if do_once then
				ref.artifact = Battle.Artifact.new()
				ref.artifact:set_texture(Engine.load_texture(_modpath .. "cursor.png", true))
				ref.artifact:sprite():set_layer(-5)
				ref.artifact:get_animation():load(_modpath .. "cursor.animation")
				ref.artifact:get_animation():set_state("SEARCH")
				ref.artifact:set_float_shoe(true)
				ref.artifact:set_air_shoe(true)
				ref.artifact:get_animation():refresh(ref.artifact:sprite())
				ref.artifact:get_animation():set_playback(Playback.Loop)
				ref.artifact.can_move_to_func = function(tile)
					if tile and tile:is_edge() then
						return false
					end
					return true
				end
				if user:get_facing() == Direction.Left then
					field:spawn(ref.artifact, field:tile_at(1, 1))
				else
					field:spawn(ref.artifact, field:tile_at(6, 1))
				end
				do_once = false
			end
			if user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot) or frame_count <= 0 then
				if not has_attacked then
					frame_count = 0
					has_attacked = true
					if not ref.artifact:is_deleted() then
						ref.artifact:get_animation():set_state("FOUND")
						ref.artifact:get_animation():refresh(ref.artifact:sprite())
						table.insert(erase_array, ref.artifact)
						table.insert(tile_array, ref.artifact:get_tile())
						Engine.play_audio(lockon_audio, AudioPriority.Low)
					end
				end
				if has_attacked and #erase_array < desired_cursors then
					if cursor_spawn_wait <= 0 then
						direction = cursor_bounce(erase_array[#erase_array], direction, user, nil)
						local spawn_tile = erase_array[#erase_array]:get_tile(direction, 1)
						table.insert(tile_array, spawn_tile)
						local cursor = Battle.Artifact.new()
						cursor:set_air_shoe(true)
						cursor:set_float_shoe(true)
						cursor:set_texture(Engine.load_texture(_modpath .. "cursor.png", true))
						cursor:sprite():set_layer(-5)
						cursor:get_animation():load(_modpath .. "cursor.animation")
						cursor:get_animation():set_state("FOUND")
						cursor:get_animation():refresh(cursor:sprite())
						field:spawn(cursor, spawn_tile)
						table.insert(erase_array, cursor)
						slide_cooldown_index = slide_cooldown_index + 1
						if slide_cooldown_index > #slide_cooldown then slide_cooldown_index = 1 end
						cursor_spawn_wait = slide_cooldown[slide_cooldown_index]
						Engine.play_audio(lockon_audio, AudioPriority.Low)
					else
						cursor_spawn_wait = cursor_spawn_wait - 1
					end
				elseif #erase_array >= desired_cursors then
					self:complete_step()
				end
			else
				current_slide_cooldown = current_slide_cooldown - 1
				if current_slide_cooldown <= 0 then
					if not ref.artifact:is_deleted() and not ref.artifact:is_sliding() then
						direction = cursor_bounce(ref.artifact, direction, user, move_audio)
						ref.artifact:teleport(ref.artifact:get_tile(direction, 1), ActionOrder.Voluntary, function()
							slide_cooldown_index = slide_cooldown_index + 1
							if slide_cooldown_index > #slide_cooldown then slide_cooldown_index = 1 end
							current_slide_cooldown = slide_cooldown[slide_cooldown_index]
						end)
					end
				end
			end
			frame_count = frame_count - 1
		end
		step2.update_func = function(self, dt)
			finish_delay = finish_delay - 1
			if finish_delay <= 0 then
				if erase_index > #erase_array then self:complete_step() end
				if step2_wait <= 0 then
					local cursor = erase_array[erase_index]
					local tile = cursor:get_tile()
					local attack = create_attack(user, props, gun_audio)
					field:spawn(attack, tile)
					if not cursor:is_deleted() then
						cursor:erase()
					end
					erase_index = erase_index + 1
					step2_wait = 3
				else
					step2_wait = step2_wait - 1
				end
			end
		end
		self:add_step(step1)
		self:add_step(step2)
	end
	return action
end

function cursor_bounce(cursor, direction, user, sound)
	local tile = cursor:get_tile()
	local next_direction = direction
	local team = user:get_team()
	local facing = user:get_facing()
	local function teamcheck(new_tile)
		if tile:get_tile(Direction.Up, 1):is_edge() and new_tile:get_team() == team and
			new_tile:get_tile(Direction.Down, 1):get_team() == team and new_tile:get_tile(Direction.Down, 2):get_team() == team then
			return true
		end
		if tile:get_tile(Direction.Down, 1):is_edge() and new_tile:get_team() == team and
			new_tile:get_tile(Direction.Up, 1):get_team() == team and new_tile:get_tile(Direction.Up, 2):get_team() == team then
			return true
		end
		return false
	end

	if tile:get_tile(Direction.Left, 1):is_edge() and tile:get_tile(Direction.Up, 1):is_edge() or
		tile:get_tile(Direction.Up, 1):is_edge() and teamcheck(tile:get_tile(Direction.Left, 1)) then
		next_direction = Direction.Right
	end
	if tile:get_tile(Direction.Right, 1):is_edge() and tile:get_tile(Direction.Up, 1):is_edge() or
		tile:get_tile(Direction.Up, 1):is_edge() and teamcheck(tile:get_tile(Direction.Right, 1)) then
		next_direction = Direction.Down
	end
	if tile:get_tile(Direction.Right, 1):is_edge() and tile:get_tile(Direction.Down, 1):is_edge() or
		tile:get_tile(Direction.Down, 1):is_edge() and teamcheck(tile:get_tile(Direction.Right, 1)) then
		next_direction = Direction.Left
	end
	if tile:get_tile(Direction.Left, 1):is_edge() and tile:get_tile(Direction.Down, 1):is_edge() or
		tile:get_tile(Direction.Down, 1):is_edge() and teamcheck(tile:get_tile(Direction.Left, 1)) then
		next_direction = Direction.Up
	end
	if sound ~= nil then Engine.play_audio(sound, AudioPriority.Low) end
	return next_direction
end

function create_attack(user, props, sound)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell:set_texture(Engine.load_texture(_modpath .. "spell_charged_bullet_hit.png", true))
	spell:sprite():set_layer(-5)
	local anim = spell:get_animation()
	anim:load(_modpath .. "spell_charged_bullet_hit.animation")
	anim:set_state("HIT")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:erase()
	end)
	spell.update_func = function(self, dt)
		local tile = self:get_tile()
		if tile and tile:is_walkable() then
			tile:attack_entities(self)
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	Engine.play_audio(sound, AudioPriority.Low)
	return spell
end
