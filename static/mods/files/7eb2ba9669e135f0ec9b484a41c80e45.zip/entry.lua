local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package)
    package:declare_package_id("VCGregar")
    package:set_special_description("Vanilla CGregar")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."overworld.animation")
    package:set_overworld_texture_path(_folderpath.."overworld.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
end

function player_init(player)
    player:set_name("VCGregar")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(38.0)

    local base_texture = Engine.load_texture(_folderpath.."Gregar_atlus.png")
    local base_animation_path = _folderpath.."Gregar_atlus.animation"
    local base_charge_color = Color.new(100, 0, 0, 50)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    local buster_cooldown = 5
    local current_buster_cooldown = 0
    local frame1 = {1, 0.03}
    local frame2 = {2, 0.03}
    local frames = make_frame_data({frame1, frame2})
    
    local has_super_armor = false

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end

	
	local original_attack_level, original_charge_level
	
	
    end
	
	
	


local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(props)
	spell.update_func = function(self, dt)
		if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
			self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
		end
		if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
			self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
		end
		self:get_tile():attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end