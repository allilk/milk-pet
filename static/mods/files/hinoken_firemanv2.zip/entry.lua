local package_id = "com.hinoken.firemanV2"
local character_id = "com.hinoken.Enemy.firemanvs2"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."fireman")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("FireMan")
  package:set_description("Something is off..")
  package:set_speed(1)
  package:set_attack(30)
  package:set_health(500)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
local texPath = _modpath.."bg.png"
local animPath = _modpath.."bg.animation"
mob:set_background(texPath, animPath, 0.0, 0.0)
mob:stream_music(_modpath.."music.ogg", 0, 0)

local spawner = mob:create_spawner(character_id,Rank.V2)
spawner:spawn_at(5, 2)
end




