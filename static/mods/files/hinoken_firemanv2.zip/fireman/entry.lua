local Engine_load_audio, Engine_load_texture, Engine_play_audio, HitProps_new, math_random, frames = Engine.load_audio, Engine.load_texture, Engine.play_audio, HitProps.new, math.random, frames;
nonce = function()
end;
local texture = nil;
local fireRingTexture = nil;
local waitTime = 0;
local anim = nil;
local aiStateIndex = 1;
local aiState = {};
local firstFrame = false;
local attack = "FIREARM";
local bombx = {};
local bomby = {};
local ruined = false;
local fireArmSound;
local fireTowerSound;
local fireBombLaunchSound;
local fireBombDieSound;
local fireBombExplodeSound;
package_init = function(self)
	fireArmSound = Engine_load_audio(_modpath .. "firearm.ogg");
	fireTowerSound = Engine_load_audio(_modpath .. "firetower.ogg");
	fireBombLaunchSound = Engine_load_audio(_modpath .. "firebomb_launch.ogg");
	fireBombDieSound = Engine_load_audio(_modpath .. "firebomb_die.ogg");
	fireBombExplodeSound = Engine_load_audio(_modpath .. "firebomb_explode.ogg");
	self:register_status_callback(Hit.Flinch, dayRuined);
	texture = Engine_load_texture(_modpath .. "FireMan.png");
	fireRingTexture = Engine_load_texture(_modpath .. "firering.png");
	self.activate_function_once = true;
	self.update_func = function(self, dt)
		waitTime = waitTime - 1;
		if (not self.activate_function_once and not ruined) then
			self.activate_function_once = true;
		end
		if ((aiStateIndex == 2) or (aiStateIndex == 6)) then
			WaitState(self, dt);
		elseif ((aiStateIndex == 4) or (aiStateIndex == 8)) then
			MoveState(self, dt);
		elseif (aiStateIndex == 10) then
			AttackState(self, dt);
		elseif self.activate_function_once then
			if (aiStateIndex == 1) then
				set_wait_timer(self, 32);
			elseif (aiStateIndex == 3) then
				set_wait_timer(self, 15);
			elseif (aiStateIndex == 5) then
				set_wait_timer(self, 40);
			elseif (aiStateIndex == 7) then
				MoveState(self, dt);
			elseif (aiStateIndex == 9) then
				set_wait_timer(self, 260);
			elseif (aiStateIndex == 10) then
				AttackState(self, dt);
			end
			self.activate_function_once = false;
		end
	end;
	self:set_name("FireManV");
	local rank = self:get_rank();
	if (rank == Rank.V1) then
		self:set_health(300);
	elseif (rank == Rank.V2) then
		self:set_health(500);
	else
		self:set_health(500);
	end
	self:set_element(Element.Fire);
	self:set_texture(texture, true);
	self:set_height(60);
	self:share_tile(false);
	math_random();
	NextState = function(fireman)
		aiStateIndex = aiStateIndex + 1;
		if (aiStateIndex > 10) then
			aiStateIndex = 1;
		end
		fireman.activate_function_once = true;
	end;
	set_wait_timer = function(fireman, seconds)
		waitTime = seconds;
		firstFrame = true;
		NextState(fireman);
	end;
	WaitState = function(self, dt)
		if firstFrame then
			firstFrame = false;
			if ruined then
				waitTime = 30;
			else
				anim:set_state("IDLE");
				anim:set_playback(Playback.Loop);
			end
		end
		if (waitTime <= 0) then
			if ruined then
				waitTime = 10;
				anim:set_state("IDLE");
				anim:set_playback(Playback.Loop);
				ruined = false;
			else
				NextState(self);
			end
		end
	end;
	MoveState = function(self, dt)
		if firstFrame then
			anim:set_state("MOVE");
			anim:set_playback(Playback.Once);
			firstFrame = false;
		end
		if (waitTime == 7) then
			local dest = self:get_field():tile_at(1, 1);
			local giveup = 0;
			while not can_move_to(dest) and (giveup < 100) do
				local randomx = self:get_tile():x();
				local randomy = self:get_tile():y();
				randomx = math_random(4, 6);
				randomy = math_random(1, 3);
				dest = self:get_field():tile_at(randomx, randomy);
				giveup = giveup + 1;
			end
			if (giveup < 100) then
				self:teleport(dest, ActionOrder.Voluntary, nonce);
			end
		end
		if (waitTime <= 0) then
			NextState(self);
		end
	end;
	AttackState = function(self, dt)
		if firstFrame then
			if (self:get_tile():x() == 4) then
				attack = "FIREARM";
				anim:set_state("FIREARM_PREP");
			elseif (self:get_tile():x() == 5) then
				attack = "FIRETOWER";
				anim:set_state("FIRETOWER_INIT");
			else
				attack = "FIREBOMB";
				anim:set_state("FIREBOMB_INIT");
			end
			anim:set_playback(Playback.Loop);
			firstFrame = false;
		elseif (attack == "FIREARM") then
			if (waitTime == 205) then
				anim:set_state("FIREARM_HEATUP");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 193) then
				anim:set_state("FIREARM");
				anim:set_playback(Playback.Loop);
				self:get_field():spawn(Firearm_Fire(self, true), self:get_tile():x() - 1, self:get_tile():y());
			end
			if (waitTime == 190) then
				self:get_field():spawn(Firearm_Fire(self), self:get_tile():x() - 2, self:get_tile():y());
			end
			if (waitTime == 187) then
				self:get_field():spawn(Firearm_Fire(self), self:get_tile():x() - 3, self:get_tile():y());
			end
			if (waitTime == 150) then
				waitTime = 1;
			end
		elseif (attack == "FIRETOWER") then
			if (waitTime == 251) then
				anim:set_state("FIRETOWER_PREP");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 205) then
				anim:set_state("FIRETOWER");
				anim:set_playback(Playback.Loop);
				Engine_play_audio(fireTowerSound, AudioPriority.High);
				self:get_field():spawn(Firetower_Fire(self), self:get_tile():x() - 1, self:get_tile():y());
				Engine_play_audio(fireTowerSound, AudioPriority.Low);
				waitTime = waitTime - 100;
			end
		elseif (attack == "FIREBOMB") then
			if (waitTime == 257) then
				anim:set_state("FIREBOMB_PREP_1");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 160) then
				anim:set_state("FIREBOMB_PREP_2");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 145) then
				anim:set_state("FIREBOMB");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 135) then
				for x = 0, 2 do
					local taken = true;
					while taken == true do
						bombx[x] = math_random(1, 6);
						bomby[x] = math_random(1, 3);
						taken = false;
						for y = 0, x - 1 do
							if ((bombx[x] == bombx[y]) and (bomby[x] == bomby[y])) then
								taken = true;
							end
						end
						if (self:get_field():tile_at(bombx[x], bomby[x]):get_team() == Team.Blue) then
							taken = true;
						end
					end
				end
				Engine_play_audio(fireBombLaunchSound, AudioPriority.High);
				self:get_field():spawn(Firebomb(self, bombx[0], bomby[0]), self:get_tile():x(), self:get_tile():y());
			end
			if (waitTime == 125) then
				Engine_play_audio(fireBombLaunchSound, AudioPriority.High);
				self:get_field():spawn(Firebomb(self, bombx[1], bomby[1]), self:get_tile():x(), self:get_tile():y());
			end
			if (waitTime == 115) then
				Engine_play_audio(fireBombLaunchSound, AudioPriority.High);
				self:get_field():spawn(Firebomb(self, bombx[2], bomby[2]), self:get_tile():x(), self:get_tile():y());
			end
			if (waitTime == 105) then
				anim:set_state("FIREBOMB_END");
				anim:set_playback(Playback.Loop);
			end
			if (waitTime == 100) then
				waitTime = 0;
			end
		end
		if (waitTime <= 0) then
			NextState(self);
		end
	end;
	Firearm_Fire = function(fireman, firstfire)
		local audiotimer = 15;
		local fire = Battle.Spell.new(Team.Blue);
		fire:set_texture(texture, true);
		fire:highlight_tile(Highlight.Solid);
		fire:sprite():set_layer(-1);
		fire:set_hit_props(HitProps.new(50, Hit.Impact | Hit.Flash | Hit.Flinch, Element.Fire, fireman:get_context(), Drag.None));
		local fireAnim = fire:get_animation();
		local expiration = 190;
		fireAnim:copy_from(anim);
		fireAnim:set_state("FIREARM_FIRE_INIT");
		fireAnim:set_playback(Playback.Loop);
		fire.update_func = function(self, dt)
			if (firstfire and ((expiration % 15) == 0)) then
				Engine.play_audio(fireArmSound, AudioPriority.High);
			end
			if (expiration == 187) then
				fireAnim:set_state("FIREARM_FIRE");
				fireAnim:set_playback(Playback.Loop);
				expiration = expiration - 150;
			end
			if (expiration < 189) then
				local hitbox = Battle.Hitbox.new(self:get_team());
				hitbox:set_hit_props(fire:copy_hit_props());
				local ymod = 0;
				fire:get_field():spawn(hitbox, fire:get_tile():x(), fire:get_tile():y() + ymod);
			end
			expiration = expiration - 1;
			if (expiration <= 0) then
				self:delete();
			end
			if ruined then
				if (waitTime == (60 - (3 * (4 - fire:get_tile():x())))) then
					self:delete();
				end
			end
		end;
		return fire;
	end;
	Firetower_Fire = function(fireman)
		local fire = Battle.Spell.new(Team.Blue);
		fire:set_texture(texture, true);
		fire:highlight_tile(Highlight.Solid);
		fire:set_facing(fireman:get_facing());
		local fireAnim = fire:get_animation();
		local expiration = 139;
		fire:set_hit_props(HitProps_new(100, Hit.Impact, Element.Fire, fireman:get_context(), Drag.None));
		fireAnim:copy_from(anim);
		fireAnim:set_state("FIRETOWER_FIRE_INIT");
		fireAnim:set_playback(Playback.Loop);
		local player = fireman:get_target();
		local ymod = 0;
		fire.update_func = function(self, dt)
			if (expiration == 139) then
				if player:get_tile() then
					if (player:get_tile():y() > fire:get_tile():y()) then
						ymod = 1;
					end
					if (player:get_tile():y() < fire:get_tile():y()) then
						ymod = -1;
					end
				end
			end
			if (expiration == 123) then
				fireAnim:set_state("FIRETOWER_FIRE");
				fireAnim:set_playback(Playback.Loop);
			end
			if (expiration == 4) then
				fireAnim:set_state("FIRETOWER_FIRE_END");
				fireAnim:set_playback(Playback.Loop);
			end
			if ((expiration < 137) and (expiration > 2)) then
				fire:get_tile():attack_entities(self);
				if (fire:get_tile():is_reserved({})) then
					self:delete();
				end
			end
			if (expiration == 122) then
				Engine_play_audio(fireTowerSound, AudioPriority.High);
				if (fire:get_tile():x() > 1) then
					self:get_field():spawn(Firetower_Fire(fireman), fire:get_tile():x() - 1, fire:get_tile():y() + ymod);
				end
			end
			expiration = expiration - 1;
			if (expiration <= 0) then
				self:delete();
			end
		end;
		fire.collision_func = function(self, other)
			self:delete();
		end;
		return fire;
	end;
	Firebomb = function(fireman, spawnx, spawny)
		local bomb = Battle.Spell.new(Team.Blue);
		bomb:set_texture(texture, true);
		bomb:set_shadow(1);
		bomb:show_shadow(true);
		bomb:set_facing(fireman:get_facing());
		local bombAnim = bomb:get_animation();
		local expiration = 197;
		local dest = fireman:get_field():tile_at(spawnx, spawny);
		bombAnim:copy_from(anim);
		bombAnim:set_state("FIREBOMB_BOMB_1");
		bombAnim:set_playback(Playback.Loop);
		bomb.update_func = function(self, dt)
			if (expiration == 122) then
				self:get_field():spawn(Firebomb_obstacle(self), self:get_tile():x(), self:get_tile():y());
				self:delete();
			end
			expiration = expiration - 1;
		end;
		bomb.can_move_to_func = function(tile)
			return true;
		end;
		bomb:jump(dest, 300, frames(75), frames(75), ActionOrder.Voluntary, nonce);
		return bomb;
	end;
	Firebomb_obstacle = function(firebomb)
		local bomb = Battle.Obstacle.new(Team.Blue);
		bomb:set_texture(texture, true);
		bomb:set_shadow(1);
		bomb:show_shadow(true);
		bomb:set_health(30);
		bomb:share_tile(true);
		bomb:set_facing(firebomb:get_facing());
		local bombAnim = bomb:get_animation();
		local expiration = 122;
		bombAnim:copy_from(anim);
		bombAnim:set_state("FIREBOMB_BOMB_2");
		bombAnim:set_playback(Playback.Loop);
		bomb.update_func = function(self, dt)
			if (expiration == 56) then
				bombAnim:set_state("FIREBOMB_BOMB_3");
				bombAnim:set_playback(Playback.Loop);
			end
			if (expiration == 20) then
				bombAnim:set_state("FIREBOMB_BOMB_4");
				bombAnim:set_playback(Playback.Loop);
			end
			expiration = expiration - 1;
			if (expiration <= 0) then
				self:get_field():spawn(Battle.Explosion.new(1, 1), bomb:get_tile():x(), bomb:get_tile():y());
				self:get_field():spawn(Firebomb_Fire(self), bomb:get_tile():x(), bomb:get_tile():y());
				Engine_play_audio(fireBombExplodeSound, AudioPriority.High);
				self:erase();
			end
		end;
		bomb.delete_func = function(self)
			Engine_play_audio(fireBombDieSound, AudioPriority.High);
		end;
		return bomb;
	end;
	Firebomb_Fire = function(firebomb)
		local fire = Battle.Spell.new(Team.Blue);
		fire:set_texture(fireRingTexture, true);
		local ringanim = fire:get_animation();
		ringanim:load(_modpath .. "firering.animation");
		ringanim:set_state("IDLE");
		ringanim:set_playback(Playback.Loop);
		fire:highlight_tile(Highlight.Solid);
		fire:sprite():set_layer(-2);
		fire:set_hit_props(HitProps_new(30, Hit.Impact, Element.Fire, firebomb:get_id(), Drag.None));
		local expiration = 200;
		fire.update_func = function(self, dt)
			fire:get_tile():attack_entities(self);
			if (fire:get_tile():is_reserved({}) and (expiration < 200)) then
				self:delete();
			end
			expiration = expiration - 1;
			if (expiration <= 0) then
				self:delete();
			end
		end;
		fire.collisionFunc = function(self, other)
			self:delete();
		end;
		return fire;
	end;
	anim = self:get_animation();
	anim:load(_modpath .. "fireman.animation");
	anim:set_state("IDLE");
	anim:set_playback(Playback.Loop);
end;
num_of_explosions = function()
	anim:set_state("FIREBOMB_PREP_1");
	return 11;
end;
dayRuined = function()
	if not ruined then
		anim:set_state("OUCH");
		anim:set_playback(Playback.Once);
		anim:on_complete(function()
			anim:set_state("IDLE");
			ruined = false;
			anim:set_playback(Playback.Loop);
		end);
		aiStateIndex = 1;
		ruined = true;
	end
end;
can_move_to = function(tile)
	if tile:is_edge() then
		return false;
	end
	if (tile:is_reserved({}) or (tile:get_team() == Team.Red) or not tile:is_walkable()) then
		return false;
	end
	return true;
end;