function package_init(package) 
    package:declare_package_id("com.alrysc.player.TankManEXE")
    package:set_special_description("Rika's net navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."tankmanOW.animation")
    package:set_overworld_texture_path(_modpath.."tankmanOW.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("TankMan")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(60.0)
    player:set_animation(_modpath.."tankman.animation")
    player:set_texture(Engine.load_texture(_modpath.."tankman.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(-4, -24)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        shoot = Engine.load_audio(_modpath .. "cannon.ogg"),
        explosion = Engine.load_audio(_modpath .. "bombmiddle.ogg"),
        vulcan = Engine.load_audio(_modpath .. "vulcan.ogg"),
        click = Engine.load_audio(_modpath .. "click.ogg")
    }


    player.icon = nil
    player.bullet_display1 = nil
    player.bullet_display2 = nil
    player.bullet_display3 = nil
    player.bullet_display1_anim = nil
    player.bullet_display2_anim = nil
    player.bullet_display3_anim = nil

    player.bullets_h = 1
    player.bullets_t = 2
    player.bullets_o = 0
    player.bullets = 120


    local first = true
    local function update_bullets(player)
        player.bullets_h = math.floor(player.bullets/100)
        player.bullets_t = math.floor((player.bullets - 100*player.bullets_h) /10)
        player.bullets_o = player.bullets - player.bullets_h*100 - player.bullets_t*10

        player.bullet_display1_anim:set_state("NUMBER_"..player.bullets_h)
        player.bullet_display2_anim:set_state("NUMBER_"..player.bullets_t)
        player.bullet_display3_anim:set_state("NUMBER_"..player.bullets_o)
    end

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    player.update_func = function(self)
        if first then 
            self.bullets_h = 1
            self.bullets_t = 2
            self.bullets_o = 0
            self.bullets = 120

            local y = -74
            local x = 0
            --[[
            self.icon = graphic_init("artifact", -18, y, "tankman.png", "tankman.animation", -5, "BULLETS_ICON", self, self:get_facing(), false)
            self.bullet_display1 = graphic_init("artifact", 6, y, "tankman.png", "tankman.animation", -5, "NUMBER_1", self, self:get_facing(), false, true)
            self.bullet_display2 = graphic_init("artifact", 22, y, "tankman.png", "tankman.animation", -5, "NUMBER_2", self, self:get_facing(), false, true)
            self.bullet_display3 = graphic_init("artifact", 38, y, "tankman.png", "tankman.animation", -5, "NUMBER_0", self, self:get_facing(), false, true)
            self.bullet_display1_anim = self.bullet_display1:get_animation()
            self.bullet_display2_anim = self.bullet_display2:get_animation()
            self.bullet_display3_anim = self.bullet_display3:get_animation()


            local field = self:get_field()
            local tile
            if self:get_facing() == Direction.Left then 
                tile = field:tile_at(6,0)
                field:spawn(self.icon, tile)
                field:spawn(self.bullet_display1, tile)
                field:spawn(self.bullet_display2, tile)
                field:spawn(self.bullet_display3, tile)


            else 
                tile = field:tile_at(1,0)
                field:spawn(self.icon, tile)
                field:spawn(self.bullet_display1, tile)
                field:spawn(self.bullet_display2, tile)
                field:spawn(self.bullet_display3, tile)
            end
        --]]
            first = false
        end

    end

    local function create_bullet_shell(sound, user, start_pos, pX, pY, pZ, facing, time, count, spin, tile, type, spell, spell_anim)
        spell = nil or spell
        spell_anim = nil or spell_anim
        local called_with_spell = false
        if spell then called_with_spell = true end
        local plusY = 0.0
        local speedY = 3*2 -- 2 is the scale
    
        local offset_facing = 1
    
        if facing == Direction.Left then 
            offset_facing = offset_facing * -2
        end
    
        local end_pos = {
            x = (start_pos.x - (8 + 16 * count * offset_facing)),
            y = start_pos.y + 1.8*pZ
        }
    
      --  local end_pos = {
        --    x = (start_pos.x - (8*4 + 8*2 * count * offset_facing)),
          --  y = start_pos.y + 1.5*pZ
       -- }
    
        local moveX = (start_pos.x - end_pos.x) / time
        local moveY = (start_pos.y - end_pos.y) / time
        local plusing = speedY / (time / 2) 
    
    
        local real_offset = {
            x = start_pos.x,
            y = start_pos.y
        }
    
    
        local function update(pX, pY, time)
    
            local new_offset = {}
        
            new_offset[1] = pX - moveX
            new_offset[2] = pY - moveY
            plusY = plusY + speedY
            speedY = speedY - plusing
        
            return new_offset
        end
        
    
        if not spell then 
            spell = Battle.Artifact.new()
            spell_anim = spell:get_animation()
            spell:set_offset(start_pos.x, start_pos.y)
    
    
            spell:sprite():set_layer(-3)
    
    
            spell:set_texture(Engine.load_texture(_modpath.."shell"..type..".png"), true)
            spell:set_animation(_modpath.."shell"..type..".animation")
        end
        spell.time = time
    
        spell_anim:set_state("shell"..spin)
        spell_anim:refresh(spell:sprite())
    
    
        spell.update_func = function(self)
            self:get_animation():set_state("shell"..spin)
            self:get_animation():refresh(self:sprite())
    
    
            spin = spin+1
            if spin > 9 then 
                spin = 0 
            end
    
            self.time = self.time - 1
            if self.time == 0 then 
                if count > 0 then 
                    create_bullet_shell(sound, user, self:get_offset(), pX, pY, 0, facing, math.floor(time/2), count-1, spin, self:get_current_tile(), type, spell, spell_anim)
                else
                    self:delete()
                end
            end
    
            local new_offset = update(pX, pY, self.time)
            pX = new_offset[1]
            pY = new_offset[2]
            self:set_offset(pX, (pY - plusY))
        end
    
    
        if not called_with_spell then 
            user:get_field():spawn(spell, tile)
        end
    
    end



    player.charged_attack_func = function()
        local action = Battle.CardAction.new(player, "TANKMAN_CANNON")
        local field = player:get_field()

        local function back_attack(user, tile, team, context)
            if not tile or tile:is_edge() then return end

            local spell = Battle.Spell.new(team)
            local lifetime = 3

            local damage = 30 + user:get_attack_level() * 30
          
            local hit_props = HitProps.new(damage,
                                       Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                                       Element.None, context, Drag.None)
            spell:set_hit_props(hit_props)

            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                lifetime = lifetime  - 1
                if lifetime == 0 then 
                    self:delete()
                end
            end

            field:spawn(spell, tile)
            field:spawn(graphic_init("artifact", 0, 32, "tankman.png", "tankman.animation", -3, "EXPLOSION", user, facing, true), tile)
        end

        local function shoot_cannon(user)
            local facing = user:get_facing()
            local context = user:get_context()
            local spell = graphic_init("spell", 0, -50, "tankman.png", "tankman.animation", -3, "BULLET", user, user:get_facing())
            spell:highlight_tile(Highlight.Solid)
    
            local hit_props = HitProps.new(30+user:get_attack_level()*30,
                                       Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                                       Element.None, context, Drag.None)
    
            spell:set_hit_props(hit_props)
    
            spell.update_func = function(self)
                self:get_tile():attack_entities(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        local tile = self:get_tile(self:get_facing_away(), 1)
                        local tile2 = tile:get_tile(Direction.Up, 1)
                        local tile3 = tile:get_tile(Direction.Down, 1)
                        back_attack(user, tile, self:get_team(), context)
                        back_attack(user, tile2, self:get_team(), context)
                        back_attack(user, tile3, self:get_team(), context)

                        Engine.play_audio(user.sounds.explosion, AudioPriority.Low)
    
                        local shake_artifact = Battle.Artifact.new()
                        local time = 0
                        shake_artifact.update_func = function(self)
                                
                            self:shake_camera(200, 0.016)
                            if time == 17 then 
                                self:delete()
                            end
                        
                            time = time+1
                        end
        
                        field:spawn(shake_artifact, user:get_current_tile())
                        self:delete()
                    end 
                    
                    local dest = self:get_tile(facing, 1)
                    local ref = self
                    self:slide(dest, frames(3), frames(0), ActionOrder.Voluntary, 
                        function()                           
                            ref.slide_started = true 
                        end)
                end
            end
    
    
            spell.collision_func = function(self, other)
                field:spawn(graphic_init("artifact", 0, 8, "tankman.png", "tankman.animation", -3, "EXPLOSION", user, facing, true), other:get_current_tile())
                Engine.play_audio(user.sounds.explosion, AudioPriority.Low)
    
                local shake_artifact = Battle.Artifact.new()
                    local time = 0
                    shake_artifact.update_func = function(self)
                            
                        self:shake_camera(200, 0.016)
                        if time == 17 then 
                            self:delete()
                        end
                    
                        time = time+1
                    end
    
                    field:spawn(shake_artifact, user:get_current_tile())
    
    
                self:delete()
    
            end
            spell.attack_func = function()
                Engine.play_audio(user.sounds.hit, AudioPriority.Low)
    
            end
    
            spell.can_move_to_func = function()
                return true
            end
    
            
            local offset = {
                y = -100,
                x = -20
            }   
    
            local height = 40
            local facing_offset = 1
            if facing == Direction.Left then 
                facing_offset = facing_offset * -1
            end
    
            create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "")
    
            field:spawn(spell, user:get_tile(facing, 1))
    
        end

        action.execute_func = function()
            action:add_anim_action(8, function()
                Engine.play_audio(player.sounds.shoot, AudioPriority.Low)
                shoot_cannon(player)
            
            end)

        end

        return action
    end

    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())

    end

    player.normal_attack_func = base_normal_attack


    player.special_attack_func = function()
        local action = Battle.CardAction.new(player, "GUN_START")
        action:set_lockout(make_sequence_lockout())
        local field= player:get_field()


        local start_step = Battle.Step.new()
        local start_first = true


        local function shoot(user)
            local facing = user:get_facing()
    
            local spell = Battle.Spell.new(user:get_team())
    
            local hit_props = HitProps.new(0,
                                       Hit.None,
                                       Element.None, user:get_context(), Drag.None)
    
            spell:set_hit_props(hit_props)
    
            spell.update_func = function(self)
                self:get_tile():attack_entities(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        self:delete()
                    end 
                    
                    local dest = self:get_tile(facing, 1)
                    local ref = self
                    self:slide(dest, frames(3), frames(0), ActionOrder.Voluntary, 
                        function()                           
                            ref.slide_started = true 
                        end)
                end
            end

            local function create_shot(user, tile)
                local spell2 = Battle.Spell.new(user:get_team())
                local effect = graphic_init("spell", 0, 0, "shot_hit.png", "tankman.animation", -3, "SHOT_HIT", user, user:get_facing_away(), true)

                spell2:highlight_tile(Highlight.Solid)

                local hit_props = HitProps.new(user:get_attack_level()*2,
                                        Hit.Impact | Hit.Breaking,
                                        Element.None, user:get_context(), Drag.None)

                spell2:set_hit_props(hit_props)

                local lifetime = 3
                spell2.update_func = function(self)
                    self:get_tile():attack_entities(self)
                    lifetime = lifetime - 1
                    if lifetime == 0 then 
                        self:delete()
                    end
                end


                spell2.attack_func = function()
                    Engine.play_audio(user.sounds.hit, AudioPriority.Low)

                end

                field:spawn(spell2, tile)
                field:spawn(effect, tile)
            end
    
    
            spell.collision_func = function(self, other)
                create_shot(player, other:get_current_tile())
                self:delete()
            end
    
            spell.can_move_to_func = function()
                return true
            end
    
            
            local offset = {
                y = -80,
                x = 30
            }   
    
            local height = 40
            local facing = user:get_facing()
            local facing_offset = 1
            if facing == Direction.Left then 
                facing_offset = facing_offset * -1
            end
    
            create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "_small")
    
            offset.x = offset.x - 48
            create_bullet_shell(nil, user, offset, offset.x*facing_offset, offset.y, height, facing, 40 + math.random(0, 20), 2, 0, user:get_current_tile(), "_small")
    
            field:spawn(spell, user:get_tile(facing, 1))
        end

        
        local function add_end_step()
            local step = Battle.Step.new()
            local start = true
            if start then 
                local anim = player:get_animation()
                anim:set_state("GUN_END")
                anim:on_complete(function()
                    step:complete_step()
                end)

                anim:refresh(player:sprite())

                start = false
            end

            action:add_step(step)
        end

        local function add_shoot_step(times)
            times = times-1
            local step = Battle.Step.new()
            local start = true
            local has_bullets = (player.bullets > 0)
            if start then 
                local anim = player:get_animation()
                if not has_bullets then 
                    anim:set_state("GUN_BLANK")
                else
                    anim:set_state("GUN_SHOOT")
                end
                anim:on_frame(2, function()
                    if not has_bullets then 
                        Engine.play_audio(player.sounds.click, AudioPriority.Low)

                    else
                        shoot(player)
                        Engine.play_audio(player.sounds.vulcan, AudioPriority.Low)

          --              player.bullets = player.bullets - 2
            --            update_bullets(player)
                    end
                end)

                anim:refresh(player:sprite())

                anim:on_complete(function()
                    if has_bullets and times ~= 0 then
                        add_shoot_step(times)
                    else
                        add_end_step()
                    end
                    step:complete_step()
                
                end)
                start = false
            end
            
            action:add_step(step)
        end

        start_step.update_func = function()
            if start_first then
                local anim = player:get_animation() 
                anim:on_complete(function()
                    start_step:complete_step()
                    add_shoot_step(5)
                end)
                start_first = false
            end
        end
        action.execute_func = function()
            action:add_step(start_step)

        end
        return action
    end

end