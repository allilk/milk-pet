local corn = include("/corn/corn.lua")


function package_init(package)
    package:declare_package_id("com.discord.FlopTart#9360.player.CornManCS")
    package:set_special_description("Now with CornShot!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."overworld.animation")
    package:set_overworld_texture_path(_folderpath.."overworld.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("CornMan")
    player:set_health(1000)
    player:set_element(Element.Wood)
    player:set_height(60.0)

    local base_texture = Engine.load_texture(_folderpath.."battle.png")
    local base_animation_path = _folderpath.."battle.animation"
    local base_charge_color = Color.new(57, 198, 243, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack

  player.update_func = function(self, dt) 
        -- nothing in particular
    end
end

function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level())
end


 function create_charged_attack(player)
    print("charged attack")
    local props = Battle.CardProperties:new()
    props.damage = (player:get_attack_level()*10)
    local corn_action = corn.card_create_action(player,props)
    return corn_action
 end

