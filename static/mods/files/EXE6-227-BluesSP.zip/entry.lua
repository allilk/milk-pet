local blues = include("blues/blues.lua")

local DAMAGE = 240

blues.codes = {"B"}
blues.shortname = "BluesSP"
blues.damage = DAMAGE
blues.time_freeze = true
blues.element = Element.Sword
blues.description = "Warp in and slice the enemy"
blues.long_description = "Warp in front of the enemy and slice it, even where you can't warp"
blues.can_boost = true
blues.card_class = CardClass.Mega
blues.limit = 1

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-227-BluesSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(blues.codes)

    local props = package:get_card_props()
    props.shortname = blues.shortname
    props.damage = blues.damage
    props.time_freeze = blues.time_freeze
    props.element = blues.element
    props.description = blues.description
    props.long_description = blues.long_description
    props.can_boost = blues.can_boost
	props.card_class = blues.card_class
	props.limit = blues.limit
end

card_create_action = blues.card_create_action