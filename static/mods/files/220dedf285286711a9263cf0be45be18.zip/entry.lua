local HIT_SFX = nil
local BLADE_SFX = nil
local RAISE_SFX = nil
local PUNCH_SFX = nli


function package_init(package)
    package:declare_package_id("com.alrysc.player.metalman")
    package:set_special_description("Customized MetalMan!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."metalmanOW.animation")
    package:set_overworld_texture_path(_modpath.."metalmanOW.png")
    package:set_icon_texture(Engine.load_texture(_modpath.."metalman_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
  --  package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("MetalMan")
    player:set_health(1000)
    player:set_element(Element.Break)
    player:set_height(75.0)

    local base_texture = Engine.load_texture(_modpath.."metalman.png")
    local base_animation_path = _modpath.."metalman.animation"
    local base_charge_color = Color.new(255, 0, 255, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -40)

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    


    local function metal_blade(player)
        local action = Battle.CardAction.new(player, "PLAYER_SWORD")
        local override_frames = {
        
            {1, 0.1833}, {2, 0.033}, {3, 0.033}, {4, 0.48333}
        }
        local frame_data = make_frame_data(override_frames)
        action:override_animation_frames(frame_data)

        

        local function create_blade(player, tile)
            local spell = graphic_init("spell", 0, 0, "metalman.png", "metalman.animation", -6, "BLADE", player, player:get_facing())
            spell:get_animation():set_playback(Playback.Loop)
            local field = player:get_field()



            local hit_props = HitProps.new(
                player:get_attack_level()*20,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                Element.Sword, 
                player:get_context(), 
                Drag.None
            )

            spell:set_hit_props(hit_props)

            spell.turn_count = 0
            spell.slide_dir = spell:get_facing()
            spell.orig_dir = spell.slide_dir
            spell.straight = false

            if tile:y() == 1 then
                spell.second_dir = Direction.Down
            elseif tile:y() == field:height() then 
                spell.second_dir = Direction.Up
            else
                spell.second_dir = nil
            end

            spell.speed = 6

            local new_spell = nil

            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                if not self:is_sliding() then 
                    if not self:get_tile(self.slide_dir, 1) then 
                        self:delete()
                        return
                    end 
                    if self.turn_count == 0 and self.second_dir ~= nil then 
                        if self:get_tile(self.slide_dir, 1):is_edge() then 
                            self.speed = 4

                            if self.second_dir == Direction.reverse(self.orig_dir) then 
                                self.speed = 7
                            end
                            self.slide_dir = self.second_dir
                            self.turn_count = self.turn_count+1

            
                        end

                        

                    elseif self.turn_count == 1 then
                        if self:get_tile(self.slide_dir, 1):is_edge() then 
                            self.speed = 7
                            self.slide_dir = Direction.reverse(self.orig_dir)
                            self.turn_count = self.turn_count+1
            
                        end

                    end

                
                    local dest = self:get_tile(self.slide_dir, 1)
                    local ref = self
                    self:slide(dest, frames(self.speed), frames(0), ActionOrder.Voluntary,
                        function()
                            ref.slide_started = true 
                        end
                    )
                end

            end

            spell.can_move_to_func = function()
                return true
            end

            spell.attack_func = function(self, other)
                Engine.play_audio(HIT_SFX, AudioPriority.Low)
                local artifact = graphic_init("artifact", self:get_tile_offset().x, -20, "overlay_fx05_animations.png", "overlay_fx05_animations.animation", -7, "1", player, player:get_facing(), true)
                field:spawn(artifact, other:get_current_tile())
            end

            spell.collision_func = function(self, other)
                
            end

            field:spawn(spell, tile)
        end


        action.execute_func = function(self)
            HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")
            BLADE_SFX =  Engine.load_audio(_modpath.."boomer.ogg")

            action:add_anim_action(2, function()
                local hilt = self:add_attachment("HILT")
                local hilt_sprite = hilt:sprite()
                hilt_sprite:set_texture(player:get_texture())
                hilt_sprite:set_layer(-2)
                hilt_sprite:enable_parent_shader(true)
                local hilt_anim = hilt:get_animation()
                hilt_anim:copy_from(player:get_animation())
                hilt_anim:set_state("HAND")
                hilt_anim:refresh(hilt_sprite)

                
            end)


            action:add_anim_action(3, function()
                Engine.play_audio(BLADE_SFX, AudioPriority.Low)
                create_blade(player, player:get_tile(player:get_facing(), 1))
            end)

        end


        return action
    end


    local function metal_fist(player)
        local action = Battle.CardAction.new(player, "PLAYER_SPECIAL")
        local field = player:get_field()
        local start_tile = nil
        local highlight_spell = nil
        local punch_spell = nil

        local function check_characters(tile, self)
            local characters = tile:find_characters(function(c)
                return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
            end)
        
            return #characters > 0
        
        end

        local function check_obstacles(tile, self)
            local ob = tile:find_obstacles(function(o)
                return o:get_health() > 0 
            end)
        
            return #ob > 0 
        end

        local function find_dest(player)
            local chosen_tile = nil
            start_tile = player:get_current_tile()
            local cur_tile = start_tile
            local edge_tile = nil
            local facing = player:get_facing()
            local team = player:get_team()

            local prev_tile = nil

            local found_target = false

            for i=1, field:width()
            do
                cur_tile = cur_tile:get_tile(facing, 1)
                if not cur_tile or cur_tile:is_edge() then 
                    break
                end

                if not edge_tile and cur_tile:get_team() ~= team then 
                    edge_tile = prev_tile

                end

                if not check_characters(cur_tile, player) then 
                    
                    if not check_obstacles(cur_tile, player) then 
                        prev_tile = cur_tile
                    end
                else
                    found_target = true
                    break
                end

            end


            if found_target then 
                chosen_tile = prev_tile
            end

            if not chosen_tile then
                if edge_tile then 
                    chosen_tile = edge_tile
                else 
                    chosen_tile = start_tile
                end
            end

            return chosen_tile
        end

        local function create_highlight(player)
            highlight_spell = Battle.Spell.new(player:get_team())
            highlight_spell:highlight_tile(Highlight.Flash)
            highlight_spell.lifetime = 23

            highlight_spell.update_func = function(self)
                self.lifetime = self.lifetime - 1
                if self.lifetime == 0 then 
                    self:delete()
                end                
            end



            field:spawn(highlight_spell, player:get_tile(player:get_facing(), 1))
        end

        local function create_punch(player)
            punch_spell = Battle.Spell.new(player:get_team())
            local field = player:get_field()

            local hit_props = HitProps.new(
                90 + player:get_attack_level()*20,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                Element.Break, 
                player:get_context(), 
                Drag.None
            )

            punch_spell:set_hit_props(hit_props)
            punch_spell.lifetime = 2

            punch_spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self.lifetime = self.lifetime - 1
                if self.lifetime == 0 then 
                    self:delete()
                end

            end

            punch_spell.attack_func = function(self, other)
                Engine.play_audio(HIT_SFX, AudioPriority.Low)
                local artifact = graphic_init("artifact", 30, 0, "overlay_fx05_animations.png", "overlay_fx05_animations.animation", -7, "1", player, player:get_facing(), true)
                field:spawn(artifact, other:get_current_tile())

            end

            punch_spell.collision_func = function(self, other)
                
            end


            local t = player:get_tile(player:get_facing(), 1)
            if t and not t:is_edge() then 
                field:spawn(punch_spell, t)
            end

            if t:is_walkable() then 
                t:set_state(TileState.Cracked)
                t:set_state(TileState.Broken)
                Engine.play_audio(PUNCH_SFX, AudioPriority.Low)

                local artifact = graphic_init("artifact", 0, 0, "overlay_fx13_animations.png", "overlay_fx13_animations.animation", -6, "0", player, player:get_facing(), true)
                field:spawn(artifact, player:get_tile(player:get_facing(), 1))

                local shake_artifact = Battle.Artifact.new()
                local time = 0
                shake_artifact.update_func = function(self)
                        
                    self:shake_camera(150, 0.016)
                    if time == 40 then 
                        self:delete()
                    end
                
                    time = time+1
                end

                field:spawn(shake_artifact, t)
            end

        end

        action.execute_func = function()
            HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")
            RAISE_SFX =  Engine.load_audio(_modpath.."raise.ogg")
            PUNCH_SFX =  Engine.load_audio(_modpath.."impact.ogg")
            action:add_anim_action(4, function()
                local tile = find_dest(player)
                start_tile:remove_entity_by_id(player:get_id())
                tile:add_entity(player)
                start_tile:reserve_entity_by_id(player:get_id())

            end)

            action:add_anim_action(6, function()
                Engine.play_audio(RAISE_SFX, AudioPriority.Low)
                create_highlight(player)
            end)

            action:add_anim_action(12, function()
                create_punch(player)
            end)

            action:add_anim_action(18, function()
                player:get_current_tile():remove_entity_by_id(player:get_id())
                start_tile:add_entity(player)
            end)

        end


        action.action_end_func = function()
            if highlight_spell and not highlight_spell:is_deleted() then 
                highlight_spell:delete()
            end

            if punch_spell and not punch_spell:is_deleted() then 
                punch_spell:delete()
            end

        end
    

        return action
    end


    player.charged_attack_func = metal_blade
    player.update_func = function(self)
        if self:input_has(Input.Pressed.Special) then 
            if self.charged_attack_func == metal_blade then 
                self.charged_attack_func = metal_fist
            else
                self.charged_attack_func = metal_blade
            end
        end


    end
end
