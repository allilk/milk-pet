nonce = function() end

local BUSTER_TEXTURE = nil
local BUSTER_ANIMATION_PATH = nil
local TARGET_TEXTURE = nil
local TARGET_ANIMATION_PATH = nil
local TILE_HIT_TEXTURE = nil
local TILE_HIT_ANIMATION_PATH = nil
local HURT_SFX = nil
local GUN_SFX = nil

function package_init(package)
  package:declare_package_id("com.discord.Konstinople#7692.card.MachGun2")
  package:set_icon_texture(Engine.load_texture(_modpath.."icon1.png"))
  package:set_preview_texture(Engine.load_texture(_modpath.."preview1.png"))
  package:set_codes({'E', 'G', 'S'})

  local props = package:get_card_props()
  props.shortname = "MachGun2" -- MachGun3
  props.damage = 50 -- 90
  props.time_freeze = false
  props.element = Element.Cursor
  props.description = "Fire 9sts at row w/clst enmy"

  -- assign the global resources
  BUSTER_TEXTURE = Engine.load_texture(_modpath.."machgun_buster.png")
  BUSTER_ANIMATION_PATH = _modpath.."machgun_buster.animation"
  TARGET_TEXTURE = Engine.load_texture(_modpath.."target.png")
  TARGET_ANIMATION_PATH = _modpath.."target.animation"
  TILE_HIT_TEXTURE = Engine.load_texture(_modpath.."tile_hit.png")
  TILE_HIT_ANIMATION_PATH = _modpath.."tile_hit.animation"
  GUN_SFX = Engine.load_audio(_modpath.."gun.ogg")
  HURT_SFX = Engine.load_audio(_modpath.."hurt.ogg")
end

local function spawn_attack(actor, x, y, props)
  local field = actor:get_field()
  local team = actor:get_team()

  local spell = Battle.Spell.new(team)
  spell:set_facing(actor:get_facing())
  spell:sprite():set_layer(1)
  spell:set_texture(TILE_HIT_TEXTURE, true)

  local anim = spell:get_animation()
  anim:load(TILE_HIT_ANIMATION_PATH)
  anim:set_state("DEFAULT")
  anim:on_complete(function()
    -- When the animation ends, delete this
    spell:delete()
  end)

  Engine.play_audio(GUN_SFX, AudioPriority.Highest)

  spell:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Impact | Hit.Flinch,
      props.element,
      actor:get_context(),
      Drag.None
    )
  )

  spell.update_func = function()
    spell:get_current_tile():attack_entities(spell)
  end

  spell.attack_func = function(entity)
    -- if entity:hit(GetHitboxProperties()) then
    Engine.play_audio(HURT_SFX, AudioPriority.Low)
    -- end
  end

  field:spawn(spell, x, y)
end

local function spawn_target(actor, x, y, props)
  local field = actor:get_field()
  local team = actor:get_team()

  local spell = Battle.Spell.new(team)
  spell:set_texture(TARGET_TEXTURE, true)
  local anim = spell:get_animation()
  anim:load(TARGET_ANIMATION_PATH)
  anim:set_state("DEFAULT")

  spell:highlight_tile(Highlight.Flash)

  local ATTACK_INTERVAL = 5
  local next_attack = ATTACK_INTERVAL

  spell.update_func = function()
    next_attack = next_attack - 1

    if next_attack <= 0 then
      spawn_attack(actor, x, y, props)
      spell:erase()
    end
  end

  field:spawn(spell, x, y)
end

local function execute(action, actor, props)
  local machgun = action:add_attachment("Buster")
  machgun:sprite():set_texture(BUSTER_TEXTURE, true)
  machgun:sprite():set_layer(-1)

  local machgun_anim = machgun:get_animation()
  machgun_anim:load(BUSTER_ANIMATION_PATH)
  machgun_anim:set_state("FIRE")

  local field = actor:get_field()
  local target = nil
  local target_tile = nil
  local move_up = true
  local first_spawn = true

  local move_rectical
  move_rectical = function(col_move)
    -- Figure out where our last rectical was
    if not target or not target_tile then
      return target_tile
    end

    local char_tile = target:get_current_tile()

    if not char_tile then return target_tile end

    local next_tile = nil

    if col_move and char_tile:x() ~= target_tile:x() then
      if char_tile:x() < target_tile:x() then
        next_tile = field:tile_at(target_tile:x() - 1, target_tile:y())

        if next_tile:is_edge() then
          next_tile = field:tile_at(target_tile:x() + 1, target_tile:y())
        end

        return next_tile
      elseif char_tile:x() > target_tile:x() then
        next_tile = field:tile_at(target_tile:x() + 1, target_tile:y())

        if next_tile:is_edge() then
          next_tile = field:tile_at(target_tile:x() - 1, target_tile:y())
        end

        return next_tile
      end
    end

    -- If you cannot move left/right keep moving up/down
    local step

    if move_up then
      step = -1
    else
      step = 1
    end

    next_tile = field:tile_at(target_tile:x(), target_tile:y() + step)

    if next_tile:is_edge() then
      move_up = not move_up
      return move_rectical(true)
    else
      return next_tile
    end
  end

  local shoot = function()
    if target == nil or target:will_erase_eof() then
      local closest_distance = math.huge
      local actor_x = actor:get_current_tile():x()
      local actor_team = actor:get_team()

      -- find the closest
      field:find_characters(function(character)
        local team = character:get_team()

        if character:will_erase_eof() or team == actor_team or team == Team.Other then
          -- not targetable
          return false
        end

        local x = character:get_current_tile():x()
        local distance = x - actor_x

        if actor:get_facing() == Direction.Left then
          distance = -distance
        end

        if distance < closest_distance then
          closest_distance = distance
          target = character
        end

        return false
      end)

      if target then
        local erase_callback = function()
          target = nil
        end

        field:notify_on_delete(target:get_id(), actor:get_id(), erase_callback)
      end
    end

    if not target_tile and target then
      target_tile = field:tile_at(target:get_current_tile():x(), 3)
    elseif not target_tile and not target then
      -- pick back col
      if actor:get_facing() == Direction.Right then
        target_tile = field:tile_at(6, 3)
      else
        target_tile = field:tile_at(1, 3)
      end
    end

    -- We initially spawn the rectical where we want to start
    -- Do note move it around
    if not first_spawn then
      target_tile = move_rectical(false)
    else
      first_spawn = false
    end

    -- Spawn rectical where the target_tile is positioned which will attack for us
    if target_tile then
      spawn_target(actor, target_tile:x(), target_tile:y(), props)
    end
  end

  -- shoots 9 times total
  for i = 0, 8, 1 do
    action:add_anim_action(2+(i*5), shoot)
  end
end

local WAIT = { 1, 0.0166 }
local FRAME1 = { 1, 0.05 }
local FRAME2 = { 2, 0.033 }

local FRAMES = make_frame_data({
  WAIT,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
  FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
})

function card_create_action(actor, props)
  local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
  action:override_animation_frames(FRAMES)

  action.execute_func = function()
    execute(action, actor, props)
  end

  return action
end
