function package_init(package) 
    package:declare_package_id("com.Dawn.card.requested.CommanderNaviChip")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C', 'B'})

    local props = package:get_card_props()
    props.shortname = "Commander"
    props.damage = 60
    props.time_freeze = true
    props.element = Element.None
    props.description = "Cmdr rain fire from on high!"
    props.long_description = "Commander fires SRMs, targeting the enemy field!"
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE") --The action must be defined so we have something to return. Else the chip won't work!
	local field = user:get_field() --The field being defined is important so we're not wasting processing power grabbing it more than once.
	local enemy_tile_list = {} --Initialize an empty list. We're going to use it in a moment.
    local goal_x = 6 --set the default goal x to 6, assuming facing right.
    local increment_x = 1 --set the default x increment to 1, assuming facing right.
    local tile_state_list = {
        TileState.Grass,
        TileState.Cracked,
        TileState.DirectionDown,
        TileState.DirectionLeft,
        TileState.DirectionRight,
        TileState.DirectionUp,
        TileState.Ice,
        TileState.Lava,
        TileState.Poison,
        TileState.Volcano
    }
    if user:get_facing () == Direction.Left then
        --if they're facing left, however, we want to sweep left to right.
        --this means that we need to set the goal x to 1 so that the loop below will start at the user's tile,
        --sweep towards X 1,
        --and increment -1 from where the user is on each loop instead of +1.
        goal_x = 1
        increment_x = -1
    end
    local user2 = user
    action:set_lockout(make_sequence_lockout()) --Sequence lockout is required for chips that use Steps to work at all.
    action.execute_func = function(self, user)
        for x = user:get_tile():x(), goal_x, increment_x do --For x values starting at the user's tile, ending at the goal x, incremented directionally based on the user's facing, scan the field.
            for y = 1, 3, 1 do --For y values starting at 1, ending at 3, scan the field. This does not need to be modified dynamically.
                local prospective_tile = field:tile_at(x, y) --Assign the tile found to a variable for easy referencing.
                --Check if the tile matches our conditions: it exists and it's not ours. Also, not an edge tile.
                if prospective_tile and prospective_tile:get_team() ~= user:get_team() and not prospective_tile:is_edge() then
                    table.insert(enemy_tile_list, prospective_tile) --Add the tile to the enemy tile list if it clears the above check.
                end
            end
        end
        local actor = self:get_actor() --obtain the stunt double. stunt doubles are used in time freeze to animate instead of the actual character, if I recall.
        actor:hide() --hide the stunt double. we don't want them showing up under our summoned navi.

        --Create our steps.
        local step1 = Battle.Step.new()
        --I use these to do something once during an update function and during other loops, which run multiple times.
        --I often set the do_once back to true even after setting it to false to do something again, so the name isn't entirely accurate.
        local do_once = true
        --The above is necessary here as Steps don't have an execute function. They do, however, have an update function - it just loops.
        --As opposed to an execute function, which runs once when something starts. Just a note for you chip-makers reading this code.
        local user_tile = user:get_tile()
        local texture = Engine.load_texture(_modpath.."CommanderAddon.png")
        local missile_rain_component = Battle.Component.new(user, Lifetimes.Battlestep)
        missile_rain_component.stored_missile_facing = user:get_facing()
        step1.update_func = function(self, dt)
            if do_once then
                print("in the do once")
                local navi = Battle.Artifact.new()
                navi:set_facing(user:get_facing())
                navi:set_texture(texture)
                local anim = navi:get_animation()
                anim:load(_modpath.."CommanderAddon.animation")
                anim:set_state("MISSILE_FIRE")
                anim:refresh(navi:sprite())
                anim:on_frame(4, function()
                    local missile = Battle.Artifact.new()
                    missile:set_facing(navi:get_facing())
                    missile:set_texture(navi:get_texture())
                    local missile_anim = missile:get_animation()
                    missile_anim:copy_from(navi:get_animation())
                    missile_anim:set_state("MISSILE_LAUNCH")
                    missile_anim:refresh(missile:sprite())
                    local point = anim:point("missile")
                    local x_offset = 8
                    if missile:get_facing() == Direction.Left then x_offset = -8 end
                    missile_anim:on_complete(function()
                        missile:set_offset(missile:get_offset().x + x_offset, missile:get_offset().y-8)
                        missile.update_func = function(self, dt)
                            self:set_offset(self:get_offset().x + x_offset, self:get_offset().y-8)
                            if self:get_offset().y <= -64 then self:erase() end
                        end
                    end)
                    Engine.play_audio(AudioType.Wave, AudioPriority.Low)
                    field:spawn(missile, user_tile)
                end)
                anim:on_frame(8, function()
                    local missile = Battle.Artifact.new()
                    missile:set_facing(navi:get_facing())
                    missile:set_texture(navi:get_texture())
                    local missile_anim = missile:get_animation()
                    missile_anim:copy_from(navi:get_animation())
                    missile_anim:set_state("MISSILE_LAUNCH_2")
                    missile_anim:refresh(missile:sprite())
                    local point = anim:point("missile")
                    local x_offset = 8
                    if missile:get_facing() == Direction.Left then x_offset = -8 end
                    missile_anim:on_complete(function()
                        missile:set_offset(missile:get_offset().x + x_offset, missile:get_offset().y-8)
                        missile.update_func = function(self, dt)
                            self:set_offset(self:get_offset().x + x_offset, self:get_offset().y-8)
                            if self:get_offset().y <= -64 then self:erase() end
                        end
                    end)
                    Engine.play_audio(AudioType.Wave, AudioPriority.Low)
                    field:spawn(missile, user_tile)
                end)
                anim:on_frame(12, function()
                    local missile = Battle.Artifact.new()
                    missile:set_facing(navi:get_facing())
                    missile:set_texture(navi:get_texture())
                    local missile_anim = missile:get_animation()
                    missile_anim:copy_from(navi:get_animation())
                    missile_anim:set_state("MISSILE_LAUNCH")
                    missile_anim:refresh(missile:sprite())
                    local point = anim:point("missile")
                    local x_offset = 8
                    if missile:get_facing() == Direction.Left then x_offset = -8 end
                    missile_anim:on_complete(function()
                        missile:set_offset(missile:get_offset().x + x_offset, missile:get_offset().y-8)
                        missile.update_func = function(self, dt)
                            self:set_offset(self:get_offset().x + x_offset, self:get_offset().y-8)
                            if self:get_offset().y <= -64 then self:erase() end
                        end
                    end)
                    Engine.play_audio(AudioType.Wave, AudioPriority.Low)
                    field:spawn(missile, user_tile)
                end)
                anim:on_complete(function()
                    print("we erased the navi, animation complete")
                    missile_rain_component.timer = 40
                    missile_rain_component.current_timer = 0
                    missile_rain_component.shuffled = {}
                    missile_rain_component.shuffled_states = {}
                    missile_rain_component.hits = 0
                    for i, v in ipairs(enemy_tile_list) do
                        local pos = math.random(1, #missile_rain_component.shuffled+1)
                        table.insert(missile_rain_component.shuffled, pos, v)
                    end
                    for i, v in ipairs(tile_state_list) do
                        local pos = math.random(1, #missile_rain_component.shuffled_states+1)
                        table.insert(missile_rain_component.shuffled_states, pos, v)
                    end
                    missile_rain_component.field = field
                    missile_rain_component.eject_timer = 10
                    missile_rain_component.shuffled_index = 1
                    missile_rain_component.shuffled_states_index = 1
                    missile_rain_component.update_func = function(self, dt)
                        if self.hits < 9 then
                            if self.current_timer <= 0 then
                                self.hits = self.hits + 1
                                self.current_timer = self.timer
                                local owner = self:get_owner()
                                local attack = Battle.Spell.new(owner:get_team())
                                attack:set_texture(Engine.load_texture(_modpath.."CommanderAddon.png", true))
                                attack:set_facing(self.stored_missile_facing)
                                local attack_anim = attack:get_animation()
                                attack_anim:load(_modpath.."CommanderAddon.animation")
                                attack_anim:set_state("MISSILE_FALL")
                                attack_anim:set_playback(Playback.Loop)
                                attack_anim:refresh(attack:sprite())
                                local x_offset = -80
                                attack.x_increment = 16
                                if self.stored_missile_facing == Direction.Left then
                                    x_offset = 80
                                    attack.x_increment = -16
                                end
                                attack.y_increment = 24
                                attack:set_offset(x_offset, -120)
                                attack.timer = 5
                                attack.current_timer = 0
                                attack:set_hit_props(
                                    HitProps.new(
                                        props.damage,
                                        Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Breaking,
                                        Element.None,
                                        owner:get_context(),
                                        Drag.None
                                    )
                                )
                                attack.can_move_to_func = function(tile)
                                    return true
                                end
                                local occupied_query = function(ent)
                                    return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
                                end
                                attack.is_destroying = false
                                attack.update_func = function(self, dt)
                                    self:get_tile():highlight(Highlight.Flash)
                                    if self.is_destroying then
                                        self:set_offset(0, 0)
                                    end
                                    if self:get_offset().y >= 0 and not self.is_destroying then
                                        self.is_destroying = true
                                        self:get_tile():highlight(Highlight.None)
                                        local tile = self:get_tile()
                                        tile:attack_entities(self)
                                        if #tile:find_entities(occupied_query) == 0 then
                                            if tile:is_walkable() then
                                                tile:set_state(missile_rain_component.shuffled_states[missile_rain_component.shuffled_states_index])
                                                missile_rain_component.shuffled_states_index = missile_rain_component.shuffled_states_index + 1
                                                if missile_rain_component.shuffled_states_index > #missile_rain_component.shuffled_states then
                                                    missile_rain_component.shuffled_states_index = 1
                                                end
                                            end
                                        end
                                        if tile:is_walkable() then
                                            Engine.play_audio(AudioType.Explode, AudioPriority.Low)
                                            local animation = self:get_animation()
                                            animation:set_state("EXPLOSION_PANEL")
                                            animation:refresh(self:sprite())
                                            animation:on_complete(function()
                                                self:erase()
                                            end)
                                        else
                                            self:set_texture(Engine.load_texture(_modpath.."mob_move.png"), true)
                                            local animation = self:get_animation()
                                            animation:load(_modpath.."mob_move.animation")
                                            animation:set_state("DEFAULT")
                                            animation:refresh(self:sprite())
                                            animation:on_complete(function()
                                                self:erase()
                                            end)
                                        end
                                    elseif self:get_offset().y < 0 and not self.is_destroying then
                                        if self.current_timer <= 0 then
                                            self:set_offset(self:get_offset().x + self.x_increment, self:get_offset().y + self.y_increment)
                                        else
                                            self.current_timer = self.current_timer - 1
                                        end
                                    end
                                end
                                self.field:spawn(attack, self.shuffled[self.shuffled_index])
                                missile_rain_component.shuffled_index = missile_rain_component.shuffled_index + 1
                                if missile_rain_component.shuffled_index > #missile_rain_component.shuffled then
                                    missile_rain_component.shuffled_index = 1
                                end
                            else
                                missile_rain_component.current_timer = missile_rain_component.current_timer - 1
                            end
                        else
                            if self.eject_timer <= 0 then
                                self:eject()
                            else
                                self.eject_timer = self.eject_timer - 1
                            end
                        end
                    end
                    user2:register_component(missile_rain_component)
                    navi:erase()
                    actor:reveal()
                    self:complete_step()
                end)
                field:spawn(navi, user_tile)
                do_once = false
            end
        end
        self:add_step(step1)
    end
    return action
end