function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

local DAMAGE = 240

local VOICE_FIREBOMB_1 = Engine.load_audio(_modpath.."faiabomu_1.ogg")
local VOICE_FIREBOMB_2 = Engine.load_audio(_modpath.."faiabomu_2.ogg")
local VOICE_FIREBOMB_3 = Engine.load_audio(_modpath.."faiabomu_3.ogg")

local NAPALMMAN_TEXTURE = Engine.load_texture(_modpath.."napalmman.png")
local NAPALMMAN_ANIMPATH = _modpath.."napalmman.animation"
local FIREBOMB_TEXTURE = Engine.load_texture(_modpath.."firebomb.png")
local FIREBOMB_ANIMPATH = _modpath.."firebomb.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_SHOOT = Engine.load_audio(_modpath.."shoot.ogg")

local BOOM_TEXTURE = Engine.load_texture(_modpath.."boom1.png")
local BOOM_ANIMPATH = _modpath.."boom1.animation"
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")

local WARP_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local WARP_ANIMPATH = _modpath.."mob_move.animation"

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-243-NapalmManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"N"})

    local props = package:get_card_props()
    props.shortname = "NaplmMnV2"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "FireBombs break panels!"
    props.long_description = "Explode the front with bombs that destroy panels!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local NOT_HOLE = true

		local VOICEACTING = false
        local input_time = 40
        local voiceline_number = 0

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local naviX = user:get_tile():x()
        local tilerange_i
        local tilerange_j
        
        if direction == Direction.Right then
            tilerange_i = naviX + 2
            tilerange_j = tilerange_i + 2
            if tilerange_j > 6 then
                tilerange_j = 6
            end
        else
            tilerange_j = naviX - 2
            tilerange_i = tilerange_j - 2
            if tilerange_i < 1 then
                tilerange_i = 1
            end
        end

        local query = function(ent)
            if not user:is_team(ent:get_team()) then
                return true
            end
        end

        local targets = {}
        local trg_count = 1

        local target_enemy = {}
        local enemy_targeted = false

        for i = tilerange_i, tilerange_j do
            for j = 1, 3 do
                print("Attack range tile: ("..i..";"..j..")")
                local tile = field:tile_at(i,j)
                targets[trg_count] = tile
                trg_count = trg_count + 1
                --[[if #tile:find_characters(query) > 0 then
                    enemy_targeted = true
                    table.insert(target_enemy, field:tile_at(i,j))
                    break
                end]]
            end
        end

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)

        if not user:get_current_tile():is_hole() then
            NOT_HOLE = true
        else
            NOT_HOLE = false
        end

        self.navi = nil
        self.tile = user:get_current_tile()
        
		local step1 = Battle.Step.new()

        local ref = self

        local do_once = true
        local do_once_2 = true
        local do_once_3 = true
        step1.update_func = function(self, dt)
			if input_time > 0 then
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
            end
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(user:get_facing())
		    	ref.navi:set_texture(NAPALMMAN_TEXTURE, true)
		    	ref.navi:sprite():set_layer(-3)

                local navi_anim = ref.navi:get_animation()
                navi_anim:load(NAPALMMAN_ANIMPATH)
                navi_anim:set_state("SPAWN")
                navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
                    print("Attack range: ("..tilerange_i..";"..tilerange_j..")")
                    print("Target tiles count: "..trg_count-1)
                    voiceline_number = math.random(1,3)
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                end)
		    	navi_anim:on_complete(function()
                    if NOT_HOLE then
                            if trg_count - 1 >= 5 then
                            navi_anim:set_state("ATTACK5")
                            navi_anim:refresh(ref.navi:sprite())
                        elseif trg_count - 1 == 3 then
                            navi_anim:set_state("ATTACK3")
                            navi_anim:refresh(ref.navi:sprite())
                        elseif trg_count - 1 <= 0 then
                            navi_anim:set_state("END")
                            navi_anim:refresh(ref.navi:sprite())
                        end
                    else
                        navi_anim:set_state("END")
                        navi_anim:refresh(ref.navi:sprite())
                    end
		    	end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK5" or anim:get_state() == "ATTACK3" then
                if do_once_2 then
                    do_once_2 = false
                    anim:on_frame(2, function()
                        shuffle(targets)
                    end)
                    anim:on_frame(3, function()
                        print("NapalmMan: FireBomb!")
                        if VOICEACTING then
                            if voiceline_number == 1 then
                                Engine.play_audio(VOICE_FIREBOMB_1, AudioPriority.Highest)
                            elseif voiceline_number == 2 then
                                Engine.play_audio(VOICE_FIREBOMB_2, AudioPriority.Highest)
                            elseif voiceline_number == 3 then
                                Engine.play_audio(VOICE_FIREBOMB_3, AudioPriority.Highest)
                            end
                        end
                        Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                        local frames_in_air = 40
                        local toss_height = 70
                        local target_tile = field:tile_at(targets[1]:x(),targets[1]:y())
                        local enemy_check = #target_tile:find_characters(query) > 0
                        action.on_landing = function()
                            if not target_tile:is_hole() then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            elseif enemy_check then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            else
                                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, 0, field, target_tile)
                            end
                        end
                        toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
                    end)
                    anim:on_frame(9, function()
                        Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                        local frames_in_air = 40
                        local toss_height = 70
                        local target_tile = field:tile_at(targets[2]:x(),targets[2]:y())
                        local enemy_check = #target_tile:find_characters(query) > 0
                        action.on_landing = function()
                            if not target_tile:is_hole() then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            elseif enemy_check then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            else
                                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, 0, field, target_tile)
                            end
                        end
                        toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
                    end)
                    anim:on_frame(15, function()
                        Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                        local frames_in_air = 40
                        local toss_height = 70
                        local target_tile = field:tile_at(targets[3]:x(),targets[3]:y())
                        local enemy_check = #target_tile:find_characters(query) > 0
                        action.on_landing = function()
                            if not target_tile:is_hole() then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            elseif enemy_check then
                                hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                            else
                                create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, 0, field, target_tile)
                            end
                        end
                        toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
                    end)
                    anim:on_frame(21, function()
                        if anim:get_state() == "ATTACK5" then
                            Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                            local frames_in_air = 40
                            local toss_height = 70
                            local target_tile = field:tile_at(targets[4]:x(),targets[4]:y())
                            local enemy_check = #target_tile:find_characters(query) > 0
                            action.on_landing = function()
                                if not target_tile:is_hole() then
                                    hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                                elseif enemy_check then
                                    hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                                else
                                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, 0, field, target_tile)
                                end
                            end
                            toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
                        end
                    end)
                    anim:on_frame(27, function()
                        if anim:get_state() == "ATTACK5" then
                            Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                            local frames_in_air = 40
                            local toss_height = 70
                            local target_tile = field:tile_at(targets[5]:x(),targets[5]:y())
                            --[[if enemy_targeted then
                                target_tile = field:tile_at(target_enemy[1]:x(),target_enemy[1]:y())
                            else
                                target_tile = field:tile_at(targets[5]:x(),targets[5]:y())
                            end]]
                            local enemy_check = #target_tile:find_characters(query) > 0
                            action.on_landing = function()
                                if not target_tile:is_hole() then
                                    hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                                elseif enemy_check then
                                    hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
                                else
                                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, 0, field, target_tile)
                                end
                            end
                            toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
                        end
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
                        anim:refresh(ref.navi:sprite())
                    end)
                end
            end
            if anim:get_state() == "END" then
                if do_once_3 then
                    do_once_3 = false 
                    anim:on_complete(function()
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function toss_spell(tosser, team, toss_height, frames_in_air, arrival_callback, field, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local spell = Battle.Spell.new(team)
    spell:set_shadow(Shadow.Small)
    local spell_animation = spell:get_animation()
    spell_animation:load(FIREBOMB_ANIMPATH)
    spell_animation:set_state("0")
    spell_animation:set_playback(Playback.Loop)
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = -36
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(FIREBOMB_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    print("Fire Bomb created. Target tile: ("..target_tile:x()..";"..target_tile:y()..")")
    field:spawn(spell, start_tile)
end

function hit_explosion(user, props, team, direction, field, target_tile, enemy_check)
    local spell = Battle.Spell.new(team)
    spell:get_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
    local spell_animation = spell:get_animation()
    spell_animation:load(BOOM_ANIMPATH)
    spell_animation:set_state("0")
    local sprite = spell:sprite()
    sprite:set_texture(BOOM_TEXTURE)
    spell_animation:refresh(sprite)
    spell_animation:on_frame(1, function()
        if not enemy_check then
            target_tile:set_state(TileState.Broken)
        end
    end)
    spell_animation:on_complete(function()
		spell:erase()
	end)
    spell.has_attacked = false
    spell.update_func = function(self)
        spell:get_current_tile():attack_entities(self)
        if not spell.has_attacked then
            spell_animation:on_frame(2, function()
                Engine.play_audio(AUDIO_BOOM, AudioPriority.Highest)
            end)
        end
    end
    spell.attack_func = function(self)
        spell.has_attacked = true
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    field:spawn(spell, target_tile)
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end