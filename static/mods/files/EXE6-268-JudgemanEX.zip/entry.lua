local DAMAGE = 120

local TEXTURE_NAVI = Engine.load_texture(_modpath .. "judgeman.png")
local NAVI_ANIMATION = _modpath .. "judgeman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath .. "spawn.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM = _modpath .. "effect.animation"
local BOOK_DMG = 30

---@type FieldHelper
local field_helper = include("field_helper.lua")


function package_init(package)
    package:declare_package_id("com.louise.card.EXE6-268-JudgeManEX")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "J" })

    local props = package:get_card_props()
    props.shortname = "JudgMnEX"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Elec
    props.description = "Whip 3 panels forward"
    props.long_description = "Whip 3 panels forward. Recover area too."
    props.can_boost = true
    props.card_class = CardClass.Mega
    props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
        actor:hide()
        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_spawn = true
        local do_whip = true
        step1.update_func = function(self, dt)
            if do_spawn then
                do_spawn = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
                ref.navi:set_texture(TEXTURE_NAVI, true)
                ref.navi:sprite():set_layer(-1)
                navi_anim = ref.navi:get_animation()
                navi_anim:load(NAVI_ANIMATION)
                --- warp in navi.
                navi_anim:set_state("WARP_IN")
                navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                navi_anim:on_complete(function()
                    -- judge whip
                    navi_anim:set_state("JUDGE_WHIP")
                    navi_anim:refresh(ref.navi:sprite())
                end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "JUDGE_WHIP" then
                if do_whip then
                    do_whip = false
                    anim:on_frame(1, function()
                        print("Judgeman: Bind Chain!")
                        ref.whip = create_whip(user, props)
                    end)
                    anim:on_frame(3, function()
                        ref.whip.shock_ready = true
                        Engine.play_audio(AudioType.Thunder, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                        if (field_helper.is_userarea_disadvantaged(user)) then
                            anim:set_state("SUMMON")
                            anim:on_complete(function()
                                print("Judgeman: The books!")
                                ref.book_tracker = { count = 0 }
                                summon_books(user, ref.book_tracker)
                                Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                                anim:set_state("IDLE_WAIT_FOR_BOOKS")
                            end)
                        else
                            print("Judgeman: No books!")
                            anim:set_state("WARP_OUT")
                            anim:on_complete(function()
                                ref.navi:erase()
                                step1:complete_step()
                            end)
                        end
                    end)
                end
            elseif (anim:get_state() == "IDLE_WAIT_FOR_BOOKS") then
                if (ref.book_tracker.count <= 0) then
                    anim:set_state("WARP_OUT")
                    anim:on_complete(function()
                        reclaim_area(user)
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function spawn_whip_hitbox(field, spell, desired_tile)
    local hitbox = Battle.Spell.new(spell:get_team())
    hitbox:set_hit_props(spell:copy_hit_props())
    field:spawn(hitbox, desired_tile)
    return hitbox
end

function reclaim_area(user)
    local reclaim_columns = field_helper.get_reclaimable_columns(user)
    for index, x in ipairs(reclaim_columns) do
        for y = 1, 3, 1 do
            user:get_field():tile_at(x, y):set_team(user:get_team(), true)
        end
    end
end

function create_whip(user, props)
    local direction = user:get_facing()
    local spell = Battle.Spell.new(user:get_team())
    local tile = user:get_tile(direction, 1)
    local field = user:get_field()
    local spell_animation = spell:get_animation()
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Stun | Hit.Pierce | Hit.Retangible,
            Element.Elec,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    spell_animation:load(NAVI_ANIMATION)
    spell_animation:set_state("WHIP")
    spell:set_texture(TEXTURE_NAVI)
    spell:sprite():set_layer(5)
    spell_animation:refresh(spell:sprite())

    spell_animation:on_complete(function()
        spell:erase()
    end)

    user:get_field():spawn(spell, tile)
    local hitbox1 = spawn_whip_hitbox(field, spell, tile:get_tile(direction, 1))
    local hitbox2 = spawn_whip_hitbox(field, spell, tile:get_tile(direction, 2))

    spell.update_func = function()
        if (spell.shock_ready) then
            spell:get_current_tile():attack_entities(spell)
            hitbox1:get_current_tile():attack_entities(hitbox1)
            hitbox2:get_current_tile():attack_entities(hitbox2)
            spell.shock_ready = false
        end
    end


    local judge_hit = function(self)
        create_basic_effect(user:get_field(), self:get_current_tile(), HIT_TEXTURE, HIT_ANIM, "ELEC")
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end

    spell.attack_func = judge_hit
    hitbox1.attack_func = judge_hit
    hitbox2.attack_func = judge_hit
    return spell
end

--- Summons the books.
---@param user any
---@param book_tracker {} keeps track of active books.
function summon_books(user, book_tracker)
    local book_tiles = field_helper.get_stolen_tiles(user)
    local delay = 12
    --delay per book is 12 + 16 frames initially
    book_tracker.count = #book_tiles
    -- ~ 12 frame delay before book moves
    for index, tile in ipairs(book_tiles) do
        create_book(user, tile, delay * index + 16, book_tracker)
    end
end

---comment
---@param user any The caster of the spell
---@param tile any Tile the book will be spawned at
---@param delay number delay in frames before book moves.
---@return Spell | nil
function create_book(user, tile, delay, book_tracker)
    local direction = user:get_facing()
    local spell = Battle.Spell.new(user:get_team())
    local query = function() return true end
    if (not tile:is_walkable() or #tile:find_characters(query) > 0 or #tile:find_obstacles(query) > 0) then
        book_tracker.count = book_tracker.count - 1
        return nil
    end
    local spell_animation = spell:get_animation()
    local book_speed = 20
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            BOOK_DMG,
            Hit.Impact | Hit.Flinch,
            Element.None,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    spell_animation:load(NAVI_ANIMATION)
    spell_animation:set_state("BOOK_SPAWN")
    spell_animation:on_complete(function()
        spell_animation:set_state("BOOK_EAT")
        spell_animation:set_playback(Playback.Loop)
    end)
    spell:set_texture(TEXTURE_NAVI)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)
    spell.current_dir = spell:get_facing()
    spell.next_tile = tile
    spell.current_tile = tile

    -- code to decide book's path.
    local update_direction = function(book)
        if (field_helper.find_target_in_field(book) == nil) then
            --no alive targets, destroy books.
            book_tracker.count = book_tracker.count - 1
            spell:erase()
            return
        end
        local next_dir = book.current_dir
        local target_char = field_helper.find_target_in_row(book:get_current_tile():y(), user:get_field(),
            user:get_team())
        if (target_char == nil) then
            next_dir = field_helper.get_direction_towards_target(book)
        else -- go back if need to go backwards
            if (target_char:get_tile() == book:get_current_tile()) then
                book_tracker.count = book_tracker.count - 1
                spell:erase()
                return
            end
            if (not check_if_can_reach(book, target_char, book.current_dir)) then
                next_dir = Direction.reverse(spell.current_dir)
            end
        end
        book.next_tile = book:get_current_tile():get_tile(next_dir, 1)
    end

    spell.delay = delay

    user:get_field():spawn(spell, tile)

    spell.update_func = function()
        if (spell.delay > 0) then
            spell.delay = spell.delay - 1
            return
        end
        if (spell.next_tile:is_edge() or not spell:get_current_tile():is_walkable()) then
            book_tracker.count = book_tracker.count - 1
            spell:erase()
        end
        if (not spell:is_sliding()) then
            update_direction(spell)
            spell:slide(spell.next_tile, frames(book_speed), frames(0), ActionOrder.Voluntary, nil)
        end
        spell:get_current_tile():attack_entities(spell)
    end
    local book_hit = function(self)
        create_basic_effect(user:get_field(), self:get_current_tile(), HIT_TEXTURE, HIT_ANIM, "8")
        spell:erase()
        book_tracker.count = book_tracker.count - 1
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.collision_func = book_hit
    return spell
end

---Check if entity1 can reach entity2 by traveling in direction
---@param entity1 any
---@param entity2 any
function check_if_can_reach(entity1, entity2, direction)
    local x1 = entity1:get_current_tile():x()
    local x2 = entity2:get_current_tile():x()
    if (direction == Direction.Right) then
        return x2 > x1
    else
        return x2 < x1
    end
end

function tiletostring(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end
