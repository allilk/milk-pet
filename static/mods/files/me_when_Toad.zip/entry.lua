function package_init(package)
    package:declare_package_id("com.isabelle.player.PermaToadSoul")
    package:set_special_description("perma toad soul")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_overworld_animation_path(_folderpath .. "overworld.animation")
    package:set_overworld_texture_path(_folderpath .. "overworld.png")
    package:set_mugshot_texture_path(_folderpath .. "mug.png")
    package:set_mugshot_animation_path(_folderpath .. "mug.animation")
end

function player_init(player)
    player:set_name("Toad Soul")
    player:set_health(1000)
    player:set_element(Element.Aqua)
    player:set_height(38.0)
    local base_texture = Engine.load_texture(_folderpath .. "battle.png")
    local chaos_texture = Engine.load_texture(_folderpath .. "chaos_battle.png")
    local base_animation_path = _folderpath .. "battle.animation"
    local base_charge_color = Color.new(57, 198, 243, 255)
    local chaos_charge_color = Color.new(200, 150, 200, 255)
    local BUSTER_TEXTURE = Engine.load_texture(_folderpath .. "widebust.png")
    local SHOT_TEXTURE = Engine.load_texture(_folderpath .. "wideshot.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    -- this var doesn't receive meaning at this point, but it's defined here so that it can remain in scope for the navi's lifetime.
    local dive_sprite = nil

    local submerge = Battle.DefenseRule.new(5438970, DefenseOrder.Always)
    player.am_moist = false
    local hole_already = false

    local prev_panel
    local tile_time = { 0, 0 }

    -- ^ When a variable is set to `false` or `nil`, this means you can have a condition such as `if variable then`,
    -- and the conditional statement will not run if the var is currently `false` or `nil`. This way don't have to specify `if variable == true then`.
    -- However, if the var is ANY other value, then `if variable then` will resolve as true.
    -- This means the value of a numerical zero is not a good way to designate `false`, because a value of zero returns true!
    -- Not every programming language is like this. Some treat 0 as false, but lua treats 0 as true, so we have to plan accordingly.

    -- remember: `can_block_func` is a type of function defined by the engine,
    -- so the logic in the defense rule needs to be defined with this name.
    submerge.can_block_func = function(judge, attacker)

        -- player.am_moist determines whether this defense rule will actively block attacks.
        -- It only blocks attacks when moist is true.
        -- The defense rule doesn't need to be removed when moisture is false because it can decide for itself whether
        -- it should be blocking damage, and it can allow damage through even while the defense rule is technically active.
        if not player.am_moist then
            return
        end
        -- ^ this if-statement runs `return` when it's true, which means it finishes this function early and nothing below
        -- this line gets ran. So everything below this line only runs when am_moist is true.

        local hitprops = attacker:copy_hit_props()

        if hitprops.element == Element.Elec or hitprops.element == Element.Cursor then
            judge:signal_defense_was_pierced()
            return
        end

        judge:block_impact()
        judge:block_damage()
    end
    -- This line is in the root of player_init. This means it's immediately ran once at battle start.
    -- The defense rule only needs to be added once. It can stay active for the full lifetime of the navi without issue.
    player:add_defense_rule(submerge)

    -- This is the function for the player that runs every frame, unconditionally. It always runs, every frame, regardless of what your navi is doing.
    -- Only one update_func can exist for your navi, so put all of your "run every frame" logic in this one function.

    local fluctuate_cooldown_table = { 150, 120, 90, 60, 30 }
    local fluctation_level = 1
    local fluctuation_cooldown = 0
    local will_charge_shot_whiff = false
    local off_color_chaos_charge = Color.new(75, 250, 200, 255)
    local Chaos = player:create_form()
    Chaos:set_mugshot_texture_path(_modpath .. "Chaos_Entry.png")
    local is_chaos = false
    Chaos.on_activate_func = function(self, player)
        player:set_texture(chaos_texture)
        player:set_fully_charged_color(chaos_charge_color)
        is_chaos = true
    end
    Chaos.on_deactivate_func = function(self, player)
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        is_chaos = false
    end
    Chaos.charged_attack_func = function(player)
        --comment out this line in the next build.
        player:set_fully_charged_color(chaos_charge_color)
        --comment out the above line in the next build.
        if not will_charge_shot_whiff then
            if fluctation_level + 1 <= #fluctuate_cooldown_table then
                fluctation_level = fluctation_level + 1
            end
            print("in create_card_action()!")
            local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
            action:set_lockout(make_animation_lockout())
            local props = HitProps.new(
                    (player:get_attack_level() * 10) + 150,
                    Hit.Impact | Hit.Flinch | Hit.Flash,
                    Element.Aqua,
                    player:get_context(),
                    Drag.None
            )
            action.execute_func = function(self, user)
                local buster = self:add_attachment("BUSTER")
                buster:sprite():set_texture(BUSTER_TEXTURE, true)
                buster:sprite():set_layer(-1)

                local buster_anim = buster:get_animation()
                buster_anim:load(_modpath .. "widebust.animation")
                buster_anim:set_state("DEFAULT")
                self:add_anim_action(3, function()
                    local cannonshot = create_sonic_slash(player, props, SHOT_TEXTURE)
                    local tile = player:get_tile(player:get_facing(), 1)
                    player:get_field():spawn(cannonshot, tile)
                end)
            end
            return action
        else
            local props = HitProps.new(
                    100,
                    Hit.Impact | Hit.Flinch,
                    Element.Elec,
                    player:get_context(),
                    Drag.None
            )
            local hitbox = Battle.Hitbox.new(Team.Other)
            hitbox:set_hit_props(props)
            player:get_field():spawn(hitbox, player:get_tile())
        end
    end
    local initial_charge_cooldown = 110
    local current_charge_cooldown = 0
    player.update_func = function(self, dt)
        if not prev_panel then
            prev_panel = player:get_current_tile()
        end
        local latest = self:get_current_tile()
        if latest:get_state() == TileState.Ice then
            tile_time[1] = tile_time[1] + 1
            tile_time[2] = 0
        else
            tile_time[2] = tile_time[2] + 1
            if tile_time[2] > 60 then
                tile_time[1] = 0
                tile_time[2] = 0
            end
        end
        if tile_time[1] > 30 then
            if latest ~= prev_panel then
                prev_panel:set_state(TileState.Normal)
                tile_time[1] = 0
            end
            prev_panel = self:get_current_tile()
        end

        if player:input_has(Input.Held.Shoot) and is_chaos then
            if current_charge_cooldown >= initial_charge_cooldown then
                current_charge_cooldown = initial_charge_cooldown
                if fluctuation_cooldown >= fluctuate_cooldown_table[fluctation_level] then
                    if will_charge_shot_whiff then
                        will_charge_shot_whiff = false
                        Engine.play_audio(AudioType.ChipConfirm, AudioPriority.High)
                        player:set_fully_charged_color(off_color_chaos_charge)
                    else
                        will_charge_shot_whiff = true
                        Engine.play_audio(AudioType.ChipCancel, AudioPriority.High)
                        player:set_fully_charged_color(chaos_charge_color)
                    end
                    fluctuation_cooldown = 0
                else
                    fluctuation_cooldown = fluctuation_cooldown + 1
                end
            else
                current_charge_cooldown = current_charge_cooldown + 1
            end
        end

        if not hole_already then
            hole_artifact(player)
            hole_already = true
        end

        -- every frame, first bind the animation component of the player to a local var
        local anim = player:get_animation()

        -- get the name of the animation that the player is currently performing
        local current_anim = anim:get_state()

        -- define a small function to use in the conditional block below. This will remove a minor amount of redundancy.
        local function surface()
            if player.am_moist then
                player.am_moist = false
                player:reveal() [[]erase_hole_artifact(user)]]

            end
        end

        -- if on the designated panel type
        if player:get_current_tile():get_state() == TileState.Ice then
            -- Observe the navi's animation to get the "pop up" effect where it isn't protected while attacking.
            -- Also handle the logic for re-submerging from an unprotected state.
            if current_anim == "PLAYER_IDLE" or player:is_moving() then
                if not player.am_moist then
                    -- Have unique behavior when becoming newly submerged. This conditional will not run again until the next time you enter a
                    -- panel that doesn't cause the submerged state, or until you attack and return to idle state.
                    player:hide()

                end
                player.am_moist = true
            else
                surface()
            end
            -- not on ice, never be moist
        else
            surface()
        end
    end

    function hole_artifact(user)
        local tile = user:get_current_tile()

        local visual_artifact = Battle.Artifact.new()
        visual_artifact:set_float_shoe(true)
        local field = user:get_field()

        visual_artifact:set_texture(base_texture)

        local visual_artifact_anim = visual_artifact:get_animation()
        visual_artifact_anim:load(_modpath .. "battle.animation")
        visual_artifact_anim:set_state("PLAYER_DIVE_IDLE")

        visual_artifact.can_move_to_func = function()
            return true
        end

        visual_artifact.update_func = function()
            visual_artifact:teleport(user:get_current_tile(), ActionOrder.Immediate, nil)

            if player.am_moist then
                visual_artifact:reveal()
                player:hide()
            else
                visual_artifact:hide()
                player:reveal()
            end
        end

        if not hole_already then
            field:spawn(visual_artifact, tile)
            hole_already = true
        end

    end

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        return special_card_action(player)
    end

    function special_card_action(user)
        local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
        action:set_lockout(make_animation_lockout())
        action.execute_func = function(self, user)
            local buster = self:add_attachment("Buster")

            buster:sprite():set_texture(base_texture)
            buster:sprite():set_layer(-1)

            local buster_anim = buster:get_animation()
            buster_anim:load(_modpath .. "battle.animation")
            buster_anim:set_state("Buster")

            local do_attack = function()
                --get the tile you want to initially spawn the spell on.
                local t1 = (user:get_tile(user:get_facing(), 1))
                --setup a search query to find beings who exist, aren't deleted, and aren't on the same team as the user.
                local target_query = function(ent)
                    return ent ~= nil and not ent:is_deleted() and not ent:is_team(user:get_team())
                end
                --search the field for all targets matching that query,
                local target_search = user:get_field():find_characters(target_query)
                --and set the target to be sent to nil. We may not find anything.
                local target = nil
                --set an absurd distance so that the first target found is guaranteed to be matched.
                local distance = 999
                --if the target search returns characters, loop over the list and check the distance between the X value of the spell's intended tile,
                --and the X value of the found target's tile. If it's less than distance, which the first one will be, set the target variable to that
                --character and set the distance to the calculated difference in X values.
                if #target_search > 0 then
                    for i = 1, #target_search, 1 do
                        local search_entry = target_search[i]
                        if math.abs(search_entry:get_tile():x() - t1:x()) < distance then
                            target = search_entry
                            distance = math.abs(search_entry:get_tile():x() - t1:x())
                        end
                    end
                end
                --spawn the attack with the following inputs: user of the attack, the direction they're facing (for initial tracking),
                --the opposite of the way they're facing (for resetting the direction of the projectile), the tile, and the target, which may be ni.
                spawn_attack(user, user:get_facing(), user:get_facing_away(), t1, target)
            end
            self:add_anim_action(2, do_attack)
        end
        return action
    end

    function spawn_attack(user, track_direction, direction, t1, target)
        local spawn_next
        spawn_next = function()
            local spell = Battle.Spell.new(user:get_team())
            spell:set_facing(direction)

            spell:set_hit_props(
                    HitProps.new(
                            (player:get_attack_level() * 10) + 20,
                            Hit.Flinch | Hit.Stun | Hit.Impact,
                            Element.Elec,
                            user:get_context(),
                            Drag.None
                    )
            )
            --make sure the spell can move to any tile.
            spell.can_move_to_func = function()
                return true
            end
            --attack entities on spell update every frame
            spell.update_func = function(self, dt)
                self:get_tile():attack_entities(self)
            end

            local animation = spell:get_animation()
            spell:set_texture(base_texture)
            spell:get_animation():load(_modpath .. "battle.animation")
            spell:get_animation():set_state("PLAYER_SPECIAL_CS")
            animation:on_frame(3, function()
                --Here comes the fun part. The tracking. If the target is NOT nil,
                --then we update the input track_direction based on whether or not
                --that target's Y coordinate is above or below the spell's current tile,
                --represented as t1.

                --If it's on the same row, the direction is reset.
                if target ~= nil then
                    if track_direction == Direction.Right then
                        if target:get_tile():y() < t1:y() then
                            track_direction = Direction.UpRight
                        elseif target:get_tile():y() > t1:y() then
                            track_direction = Direction.DownRight
                        end
                    elseif track_direction == Direction.Left then
                        if target:get_tile():y() < t1:y() then
                            track_direction = Direction.UpLeft
                        elseif target:get_tile():y() > t1:y() then
                            track_direction = Direction.DownLeft
                        end
                    end
                end
                --set t1 to equal the tile in the direction we picked, and
                t1 = t1:get_tile(track_direction, 1)
                --reset the track direction, and
                track_direction = Direction.reverse(direction)
                --spawn that damn spell. repeat until done.
                spawn_next()
            end)
            animation:on_complete(function()
                if not spell:is_deleted() then
                    spell:erase()
                end
            end)

            spell.collision_func = function(self)
                self:erase()
            end

            user:get_field():spawn(spell, t1)
        end
        spawn_next()
    end
end

function create_sonic_slash(user, props, texture)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(props)
    local anim = spell:get_animation()
    spell:set_texture(texture, true)
    anim:load(_modpath .. "wideshot.animation")
    anim:set_state("DEFAULT")
    spell.update_func = function(self, dt)
        if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
            self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
            self:get_tile():get_tile(Direction.Up, 1):attack_entities(self)
        end
        if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
            self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
            self:get_tile():get_tile(Direction.Down, 1):attack_entities(self)
        end
        self:get_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end

            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true
                    end
            )
        end

    end
    spell.collision_func = function(self, other)
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end

    Engine.play_audio(Engine.load_audio(_folderpath .. "wide_sfx.ogg", true), AudioPriority.Low)

    return spell
end