local modify, recruit, find_opponent

function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.CO-OP.blue")
    block:set_name("CO-OP")
    block:set_description("Join your opponent!")
    block:set_color(Blocks.Blue)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 1, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    local i = 0

    component.update_func = function ()
        i = i + 1

        -- allow time for setup
        if i == 1 then return end

        recruit(player)
        component:eject()
    end

    player:register_component(component)
end

function recruit(player)
    local opponent = find_opponent(player)

    if not opponent then
        -- no opponent
        return
    end

    local recruiter = opponent
    local recruit = player

    recruit:set_team(recruiter:get_team())
    recruit:set_facing(recruiter:get_facing())

    -- forcibly move the player to our side >:)
    recruit:get_tile():remove_entity_by_id(recruit:get_id())
    recruiter:get_tile(recruiter:get_facing_away(), 1):add_entity(recruit)
end

function find_opponent(player)
    local opponent

    player:get_field():find_characters(function(c)
        if c:get_team() == player:get_team() then
            -- already on the same team
            return false
        end

        local possible_p = Battle.Player.from(c)

        if possible_p then
            -- is a player on the opposite team!
            -- found the opponent!
            opponent = possible_p
        end

        return false
    end)

    return opponent
end
