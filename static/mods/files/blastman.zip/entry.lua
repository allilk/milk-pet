-- Script by Thor, Animation/battle sprite edits Work by D3stroy3d

--Huge thanks and shoutout to OTA for making the amazing blastman ow sprites so we can finally move away from the the playing card ow sprites


local pvp_mode = false -- Set this to true to make pvp friendly

local fire_tornado_texture = Engine.load_texture(_modpath .. "tornado.png")
local fire_tornado_animation = _modpath.."tornado.animation"
local tummy_fire_texture = Engine.load_texture(_modpath .. "tummy_fire.png")
local tummy_fire_animation = _modpath.."tummy_fire.animation"
local wind_texture = Engine.load_texture(_modpath .. "wind.png")
local wind_animation = _modpath.."wind.animation"
local fireball_texture = Engine.load_texture(_modpath .. "fireball.png")
local fireball_animation = _modpath.."fireball.animation"
local numbers_texture = Engine.load_texture(_modpath .. "numbers.png")
local numbers_animation = _modpath.."numbers.animation"
local fireball_sfx = Engine.load_audio(_modpath .. "BlastManFireBall.ogg")
local tornado_sfx = Engine.load_audio(_modpath .. "BlastManWhirlwind.ogg")
local charge_damage

function package_init(package)
    package:declare_package_id("com.Thor.Ota.D3stroy3d.player.Blastman")
    package:set_special_description("Gotta Blast!")
    package:set_speed(5.0)
    package:set_attack(5)
    package:set_charged_attack(50)
    package:set_icon_texture(Engine.load_texture(_modpath.."face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."blastman_ow.animation")
    package:set_overworld_texture_path(_modpath.."blastman_ow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
	player.used_special = 3
    player:set_name("BlastMan")
    player:set_element(Element.Fire)
    player:set_height (76.0)
    player:set_animation(_modpath.."blastman.animation")
    player:set_texture(Engine.load_texture(_modpath.."blastman.png"), true)
    player:set_fully_charged_color(Color.new(255,0,0,255))
	player:set_charge_position(0, -44)
	charge_damage = player:get_attack_level() *10
	player.normal_attack_func = create_normal_attack

	if pvp_mode == true then
		player.charged_attack_func = create_charge_attack
		player.special_attack_func = create_special_attack
		player:set_health(1000)
	else
		player.charged_attack_func = create_charge_attack_blastman
		player.special_attack_func = create_special_attack_blastman
		player:set_health(1000)
	end
	local run_once = true
	player.gui = Battle.Artifact.new()
	
    
	player.update_func = function(self, dt) 
        if run_once == true then
			player.gui:sprite():set_layer(-5)
			player.gui:set_texture(numbers_texture, true)
			local offsetX = -24
			if player:get_facing() == Direction.Left then 
				offsetX = offsetX * -1
		
			end
			player.gui:set_offset(offsetX, -92)
			player.gui:get_animation():load(numbers_animation)
			player.gui:never_flip(true)
			player.gui:get_animation():set_state(tostring(player.used_special))
			player.gui:get_animation():refresh(player.gui:sprite())
			if player:get_facing() == Direction.Left then 
				player:get_field():spawn(player.gui, player:get_field():tile_at(6, 0))
			else 
				player:get_field():spawn(player.gui, player:get_field():tile_at(1, 0))
			end
			run_once = false
		end
		
		player.gui:get_animation():set_state(tostring(player.used_special))
    end
end



function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charge_attack(player)
    print("charged attack")
    return Battle.Buster.new(player, true, player:get_attack_level() *10)
end

function create_special_attack(player)
    print("execute special")
    --Nothing
end



function create_charge_attack_blastman(player)
	print("charged attack")
    local props = Battle.CardProperties:new()
    --props.damage = player:get_attack_level() *10
    local buster_action = card_create_action_fire_tornado(player,props)
    return buster_action
end

function card_create_action_fire_tornado(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "SHOOT_FIRE_TORNADO")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)		
		local cannonshot1 = create_fire_tornado("DEFAULT", user)
		local tile1 = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot1, tile1)
		
		local cannonshot2 = create_fire_tornado("DEFAULT", user)
		local tile2 = user:get_tile(user:get_facing(), 2)
		actor:get_field():spawn(cannonshot2, tile2)
		
		local cannonshot3 = create_fire_tornado("DEFAULT", user)
		local tile3 = user:get_tile(user:get_facing(), 3)
		actor:get_field():spawn(cannonshot3, tile3)
		
		local tummyfire = create_tummy_fire("DEFAULT", user)
		local tile = user:get_tile()
		actor:get_field():spawn(tummyfire, tile)
		Engine.play_audio(tornado_sfx, AudioPriority.Highest)
		
	end
    return action
end

function create_fire_tornado(animation_state, user)
	local spell_counter = 0
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(HitProps.new(charge_damage, Hit.Impact, Element.Fire, user:get_context() , Drag.None))

	local sprite = spell:sprite()
	sprite:set_texture(fire_tornado_texture)
	sprite:set_layer(-1)

	local animation = spell:get_animation()
	animation:load(fire_tornado_animation)
	animation:set_state("DEFAULT")
	animation:refresh(sprite)
	animation:on_complete(function() 
		spell:erase() 
	end)
	
	spell.update_func = function()
		spell:get_current_tile():attack_entities(spell)
	end
    return spell
end

function create_tummy_fire(animation_state, user)

	local spell2 = Battle.Spell.new(user:get_team())
    spell2:set_facing(user:get_facing())
	local sprite2 = spell2:sprite()
	sprite2:set_texture(tummy_fire_texture)
	sprite2:set_layer(-1)

	local animation2 = spell2:get_animation()
	animation2:load(tummy_fire_animation)
	animation2:set_state("DEFAULT")
	animation2:refresh(sprite2)
	animation2:on_complete(function() 
        spell2:erase() 
	end)
    return spell2
end



function create_special_attack_blastman(player)
	if player.used_special > 0 then
		print("special attack")
		local props = Battle.CardProperties:new()
		props.damage = player:get_attack_level() *10
		local buster_action = card_create_action_fire_wave(player,props)
		player.used_special = player.used_special - 1
		return buster_action
	end
end

function card_create_action_fire_wave(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "CHARGE_FIRE_WAVE")
	
	action:set_lockout(make_animation_lockout())
	local field = actor:get_field()
	local counter = 0
	local random_number = 10
    action.update_func = function(self, dt)		
		local result = counter % random_number
		if (result == 0) then
			local spawn_tile = math.random(1,3)
			spawn_wind(actor, field, spawn_tile)
			random_number = math.random(15,30)
		end
		counter = counter + 1
	end
	action.action_end_func = function(self)
		local animation_player = actor:get_animation()
		animation_player:set_state("SHOOT_FIRE_WAVE")
		local fireball = spawn_fireball(actor)
		local tile1
		local tile2
		local tile3
		if actor:get_facing() == Direction.Left then
			tile1 = field:tile_at(7,1)
		else
			tile1 = field:tile_at(0,1)
		end
		field:spawn(fireball,tile1)
		local fireball = spawn_fireball(actor)
		if actor:get_facing() == Direction.Left then
			tile2 = field:tile_at(7,2)
		else
			tile2 = field:tile_at(0,2)
		end
		field:spawn(fireball,tile2)
		local fireball = spawn_fireball(actor)
		if actor:get_facing() == Direction.Left then
			tile3 = field:tile_at(7,3)
		else
			tile3 = field:tile_at(0,3)
		end
		field:spawn(fireball,tile3)
		Engine.play_audio(fireball_sfx, AudioPriority.Highest)
	end
	return action
end

function spawn_wind(user,field, spawn_tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
	spell:set_offset(0.0, -30.0)
    --spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(0, Hit.None, Element.Fire, user:get_context() , Drag.None))

    local sprite = spell:sprite()
    sprite:set_texture(wind_texture)
    sprite:set_layer(-1)

    local animation = spell:get_animation()
    animation:load(wind_animation)
    animation:set_state("WIND_HOR")
    animation:refresh(sprite)
    animation:set_playback(Playback.Loop)
    
    
	
	local do_once = true
	local loop_count = 0
	spell.update_func = function()
		if do_once then 
			if user:get_facing() == Direction.Left then
				dest = field:tile_at(0,spawn_tile)
				spell:slide(dest, frames(50), frames(0), ActionOrder.Voluntary, function()end)
				do_once = false
			else
				dest = field:tile_at(7,spawn_tile)
				spell:slide(dest, frames(50), frames(0), ActionOrder.Voluntary, function()end)
				do_once = false
			end
		end
		if loop_count >= 10 then
			if spell:is_sliding() == false then
				spell:delete()
			end
		end
		loop_count = loop_count + 1
	end
	spell.can_move_to_func = function(tile)
        return true
    end
	
	if user:get_facing() == Direction.Left then
		tile = field:tile_at(7,spawn_tile)
	else
		tile = field:tile_at(0,spawn_tile)
	end
    field:spawn(spell, tile)
    return
end

function spawn_fireball(owner)
    local spell = Battle.Spell.new(owner:get_team())
    spell:set_facing(owner:get_facing())
	spell:set_offset(-25, -30.0)
	spell:set_texture(fireball_texture, true)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(charge_damage * 2, Hit.Impact | Hit.Flinch | Hit.Flash, Element.Fire, owner:get_context(), Drag.None))

    local animation = spell:get_animation()
    animation:load(fireball_animation)
    animation:set_state("FIREBALL_HOR")
    animation:set_playback(Playback.Loop)
     

	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

			dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	
	spell.attack_func = function() 
        -- nothing
    end
	
	spell.can_move_to_func = function(tile)
        return true
    end
	
	spell.collision_func = function()
		spell:erase()
	end
	
	spell.delete_func = function(self) 
    end
        
    return spell
end