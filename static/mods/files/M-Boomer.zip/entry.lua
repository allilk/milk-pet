--local variables go up here
local TEXTURE = Engine.load_texture(_modpath.."boomer.png")
local ANIMATION_PATH = _modpath.."boomer.animation"
local START_AUDIO = Engine.load_audio(_modpath.."boomer.ogg")

function package_init(package)
    package:declare_package_id("astandard_121_m-boomer_bn6")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"I","M","W"})
    local props = package:get_card_props()
    props.shortname = "M-Boomer"
    props.damage = 170
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Boomerang that circ btl field"
    props.limit = 3
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
  -- action:set_lockout(make_async_lockout(0.67))
  -- action:override_animation_frames(FRAMES)

  action.execute_func = function()
    local buster = action:add_attachment("Buster")
    buster:sprite():set_texture(actor:get_texture(), true)
    buster:sprite():set_layer(-1)
    buster:sprite():enable_parent_shader(true)

    local buster_anim = buster:get_animation()
    buster_anim:copy_from(actor:get_animation())
    buster_anim:set_state("BUSTER")
    execute_func(actor, props)
    end


  return action

end
function execute_func(actor, props)
    
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellteam = spell:get_team()
    spell:set_texture(TEXTURE, true)
    spell:set_offset(0, -15)
    local anim = spell:get_animation()
    anim:load(ANIMATION_PATH)
    anim:set_state("DEFAULT")
    anim:set_playback(Playback.Loop)
  Engine.play_audio(START_AUDIO, AudioPriority.High)
 
    spell.can_move_to_func =
    function ()
      return true
    end
    spell:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Flinch | Hit.Impact,
      props.element,
      actor:get_context(),
      Drag.None
        )
    )
    if spellteam == 2 then
         field:spawn(spell, 1, 3)
    else
        field:spawn(spell, 6, 3)
    end
    local direction = actor:get_facing()
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        local is_at = spell:get_tile(direction, 0)
        --i am so sorry
        
        if spellteam == 2 then
            if is_at == field:tile_at(1,3)
                then spell:slide(field:tile_at(2,3), frames(4), frames(0), ActionOrder.Voluntary, nil) 
            end
            if is_at == field:tile_at(2,3)
                then spell:slide(field:tile_at(3,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(3,3) 
                then spell:slide(field:tile_at(4,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(4,3)
                then spell:slide(field:tile_at(5,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(5,3)
                then spell:slide(field:tile_at(6,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(6,3)
                then spell:slide(field:tile_at(6,2), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(6,2)
                then spell:slide(field:tile_at(6,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(6,1)
                then spell:slide(field:tile_at(5,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(5,1)
                then spell:slide(field:tile_at(4,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(4,1)
                then spell:slide(field:tile_at(3,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(3,1)
                then spell:slide(field:tile_at(2,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(2,1)
                then spell:slide(field:tile_at(1,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
        else
            if is_at == field:tile_at(6,3)
                then spell:slide(field:tile_at(5,3), frames(4), frames(0), ActionOrder.Voluntary, nil) 
            end
            if is_at == field:tile_at(5,3)
                then spell:slide(field:tile_at(4,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(4,3) 
                then spell:slide(field:tile_at(3,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(3,3)
                then spell:slide(field:tile_at(2,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(2,3)
                then spell:slide(field:tile_at(1,3), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(1,3)
                then spell:slide(field:tile_at(1,2), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(1,2)
                then spell:slide(field:tile_at(1,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(1,1)
                then spell:slide(field:tile_at(2,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(2,1)
                then spell:slide(field:tile_at(3,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(3,1)
                then spell:slide(field:tile_at(4,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(4,1)
                then spell:slide(field:tile_at(5,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
            if is_at == field:tile_at(5,1)
                then spell:slide(field:tile_at(6,1), frames(4), frames(0), ActionOrder.Voluntary, nil)
            end
        end
        spell:highlight_tile(Highlight.Solid)
        if spellteam == 2 then
        if is_at == field:tile_at(1,1)
            then spell:erase()
            end
        else 
            if is_at == field:tile_at(6,1)
            then spell:erase()
            end

end
return action
end
end


