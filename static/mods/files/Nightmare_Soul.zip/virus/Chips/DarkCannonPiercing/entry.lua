nonce = function() end

local chip = {name="PiercingCannon"}

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."darkcannon.png")
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.claris.dark.DarkCannonCL")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'X'})

    local props = package:get_card_props()
    props.shortname = "DarkCan"
    props.damage = 400
    props.time_freeze = false
    props.element = Element.Cursor
    props.description = "PIERCES THROUGH THE VEIL"
	props.card_class = CardClass.Dark
	props.limit = 1
	props.can_boost = false
	props.long_description = "DARK CHIP (C) NEBULA. PIERCE WITH A CANNON."
end

chip.card_create_action = function(actor)
	print("in create_card_action()!")
	local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."darkcannon.png")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.1}
	local frame2 = {2, 0.1}
	local frame3 = {3, 0.05}
	local frame4 = {4, 0.05}
	local frame5 = {5, 0.05}
	local frame6 = {6, 0.305}
	local frame7 = {7, 0.153}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7})
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		local field = user:get_field()
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_folderpath.."darkcannon.animation")
		buster_anim:set_state("Cannon1")
		
		self:add_anim_action(1, function()
			actor:toggle_counter(true)
		end)
		
		self:add_anim_action(5, function()
			actor:toggle_counter(false)
			local spell = create_attack(user)
			local BEAM_TEXTURE = Engine.load_texture(_folderpath.."dark_beam.png")
			local beam = buster:sprite():create_node()
			beam:set_texture(BEAM_TEXTURE)
			local anim = Engine.Animation.new(_folderpath.."dark_beam.animation")
			anim:set_state("SPAWN")
			anim:refresh(beam)
			self.animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
			self.animate_component.update_func = function(self, dt)
				anim:update(dt, beam)
				if anim:get_state() == "FADE" then
					anim:on_complete(function()
						self:eject()
						spell:erase()
					end)
				end
			end
			user:register_component(self.animate_component)
			anim:on_frame(6, function()
				local hitbox = Battle.SharedHitbox.new(spell, 0.017)
				hitbox:set_hit_props(spell:copy_hit_props())
				local desired_tile = spell:get_tile(spell:get_facing(), 1)
				if desired_tile then
					desired_tile:highlight(Highlight.Solid)
					field:spawn(hitbox, desired_tile)
				end
			end)
			anim:on_frame(8, function()
				local hitbox = Battle.SharedHitbox.new(spell, 0.017)
				hitbox:set_hit_props(spell:copy_hit_props())
				local desired_tile = spell:get_tile(spell:get_facing(), 2)
				if desired_tile then
					desired_tile:highlight(Highlight.Solid)
					field:spawn(hitbox, desired_tile)
				end
			end)
			anim:on_frame(10, function()
				local hitbox = Battle.SharedHitbox.new(spell, 0.017)
				hitbox:set_hit_props(spell:copy_hit_props())
				local desired_tile = spell:get_tile(spell:get_facing(), 3)
				if desired_tile then
					desired_tile:highlight(Highlight.Solid)
					field:spawn(hitbox, desired_tile)
				end
			end)
			anim:on_frame(12, function()
				local hitbox = Battle.SharedHitbox.new(spell, 0.017)
				hitbox:set_hit_props(spell:copy_hit_props())
				local desired_tile = spell:get_tile(spell:get_facing(), 4)
				if desired_tile then
					desired_tile:highlight(Highlight.Solid)
					field:spawn(hitbox, desired_tile)
				end
			end)
			anim:on_frame(14, function()
				local hitbox = Battle.SharedHitbox.new(spell, 0.017)
				hitbox:set_hit_props(spell:copy_hit_props())
				local desired_tile = spell:get_tile(spell:get_facing(), 5)
				if desired_tile then
					desired_tile:highlight(Highlight.Solid)
					field:spawn(hitbox, desired_tile)
				end
			end)
			anim:on_complete(function()
				anim:set_state("FADE")
			end)
			field:spawn(spell, user:get_tile())
		end)
	end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
	end
    return action
end

function create_attack(user)
	local spell = Battle.Spell.new(user:get_team())	
    spell:set_hit_props(
        HitProps.new(
            400,
            Hit.Impact | Hit.Flinch | Hit.Pierce | Hit.Flash,
            Element.Cursor,
            user:get_context(),
            Drag.None
        )
    )
	spell.update_func = function(self, dt) 
		self:get_tile():attack_entities(self)
    end
	spell.collision_func = function(self, other)
	end
    spell.attack_func = function(self, other) 
    end
    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end
	local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")
	Engine.play_audio(AUDIO, AudioPriority.Low)
	return spell
end

return chip