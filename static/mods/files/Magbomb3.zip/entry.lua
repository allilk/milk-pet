local bomb = include('bomb.lua')

bomb.name="MagBomb3"
bomb.damage=120
bomb.element=Element.Elec
bomb.description = "Stops the enemy in place"
bomb.codes = {"H","K","O","Q","S"}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = bomb.name
    props.damage = bomb.damage
    props.time_freeze = false
    props.element = bomb.element
    props.description = bomb.description
    props.limit = 5

    package:declare_package_id("hoov.cards."..props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(bomb.codes)
end

card_create_action = bomb.card_create_action