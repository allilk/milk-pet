
function package_init(package)
	package:declare_package_id("com.mars.player.BlockMan")
	package:set_special_description("Let's rock, man!")
	package:set_speed(1.0)
	package:set_attack(5)
	package:set_charged_attack(200)
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_overworld_animation_path(_modpath.."overworld.animation")
	package:set_overworld_texture_path(_modpath.."overworld.png")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
	player:set_name("Blockman")
	player:set_health(2000)
	player:set_element(Element.Summon)
	player:set_height(40.0)
	player:set_animation(_modpath.."RockCube.animation")
	player:set_texture(Engine.load_texture(_modpath.."RockCube.png"), false)
	local base_charge_color = Color.new(255, 0, 30, 255)
	player:set_fully_charged_color(base_charge_color)
	player:set_charge_position(0, -20)
	

	player.update_func = function(self, dt)
		--nothing
	end

	player.normal_attack_func = function(player)
		return Battle.Buster.new(player, false, player:get_attack_level() * 1)
	end
	
	player.charged_attack_func = function(player)
		local props = Battle.CardProperties:new()
		props.damage = 200
		props.element = Element.Break

		local cube_dash_action = cube_dash_card_create_action(player, props)
		return cube_dash_action
	end
end


--	code adapted from Keristero's StarMan and Claris's RockCube obstacle.
--	most of these comments are from mars.

--	[BEWARE] this is not a suggestion for how to write good scripted content;
--	I am being lazy with this and probably breaking several conventions.

--local battle_helpers = include('cube_dash/battle_helpers.lua')
local sub_folder_path = _modpath.."/cube_dash/" --folder we are inside

local blockman_effects_texture = Engine.load_texture(sub_folder_path .. "effects.png")
local blockman_effects_texture_animation_path = sub_folder_path.. "effects.animation"

local hurt_sfx	= Engine.load_audio(sub_folder_path .. "hurt.ogg") 
local break_sfx	= Engine.load_audio(sub_folder_path .. "meteor.ogg") 
local go_sfx	= Engine.load_audio(sub_folder_path .. "windrack.ogg") 
local rumble_sfx = Engine.load_audio(sub_folder_path .. "fireburn.ogg") 

function cube_dash_card_create_action(player, props)
	local action = Battle.CardAction.new(player, "PLAYER_SHAKE")
	action:set_lockout(make_animation_lockout())


	action.execute_func = function(self, user)

		-- make some noise
		self:add_anim_action(1,function()
			cube_startup(user, props)
		end)

		-- spawn cube when shaking finishes
		self:add_anim_action(16,function()
			player:toggle_hitbox(false)
		end)

		-- spawn cube when shaking finishes
		self:add_anim_action(17,function()
			cube_spawn(user, props)
		end)

		self:add_anim_action(18,function()
			player:set_elevation(-500)
		end)

		action.action_end_func = function()
			player:toggle_hitbox(true)
			player:set_elevation(0)
		end

	end
	return action
end

function cube_startup(player, props)
	-- let's make some noise
	Engine.play_audio(rumble_sfx, AudioPriority.High)
end


function cube_spawn(player, props)
	local cube = Battle.Obstacle.new(Team.Other)

	cube:set_facing(player:get_facing())
	cube:set_texture(blockman_effects_texture, true)
	cube:get_animation():load(blockman_effects_texture_animation_path)
	cube:get_animation():set_state("CUBE_GO")
	cube:get_animation():set_playback(Playback.Loop)
	cube:set_health(200)

	-- deletion process var
	local delete_self = nil
	local spawned_hitbox = false
	local countdown = 900
	-- slide tracker
	local continue_slide = true
	local prev_tile = nil
	local cube_speed = 4


	-- define cube collision hitprops
	local props = HitProps.new(
		props.damage,
		Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
		props.element,
		player:get_context(),
		Drag.None)

	-- upon tangible collision
	cube.collision_func = function(self)

		-- define the hitbox with its props every frame
		local hitbox = Battle.Hitbox.new(cube:get_team())
		hitbox:set_hit_props(props)

		-- only spawn the hitbox if not in the deletion process
		if not spawned_hitbox then
			cube:get_field():spawn(hitbox, cube:get_current_tile())
			spawned_hitbox = true
		end
		cube.delete_func()
	end

	-- upon passing the defense check
	cube.attack_func = function(self)
		Engine.play_audio(hurt_sfx, AudioPriority.High)
	end

	cube.can_move_to_func = function(tile)
		if tile then
			-- get a list of every obstacle with Team.Other on the field
			local field = cube:get_field()
			local cube_team = cube:get_team()
			local Other_obstacles = function(obstacle)
				return obstacle:get_team() == cube_team
			end
			local obstacles_here = field:find_obstacles(Other_obstacles)
			local respect_other_obstacle = false
			-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
			for ii=1,#obstacles_here do
				if tile == obstacles_here[ii]:get_tile() then
					respect_other_obstacle = true
				end
			end
			if tile:is_edge() or tile:is_hole() or respect_other_obstacle or not tile:is_walkable() then
				return false
			end
			-- print("is_edge " .. tostring(tile:is_edge()))
			-- print("is_hole " .. tostring(tile:is_hole()))
			-- print("is_walkable " .. tostring(tile:is_walkable()))
			-- print("------------------")

			return true
		end
		return false
	end

	-- run every frame
	cube.update_func = function(self, dt)
		local tile = cube:get_current_tile()
		if not tile then
			cube.delete_func()
		end
		if not tile:is_walkable() or tile:is_edge() then
			cube.delete_func()
		end
		if not delete_self then
			tile:attack_entities(cube)
		end
		local direction = cube:get_facing()

		if self:is_sliding() then
			continue_slide = true
		else
			-- become aware of which direction you just moved in, turn to face that direction
			if prev_tile then
				-- turn around if you need to
				if prev_tile:x() ~= tile:x() and prev_tile:get_tile(direction, 1):x() ~= tile:x() then
					direction = self:get_facing_away()
					self:set_facing(direction)
				end
				-- stop sliding if the movement was only vertical
				if prev_tile:y() ~= tile:y() and prev_tile:x() == tile:x() then
					continue_slide = false
				end
			end
			prev_tile = tile
		end

		if not self:is_sliding() and continue_slide then
			prev_tile = tile
			continue_slide = self:slide(self:get_tile(direction, 1), frames(cube_speed), frames(0), ActionOrder.Voluntary, function() end)
		end

		if self:get_health() <= 0 then
			cube.delete_func()
		end
		if countdown > 0 then countdown = countdown - 1 else cube.delete_func() end

		-- deletion handler in main loop, starts running once something in here has requested deletion
		if delete_self then
			if type(delete_self) ~= "number" then
				delete_self = 2
			end
			if delete_self > 0 then
				delete_self = delete_self - 1
			elseif delete_self == 0 then
				delete_self = -1
				Engine.play_audio(break_sfx, AudioPriority.High)
				self:erase()
			end
		end
	end

	-- function to request that the cube start deleting itself.
	-- allows time to run some extra code, also sets a var to tell
	-- itself to stop spawning new hitboxes
	cube.delete_func = function(self)
		if type(delete_self) ~= "number" then
			delete_self = true
		end
	end

	local spawn_distance = 0
	local spawn_direction = player:get_facing()

	if player:input_has(Input.Held.Shoot) then
		continue_slide = false
		spawn_distance = 1
		local iU = Input.Held.Up
		local iD = Input.Held.Down
		local y_dir = Direction.None
		local pressing_dir = true
		if player:input_has(iU) then
			y_dir = Direction.Up
		elseif player:input_has(iD) then
			y_dir = Direction.Down
		else
			pressing_dir = false
		end
		if pressing_dir then
			if player:input_has(Input.Held.Right) or player:input_has(Input.Held.Left) then
				spawn_direction = Direction.join(spawn_direction, y_dir)
			else
				spawn_direction = y_dir
			end
			print()
		end
	end
	local query = function(arg)
		return Battle.Obstacle.from(arg) ~= nil
	end
	local tt = player:get_tile(spawn_direction, 1)
	local tt_ne = not(tt:is_edge())
	local tt_w = tt:is_walkable()
	local ent_count = tt:find_entities(query)

	-- runs once, initial spawning of cube
	if (tt_ne and continue_slide) or (#ent_count == 0 and tt_w and not continue_slide) then
		player:get_field():spawn(cube, player:get_tile(spawn_direction, spawn_distance))
	end
	Engine.play_audio(go_sfx, AudioPriority.High)
end
