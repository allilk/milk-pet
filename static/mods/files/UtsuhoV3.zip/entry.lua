local HIT_SFX = nil
local APPEAR_SFX = nil
local CHARGE_SFX = nil
local WING_SFX = nil



function package_init(package) 
    package:declare_package_id("com.alrysc.card.UtsuhoV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'U','R'})

    local props = package:get_card_props()
    props.shortname = "UtsuhoV3"
    props.damage = 180
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Sweep w/ blazing wings!"
    props.card_class = CardClass.Mega
    props.limit = 1
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true

    local actor = nil
    local utsuho = nil
    local anim = nil

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    

    local count = 0
    local finish_delay = 30
    local can_end = false
    step.update_func = function()
        if count == 3 then 
            actor:hide()
            tile = user:get_current_tile()
            field:spawn(utsuho, tile)
            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)


        end

        if can_end then 
            finish_delay = finish_delay - 1
            if finish_delay == 0 then 
                step:complete_step()
            end
        end
        

        count = count + 1
    end


    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
        CHARGE_SFX = Engine.load_audio(_folderpath.."shoot.ogg")
        WING_SFX = Engine.load_audio(_folderpath.."wing.ogg")

        
        utsuho = graphic_init("spell", 0, 0, "utsuho.png", "utsuho.animation", -5, "DEFAULT", user, facing)
        utsuho.sliding = false

        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking | Hit.Shake,
                Element.Fire, 
                user:get_context(), 
                Drag.None
            )

        utsuho:set_hit_props(hit_props)

        local side_spells = Battle.Spell.new(user:get_team())

        local hit_props2 = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake,
                Element.Fire, 
                user:get_context(), 
                Drag.None
            )

        side_spells:set_hit_props(hit_props2)

        utsuho.can_move_to_func = function()
            return true
        end

        side_spells.can_move_to_func = function()
            return true
        end

        user:get_field():spawn(side_spells, user:get_current_tile())



        anim = utsuho:get_animation()

        anim:on_frame(2, function()
            Engine.play_audio(WING_SFX, AudioPriority.Low)
        end)
        anim:on_complete(function()
            Engine.play_audio(CHARGE_SFX, AudioPriority.Low)
            anim:set_state("FLY_LOOP")
            anim:set_playback(Playback.Loop)
            anim:refresh(utsuho:sprite())
          --  Engine.play_audio(DASH_SFX, AudioPriority.Low)
            utsuho.update_func = function()
                local t1 = utsuho:get_current_tile()

                local tiles = {
                    t1,
                    t1:get_tile(Direction.Up, 1),
                    t1:get_tile(Direction.Down, 1)
                }
            
                for i=1, #tiles
                do
                    local t = tiles[i]
                    if t and not t:is_edge() then 
                        if i == 1 then 
                            t:attack_entities(utsuho)
                        else
                            t:attack_entities(side_spells)
                        end

                        t:highlight(Highlight.Solid)
                    end
                    

                end

                if not utsuho:is_sliding() then 
                    local dest = utsuho:get_tile(facing, 1)
                    if not dest then 
                        can_end = true
                        utsuho:delete()
                        side_spells:delete()
                    else
                        utsuho:slide(dest, frames(5), frames(0), ActionOrder.Voluntary,
                        function()
                        end)
                    end
                end

              
            end
        end)

        
        utsuho.attack_func = function(self, other)
            
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

            user:get_field():spawn(graphic_init("artifact", 0, 0, "effect.png", "effect.animation", -6, "DEFAULT", user, utsuho:get_facing(), true), other:get_current_tile())

          
        end


        side_spells.attack_func = utsuho.attack_func


    end


    return action
end