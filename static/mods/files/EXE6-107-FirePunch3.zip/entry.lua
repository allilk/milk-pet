local DAMAGE = 180

local FIREPUNCH_TEXTURE = Engine.load_texture(_modpath.."firepunch.png")
local FIREPUNCH_ANIMPATH = _modpath.."firepunch.animation"
local FIREPUNCH_AUDIO = Engine.load_audio(_modpath.."firepunch.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-107-FirePunch3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A","B","C"})

    local props = package:get_card_props()
    props.shortname = "FirPnch3"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Punch closest column!"
    props.long_description = "Punch the nearest column in the front 3 columns!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(0.633))
    local override_frames = {{1,0.017},{1,0.017}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local query = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil
			elseif user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return Battle.Obstacle.from(ent) ~= nil
            end
        end

        self:add_anim_action(1, function()
            target_finder(user, props, team, direction, field, self_X, self_Y)
        end)
    end
    return action
end

function target_finder(owner, props, team, direction, field, owner_X, owner_Y)
    local finder1 = Battle.Spell.new(team)
    finder1:set_facing(direction)
    local anim1 = finder1:get_animation()
    anim1:load(_modpath.."attack.animation")
    anim1:set_state("0")

    local targeted = false
    local targeted_1 = false
    local targeted_2 = false
    local targeted_3 = false
    local targeted_1FD = false
    local targeted_2FD = false
    local targeted_3FD = false

    local tile1 = field:tile_at(owner_X, 1)
    local tile2 = field:tile_at(owner_X, 2)
    local tile3 = field:tile_at(owner_X, 3)
    local tile1_front = nil
    local tile2_front = nil
    local tile3_front = nil
	local check1_front = false
	local check2_front = false
	local check3_front = false
    local tile_array1 = {}
    local tile_array2 = {}
    local tile_array3 = {}
    local min_X = nil
    local tile1FD_front = nil
    local tile2FD_front = nil
    local tile3FD_front = nil
	local check1FD_front = false
	local check2FD_front = false
	local check3FD_front = false
    local tile1FD_array = {}
    local tile2FD_array = {}
    local tile3FD_array = {}

    local team_check = function(ent)
        if not owner:is_team(ent:get_team()) then
            return true
        end
    end

    for i = 1, 3, 1 do
        if i <= 3 then
             
            tile1_front = tile1:get_tile(direction, i)
             
            check1_front = tile1_front and #tile1_front:find_characters(team_check) > 0 and tile1_front ~= nil and not tile1_front:is_edge()
             
            if check1_front then
                print("Y1 TARGETED")
                targeted = true
                targeted_1 = true
                table.insert(tile_array1, tile1_front)
                break
            end
        end
    end
    for i = 1, 3, 1 do
        if i <= 3 then
             
            tile2_front = tile2:get_tile(direction, i)
             
            check2_front = tile2_front and #tile2_front:find_characters(team_check) > 0 and tile2_front ~= nil and not tile2_front:is_edge()
             
            if check2_front then
                print("Y2 TARGETED")
                targeted = true
                targeted_2 = true
                table.insert(tile_array2, tile2_front)
                break
            end
        end
    end
    for i = 1, 3, 1 do
        if i <= 3 then
             
            tile3_front = tile3:get_tile(direction, i)
             
            check3_front = tile3_front and #tile3_front:find_characters(team_check) > 0 and tile3_front ~= nil and not tile3_front:is_edge()
             
            if check3_front then
                print("Y3 TARGETED")
                targeted = true
                targeted_3 = true
                table.insert(tile_array3, tile3_front)
                break
            end
        end
    end
    for i = 4, 5, 1 do
        if i <= 5 then
             
            tile1FD_front = tile1:get_tile(direction, i)
             
            check1FD_front = tile1FD_front and #tile1FD_front:find_characters(team_check) > 0 and tile1FD_front ~= nil and not tile1FD_front:is_edge()
             
            if check1FD_front then
                print("Y1 (FARDIST) TARGETED")
                targeted = true
                targeted_1FD = true
                table.insert(tile1FD_array, tile1FD_front)
                break
            end
        end
    end
    for i = 4, 5, 1 do
        if i <= 5 then
             
            tile2FD_front = tile2:get_tile(direction, i)
             
            check2FD_front = tile2FD_front and #tile2FD_front:find_characters(team_check) > 0 and tile2FD_front ~= nil and not tile2FD_front:is_edge()
             
            if check2FD_front then
                print("Y2 (FARDIST) TARGETED")
                targeted = true
                targeted_2FD = true
                table.insert(tile2FD_array, tile2FD_front)
                break
            end
        end
    end
    for i = 4, 5, 1 do
        if i <= 5 then
             
            tile3FD_front = tile3:get_tile(direction, i)
             
            check3FD_front = tile3FD_front and #tile3FD_front:find_characters(team_check) > 0 and tile3FD_front ~= nil and not tile3FD_front:is_edge()
             
            if check3FD_front then
                print("Y3 (FARDIST) TARGETED")
                targeted = true
                targeted_3FD = true
                table.insert(tile3FD_array, tile3FD_front)
                break
            end
        end
    end

    anim1:on_frame(2, function()
        if     targeted_1 and targeted_2 and targeted_3 then
            min_X = math.min(tile_array1[1]:x(), tile_array2[1]:x(), tile_array3[1]:x())
            if tile_array1[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 1)
            end
            if tile_array2[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 2)
            end
            if tile_array3[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 3)
            end
        elseif targeted_1 and targeted_2 and not targeted_3 then
            min_X = math.min(tile_array1[1]:x(), tile_array2[1]:x())
            if tile_array1[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 1)
            end
            if tile_array2[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 2)
            end
        elseif targeted_1 and not targeted_2 and targeted_3 then
            min_X = math.min(tile_array1[1]:x(), tile_array3[1]:x())
            if tile_array1[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 1)
            end
            if tile_array3[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 3)
            end
        elseif not targeted_1 and targeted_2 and targeted_3 then
            min_X = math.min(tile_array2[1]:x(), tile_array3[1]:x())
            if tile_array2[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 2)
            end
            if tile_array3[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 3)
            end
        elseif targeted_1 and not targeted_2 and not targeted_3 then
            min_X = math.min(tile_array1[1]:x())
            if tile_array1[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 1)
            end
        elseif not targeted_1 and targeted_2 and not targeted_3 then
            min_X = math.min(tile_array2[1]:x())
            if tile_array2[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 2)
            end
        elseif not targeted_1 and not targeted_2 and targeted_3 then
            min_X = math.min(tile_array3[1]:x())
            if tile_array3[1]:x() == min_X then
                create_punch(owner, props, team, direction, field, min_X, 3)
            end
        elseif not targeted_1 and not targeted_2 and not targeted_3 then
            if     targeted_1FD and targeted_2FD and targeted_3FD then
                min_X = math.min(tile1FD_array[1]:x(), tile2FD_array[1]:x(), tile3FD_array[1]:x())
                if tile1FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile1:get_tile(direction, 3):x(), 1)
                end
                if tile2FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile2:get_tile(direction, 3):x(), 2)
                end
                if tile3FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile3:get_tile(direction, 3):x(), 3)
                end
            elseif targeted_1FD and targeted_2FD and not targeted_3FD then
                min_X = math.min(tile1FD_array[1]:x(), tile2FD_array[1]:x())
                if tile1FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile1:get_tile(direction, 3):x(), 1)
                end
                if tile2FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile2:get_tile(direction, 3):x(), 2)
                end
            elseif targeted_1FD and not targeted_2FD and targeted_3FD then
                min_X = math.min(tile1FD_array[1]:x(), tile3FD_array[1]:x())
                if tile1FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile1:get_tile(direction, 3):x(), 1)
                end
                if tile3FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile3:get_tile(direction, 3):x(), 3)
                end
            elseif not targeted_1FD and targeted_2FD and targeted_3FD then
                min_X = math.min(tile2FD_array[1]:x(), tile3FD_array[1]:x())
                if tile2FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile2:get_tile(direction, 3):x(), 2)
                end
                if tile3FD_array[1]:x() == min_X then
                    create_punch(owner, props, team, direction, field, tile3:get_tile(direction, 3):x(), 3)
                end
            elseif targeted_1FD and not targeted_2FD and not targeted_3FD then
                min_X = math.min(tile1FD_array[1]:x())
                create_punch(owner, props, team, direction, field, tile1:get_tile(direction, 3):x(), 1)
            elseif not targeted_1FD and targeted_2FD and not targeted_3FD then
                min_X = math.min(tile2FD_array[1]:x())
                create_punch(owner, props, team, direction, field, tile2:get_tile(direction, 3):x(), 2)
            elseif not targeted_1FD and not targeted_2FD and targeted_3FD then
                min_X = math.min(tile3FD_array[1]:x())
                create_punch(owner, props, team, direction, field, tile3:get_tile(direction, 3):x(), 3)
            end
        end
    end)
    anim1:on_complete(function()
        finder1:erase()
    end)

    finder1.update_func = function(self, dt)
    end
    finder1.battle_end_func = function(self)
		self:erase()
	end
    finder1.delete_func = function(self)
		self:erase()
    end
    finder1.can_move_to_func = function(tile)
		return true
	end

    field:spawn(finder1, owner_X, 2)

    return finder1
end

function create_punch(owner, props, team, direction, field, punch_X, punch_Y)
    local punch = Battle.Spell.new(team)
    punch:set_facing(direction)
    punch:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact,
            props.element,
            owner:get_id(),
            Drag.None
        )
    )
    local punch_sprite = punch:sprite()
    punch_sprite:set_texture(FIREPUNCH_TEXTURE)
    punch_sprite:set_layer(-9)
    local punch_anim = punch:get_animation()
    punch_anim:load(FIREPUNCH_ANIMPATH)
    punch_anim:set_state("0")
    punch_anim:refresh(punch_sprite)
    punch_anim:on_complete(function() punch:erase() end)
     
    punch.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
     
    punch.can_move_to_func = function(tile)
		return true
	end
     
    --[[punch.battle_end_func = function(self)
		self:erase()
	end]]
     
    punch.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
		create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end
     
    punch.delete_func = function(self)
		self:erase()
    end

    local delay = Battle.Spell.new(team)
    delay:get_facing(direction)
    local delay_anim = delay:get_animation()
    delay_anim:load(_modpath.."attack.animation")
    delay_anim:set_state("1")
    delay_anim:refresh(punch_sprite)
    delay_anim:on_frame(1, function()
        delay:highlight_tile(Highlight.Solid)
    end)
    delay_anim:on_frame(2, function()
        Engine.play_audio(FIREPUNCH_AUDIO, AudioPriority.High)
        delay:highlight_tile(Highlight.None)
    end)
    delay_anim:on_frame(3, function()
        field:spawn(punch, punch_X, punch_Y)
    end)
    delay_anim:on_complete(function() delay:erase() end)
    delay.update_func = function(self, dt)
    end
    delay.can_move_to_func = function(tile)
		return true
	end
    delay.battle_end_func = function(self)
		self:erase()
	end
    punch.delete_func = function(self)
		self:erase()
    end
     
    field:spawn(delay, punch_X, punch_Y)
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end