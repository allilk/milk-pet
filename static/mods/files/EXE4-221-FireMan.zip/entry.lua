local DAMAGE = 100

local VOICE_FIREARM_1 = Engine.load_audio(_modpath.."faiaaamu1.ogg")
local VOICE_FIREARM_2 = Engine.load_audio(_modpath.."faiaaamu2.ogg")

local TEXTURE_FIREMAN = Engine.load_texture(_modpath.."fireman.png")
local TEXTURE_FIREARM = Engine.load_texture(_modpath.."firearm.png")
local ANIMPATH_FIREMAN = _modpath.."fireman.animation"
local ANIMPATH_FIREARM = _modpath.."firearm.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_INPUT = Engine.load_audio(_modpath.."input.ogg")
local AUDIO_FIREARM = Engine.load_audio(_modpath.."firearm.ogg")

local TEXTURE_ATTACK = Engine.load_texture(_modpath.."attack.png")
local ANIMPATH_ATTACK = _modpath.."attack.animation"

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-221-FireMan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F"})

    local props = package:get_card_props()
    props.shortname = "FireMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Fire burn to front side"
    props.long_description = "A flame that penetrates the front horizontal row! Fire Arm!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local input_1 = false
        local input_success = false
        local success_played = false

        local VOICEACTING = false

        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

		local step1 = Battle.Step.new()
        local step2 = Battle.Step.new()

        self.fireman = nil
        self.tile    = user:get_current_tile()

        local ref = self

        local remaining_time = 40

        local input_once = true
        local do_once = true
        local do_once_part_two = true
        local do_once_part_three = true
        step1.update_func = function(self, dt)
            remaining_time = remaining_time - 1
            if remaining_time > 0 and remaining_time < 20 then
                --print("read")
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
                if user:input_has(Input.Pressed.Down) and not input_1 then
                    --print("PRESSED")
                    input_1 = true
                end
                if user:input_has(Input.Pressed.Right) and input_1 then
                    --print("PRESSED")
                    input_success = true
                end
                if input_success then
                    if not success_played then
                        print("SUCCESS")
                        Engine.play_audio(AUDIO_INPUT, AudioPriority.High)
                        success_played = true
                    end
                end
            end
            if remaining_time <= 1 then
                --print("read_input: OFF")
                step1:complete_step()
            end
            if do_once then
                do_once = false
                ref.fireman = Battle.Artifact.new()
                ref.fireman:set_facing(direction)
		    	ref.fireman:set_texture(TEXTURE_FIREMAN, true)
		    	ref.fireman:sprite():set_layer(-1)


                fire_anim = ref.fireman:get_animation()
                fire_anim:load(ANIMPATH_FIREMAN)
                fire_anim:set_state("SPAWN")
		    	fire_anim:refresh(ref.fireman:sprite())
                fire_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                fire_anim:on_complete(function()
                    fire_anim:set_state("MID")
                    fire_anim:refresh(ref.fireman:sprite())
		    	end)
                field:spawn(ref.fireman, ref.tile)
            end
        end
        self:add_step(step1)

        step2.update_func = function(self, dt)
            local anim = ref.fireman:get_animation()
            if anim:get_state() == "MID" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_complete(function()
                        if VOICEACTING then
                            if math.random(1,2) == 1 then
                                Engine.play_audio(VOICE_FIREARM_1, AudioPriority.High)
                            else
                                Engine.play_audio(VOICE_FIREARM_2, AudioPriority.High)
                            end
                        end
                        anim:set_state("ATTACK")
		    		    anim:refresh(ref.fireman:sprite())
                    end)
                end
            end
            if anim:get_state() == "ATTACK" then
                if do_once_part_three then
                    do_once_part_three = false
                    local firearm1 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm2 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm3 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm4 = create_firearm(user, ANIMPATH_ATTACK, props)
                    local firearm5 = create_firearm(user, ANIMPATH_ATTACK, props)

                    local firearm1m = create_firearm_magma(user, ANIMPATH_ATTACK, props)
                    local firearm2m = create_firearm_magma(user, ANIMPATH_ATTACK, props)
                    local firearm3m = create_firearm_magma(user, ANIMPATH_ATTACK, props)
                    local firearm4m = create_firearm_magma(user, ANIMPATH_ATTACK, props)
                    local firearm5m = create_firearm_magma(user, ANIMPATH_ATTACK, props)

                    local firefx1 = Battle.Artifact.new()
				    firefx1:set_facing(direction)
                    firefx1:set_texture(TEXTURE_FIREARM, true)
				    local fx1_anim = firefx1:get_animation()
				    fx1_anim:load(ANIMPATH_FIREARM)
				    fx1_anim:set_state("0")
                    fx1_anim:on_complete(function()
                        firefx1:erase()
                    end)

                    local firefx2 = Battle.Artifact.new()
				    firefx2:set_facing(direction)
                    firefx2:set_texture(TEXTURE_FIREARM, true)
				    local fx2_anim = firefx2:get_animation()
				    fx2_anim:load(ANIMPATH_FIREARM)
				    fx2_anim:set_state("0")
                    fx2_anim:on_complete(function()
                        firefx2:erase()
                    end)

                    local firefx3 = Battle.Artifact.new()
				    firefx3:set_facing(direction)
                    firefx3:set_texture(TEXTURE_FIREARM, true)
				    local fx3_anim = firefx3:get_animation()
				    fx3_anim:load(ANIMPATH_FIREARM)
				    fx3_anim:set_state("0")
                    fx3_anim:on_complete(function()
                        firefx3:erase()
                    end)
                    
                    local firefx4 = Battle.Artifact.new()
				    firefx4:set_facing(direction)
                    firefx4:set_texture(TEXTURE_FIREARM, true)
				    local fx4_anim = firefx4:get_animation()
				    fx4_anim:load(ANIMPATH_FIREARM)
				    fx4_anim:set_state("0")
                    fx4_anim:on_complete(function()
                        firefx4:erase()
                    end)
                    
                    local firefx5 = Battle.Artifact.new()
				    firefx5:set_facing(direction)
                    firefx5:set_texture(TEXTURE_FIREARM, true)
				    local fx5_anim = firefx5:get_animation()
				    fx5_anim:load(ANIMPATH_FIREARM)
				    fx5_anim:set_state("0")
                    fx5_anim:on_complete(function()
                        firefx5:erase()
                    end)

                    local tile_number = 0

                    for i = 1, 6, 1 do
                        if user:get_tile(direction, i):is_edge() then
                            break
                        else
                            tile_number = i
                        end
                    end

                    anim:on_frame(1, function()
                        print("FireMan: FireArm!")
                        Engine.play_audio(AUDIO_FIREARM, AudioPriority.High)
                        if tile_number >= 1 then
                            field:spawn(firefx1, user:get_tile(direction, 1))
                            if input_success then
                                field:spawn(firearm1m, user:get_tile(direction, 1))
                            else
                                field:spawn(firearm1, user:get_tile(direction, 1))
                            end
                        end
                    end)
                    anim:on_frame(4, function()
                        if tile_number >= 2 then
                            field:spawn(firefx2, user:get_tile(direction, 2))
                            if input_success then
                                field:spawn(firearm2m, user:get_tile(direction, 2))
                            else
                                field:spawn(firearm2, user:get_tile(direction, 2))
                            end
                        end
                    end)
                    anim:on_frame(7, function()
                        if tile_number >= 3 then
                            field:spawn(firefx3, user:get_tile(direction, 3))
                            if input_success then
                                field:spawn(firearm3m, user:get_tile(direction, 3))
                            else
                                field:spawn(firearm3, user:get_tile(direction, 3))
                            end
                        end
                    end)
                    anim:on_frame(10, function()
                        if tile_number >= 4 then
                            field:spawn(firefx4, user:get_tile(direction, 4))
                            if input_success then
                                field:spawn(firearm4m, user:get_tile(direction, 4))
                            else
                                field:spawn(firearm4, user:get_tile(direction, 4))
                            end
                        end
                    end)
                    anim:on_frame(13, function()
                        if tile_number >= 5 then
                            field:spawn(firefx5, user:get_tile(direction, 5))
                            if input_success then
                                field:spawn(firearm5m, user:get_tile(direction, 5))
                            else
                                field:spawn(firearm5, user:get_tile(direction, 5))
                            end
                        end
                    end)
                    anim:on_complete(function()
                        ref.fireman:erase()
                        step2:complete_step()
                    end)
                end
            end
        end
        self:add_step(step2)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_firearm(actor, animpath, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    spell:get_facing(direction)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(animpath)
    anim:set_state("0")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_hit_effect(field, spell:get_current_tile())
    end

    return spell
end

function create_firearm_magma(actor, animpath, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    spell:get_facing(direction)
    spell:set_texture(TEXTURE_ATTACK, true)
    spell:sprite():set_layer(-1)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(animpath)
    anim:set_state("0")
    anim:refresh(spell:sprite())
    anim:on_frame(38, function()
        local tile = spell:get_tile()
        tile:set_state(TileState.Lava)
    end)
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_hit_effect(field, spell:get_current_tile())
    end

    return spell
end

function create_hit_effect(field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(TEXTURE_EFFECT, true)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    hitfx_sprite:set_offset(math.random(-25,25), math.random(-25,25))
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(ANIMPATH_EFFECT)
	hitfx_anim:set_state("0")
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end