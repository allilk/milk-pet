
local ZAP_SFX = nil
local texture = nil
local shadow_texture = nil
local APPEAR_SFX = nil

function package_init(package) 
    package:declare_package_id("com.seabitty.sfgeminithunder")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'G'})

    local props = package:get_card_props()
    props.shortname = "GemnThnd"
    props.damage = 400
    props.time_freeze = true
    props.element = Element.Elec
    props.description = "GeminiThndr centr colmn!"
    props.card_class = CardClass.Giga
    props.limit = 1
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())
    local step = Battle.Step.new()
    local step_first = true

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete)
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:set_texture(texture, false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end
   
    
    local function laser_attack(self)
        local list = {}
        local field = self:get_field()
        local facing = self:get_facing()
        local tile = self:get_tile(facing, 1)
    
        table.insert(list, tile)
    
        local check_tile = tile
        for i=2, field:width()
        do
            check_tile = check_tile:get_tile(facing, 1)
            if check_tile and not check_tile:is_edge() then 
                table.insert(list, check_tile)
            else
                break
            end
        end
        
        local function spawn_spell(tile, lifetime)
            local spell = Battle.Spell.new(self:get_team())
            spell.lifetime = lifetime
            local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Stun | Hit.Pierce,
                Element.Elec, 
                self:get_id(), 
                Drag.None
            )
    
            spell:set_hit_props(hit_props)
    
            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self.lifetime = self.lifetime - 1
                if self.lifetime == 0 then 
                    self:delete()
                end
            end
            spell.attack_func = function()
            end

    
            field:spawn(spell, tile)
        end
    
    
        local function back_laser_attack(tile, lifetime)
            local artifact = graphic_init("artifact", 0, 0, texture, "GeminiSpark.animation", -4, "EXPLOSION", self, self:get_facing(), true)
            local tile1 = tile:get_tile(Direction.Up, 1)
            local tile2 = tile:get_tile(Direction.Down, 1) 
    
    
            field:spawn(artifact, tile)
            spawn_spell(tile1, 20)
            spawn_spell(tile2, 20)
    
        end
    
    
        for i=1, #list 
        do
            spawn_spell(list[i], 45)
        end
    
        back_laser_attack(list[#list], 20)
    

    
    end
    
    

    local gemini

    local actor
    step.update_func = function()
        if step_first then 
            actor:hide()
            field:spawn(gemini, user:get_current_tile())
            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)

            step_first = false
        end

    end

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        APPEAR_SFX = Engine.load_audio(_modpath.."spawn.ogg")
        ZAP_SFX = Engine.load_audio(_folderpath.."GeminiThunder.ogg")
        texture = Engine.load_texture(_modpath.."GeminiSpark.png")
        shadow_texture = Engine.load_texture(_modpath.."shadow.png")
        
        gemini = graphic_init("artifact", 0, 0, texture, "GeminiSpark.animation", -3, "DEFAULT", user, facing)
        gemini:set_team(user:get_team())

        local anim = gemini:get_animation()
        anim:on_complete(function()
            gemini:delete()
            step:complete_step()
            user:reveal()
        end)

        anim:on_frame(15, function()
            local laser_graphic = graphic_init("artifact", 0, 0, texture, "GeminiSpark.animation", -3, "LASER_GRAPHIC", gemini, gemini:get_facing(), true)

            gemini:get_field():spawn(laser_graphic, gemini:get_current_tile())
        end)

        anim:on_frame(16, function()
            Engine.play_audio(ZAP_SFX, AudioPriority.Low)
        end)

        anim:on_frame(18, function()
            laser_attack(gemini)
        end)
        




    end

    return action
end