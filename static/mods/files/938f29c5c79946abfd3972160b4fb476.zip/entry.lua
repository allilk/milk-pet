function package_init(package) 
    package:declare_package_id("com.navi.Searchman")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_special_description("Search out your foes")
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."searchmanOW.animation")
    package:set_overworld_texture_path(_modpath.."searchmanOW.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
end

function player_init(player)
    player:set_name("Searchman")
    player:set_health(1500)
    player:set_element(Element.Cursor)
    player:set_height(60.0)
    player:set_charge_position(0,-30)

    local base_animation_path = _modpath.."searchman_atlas.animation"
    local base_texture = Engine.load_texture(_modpath.."searchman_atlas.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(0,128,0, 255))

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end
end
