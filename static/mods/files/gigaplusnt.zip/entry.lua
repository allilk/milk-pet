function package_init(block)
    block:declare_package_id("com.isabelle.block.gigaplusnt")
    block:set_name("gigaplusnt")
    block:as_program()
    block:set_description("Does not add one extra giga")
    block:set_color(Blocks.Red)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)

end