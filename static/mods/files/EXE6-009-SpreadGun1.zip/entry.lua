local spreadgun = include("spreadgun/spreadgun.lua")

local DAMAGE = 30

spreadgun.codes = {"L","M","N","*"}
spreadgun.shortname = "SprdGun1"
spreadgun.damage = DAMAGE
spreadgun.time_freeze = false
spreadgun.element = Element.None
spreadgun.description = "Spreads to 1 sqr around!"
spreadgun.long_description = "When hits, spreads to 1 square around!"
spreadgun.can_boost = true
spreadgun.card_class = CardClass.Standard
spreadgun.memory = 10
spreadgun.limit = 5

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-009-SpreadGun1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(spreadgun.codes)

    local props = package:get_card_props()
    props.shortname = spreadgun.shortname
    props.damage = spreadgun.damage
    props.time_freeze = spreadgun.time_freeze
    props.element = spreadgun.element
    props.description = spreadgun.description
    props.long_description = spreadgun.long_description
    props.can_boost = spreadgun.can_boost
	props.card_class = spreadgun.card_class
	props.limit = spreadgun.limit
end

card_create_action = spreadgun.card_create_action