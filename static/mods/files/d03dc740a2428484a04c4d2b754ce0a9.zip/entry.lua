local DAMAGE = 0

local TEXTURE_KILLERSEYE = Engine.load_texture(_modpath.."killerseye.png")
local ANIMPATH_KILLERSEYE = _modpath .. "killerseye.animation"
local TEXTURE_KILLERSBEAM = Engine.load_texture(_modpath.."laser.png")
local ANIMPATH_KILLERSBEAM = _modpath .. "laser.animation"
local TEXTURE_BUTTON = Engine.load_texture(_modpath.."button.png")
local ANIMPATH_BUTTON = _modpath .. "button.animation"
local TEXTURE_SCAN = Engine.load_texture(_modpath.."scan.png")
local ANIMPATH_SCAN = _modpath .. "scan.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SCAN = Engine.load_audio(_modpath.."scan.ogg")
local AUDIO_KILLERSBEAM = Engine.load_audio(_modpath.."killersbeam.ogg")

function package_init(package) 
    package:declare_package_id("com.louis.k1rbyat1na.card.EXE3-181-KillersEye")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"E","I","K","L","R"})

    local props = package:get_card_props()
    props.shortname = "KillrEye"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Elec
    props.description = "Summons a KillerEye to fight!"
	props.long_description = "Summons a Killer's Eye to attack!"
	props.can_boost = false
    props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local step1 = Battle.Step.new()
		local sensor = Battle.Artifact.new()
		local do_once0 = true
		local do_once = true
		local do_once2 = true
		local max_duration = 490
		local current_time = 0
		local sensor_type = 1;
		local end_attack = -1
		local laserspells = {}
		local attacked = false
		step1.update_func = function(self, dt)
			if do_once0 then
                do_once0 = false
				sensor:set_facing(direction)
				sensor:set_texture(TEXTURE_KILLERSEYE, true)
				--sensor:set_offset(-8, -38)
				local killer_sprite = sensor:sprite()
				killer_sprite:set_layer(-3)
                local killer_anim = sensor:get_animation()
                killer_anim:load(ANIMPATH_KILLERSEYE)
                killer_anim:set_state("SPAWN")
		    	killer_anim:refresh(killer_sprite)
                killer_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
		    	killer_anim:on_complete(function()
		    		killer_anim:set_state("SEARCH")
					killer_anim:set_playback(Playback.Loop)
		    		killer_anim:refresh(killer_sprite)
		    	end)
				--[[local scan_forward = create_scanner(actor, user:get_tile(user:get_facing(), 1),1)
				local scan_up = create_scanner(actor, user:get_tile(user:get_facing(), 1),2)
				local scan_down = create_scanner(actor, user:get_tile(user:get_facing(), 1),3)]]
				local query = function() return true end
				local tile = user:get_tile(direction, 1)
				if not tile:is_walkable() or #tile:find_characters(query)~= 0 then
					sensor:delete()
					--[[erase_scanners(scan_forward)
					erase_scanners(scan_up)
					erase_scanners(scan_down)]]
					step1:complete_step()
				else
					field:spawn(sensor, tile)
				end
            end
			local anim = sensor:get_animation()
            if anim:get_state() == "SEARCH" then
				if do_once then
					do_once = false
					--[[sensor:set_facing(direction)
					sensor:set_texture(TEXTURE_KILLERSEYE, true)
					sensor:sprite():set_layer(-2)
					--sensor:set_offset(-8, -38)
					anim:load(ANIMPATH_KILLERSEYE)
					anim:set_state("SENSORSELECT")
					anim:set_playback(Playback.Loop)
					anim:refresh(sensor:sprite())]]

					local query = function() return true end
					local tile = user:get_tile(direction, 1)

					local button_gui = Battle.Artifact.new()
					button_gui:set_facing(Direction.Right)
		    		button_gui:set_texture(TEXTURE_BUTTON, true)
					local button_sprite = button_gui:sprite()
					button_sprite:set_layer(-9999999)
					local button_anim = button_gui:get_animation()
					button_anim:load(ANIMPATH_BUTTON)
					button_anim:set_state("0")
					button_anim:set_playback(Playback.Loop)
		    		button_anim:refresh(button_sprite)
					field:spawn(button_gui, tile)

					-- Create scanners:
					local scan_forward = create_scanner(actor, user:get_tile(user:get_facing(), 1),1)
					local scan_up = create_scanner(actor, user:get_tile(user:get_facing(), 1),2)
					local scan_down = create_scanner(actor, user:get_tile(user:get_facing(), 1),3)

					anim:on_frame(1,function ()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						sensor_type=1
						show_scanner(scan_forward)
						hide_scanner(scan_up, scan_down)
					end)
					anim:on_frame(2,function ()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						sensor_type=2
						show_scanner(scan_up)
						hide_scanner(scan_down, scan_forward)
					end)
					anim:on_frame(3,function ()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						sensor_type=3
						show_scanner(scan_down)
						hide_scanner(scan_up, scan_forward)
					end)
					anim:on_frame(4,function ()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						sensor_type=4
						show_scanner(scan_forward)
						hide_scanner(scan_up, scan_down)
					end)

					--[[if not tile:is_walkable() or #tile:find_characters(query)~= 0 then
						sensor:delete()
						erase_scanners(scan_forward)
						erase_scanners(scan_up)
						erase_scanners(scan_down)
						step1:complete_step()
					else
						field:spawn(sensor, tile)
					end]]

					sensor.update_func = function(self, dt)
						current_time=current_time+1
						if not attacked then
						if (user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot)) or current_time>=max_duration then
							if(do_once2) then
								button_gui:erase()
								anim:set_state("V"..sensor_type.."_ATTACK")
								anim:refresh(sensor:sprite())
								anim:on_frame(3, function()
									Engine.play_audio(AUDIO_KILLERSBEAM, AudioPriority.High)
									erase_scanners(scan_forward)
									erase_scanners(scan_up)
									erase_scanners(scan_down)
									laserspells = spawn_laser(team, field, user, user:get_tile(direction, 1), sensor_type)
								end)
								end_attack=200
								attacked = true
								do_once2=false
							end
						end
					end
				end
			end
			end
			if(end_attack == 100) then
				despawnLasers(laserspells)
				end_attack=end_attack-1
			elseif(end_attack == 35) then
				sensor:delete()
				step1:complete_step()
			elseif(end_attack > 0) then
				end_attack=end_attack-1
			end
		end
		self:add_step(step1)
	end
    return action
end

function create_scanner(owner, start_tile, sensor_type)
    local field = owner:get_field()
    local direction = getDirectionForSensorType(sensor_type, owner:get_facing())
	local nextile=start_tile
	local scanList = {}

	local scan_tile = function (tile)
		local scanner =  Battle.Artifact.new()
		scanner:set_facing(owner:get_facing())
		scanner:sprite():set_layer(-999)
		local sprite = scanner:sprite()
		sprite:set_texture(TEXTURE_SCAN)
		scanner:set_offset(0,-20)
		local animation = scanner:get_animation()
		animation:load(ANIMPATH_SCAN)
		if(isUpDirection(direction)) then
			if owner:get_tile():y() ~= 2 then
				--print("X ~= 2")
				if owner:get_facing() == Direction.Right then
					animation:set_state("DIAGONAL_1R")
				else
					animation:set_state("DIAGONAL_1L")
				end
			else
				--print("X == 2")
				animation:set_state("DIAGONAL_3")
			end
		elseif(isDownDirection(direction)) then
			if owner:get_tile():y() ~= 2 then
				--print("X ~= 2")
				if owner:get_facing() == Direction.Right then
					animation:set_state("DIAGONAL_2R")
				else
					animation:set_state("DIAGONAL_2L")
				end
			else
				--print("X == 2")
				animation:set_state("DIAGONAL_3")
			end
		else
			if owner:get_facing() == Direction.Right then
				animation:set_state("STRAIGHT_R")
			else
				animation:set_state("STRAIGHT_L")
			end
		end
		animation:set_playback(Playback.Loop)
		animation:refresh(sprite)
		if(tile == nil or tile:is_edge())  then
         return end
		field:spawn(scanner, tile)
		--scanner:hide()
		animation:refresh(sprite)
		table.insert(scanList, scanner)
	end
	--[[while (nextile ~= nil) do
		nextile = nextile:get_tile(direction, 1)
		scan_tile(nextile)
	end]]
	nextile = nextile:get_tile(direction, 1)
	scan_tile(nextile)
	return scanList
end

function hide_scanner(scanList1, scanList2)
	for index, scanner in ipairs(scanList1) do
		scanner:hide()
	end
	for index, scanner in ipairs(scanList2) do
		scanner:hide()
	end
end

function show_scanner(scanList)
	for index, scanner in ipairs(scanList) do
		scanner:reveal()
	end
end

function erase_scanners(scanList)
	for index, scanner in ipairs(scanList) do
		scanner:erase()
	end
end

function spawn_laser(team, field, owner, actor_tile, sensor_type)
    --spawn paralyzing laser for owner
	local laserspells = {}
    local owner_id = owner:get_id()
	local damage = getDamageForSensorType(sensor_type)
    local direction = getDirectionForSensorType(sensor_type, owner:get_facing())
	local tile = actor_tile:get_tile(direction,1)
    local spawn_next
    spawn_next = function()
        local spell = Battle.Spell.new(team)
        spell:set_facing(owner:get_facing())
        spell:set_hit_props(HitProps.new(damage, Hit.Stun | Hit.Flinch | Hit.Pierce, Element.Elec, owner_id, Drag.new()))
        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_KILLERSBEAM)
        spell:set_offset(-10,-50)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_KILLERSBEAM)
        if(isUpDirection(direction)) then
        	animation:set_state("DIAGONAL_1")
        elseif(isDownDirection(direction)) then
            animation:set_state("DIAGONAL_2")
        else
            animation:set_state("STRAIGHT")
        end
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)

        animation:on_frame(2, function()
            tile = getNextTile(direction, spell)
        end)
        animation:on_frame(4, function()
            spawn_next()
        end, true)
        animation:on_complete(function() 
            --spell:erase() 
            
        end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end
		spell.attack_func = function()
			create_hit_effect(field, spell:get_current_tile())
		end
        if tile == nil or tile:is_edge() then return end
        table.insert(laserspells, spell)
        field:spawn(spell, tile)
    end
    spawn_next()
	return laserspells
end

--Sensor utilities from killereyemob

function isForwardDirection(dir)
    -- check if direction is forward
    local returnval = (dir == Direction.Left or dir == Direction.Right)
    return returnval
end

function isUpDirection(dir)
    -- check if direction contains up
    return dir == Direction.UpLeft or dir == Direction.UpRight
end

function isDownDirection(dir)
    -- check if direction contains down
    return dir == Direction.DownLeft or dir == Direction.DownRight
end

function getNextTile(direction, spell) 
    local tile = spell:get_current_tile():get_tile(direction, 1)
    return tile
end

function getDirectionForSensorType(sensor_type, owner_facing)
	local basedir = Direction.None
	if(sensor_type==2) then
		basedir = Direction.Up
	elseif(sensor_type==3) then
		basedir = Direction.Down
	end
	return Direction.join(basedir, owner_facing)
end

function getDamageForSensorType(sensor_type) 
    if(sensor_type<=3) then
		return 100
	end
	return 150
end

function despawnLasers(laserspells) 
	for index, laser in ipairs(laserspells) do
		laser:erase()
		laserspells[index]=nil
	end
end

function create_hit_effect(field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(Engine.load_texture(_folderpath.."effect.png"), true)
	hitfx:set_offset(math.random(-10,10), math.random(-10,10))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(_folderpath.."effect.animation")
	hitfx_anim:set_state("0")
	hitfx_anim:refresh(hitfx_sprite)
	hitfx_anim:on_frame(1, function()
        Engine.play_audio(Engine.load_audio(_folderpath.."hitsound.ogg"), AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end