local HIT_SFX = nil
local APPEAR_SFX = nil
local SHOCKWAVE_SFX = nil
local WATER_SFX = nil
local DASH_SFX = nil
local CHARGE_SFX = nil



function package_init(package) 
    package:declare_package_id("com.alrysc.card.CirnoV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C','Q'})

    local props = package:get_card_props()
    props.shortname = "CirnoV3"
    props.damage = 170
    props.time_freeze = true
    props.element = Element.Aqua
    props.description = "Charge! Pierce over ice!"
    props.card_class = CardClass.Mega
    props.limit = 1
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true

    local actor = nil
    local cirno = nil
    local cirno_mover = nil
    local ice = nil
    local anim = nil

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local function move_slide_horizontal(self, mover, direction, moveTime)
        local slide_component = Battle.Component.new(mover, Lifetimes.Local)
        mover.sliding = true
        local startPosition = 0
        local target = -80
        if direction == Direction.Right then 
            target = target * -1
        end
        local elapsedMoveTime = 0
        local delta = 0
    
        local interp = 0
        local tileOffset = 0 
        local t = self:get_tile(direction, 1);
    
        local moved = false;
        local already_moved = false;
        slide_component.update_func = function()
            if not self.charge and self:get_current_tile():get_state() == TileState.Ice then
                self.charge = true
                moveTime = math.ceil(3*moveTime/4)
            end
            if delta >= 0.5 and not moved then 
                target = 0
            end
            
            delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
            interp =  target * delta + (startPosition * (1 - delta))
            
            tileOffset = interp - startPosition
            if delta >= 0.5 then
                tileOffset = -1*target + startPosition + tileOffset
            end
    

    
            -- Offsets are reflected a frame later than they're set
                -- So this moves us a frame later than we set an offset 
                -- for the new panel
            if moved and not already_moved then 
                already_moved = true
                start_tile = self:get_current_tile()
                start_tile:get_tile(direction, 1):add_entity(self)
                start_tile:remove_entity_by_id(self:get_id())
            end
    
            if delta >=0.5 and not moved then             
                moved = true
    
            end
    
            self:set_offset(tileOffset, 0)
    
    
            if elapsedMoveTime >= moveTime then 
                mover.sliding = false
                slide_component:eject()
                self:set_offset(0, 0)
    
    
            end
    
            elapsedMoveTime = elapsedMoveTime + 1
    
        end
    
    
        mover:register_component(slide_component)
    
      
    end

    local count = 0
    local finish_delay = 10
    local can_end = false
    step.update_func = function()
        if count == 3 then 
            actor:hide()
            tile = user:get_current_tile()
            field:spawn(cirno, tile)
            field:spawn(ice, tile)
            field:spawn(cirno_mover, tile)

            Engine.play_audio(SHOCKWAVE_SFX, AudioPriority.Low)

        end

        if can_end then 
            finish_delay = finish_delay - 1
            if finish_delay == 0 then 
                step:complete_step()
            end
        end
        

        count = count + 1
    end


    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
        SHOCKWAVE_SFX = Engine.load_audio(_folderpath.."break.ogg")
        WATER_SFX = Engine.load_audio(_folderpath.."water.ogg")
        DASH_SFX = Engine.load_audio(_folderpath.."dash.ogg")
        CHARGE_SFX = Engine.load_audio(_folderpath.."shoot.ogg")

        
        cirno = graphic_init("spell", 0, 0, "cirno.png", "cirno.animation", -5, "DEFAULT", user, facing)
        ice = graphic_init("spell", 0, 0, "effects.png", "effects.animation", -6, "ICE", user, facing, true)
        cirno.sliding = false
        cirno.is_boosted = false
        

        cirno_mover = Battle.Artifact.new()

        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking | Hit.Shake,
                Element.Aqua, 
                user:get_context(), 
                Drag.None
            )

        cirno:set_hit_props(hit_props)

        cirno.can_move_to_func = function()
            return true
        end
        anim = cirno:get_animation()
        anim:on_complete(function()
            cirno:highlight_tile(Highlight.Solid)

            Engine.play_audio(DASH_SFX, AudioPriority.Low)
            cirno.update_func = function()
                if not cirno.is_boosted and cirno:get_current_tile():get_state() == TileState.Ice then 
                    Engine.play_audio(CHARGE_SFX, AudioPriority.Low)
                    hit_props.damage = hit_props.damage*2
                    cirno:set_hit_props(hit_props)
                    anim:set_state("CHARGE")
                    anim:refresh(cirno:sprite())

                    cirno.is_boosted = true
                end
                if not cirno_mover.sliding then 
                    local speed = 10
                    if cirno.charge then speed = 5 end
                    if cirno:get_tile(cirno:get_facing(), 1):is_edge() then 
                        cirno:delete()
                        cirno_mover:delete()
                        user:reveal()
                        can_end = true
                    else
                        cirno_mover.sliding = true
                        move_slide_horizontal(cirno, cirno_mover, cirno:get_facing(), speed)
                    end
                end

                if cirno.is_boosted or not cirno.has_hit then 
                    cirno:get_current_tile():attack_entities(cirno)
                end
            end
        end)

        anim:on_frame(7, function()
            Engine.play_audio(WATER_SFX, AudioPriority.Low)
        end)

        cirno.attack_func = function(self, other)
            if not self.is_boosted then 
                anim:set_state("NO_ICE")
                anim:refresh(cirno:sprite())
            end
            cirno.has_hit = true
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

            user:get_field():spawn(graphic_init("artifact", 0, 0, "effects.png", "effects.animation", -6, "HIT_EFFECT", user, cirno:get_facing(), true), other:get_current_tile())

            local shake_artifact = Battle.Artifact.new()
            local time = 0
            shake_artifact.update_func = function(self)
                    
                self:shake_camera(150, 0.016)
                if time == 8 then 
                    self:delete()
                end
            
                time = time+1
            end

            user:get_field():spawn(shake_artifact, tile)
        end


    end


    return action
end