nonce = function() end

local DAMAGE = 160
local TEXTURE = Engine.load_texture(_modpath.."spell_zapring.png")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster_zapring.png")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")
local AUDIO_HEAL = Engine.load_audio(_modpath.."sfx.ogg")


local AUDIO_shotgun = Engine.load_audio(_modpath.."shock.ogg")
function package_init(package) 
    package:declare_package_id("com.DJ.CurrentLane")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"C","H", "L"})

    local props = package:get_card_props()
    props.shortname = "CrntLane"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Reverse Arc Strike!"
    props.long_description = "Reverse Arc heals if Navi is Elec"
    props.card_class = CardClass.Standard
    props.limit = 2
end

--[[
    1. megaman loads buster
    2. zapring flies out
--]]

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    local frame1 = {1, 0.2}
	local frame2 = {2, 0.09}
	local frame3 = {2, 0.09}
    local frame4 = {2, 0.09}
    local frame5 = {3, 0.15}


  
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5})
    action:override_animation_frames(frame_sequence)
	
	action:set_lockout(make_animation_lockout())
   
    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
       

       
        
	local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."buster_zapring.animation")
		buster_anim:set_state("DEFAULT")
        
	
    
        self:add_anim_action(2, function() 
          local animation_state = "DEFAULT"
		  
          local tile = user:get_tile(user:get_facing(), 3)
          local cannonshot1 = create_zap(animation_state,user, props)
          actor:get_field():spawn(cannonshot1, tile)
          
          
          Engine.play_audio(AUDIO_shotgun, AudioPriority.Highest)
        end)

      
         

          
          self:add_anim_action(5, function() 
            
            
            
             
            
            
            
        
            
    
            
            
            
          end)
         

    end

    
    return action

    

    
end

function create_zap(animation_state, user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(TEXTURE, true)
    spell:highlight_tile(Highlight.Solid)
	local direction = user:get_facing_away()
    spell.slide_started = false
	
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash, 
            Element.Elec,
            user:get_context(),
            Drag.None
        )
    )
	

    local anim = spell:get_animation()
    anim:load(_modpath.."spell_zapring.animation")
    anim:set_state(animation_state)
    
    
    spell.update_func = function(self, dt) 
        
        spell:get_tile():attack_entities(self)
        if self:is_sliding() == false then 
            local dest = self:get_tile(direction, 1)
			local ref = self
			self:slide(dest, frames(9), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
        if not user:is_deleted() and user:get_current_tile() == spell:get_current_tile() then
            self:delete()
        if user:get_element() == Element.Elec then
         user:set_health(user:get_health() + 100)
         Engine.play_audio(AUDIO_HEAL, AudioPriority.High)
         

			
        
    
        end
    end
end
    
    
        

    
    
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        
       
        
    end
	
	spell.collision_func = function(self, other)
        
        
	
	end
	
    spell.delete_func = function(self) 
    
    end

    spell.can_move_to_func = function(tile)
        return true
        
        
    end

	

    return spell
end



