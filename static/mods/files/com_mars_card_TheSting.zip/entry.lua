
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."hive.png")
local SHOT_TEXTURE = Engine.load_texture(_modpath.."bees.png")

local BLOCKED_TEXTURE = Engine.load_texture(_modpath.."guard_hit.png")
local BLOCKED_ANIM_PATH = _modpath .. "guard_hit.animation"
local BLOCKED_SFX = Engine.load_audio(_modpath.."tink.ogg")

local HIT_TEXTURE = Engine.load_texture(_modpath.."wood_hit.png")
local HIT_ANIM_PATH = _modpath .. "wood_hit.animation"
local HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")

local SMOKE_TEXTURE = Engine.load_texture(_modpath.."smoke.png")
local SMOKE_ANIM_PATH = _modpath .. "smoke.animation"
local PANEL_SFX = Engine.load_audio(_modpath.."PanelCrack.ogg")

local f = 0.016
local FRAME1 = {1,2*f}
local FRAME2 = {1,2*f}
local FRAMES = make_frame_data({
	FRAME1, FRAME2, FRAME1, FRAME2, FRAME1, 
	FRAME2, FRAME1, FRAME2, FRAME1, FRAME2,
	FRAME1, FRAME2, FRAME1, FRAME2, FRAME1,
	FRAME2, FRAME1, FRAME2, FRAME1, FRAME2, 
	FRAME2, FRAME1, FRAME2, FRAME1, FRAME2, 
	FRAME1, FRAME2, FRAME1, FRAME2, FRAME1,
	FRAME2, FRAME1, FRAME2, FRAME1, FRAME2, 
	FRAME2, FRAME1, FRAME2, FRAME1, FRAME2, 
	FRAME1, FRAME2, FRAME1, FRAME2, FRAME1
	})

function package_init(package) 
    package:declare_package_id("com.mars.card.TheSting")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'S'})

    local props = package:get_card_props()
    props.shortname = "TheSting"
    props.damage = 5
    props.can_boost = false
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Thinkin about the TheSting"
    props.long_description = "Real ones know about The Sting"
    props.limit = 1
    props.card_class = CardClass.Dark
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(FRAMES)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."hive.animation")
		buster_anim:set_state("DEFAULT")
		buster_anim:set_playback(Playback.Loop)
		add_defense(user)
		local current_tile = user:get_current_tile()
		local tile_state = current_tile:get_state()
		if not (tile_state == TileState.Empty or tile_state == TileState.Hidden) then
			Engine.play_audio(PANEL_SFX, AudioPriority.High)
			current_tile:set_state(TileState.Poison)
			make_smoke(user)
		end

		for ii=2,40,2 do
			action:add_anim_action(ii, function()
				local tile = user:get_tile(user:get_facing(), 1)
				local shot = create_bees(user, props)
				actor:get_field():spawn(shot, tile)

				local hit = hit_self(user)
				local self_tile = user:get_current_tile()
				actor:get_field():spawn(hit, self_tile)
			end)
		end
	end
    return action
end

function make_smoke(user)
	local artifact = Battle.Spell.new(user:get_team())
	artifact:sprite():set_layer(1)
	local artifanim = artifact:get_animation()
	artifanim:load(SMOKE_ANIM_PATH)
	artifanim:set_state("DEFAULT")
	artifact:set_offset(0, -10)
	artifact:set_texture(SMOKE_TEXTURE, true)
	artifanim:refresh(artifact:sprite())
	artifanim:on_complete(function()
		artifact:erase()
	end)
	local field = user:get_field()
	local tile = user:get_current_tile()
	field:spawn(artifact, tile:x(), tile:y())
end

function bee_hit(user, props, wait_time)
	local bh_spell = Battle.Spell.new(user:get_team())
	bh_spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch,
			props.element,
			user:get_context(),
			Drag.None
		)
	)

	local bh_field
	local bh_tile
	local bh_lifetime = 2

	bh_spell.update_func = function(self)
		bh_field = bh_spell:get_field()
		bh_tile = bh_spell:get_current_tile()

		if wait_time < 1 then
			bh_tile:attack_entities(bh_spell)
			bh_lifetime = bh_lifetime - 1
			if bh_lifetime < 1 then
				self:delete()
			end
		end
		wait_time = wait_time - 1
	end

    bh_spell.collision_func = function(self, other) 
		local artifact = Battle.Spell.new(Team.Other)
		artifact:sprite():set_layer(-1)
		local artifanim = artifact:get_animation()
		artifanim:load(HIT_ANIM_PATH)
		artifanim:set_state("DEFAULT")
		artifact:set_offset(math.random(-20,20), (-40) + math.random(-20,20))
		artifact:set_texture(HIT_TEXTURE, true)
		artifanim:refresh(artifact:sprite())
		artifanim:on_complete(function()
			artifact:erase()
		end)
		local tile = bh_spell:get_current_tile()
		bh_field:spawn(artifact, tile:x(), tile:y())
		Engine.play_audio(HIT_SFX, AudioPriority.Low)
		self:delete()
    end
	bh_spell.delete_func = function(self)
		self:erase()
	end
	bh_spell.can_move_to_func = function(tile)
		return true
	end
	return bh_spell
end

function create_bees(user, props)
	local spell = Battle.Spell.new(user:get_team())
	local direction = user:get_facing()
	spell:set_facing(direction)
	spell:set_hit_props(
		HitProps.new(
			0,
			Hit.Impact,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(SHOT_TEXTURE, true)
	anim:load(_modpath.."bees.animation")
	local ran_anim = {"ONE", "TWO", "THREE"}
	anim:set_state(ran_anim[math.random(#ran_anim)])
	anim:set_playback(Playback.Loop)

	local target = nil
	local field = user:get_field()
	local prev_direction
	local turn_count = 3
	local delete_self
	local delete_timer = 12
	local move_delay = true

	spell.update_func = function(self, dt)
		local tile = spell:get_current_tile()
		-- delete when going off field
		if tile:is_edge() then
			spell:erase()
		end

		if delete_self then
			delete_timer = delete_timer -1
			if delete_timer < 1 then
				self:delete()
			end
			return
		end
		-- Always affect the tile we're occupying
		tile:attack_entities(spell)

		if move_delay then
			move_delay = nil
			return
		end

		-- Find target if we don't have one
		if not target then
			local closest_dist = math.huge

			field:find_characters(function(character)
				local character_team = character:get_team()
				if (
					character_team == user:get_team() or
					character_team == Team.Other or
					character:will_erase_eof()
				) then
					return false
				end
				if not target then
					target = character
				else
					-- If the distance to one enemy is shorter than the other, target the shortest enemy path
					local dist = math.abs(tile:x() - character:get_current_tile():x()) + math.abs(tile:y() - character:get_current_tile():y())

					if dist < closest_dist then
						target = character
						closest_dist = dist
					end
				end
				return false
			end)
			-- We have found a target
			-- Create a notifier so we can null the target when they are deleted
			if target then
				local callback = function()
					target = nil
				end
				field:notify_on_delete(target:get_id(), spell:get_id(), callback)
			end
		end

		-- If sliding is flagged to false, we know we've ended a move
		if not spell:is_sliding() then

			if target and turn_count > 0 then
				local target_tile = target:get_current_tile()
				if target_tile then
					local txy = {target_tile:x(), target_tile:y()}
					local xy = {tile:x(), tile:y()}
					local xdif = txy[1] - xy[1]
					local newxdif = txy[1] - spell:get_tile(direction, 1):x()
					if math.abs(newxdif) > math.abs(xdif) then
						if target_tile:y() < tile:y() then
							direction = Direction.Up
						elseif target_tile:y() > tile:y() then
							direction = Direction.Down
						elseif target_tile:x() < tile:x() then
							direction = Direction.Left
						elseif target_tile:x() > tile:x() then
							direction = Direction.Right
						end
					else
						if target_tile:x() < tile:x() then
							direction = Direction.Left
						elseif target_tile:x() > tile:x() then
							direction = Direction.Right
						end
					end

					-- Poll if target is flagged for deletion, remove our mark
					if target:will_erase_eof() then
						target = nil
					end
				end
			end
			-- Always slide to the tile we're moving to
			local next_tile = spell:get_tile(direction, 1)
			spell:slide(next_tile, frames(15), frames(0), ActionOrder.Voluntary, nil)
		end
	end

    spell.collision_func = function(self, other)
    	local tile = self:get_current_tile() 
    	local state = self:get_animation():get_state()
    	local facing = self:get_facing()
    	local bees1 = bee_hit(user, props, 0)
    	local bees2 = bee_hit(user, props, math.floor(delete_timer/2))
    	local bees3 = bee_hit(user, props, delete_timer)
    	field:spawn(bees1, tile)
    	field:spawn(bees2, tile)
    	field:spawn(bees3, tile)
		delete_self = true
    end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	return spell
end

function hit_self(user)
	local spell = Battle.Spell.new(Team.Other)
	spell:set_hit_props(
		HitProps.new(
			0,
			Hit.Impact | Hit.Pierce,
			Element.None,
			user:get_context(),
			Drag.None
		)
	)
	local field = user:get_field()
	local lifetime = 1

	spell.update_func = function(self)
		local tile = spell:get_current_tile()
		tile:attack_entities(spell)

		lifetime = lifetime - 1
		if lifetime < 1 then
			self:delete()
		end
	end
    spell.collision_func = function(self, other) 
		local artifact = Battle.Spell.new(Team.Other)
		artifact:sprite():set_layer(-1)
		local artifanim = artifact:get_animation()
		artifanim:load(BLOCKED_ANIM_PATH)
		artifanim:set_state("DEFAULT")
		artifact:set_offset(math.random(-20,20), (-40) + math.random(-20,20))
		artifact:set_texture(BLOCKED_TEXTURE, true)
		artifanim:refresh(artifact:sprite())
		artifanim:on_complete(function()
			artifact:erase()
		end)
		local tile = spell:get_current_tile()
		field:spawn(artifact, tile:x(), tile:y())

		Engine.play_audio(BLOCKED_SFX, AudioPriority.Low)
		self:delete()
    end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	return spell
end

function add_defense(user)
	local hivelife = Battle.Component.new(user, Lifetimes.Battlestep)
	local hivetime = 46
	local hive = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
	hive.can_block_func = function(judge, attacker, defender)
		hits = attacker:copy_hit_props()
		if (hits.element ~= Element.Fire) then
			judge:block_damage()
			judge:block_impact()
		end
	end
	hivelife.update_func = function(self)
		hivetime = hivetime - 1
		if hivetime < 0 then
			self:eject()
			self:get_owner():remove_defense_rule(hive)
		end
	end
	user:register_component(hivelife)
	user:add_defense_rule(hive)
end