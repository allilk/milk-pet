function package_init(package)
    package:declare_package_id("com.Dawn.BasicVersion.HarpyV1")
    package:set_special_description("Personal Navi, Ver.001!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."harpyow.animation")
    package:set_overworld_texture_path(_modpath.."harpyow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
	player:set_name("HarpyV1")
	player:set_health(1500)
	player:set_element(Element.None)
    player:set_height(70.0)
    player:set_animation(_modpath.."harpybat.animation")
    player:set_texture(Engine.load_texture(_modpath.."harpybat.greyscaled.png"), false)
	local base_palette = Engine.load_texture(_modpath.."harpybat.palette.png")
	local base_charge_color = Color.new(0, 100, 200, 255)
	player:set_fully_charged_color(base_charge_color)
	player:set_charge_position(0, -35)
	
	player:set_palette(base_palette)
	
	player.update_func = function(self, dt)
		--nothing
    end
	
    player.normal_attack_func = function(player)
		print("buster attack")
		return Battle.Buster.new(player, false, player:get_attack_level() * 1)
	end
    player.charged_attack_func = function(player)
		print("buster attack charged")
		return Battle.Buster.new(player, true, player:get_attack_level() * 10)
	end
end