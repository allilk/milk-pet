local DAMAGE = 50

local TEXTURE_FORTE = Engine.load_texture(_modpath.."forte.png")
local TEXTURE_EXPLOSION = Engine.load_texture(_modpath.."explosion.png")
local ANIMPATH_FORTE = _modpath.."forte.animation"
local ANIMPATH_EXPLOSION = _modpath.."explosion.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_CHARGE = Engine.load_audio(_modpath.."charge.ogg")
local AUDIO_AIRBURST = Engine.load_audio(_modpath.."airburst.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-248-Forte")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F"})

    local props = package:get_card_props()
    props.shortname = "Bass"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "AirBurst attacks all rows!"
    props.long_description = "Air Burst attacks on all rows!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset = nil

        if direction == Direction.Right then
            X_offset = X + 1
        else
            X_offset = X - 1
        end

		local step1 = Battle.Step.new()

        self.forte = nil
        self.tile  = user:get_current_tile()
        
        local field = user:get_field()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.forte = Battle.Artifact.new()
                ref.forte:set_facing(user:get_facing())
		    	ref.forte:set_texture(TEXTURE_FORTE, true)
		    	ref.forte:sprite():set_layer(-1)

                forte_anim = ref.forte:get_animation()
                forte_anim:load(ANIMPATH_FORTE)
                forte_anim:set_state("SPAWN")
		    	forte_anim:refresh(ref.forte:sprite())
                forte_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
		    	end)
                forte_anim:on_frame(12, function()
		    		Engine.play_audio(AUDIO_CHARGE, AudioPriority.High)
		    	end)
		    	forte_anim:on_complete(function()
		    		forte_anim:set_state("ATTACK")
		    		forte_anim:refresh(ref.forte:sprite())
		    	end)
                field:spawn(ref.forte, ref.tile)
            end
            local anim = ref.forte:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local explosion_01 = create_explosion(user, props)
                    local explosion_02 = create_explosion(user, props)
                    local explosion_03 = create_explosion(user, props)
                    local explosion_04 = create_explosion(user, props)
                    local explosion_05 = create_explosion(user, props)
                    local explosion_06 = create_explosion(user, props)
                    local explosion_07 = create_explosion(user, props)
                    local explosion_08 = create_explosion(user, props)
                    local explosion_09 = create_explosion(user, props)
                    local explosion_10 = create_explosion(user, props)
                    local explosion_11 = create_explosion(user, props)
                    local explosion_12 = create_explosion(user, props)
                    local explosion_13 = create_explosion(user, props)
                    local explosion_14 = create_explosion(user, props)
                    local explosion_15 = create_explosion(user, props)
                    local explosion_16 = create_explosion(user, props)
                    local explosion_17 = create_explosion(user, props)
                    local explosion_18 = create_explosion(user, props)
                    local explosion_19 = create_explosion(user, props)
                    local explosion_20 = create_explosion(user, props)
                    anim:on_frame(1, function()
                        print("Forte: Explosion!")
                        ref.forte:shake_camera(4, 4)
                    end)
                    anim:on_frame(9, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_01, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(21, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_02, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(33, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_03, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(45, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_04, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(57, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_05, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(69, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_06, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(77, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_07, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(85, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_08, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(93, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_09, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(101, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_10, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(109, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_11, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(117, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_12, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(129, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_13, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(137, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_14, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(145, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_15, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(157, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_16, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(165, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_17, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(177, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_18, X_offset, math.random(1,3))
                    end)
                    anim:on_frame(185, function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_19, X_offset, math.random(1,3))
                    end)
                    anim:on_complete(function()
                        Engine.play_audio(AUDIO_AIRBURST, AudioPriority.Highest)
                        field:spawn(explosion_20, X_offset, math.random(1,3))
                        anim:set_state("END")
                        anim:refresh(ref.forte:sprite())
                        anim:on_complete(function()
                            ref.forte:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_explosion(user, props)
    local spell = Battle.Spell.new(user:get_team())
    local direction = user:get_facing()
    local field = user:get_field()
    local anim = spell:get_animation()
    spell:set_facing(direction)
    spell:highlight_tile(Highlight.Solid) 
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE_EXPLOSION)
    local anim = spell:get_animation()
    anim:load(ANIMPATH_EXPLOSION)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_frame(7, function()
        tile = spell:get_tile(direction, 1)
        create_explosion_2(user, props, field, tile)
    end, true)
    anim:on_complete(function() spell:erase() end)
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    
	spell.collision_func = function(self, other)
        spell:erase()
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
		spell:erase()
	end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

function create_explosion_2(user, props, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(user:get_team())
        local direction = user:get_facing()
        local anim = spell:get_animation()
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch,
                props.element, 
                user:get_id(), 
                Drag.None
            )
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_EXPLOSION)

        local anim = spell:get_animation()
        anim:load(ANIMPATH_EXPLOSION)
        anim:set_state("1")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        anim:on_complete(function() spell:erase() end)
        
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other) 
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end
        
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
        
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end