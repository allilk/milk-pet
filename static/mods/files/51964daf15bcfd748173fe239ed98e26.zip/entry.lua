function package_init(package) 
    package:declare_package_id("com.alrysc.card.EleFang1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'A','I', 'R', '*'})

    local props = package:get_card_props()
    props.shortname = "EleFang1"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Forked electric bolts!"
    props.limit = 5

end



local HIT = Engine.load_audio(_modpath.."hit.ogg")
local SHOOT = Engine.load_audio(_modpath.."thunder.ogg")

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        -- 11, 1, 21 and check that 21 because it might last a little longer
        {1, 0.183}, {2, 0.016}, {1, 0.0166}, {1, 0.4}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local spell_list = {}

    
    local function create_fork(user)
        local facing = user:get_facing()
        local tile = user:get_tile(facing, 1)

        local t2 = tile:get_tile(Direction.Up, 1)
        local t3 = tile:get_tile(Direction.Down, 1)

    end


    local function create_bolt(user, tile, dir, elevation)
        if not tile then return end
        local spell = graphic_init("spell", 0, 0, "electricity.png", "electricity.animation", -4, "BOLT_"..dir, user, user:get_facing(), true)
        if not tile:is_edge() then 
            spell:highlight_tile(Highlight.Solid)
        end

        spell:set_elevation(elevation)


        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Elec, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            local t = self:get_current_tile()
            if not t:is_edge() then 
                self:get_current_tile():attack_entities(self)
            end
        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        user:get_field():spawn(spell, tile)
    end

    action.execute_func = function(self)
        action:add_anim_action(1, function()
            local attach = self:add_attachment("Buster")
            local attach_sprite = attach:sprite()
            attach_sprite:set_texture(Engine.load_texture(_modpath.."attachment.png"), false)
            attach_sprite:set_layer(-2)
            attach_sprite:enable_parent_shader(false)
            
            local attach_anim = attach:get_animation()
            attach_anim:load(_modpath.."attachment.animation")
            attach_anim:set_state("DEFAULT")

        
        
        end)

        local point = nil
        local origin = nil
        local elevation = nil
        action:add_anim_action(3, function()
            point = user:get_animation():point("buster")
            origin = user:get_animation():point("origin")
            elevation = ((origin.y - point.y)*2)
            create_bolt(user, user:get_tile(user:get_facing(), 1), "CENTER", elevation)
            Engine.play_audio(SHOOT, AudioPriority.Low)

        end)

        action:add_anim_action(4, function()
            local facing = user:get_facing()

            local front = user:get_tile(facing, 1)
            local t = front:get_tile(Direction.Up, 1)
            local t2 = front:get_tile(Direction.Down, 1)
            local field = user:get_field()
            local tiles = {}

            create_bolt(user, t, "UP", elevation)
            create_bolt(user, t2, "DOWN", elevation)

            for i=1, field:width()
            do
                local temp = t:get_tile(facing, 1)
                if temp then
                    create_bolt(user, temp, "TOP", elevation)
                    t = temp
                else
                    break
                end
            end

            t = t2
            tiles = {}

            for i=1, field:width()
            do
                local temp = t:get_tile(facing, 1)
                if temp then
                    create_bolt(user, temp, "BOTTOM", elevation)
                    t = temp
                else
                    break
                end
            end


        end)
    end

    return action
end