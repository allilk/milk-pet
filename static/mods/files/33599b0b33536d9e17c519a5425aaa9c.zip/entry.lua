local HIT_SFX = nil
--local APPEAR_SFX = nil
local GUITAR_SFX = nil
local SHOT_SFX = nil
local STRING_SFX = nil


function package_init(package) 
    package:declare_package_id("com.alrysc.card.HarpNote")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'H','*'})

    local props = package:get_card_props()
    props.shortname = "HarpNote"
    props.damage = 20
    props.time_freeze = true
    props.element = Element.None
    props.description = "5 hit if enmy ahd, else 3!"
    props.card_class = CardClass.Mega
    props.limit = 2
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    local facing = nil
    action:set_lockout(make_sequence_lockout())

    local actor = nil

    local harpnote = nil
    local anim = nil
    local speaker1 = nil
    local speaker2 = nil

    local string_start = nil
    local string_middle = nil
    local string_end = nil

    local string_notes = 5
    local speaker_notes = 3
    local last_note = nil -- Last note created. Stuff ends when deleted. Sure hope it doesn't lead to softlocks

    local start_step = Battle.Step.new()
    local start_first = true

    local string_step = Battle.Step.new()
    local string_first = true

    local attack_step = Battle.Step.new()
    local attack_first = true

    local speaker_step = Battle.Step.new()
    local speaker_first = true

    local finish_step = Battle.Step.new()
    local finish_first = true

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function create_note(user, tile, from_string)
        local sound = GUITAR_SFX
        if from_string then 
            sound = SHOT_SFX
        end

        if not tile or (tile and tile:is_edge()) then 
            Engine.play_audio(sound, AudioPriority.Low)
            return
        end
        local spell = graphic_init("spell", 0, -28, "harpnote.png", "harpnote.animation", -7, "NOTE", user, facing)
        spell:get_animation():set_playback(Playback.Loop)

        local flags = Hit.Impact | Hit.Stun | Hit.Shake

        if from_string then 
            flags = flags | Hit.Breaking 
        end

        spell.on_spawn_func = function()
            Engine.play_audio(sound, AudioPriority.Low)
        end


        local hit_props = HitProps.new(
            props.damage,
            flags,
            props.element, 
            user:get_context(), 
            Drag.None
        )


        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
    
                end 
                
                local dest = self:get_tile(facing, 1)
                local ref = self
                self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end

        end
        

        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

        end
        spell.can_move_to_func = function()
            return true
        end

        field:spawn(spell, tile)

        return spell
    end

    local function create_speaker(user, tile)
        local ob = nil
        if tile and not tile:is_edge() then 
            ob = tile:find_obstacles(function(o)
                return o:get_health() > 0
            end)
        end

        if not (ob and #ob == 0 and not tile:is_reserved({})) then return nil end

        local spell = graphic_init("spell", 0, 0, "harpnote.png", "harpnote.animation", -3, "SPEAKER", user, facing)


        spell.on_spawn_func = function()
            Engine.play_audio(AudioType.Appear, AudioPriority.Low)
        end

        field:spawn(spell, tile)

        return spell
    end

    local function create_string(user, tile)
        local offset = 38
        local y = -46

        local width = 8
        local speed = 20
        string_start = graphic_init("spell", offset, y, "harpnote.png", "harpnote.animation", -5, "STRING_START", user, facing)
        string_middle = graphic_init("spell", offset+6, y, "harpnote.png", "harpnote.animation", -4, "STRING_MIDDLE", user, facing)
        string_end = graphic_init("spell", offset+speed, y, "harpnote.png", "harpnote.animation", -5, "STRING_END", user, facing)
        
        local sprite = string_middle:sprite()


        local function create_string_box(tile)
            local spell = Battle.Spell.new(user:get_team())

            local hit_props = HitProps.new(
                0,
                Hit.Impact | Hit.Shake,
                Element.None, 
                user:get_context(), 
                Drag.None
            )


            spell:set_hit_props(hit_props)

            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self:delete()
            end


            field:spawn(spell, tile)
        end

        string_start.on_spawn_func = function()
            Engine.play_audio(STRING_SFX, AudioPriority.Low)
        end

        local dir = 1

        if facing == Direction.Left then 
            dir = -1
        end
        
        -- That offset is in the wrong direction, probably. Check facing. 
        sprite:set_width(dir*width)
        string_end:set_offset(dir*(offset+speed+width), y)

        local iter_tile = tile
        local string_frame = false
        string_middle.update_func = function()
            width = width + speed
            sprite:set_width(dir*width)
            string_end:set_offset(dir*(offset+speed+width), y)

            if iter_tile and not iter_tile:is_edge() and string_frame then 
                create_string_box(iter_tile)
                iter_tile = iter_tile:get_tile(facing, 1)
            end

            string_frame = not string_frame
        end

        field:spawn(string_start, tile)
        field:spawn(string_middle, tile)
        field:spawn(string_end, tile)
    end


    local function enemy_lined_up(user)
        local y = user:get_current_tile():y()
        local team = user:get_team()
        local list = field:find_characters(function(c)
            return c:get_team() ~= team and c:get_current_tile():y() == y
        end)


        return #list > 0
    end

    local count = 0
    local finish_delay = 40
    local can_end = false
    local should_string = false
    local start_delay = 33
    start_step.update_func = function()
        if count == 3 then 
            actor:hide()
            local tile = user:get_current_tile()
            field:spawn(harpnote, tile)

            harpnote:get_animation():on_complete(function()
                if not tile:is_walkable() then 
                    can_end = true
                    anim:set_state("LEAVE")
                    anim:on_complete(function()
                        start_step:complete_step()
                    end)
                end
            end)

            should_string = enemy_lined_up(harpnote)
            if not should_string then 
                start_delay = 18
            end

            Engine.play_audio(AudioType.Appear, AudioPriority.Low)
         
        end


        if count == start_delay and not can_end then 
            if should_string then 
                action:add_step(string_step)
            else
                action:add_step(speaker_step)
            end

            start_step:complete_step()
        end


        count = count + 1
    end

    local speaker_delay = 30
    local speaker_shoot = false
    local speaker_counter = 0
    speaker_step.update_func = function()
        if speaker_first then 
            local above = harpnote:get_tile(Direction.join(facing, Direction.Up), 1)
            local below = harpnote:get_tile(Direction.join(facing, Direction.Down), 1)

            local choice1
            local choice2
            if above and not above:is_edge() then 
                choice1 = above
            else
                choice1 = below
            end

            if below and not below:is_edge() then 
                if choice1 and not choice1:is_edge() and choice1 == below then 
                    choice2 = below:get_tile(Direction.Down, 1)
                else
                    choice2 = below
                end
            else
                if choice1 then 
                    local t = above:get_tile(Direction.Up, 1)
                    if t and not t:is_edge() then 
                        choice2 = t
                    end

                end
            end
            
            speaker1 = create_speaker(user, choice1)
            speaker2 = create_speaker(user, choice2)

            speaker_first = false
        end

        if speaker_delay == 0 then 
            anim:set_state("JUMP")

            anim:on_frame(9, function()
                speaker_shoot = true
            
            end)
            
        end

        if speaker_shoot then 
            if speaker_counter % 10 == 0 then 
                speaker_notes = speaker_notes - 1
                
                local s = nil
                if speaker1 then 
                    s = create_note(harpnote, speaker1:get_tile(harpnote:get_facing(), 1))
                end

                if speaker2 then 
                    local b = create_note(harpnote, speaker2:get_tile(harpnote:get_facing(), 1))
                    if not s then s = b end
                end

                if speaker_notes == 0 then 
                    last_note = s
                    speaker_step:complete_step()
                    action:add_step(finish_step)
                end
            end

            speaker_counter = speaker_counter + 1
        end

        speaker_delay = speaker_delay - 1
    end

    string_step.update_func = function()
        if string_first then 
            anim:set_state("SHOOT_STRING")
            
            anim:on_frame(5, function()
                create_string(user, harpnote:get_current_tile())

            end)

            anim:on_complete(function()
                action:add_step(attack_step)
                string_step:complete_step()
            
            end)

            anim:refresh(harpnote:sprite())

            string_first = false
        end

    end

    attack_step.update_func = function()
        if attack_first then 
            anim:set_state("STRUM")

            for i=3, string_notes*4, 4
            do
                anim:on_frame(i, function()
                    string_notes = string_notes - 1
                    local s = create_note(harpnote, harpnote:get_tile(harpnote:get_facing(), 1), true)
                    if string_notes == 0 then 
                        last_note = s
                    end
                end)
            end
                           

            anim:on_complete(function()
                attack_step:complete_step()
                action:add_step(finish_step)

            end)

            anim:refresh(harpnote:sprite())

            attack_first = false
        end

    end

    finish_step.update_func = function()
        -- Probably preventing softlocks with weird nesting
        if last_note then 
            if last_note:is_deleted() then 
                if string_start and not string_start:is_deleted() then 
                    string_start:delete()
                    string_middle:delete()
                    string_end:delete()
                
                else
                    finish_delay = finish_delay - 1

                    if finish_delay == 0 then 
                        harpnote:delete()
                        if speaker1 then speaker1:delete() end
                        if speaker2 then speaker2:delete() end
                        finish_step:complete_step()
                    end
                end
            end
        else
            finish_delay = finish_delay - 1
            if finish_delay == 0 then 
            harpnote:delete()
                if speaker1 then speaker1:delete() end
                if speaker2 then speaker2:delete() end
                if string_start and not string_start:is_deleted() then 
                    string_start:delete()
                    string_middle:delete()
                    string_end:delete()
                end
                finish_step:complete_step()
            end
        end

        
    end



    action.execute_func = function()
        actor = action:get_actor()
        facing = user:get_facing()
        harpnote = graphic_init("spell", 0, 0, "harpnote.png", "harpnote.animation", 0, "APPEAR", user, facing)
        anim = harpnote:get_animation()
    
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
      --  APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        GUITAR_SFX = Engine.load_audio(_folderpath.."guitar.ogg")
        SHOT_SFX = Engine.load_audio(_folderpath.."shot.ogg")
        STRING_SFX = Engine.load_audio(_folderpath.."string.ogg")


        action:add_step(start_step)
        local tile = user:get_tile()
    end

    return action
end