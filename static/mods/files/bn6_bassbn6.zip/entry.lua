local DAMAGE = 60

local TEXTURE_NAVI = Engine.load_texture(_modpath .. "bass.png")
local RAKE_TEXTURE = Engine.load_texture(_modpath .. "burst.png")
local BUSTER_FX = Engine.load_texture(_modpath .. "buster_fx.png")
local BUSTER_FX_ANIM = _modpath .. "buster_fx.animation"
local RAKE_ANIMATION = _modpath .. "burst.animation"
local NAVI_ANIMATION = _modpath .. "bass.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath .. "spawn.ogg")
local AUDIO_BUSTERRAKE = Engine.load_audio(_modpath .. "BusterRake.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.BassBn4-6")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "X", "F" })

    local props = package:get_card_props()
    props.shortname = "Bass"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Buster rake half enmy area"
    props.long_description = "Buster rake hits each tile 8 times!"
    props.can_boost = true
    props.card_class = CardClass.Giga
    props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
        actor:hide()
        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        local float_up = true
        local buster_rake = false
        local frame = 0
        local center_tile = nil
        local targeted_tiles = {}
        local rake_index = 1
        if (actor:get_facing() == Direction.Right) then
            center_tile = field:tile_at(5, 2)
        else
            center_tile = field:tile_at(2, 2)
        end

        local max_elevation = 80
        local elevation = 0
        local action_end = false

        add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
            center_tile:get_tile(Direction.UpLeft, 1),
            center_tile:get_tile(Direction.Left, 1),
            center_tile:get_tile(Direction.DownLeft, 1))
        add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
            center_tile:get_tile(Direction.Up, 1),
            center_tile,
            center_tile:get_tile(Direction.Down, 1))
        add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
            center_tile:get_tile(Direction.UpRight, 1),
            center_tile:get_tile(Direction.Right, 1),
            center_tile:get_tile(Direction.DownRight, 1))

        shuffle(targeted_tiles)

        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
                ref.navi:set_texture(TEXTURE_NAVI, true)
                ref.navi:sprite():set_layer(-1)
                ref.navi:set_shadow(Shadow.Small)
                ref.navi:show_shadow(true)

                navi_anim = ref.navi:get_animation()
                navi_anim:load(NAVI_ANIMATION)
                navi_anim:set_state("SPAWN")
                navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                navi_anim:on_complete(function()
                    navi_anim:set_state("ATTACK")
                    navi_anim:refresh(ref.navi:sprite())
                end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    print("Bass: Buster rake!")
                    navi_anim:set_state("BUSTER_RAKE")
                    navi_anim:set_playback(Playback.Loop)
                    buster_rake = true
                end
            end
            if (float_up) then
                elevation = elevation + 1
                ref.navi:set_elevation(elevation)
                if (elevation >= max_elevation) then
                    float_up = false
                end
            end
            if (buster_rake) then
                frame = frame + 1
                if (frame % 8 == 0) then
                    create_buster_rake(ref.navi, targeted_tiles[rake_index])
                    rake_index = rake_index + 1
                    if (rake_index > #targeted_tiles) then
                        rake_index = 1
                    end
                    create_buster_rake(ref.navi, targeted_tiles[rake_index])
                    rake_index = rake_index + 1
                    if (rake_index > #targeted_tiles) then
                        rake_index = 1
                    end
                    --this is an effect shown on bass
                    local buster_fx = Battle.Artifact.new()
                    buster_fx:set_texture(BUSTER_FX)
                    local buster_fx_anim = buster_fx:get_animation()
                    local fx_offset = 15
                    if (actor:get_facing() == Direction.Left) then
                        fx_offset = -fx_offset
                    end
                    buster_fx:set_offset(fx_offset, -max_elevation - 65)
                    buster_fx_anim:load(BUSTER_FX_ANIM)
                    buster_fx_anim:set_state("DEFAULT")
                    buster_fx:sprite():set_layer(-2)
                    buster_fx_anim:on_complete(function()
                        buster_fx:erase()
                    end)
                    buster_fx_anim:refresh(buster_fx:sprite())
                    field:spawn(buster_fx, ref.navi:get_tile())
                end
                if (frame >= (#targeted_tiles * 8 * 8) / 2) then
                    navi_anim:set_state("SPAWN")
                    buster_rake = false
                    action_end = true
                    frame = 0
                end
            end
            if (action_end) then
                frame = frame + 1
                if (frame == 70) then
                    ref.navi:erase()
                    step1:complete_step()
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function add_targeted_row(team, userX, facing, targeted_tiles, tile1, tile2, tile3)
    if (facing == Direction.Right) then
        if (userX >= tile1:x()) then
            return -- bass does not target his own row or any rows to the left
        end
    else
        if (userX <= tile1:x()) then
            return -- bass does not target his own row or any rows to the left
        end
    end
    if (tile1:get_team() ~= team or tile2:get_team() ~= team or tile3:get_team() ~= team) then
        targeted_tiles[#targeted_tiles + 1] = tile1
        targeted_tiles[#targeted_tiles + 1] = tile2
        targeted_tiles[#targeted_tiles + 1] = tile3
    else
        return
    end

end

function create_buster_rake(owner, tile)
    local spell = Battle.Spell.new(owner:get_team())
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(
        HitProps.new(
            60,
            Hit.Flinch | Hit.Impact,
            Element.None,
            owner:get_context(),
            Drag.None
        )
    )
    local do_once = true
    local field = owner:get_field()
    local flash_before_strike = 10
    spell.update_func = function(self, dt)
        if flash_before_strike <= 0 then
            if do_once then
                do_once = false
                if (not self:get_tile():is_hole()) then
                    self:get_current_tile():attack_entities(spell)
                    local blast_fx = Battle.Artifact.new()
                    blast_fx:set_texture(RAKE_TEXTURE)
                    local blast_anim = blast_fx:get_animation()
                    blast_anim:load(RAKE_ANIMATION)
                    blast_anim:set_state("DEFAULT")
                    blast_fx:sprite():set_layer(-2)
                    field:spawn(blast_fx, self:get_tile())
                    blast_anim:on_complete(function()
                        blast_fx:erase()
                        self:erase()
                    end)

                else
                    self:erase()
                end
            end
        else
            flash_before_strike = flash_before_strike - 1
        end
    end
    spell.attack_func = function(self, other)
        if (not self:get_tile():is_hole()) then
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        end
    end
    Engine.play_audio(AUDIO_BUSTERRAKE, AudioPriority.Highest)
    field:spawn(spell, tile)
end

--shuffle function to provide some randomness
function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end
