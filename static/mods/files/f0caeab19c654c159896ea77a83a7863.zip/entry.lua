local HIT_SFX = nil
local APPEAR_SFX = nil
local SHOCKWAVE_SFX = nil
local SHOCK_SFX = nil
local QUAKE_SFX = nil


function package_init(package) 
    package:declare_package_id("com.alrysc.card.SpannerManX")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'S','X'})

    local props = package:get_card_props()
    props.shortname = "SpannrMX"
    props.damage = 150
    props.time_freeze = true
    props.element = Element.None
    props.description = "Hit with Arm and Spanner!"
    props.card_class = CardClass.Mega
    props.limit = 1
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true

    local actor = nil
    local spannerman = nil
    local anim = nil
    local sound_played = false

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local function shock_punch(user, tile)
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Stun | Hit.Shake,
                Element.Elec, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        spell.lifetime = 3

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            self.lifetime = self.lifetime - 1
            if self.lifetime == 0 then 
                self:delete()
            end
        end

        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
        end

        field:spawn(spell, tile)
    end

    local function create_shockwave(user, tile, facing)
        if not tile or tile:is_edge() then return end
        local state = tile:get_state()
        if state == TileState.Empty or state == TileState.Broken then return end
        local field = user:get_field()
        local spell = graphic_init("spell", 0, 0, "effects.png", "effects.animation", -3, "SHOCKWAVE", user, facing, true)
        
        spell:get_animation():on_frame(4,function()
            create_shockwave(user, spell:get_tile(spell:get_facing(), 1), spell:get_facing())
        
        end)

        spell:highlight_tile(Highlight.Solid)
        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Shake,
                Element.None, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        
        spell.first = true
        spell.update_func = function(self)
            if self.first then 
                if not sound_played then 
                    Engine.play_audio(SHOCKWAVE_SFX, AudioPriority.Low)
                    sound_played = true
                end
                self.first = false
            end

            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
        end


        field:spawn(spell, tile)
    end

    local count = 0
    step.update_func = function()
        if count == 3 then 
            actor:hide()
            tile = user:get_current_tile()
            field:spawn(spannerman, tile)

            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)

        end

        count = count + 1
    end


    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
        SHOCKWAVE_SFX = Engine.load_audio(_folderpath.."break.ogg")
        SHOCK_SFX = Engine.load_audio(_folderpath.."thunder.ogg")
        QUAKE_SFX = Engine.load_audio(_folderpath.."quake.ogg")

        
        spannerman = graphic_init("spell", 0, 0, "spannerman.png", "spannerman.animation", -5, "DEFAULT", user, facing)
        spannerman.update_func = function()
            sound_played = false
        end
        anim = spannerman:get_animation()
        anim:on_frame(12, function()
            shock_punch(user, spannerman:get_tile(facing, 1))
            Engine.play_audio(SHOCK_SFX, AudioPriority.Lowest)
        end)

        anim:on_frame(14, function()
            Engine.play_audio(SHOCK_SFX, AudioPriority.Low)
        end)

        anim:on_frame(21, function()
            local t = spannerman:get_tile(facing, 1)
            create_shockwave(user, t, facing)
            create_shockwave(user, t:get_tile(Direction.Up, 1), facing)
            create_shockwave(user, t:get_tile(Direction.Down, 1), facing)
            Engine.play_audio(QUAKE_SFX, AudioPriority.Low)

            local shake_artifact = Battle.Artifact.new()
            local time = 0
            shake_artifact.update_func = function(self)
                    
                self:shake_camera(150, 0.016)
                if time == 70 then 
                    self:delete()
                end
            
                time = time+1
            end

            field:spawn(shake_artifact, tile)

        end)

        anim:on_frame(27, function()
            field:spawn(graphic_init("spell", 0, 0, "effects.png", "effects.animation", -5, "MOVE", user, facing, true), spannerman:get_current_tile())
        end)
    
        anim:on_complete(function()
            spannerman:delete()
            user:reveal()
            step:complete_step()
        end)


    end


    return action
end