local package_id = "com.louise.Bugtank"
local character_id = "com.louise.enemy."

-- To spawn this enemy use
-- com.louise.enemy.Bugtank

function package_requires_scripts()
  Engine.define_character(character_id .. "Bugtank", _modpath .. "Bugtank")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Bugtank")
  package:set_description("Bugtank!")
  package:set_speed(1)
  package:set_attack(30)
  package:set_health(100)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)

  local spawner = mob:create_spawner(character_id .. "Bugtank", Rank.SP)
  spawner:spawn_at(4, 1)

  local spawner = mob:create_spawner(character_id .. "Bugtank", Rank.Rare2)
  spawner:spawn_at(5, 2)

  local spawner = mob:create_spawner(character_id .. "Bugtank", Rank.NM)
  spawner:spawn_at(6, 3)
end
