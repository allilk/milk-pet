local debug = true
local attachment_texture = Engine.load_texture(_folderpath .. "attachment.png")
local attachment_animation_path = _folderpath .. "attachment.animation"
local explosion_texture1 = Engine.load_texture(_folderpath .. "explosion.png")
local explosion_texture2 = Engine.load_texture(_folderpath .. "explosion2.png")
local explosion_texture3 = Engine.load_texture(_folderpath .. "explosion3.png")
local explosion_sfx = Engine.load_audio(_folderpath .. "explosion.ogg")
local explosion_animation_path = _folderpath .. "explosion.animation"


function debug_print(text)
    if debug then
        print("[chip] " .. text)
    end
end

local chip = {

}

chip.card_create_action = function(actor, props, type)
    local anim = actor:get_animation()

    local uninstall = false
    local hit_effect = Hit.Flash;
    local do_break = false
    local explosion_texture = explosion_texture1
    if (type == "PARA") then
        explosion_texture = explosion_texture2
        hit_effect = Hit.Stun
    elseif (type == "RESET") then
        explosion_texture = explosion_texture3
        uninstall = true
    elseif (type == "BREAK") then
        do_break = true
    end
    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | hit_effect,
        props.element,
        actor:get_context(),
        Drag.None
    )


    local frames_in_air = 40
    local toss_height = 70
    local target_tile = find_target(actor):get_tile()
    if not target_tile then
        return
    end
    local function on_landing()
        if target_tile:is_walkable() then
            hit_explosion(actor, target_tile, hit_props, explosion_texture, explosion_animation_path,
                explosion_sfx, uninstall, do_break)
            local above_tile = target_tile:get_tile(Direction.Up, 1)
            hit_explosion(actor, above_tile, hit_props, explosion_texture, explosion_animation_path, explosion_sfx,
                uninstall, do_break)
            local above_tile = target_tile:get_tile(Direction.Down, 1)
            hit_explosion(actor, above_tile, hit_props, explosion_texture, explosion_animation_path, explosion_sfx,
                uninstall, do_break)
        end
    end

    toss_spell(actor, toss_height, attachment_texture, attachment_animation_path, target_tile, frames_in_air,
        on_landing)


end

---comment
---@param tosser any
---@param toss_height any
---@param texture any
---@param animation_path any
---@param target_tile Tile
---@param frames_in_air any
---@param arrival_callback any
function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("DEFAULT")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height() + 40)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 40
    spell.ending_x_offset = 40
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -40
        spell.ending_x_offset = -40
    end

    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset, spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset / frames_in_air)
            self.x_offset = self.x_offset - (self.ending_x_offset / frames_in_air)
            self:set_offset(self.x_offset, self.y_offset)
            local above_tile = target_tile:get_tile(Direction.Up, 1)
            local below_tile = target_tile:get_tile(Direction.Down, 1)
            target_tile:highlight(Highlight.Flash)
            above_tile:highlight(Highlight.Flash)
            below_tile:highlight(Highlight.Flash)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function hit_explosion(user, target_tile, props, texture, anim_path, explosion_sound, uninstall, do_break)
    if (target_tile:is_edge()) then
        return
    end
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())

    local spell_animation = spell:get_animation()
    spell_animation:load(anim_path)
    spell_animation:set_state("DEFAULT")
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell_animation:refresh(sprite)

    spell_animation:on_complete(function()
        spell:erase()
    end)

    spell:set_hit_props(props)
    if (uninstall) then
        spell.attack_func = uninstall_func
    end
    spell.has_attacked = false
    spell.update_func = function(self)
        if not spell.has_attacked then
            Engine.play_audio(explosion_sound, AudioPriority.Highest)
            spell:get_current_tile():attack_entities(self)
            if (do_break) then
                spell:get_current_tile():set_state(TileState.Cracked)
            end
            spell.has_attacked = true
        end
    end
    field:spawn(spell, target_tile)
end

--find a target character
function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        return
    end
    local target_character = target_list[1]
    return target_character
end

uninstall_func = function(self, other)
    local uninstll = Battle.Component.new(other, Lifetimes.Battlestep)
    local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
    local super_armor2 = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
    local super_armor3 = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
    local antifreeze = Battle.DefenseRule.new(913, DefenseOrder.CollisionOnly)
    local sunglasses = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
    local undershirt = Battle.DefenseRule.new(61044, DefenseOrder.CollisionOnly)
    uninstll.update_func = function(self, dt)
        local owner = self:get_owner()
        owner:set_air_shoe(false)
        owner:set_float_shoe(false)
        owner:add_defense_rule(super_armor)
        owner:remove_defense_rule(super_armor)
        owner:add_defense_rule(super_armor2)
        owner:remove_defense_rule(super_armor2)
        owner:add_defense_rule(super_armor3)
        owner:remove_defense_rule(super_armor3)
        owner:add_defense_rule(sunglasses)
        owner:remove_defense_rule(sunglasses)
        owner:add_defense_rule(undershirt)
        owner:remove_defense_rule(undershirt)
        owner:add_defense_rule(antifreeze)
        owner:remove_defense_rule(antifreeze)
        self:eject()
    end
    other:register_component(uninstll)
end

return chip
