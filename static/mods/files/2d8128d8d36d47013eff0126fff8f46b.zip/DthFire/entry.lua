local shared_package_init = include("../MetFire/character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "DeathFire",
        hp = 200,
        damage = 120,
        palette = _folderpath .. "V3.png",
        height = 44,
        frames_between_actions = 16,
        element = Element.Fire
    }

    shared_package_init(character, character_info)
end
