local shared_package_init = include("../Metfire/character.lua")
function package_init(character)
    local character_info = {
        name = "FulFire",
        hp = 180,
        damage = 80,
        palette = _folderpath .. "V2.png",
        height = 44,
        frames_between_actions = 24,
        element = Element.Fire
    }

    shared_package_init(character, character_info)
end
