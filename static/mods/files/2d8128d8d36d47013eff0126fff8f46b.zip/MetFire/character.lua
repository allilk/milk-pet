-- Includes
---@type BattleHelpers
local battle_helpers = include("battle_helpers.lua")



-- Animations and Textures
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")

local FIRE_FX = Engine.load_texture(_folderpath .. "FireFX.png")
local FIRE_FX_anim = _folderpath .. "FireFX.animation"

--possible states for character
local states = { MOVE = 1, ATTACK = 2 }
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.damage = (character_info.damage)
    self.frames_between_actions = character_info.frames_between_actions
    -- MetFire Specific
    self:set_element(character_info.element)

    --Other Setup
    self:set_explosion_behavior(4, 1, false)
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false

    ---Dawn Setup Variables
    self._pattern = { "MOVE", "MOVE", "MOVE", "MOVE", "MOVE", "ATTACK" }
    self._pattern_index = 1
    self.field = nil
    self._tiles = {}
    self._attack_start = true
    self._meteor_texture = Engine.load_texture(_folderpath .. "meteor.png")
    self._meteor_anim = _folderpath .. "meteor.animation"
    self._explosion_texture = Engine.load_texture(_folderpath .. "ring_explosion.png")
    self._explosion_anim = _folderpath .. "ring_explosion.animation"
    self._explosion_sound = Engine.load_audio(_folderpath .. "sounds/boom.ogg")
    self._landing_sound = Engine.load_audio(_folderpath .. "sounds/meteor.ogg")
    self._move_texture = Engine.load_texture(_folderpath .. "mob_move.png")
    self._minimum_meteors = 4
    self._maximum_meteors = 8
    self._cooldown = 0
    self._cooldown_max = 40
    self._accuracy_chance = 20
    self._meteor_cooldown = 32

    self.on_spawn_func = function(self)
        self.field = self:get_field()
        for x = 1, 6, 1 do
            for y = 1, 3, 1 do
                local tile = self.field:tile_at(x, y)
                if tile and not tile:is_edge() then
                    table.insert(self._tiles, tile)
                end
            end
        end
    end
    self._query = function(e)
        if e and not e:is_deleted() then
            return Battle.Obstacle.from(e) ~= nil or Battle.Character.from(e) ~= nil or Battle.Player.from(e) ~= nil
        end
        return false
    end
    self._obstacle_query = function(o)
        return o and not o:is_deleted()
    end
    self.can_move_to_func = function(tile)
        return tile and self:is_team(tile:get_team()) and tile:is_walkable() and not tile:is_edge() and
            #tile:find_entities(self._query) == 0
    end

    local anim = self:get_animation()
    anim:load(_folderpath .. "battle.animation")
    anim:set_state("IDLE")
    anim:refresh(self:sprite())
    anim:set_playback(Playback.Loop)

    -- end dawn setup


    --This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.move_counter = 0

    -- actions for states

    -- Code that runs in the default state
    ---@param frame number
    self.action_move = function(frame)
        if (frame == 1) then
            local list_2 = {}
            for i = 1, #self._tiles, 1 do
                local check = self.can_move_to_func(self._tiles[i])
                if check then table.insert(list_2, self._tiles[i]) end
            end
            local dest = list_2[math.random(1, #list_2)]
            self.field:spawn(battle_helpers.create_mob_move(self, false), self:get_tile())
            self:teleport(dest, ActionOrder.Immediate, function()
                self:set_facing(dest:get_facing())
                self.field:spawn(battle_helpers.create_mob_move(self, true), dest)
                self._pattern_index = self._pattern_index + 1 --Increment the pattern to the next slot
                if self._pattern_index > #self._pattern then self._pattern_index = 1 end --Loop the pattern if we hit the end.
            end)
        elseif (frame == self.frames_between_actions) then
            self.move_counter = self.move_counter + 1
            if (self.move_counter < 5) then
                self.set_state(states.MOVE)
            else
                self.set_state(states.ATTACK)
                self.move_counter = 0
            end
        end
    end

    --- Code that runs in the attack state.
    ---@param frame number
    self.action_attack = function(frame)
        if (frame == 1) then
            if self._attack_start then
                local list_2 = {}
                for i = 1, #self._tiles, 1 do
                    local check_tile = self._tiles[i]
                    local check = self.can_move_to_func(check_tile)
                    if check then
                        local tile_preferred = check_tile:get_tile(self:get_facing(), 1)
                        if check_tile and self.can_move_to_func(check_tile) and
                            #tile_preferred:find_obstacles(self._obstacle_query) > 0 then
                            self.field:spawn(battle_helpers.create_mob_move(self, false), self:get_tile())
                            self:teleport(check_tile, ActionOrder.Immediate, function()
                                self:set_facing(check_tile:get_facing())
                                self.field:spawn(battle_helpers.create_mob_move(self, true), check_tile)
                            end)
                            break
                        end
                    end
                end
                self._attack_start = false
                anim:set_state("MELT")
                create_meteor_component(self)
                anim:on_complete(function()
                    anim:set_state("ATTACK")
                    anim:set_playback(Playback.Loop)
                end)
            else
            end
        end
    end
    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_move, [2] = self.action_attack }
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.MOVE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end
end

function create_meteor(enemy, props, tile, team, direction, field)
    if not enemy or enemy and enemy:is_deleted() then return end
    local spawn_meteor
    spawn_meteor = function()
        Engine.play_audio(enemy._landing_sound, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(Direction.Right)
        spell:set_hit_props(HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            enemy:get_context(),
            Drag.new())
        )
        spell.attacked = false

        local sprite = spell:sprite()
        sprite:set_texture(enemy._explosion_texture)
        sprite:set_layer(-99)

        local animation = spell:get_animation()
        animation:load(enemy._explosion_anim)
        animation:set_state("0")
        animation:refresh(sprite)
        animation:on_complete(function()
            spell:erase()
        end)

        animation:on_frame(1, function()
            if not spell.attacked then
                Engine.play_audio(enemy._explosion_sound, AudioPriority.Highest)
            end
        end)

        local meteor = Battle.Artifact.new()
        meteor:set_facing(direction)
        meteor:highlight_tile(Highlight.Solid)
        local meteor_sprite = meteor:sprite()
        meteor_sprite:set_layer(-11)
        meteor_sprite:set_texture(enemy._meteor_texture, true)
        local meteor_anim = meteor:get_animation()
        meteor_anim:load(enemy._meteor_anim)
        meteor_anim:set_state("0")
        meteor_anim:refresh(meteor_sprite)
        meteor_anim:on_frame(9, function()
            if not tile:is_hole() then
                meteor:shake_camera(9, 0.25)
                field:spawn(spell, tile)
            end
        end, true)
        meteor_anim:on_complete(function()
            meteor:erase()
        end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function()
            spell.attacked = true
            create_effect(FIRE_FX, FIRE_FX_anim, "FIRE", math.random(-15, 15), math.random(-15, 15), field,
                spell:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(meteor, tile)
    end

    spawn_meteor()
end

function create_meteor_component(metrid)
    if not metrid or metrid and metrid:is_deleted() then return end
    local meteor_component = Battle.Component.new(metrid, Lifetimes.Battlestep)
    meteor_component.count = math.random(metrid._minimum_meteors, metrid._maximum_meteors)
    meteor_component.attack_cooldown_max = metrid._meteor_cooldown
    meteor_component.highlight_cooldown_max = 24
    meteor_component.highlight_cooldown = 24
    meteor_component.initial_cooldown = metrid._cooldown
    meteor_component.attack_cooldown = 0
    meteor_component.owner = metrid
    meteor_component.animate_once = true
    meteor_component.accuracy_chance = metrid._accuracy_chance
    meteor_component.tile_list = {}
    meteor_component.create_once = true
    meteor_component.next_tile = nil
    meteor_component.desired_cooldown = 0
    if metrid:get_rank() == Rank.NM then meteor_component.desired_cooldown = meteor_component.attack_cooldown_max - 16 end
    meteor_component.field = metrid.field
    for t = 1, #metrid._tiles, 1 do
        local desired_tile = metrid._tiles[t]
        --Neat trick: if you only have one declaration, you can put it all in a single line like this with the if statement.
        if not metrid:is_team(desired_tile:get_team()) then table.insert(meteor_component.tile_list, desired_tile) end
    end
    meteor_component.update_func = function(self, dt)
        if self.owner:is_deleted() then return end
        if self.count <= 0 then
            if self.animate_once then
                self.animate_once = false
                local owner_anim = self.owner:get_animation()
                owner_anim:set_state("BACKTONORMAL")
                owner_anim:on_complete(function()
                    owner_anim:set_state("IDLE")
                    owner_anim:set_playback(Playback.Loop)
                    self.owner._ai_state = "MOVE"
                    self.owner._cooldown = self.owner._cooldown_max
                    self.owner._attack_start = true
                    metrid.set_state(states.MOVE)
                end)
            end
        else
            if self.initial_cooldown > 0 then self.initial_cooldown = self.initial_cooldown - 1 end
            if self.initial_cooldown <= 0 then
                if self.next_tile ~= nil then self.next_tile:highlight(Highlight.Flash) end
                if self.highlight_cooldown <= 0 then
                    --Use less than or equal to copmarison to confirm a d100 roll of accuracy.
                    --Example: if a Metrid has an accuracy chance of 20, then a 1 to 100 roll will
                    --Only target the player's tile on a roll of 1-20, leading to an 80% chance of
                    --Targeting a random player tile.
                    if math.random(1, 100) <= self.accuracy_chance then
                        local target = battle_helpers.find_best_target(self.owner)
                        if target ~= nil then
                            self.next_tile = target:get_tile()
                        else
                            self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                        end
                    else
                        self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                    end
                    self.highlight_cooldown = self.highlight_cooldown_max
                else
                    self.highlight_cooldown = self.highlight_cooldown - 1
                end
                if self.attack_cooldown <= self.desired_cooldown and self.next_tile ~= nil then
                    self.count = self.count - 1
                    self.attack_cooldown_max = self.attack_cooldown_max
                    self.attack_cooldown = self.attack_cooldown_max
                    local props = {
                        damage = metrid.damage,
                        element = Element.Fire
                    }
                    create_meteor(self.owner, props, self.next_tile, metrid:get_team(), metrid:get_facing(),
                        metrid:get_field())
                else
                    self.attack_cooldown = self.attack_cooldown - 1
                end
            end
        end
    end
    metrid:register_component(meteor_component)
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(effect_animpath)
    hitfx_anim:set_state(effect_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init
