--Functions for easy reuse in scripts
--Version 1.1

---@class BattleHelpers
battle_helpers = {}

-- This function returns a target enemy.
function battle_helpers.find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        --print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

-- This function spawns a visual effect that will remove itself once the effect animation completes.
function battle_helpers.spawn_visual_artifact(field, tile, texture, animation_path, animation_state, position_x,
                                              position_y)
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    anim:refresh(visual_artifact:sprite())
    field:spawn(visual_artifact, tile:x(), tile:y())
end

-- This function returns true if the entity can move to the tile, false otherwise.
battle_helpers.can_move_to_func = function(tile, entity)
    if not tile:is_walkable() or tile:get_team() ~= entity:get_team() or
        tile:is_reserved({ entity:get_id(), entity._reserver }) then
        return false
    end

    local has_character = false

    tile:find_characters(function(c)
        if c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)
    tile:find_obstacles(function(c)
        if c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)
    return not has_character
end

-- This function moves the character to an adjacent tile.
function battle_helpers.move_random_adjacent(character)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local adjacent_tiles = { my_tile:get_tile(Direction.Up, 1),
        my_tile:get_tile(Direction.Down, 1),
        my_tile:get_tile(Direction.Left, 1),
        my_tile:get_tile(Direction.Right, 1)
    }
    for index, prospective_tile in ipairs(adjacent_tiles) do
        if battle_helpers.can_move_to_func(prospective_tile, character) and
            my_tile ~= prospective_tile then
            table.insert(tile_array, prospective_tile)
        end
    end
    if #tile_array == 0 then return false end
    target_tile = tile_array[math.random(1, #tile_array)]
    if target_tile then
        moved = character:teleport(target_tile, ActionOrder.Immediate)
    end
    return moved
end

--This function moves the character towards a position.
function battle_helpers.move_towards_row(character, row)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local target_tile = nil

    -- Check which tile the bunny needs to move towards to reach megaman.
    if (row < my_tile:y()) then
        target_tile = my_tile:get_tile(Direction.Up, 1)
    else
        target_tile = my_tile:get_tile(Direction.Down, 1)
    end

    if battle_helpers.can_move_to_func(target_tile, character) then
        moved = character:teleport(target_tile, ActionOrder.Immediate)
        return moved
    else
        --if cant move to prospective tile, move to a random tile left or right.
        local alternate_tiles = { my_tile:get_tile(Direction.Left, 1),
            my_tile:get_tile(Direction.Right, 1) }

        for index, prospective_tile in ipairs(alternate_tiles) do
            if battle_helpers.can_move_to_func(prospective_tile, character) and
                my_tile ~= prospective_tile then
                table.insert(tile_array, prospective_tile)
            end
        end
        if #tile_array == 0 then return false end
        target_tile = tile_array[math.random(1, #tile_array)]
        if target_tile then
            moved = character:teleport(target_tile, ActionOrder.Immediate)
        end
        return moved
    end

end

battle_helpers.create_mob_move = function(enemy, is_appear)
    if not enemy or enemy and enemy:is_deleted() then return end --Don't bother if the mob is deleted
    local movement = Battle.Spell.new(enemy:get_team()) --Use a spell so it doesn't animate during time freeze
    movement:set_texture(enemy._move_texture) --Use the stored texture
    local anim = movement:get_animation()
    anim:load(_folderpath .. "mob_move.animation")
    --determine the state to use
    anim:set_state("MOB_MOVE")
    if is_appear then
        anim:set_state("MOB_APPEAR")
    end
    anim:on_complete(function()
        movement:erase()
    end)
    anim:refresh(movement:sprite())
    movement:sprite():set_layer(-2) --Set layer so it appears over the metrid
    return movement
end

battle_helpers.find_best_target = function(virus)
    if not virus or virus and virus:is_deleted() then return end
    local target = virus:get_target() --Grab a basic target from the virus itself.
    local field = virus:get_field() --Grab the field so you can scan it.
    local query = function(c)
        return c:get_team() ~= virus:get_team() --Make sure you're not targeting the same team, since that won't work for an attack.
    end
    local potential_threats = field:find_characters(query) --Find CHARACTERS, not entities, to attack.
    local goal_hp = 999999 --Start with a ridiculous health.
    if #potential_threats > 0 then --If the list is bigger than 0, we go in to a loop.
        for i = 1, #potential_threats, 1 do --The pound sign, or hashtag if you're more familiar with that term, is used to denote length of a list or array in lua.
            local possible_target = potential_threats[i] --Index with square brackets.
            --Make sure it exists, is not deleted, and that its health is less than the goal HP. First one always will be.
            if possible_target and not possible_target:is_deleted() and possible_target:get_health() <= goal_hp then
                --Make it the new target. This way the lowest HP target is attacked.
                target = possible_target
            end
        end
    end
    --Return whoever the target is.
    return target
end

return battle_helpers
