local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "MetFire",
        hp = 100,
        damage = 30,
        palette = _folderpath .. "V1.png",
        height = 44,
        element = Element.Fire,
        frames_between_actions = 34,
    }
    if character:get_rank() == Rank.Rare1 then
        character_info.hp = 180
        character_info.damage = 80
        character_info.palette = _folderpath .. "Rare1.png"
        frames_between_actions = 18
    end
    if character:get_rank() == Rank.Rare2 then
        character_info.hp = 320
        character_info.damage = 180
        character_info.palette = _folderpath .. "Rare2.png"
        frames_between_actions = 12
    end
    if character:get_rank() == Rank.SP then
        character_info.hp = 300
        character_info.damage = 150
        character_info.palette = _folderpath .. "SP.png"
        frames_between_actions = 14
    end
    if character:get_rank() == Rank.NM then
        character_info.hp = 500
        character_info.damage = 250
        character_info.palette = _folderpath .. "NM.png"
        frames_between_actions = 8
    end
    shared_package_init(character, character_info)
end
