local sound = Engine.load_audio(_modpath .. "sfx.ogg")

function package_init(package)
    package:declare_package_id("com.EXE3.Card164-Shadow")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "H", "J", "N", "Q", "U", "*" })

    local props = package:get_card_props()
    props.shortname = "Shadow"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Only swrd attacks hurt you"
    props.limit = 4
end

local idle_data = make_frame_data({
    { 1, 0.14 }
})

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:override_animation_frames(idle_data)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        Engine.play_audio(sound, AudioPriority.Low)
        local ReverentFlicker = Battle.Component.new(user, Lifetimes.Scene)
        local ReverentDefense = Battle.DefenseRule.new(20000, DefenseOrder.CollisionOnly)
        ReverentDefense.can_block_func = function(judge, attacker, defender)
            local attacker_props = attacker:copy_hit_props()
            if attacker_props.element ~= Element.Sword then
                judge:block_damage()
            else
                defender:remove_defense_rule(ReverentDefense)
                ReverentFlicker:eject()
            end
        end
        ReverentFlicker.timer = 360
        ReverentFlicker.owner = user
        ReverentFlicker.sprite = user:sprite()
        local green1 = Color.new(16, 255, 49, 225)
        local green2 = Color.new(80, 255, 80, 225)
        ReverentFlicker.green_channels = {green1, green2, green1}
        ReverentFlicker.green_index = 1
        ReverentFlicker.black = Color.new(0, 0, 0, 255)
        ReverentFlicker.update_func = function(self, dt)
            if self.owner:is_deleted() then return end
            if self.timer <= 0 then
                self.owner:remove_defense_rule(ReverentDefense)
                self:eject()
                return
            end
            if self.timer > 344 then
                self.owner:set_color(self.green_channels[self.green_index])
                self.green_index = self.green_index + 1
                if self.green_index > #self.green_channels then self.green_index = 1 end
            else
                self.sprite:set_color_mode(ColorMode.Multiply)
                self.owner:set_color(self.black)
            end
            self.timer = self.timer - 1
        end
        user:register_component(ReverentFlicker)
        user:add_defense_rule(ReverentDefense)
    end

    return action
end
