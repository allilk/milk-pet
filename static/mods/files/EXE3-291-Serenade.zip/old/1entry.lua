function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

local DAMAGE = 100

local SERENADE_TEXTURE = Engine.load_texture(_modpath.."serenade.png")
local SERENADE_ANIMPATH = _modpath.."serenade.animation"
local HOLYSHOCK_TEXTURE = Engine.load_texture(_modpath.."holyshock.png")
local HOLYSHOCK_ANIMPATH = _modpath.."holyshock.animation"
local HOLYSHOCK_AUDIO = Engine.load_audio(_modpath.."holyshock.ogg")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."explosion.png")
local EXPLOSION_ANIMPATH = _modpath.."explosion.animation"
local EXPLOSION_AUDIO = Engine.load_audio(_modpath.."explosion.ogg")
local AUDIO_SPAWN = Engine.load_audio(_modpath.."exe3-spawn.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-291-Serenade")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"S"})

    local props = package:get_card_props()
    props.shortname = "Serenade"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Rain on enmy then lance atk"
    props.long_description = "Blood Rain on enemy area, then lance attack"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        
        local self_tile = user:get_current_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local targets = {}
        local trg_count = 1
        --[[for i = 1, 6 do
            for j = 1, 3 do
                if field:tile_at(i,j):get_team() ~= team then
                    targets[trg_count] = field:tile_at(i,j)
                    trg_count = trg_count + 1
                end
            end
        end]]
        for i = 1, 16 do
            local tile1_X = nil
            local tile1_Y = nil
            local tile2_X = nil
            local tile2_Y = nil

            local trg_tile1
            local trg_tile2
            repeat
                tile1_X = math.random(1, 6)
                tile1_Y = math.random(1, 3)
                tile2_X = math.random(1, 6)
                tile2_Y = math.random(1, 3)
            until field:tile_at(tile1_X, tile1_Y):get_team() ~= team and field:tile_at(tile2_X, tile2_Y):get_team() ~= team and field:tile_at(tile1_X, tile1_Y) ~= field:tile_at(tile2_X, tile2_Y)
            trg_tile1 = field:tile_at(tile1_X, tile1_Y)
            trg_tile2 = field:tile_at(tile2_X, tile2_Y)
            if trg_tile1 and trg_tile2 and trg_tile1:get_team() ~= team and trg_tile2:get_team() ~= team and trg_tile1 ~= trg_tile2 then
                targets[trg_count] = trg_tile1
                trg_count = trg_count + 1
                targets[trg_count] = trg_tile2
                trg_count = trg_count + 1
            end
        end

        local loops = nil

        self.loops1   = 4
        self.loops2   = 38
        self.loops3   = 4
        self.tile     = user:get_current_tile()

        local ref = self

		local step1 = Battle.Step.new()

        local serenade = Battle.Artifact.new()
        serenade:set_facing(direction)
        local serenade_sprite = serenade:sprite()
		serenade_sprite:set_texture(SERENADE_TEXTURE, true)
		serenade_sprite:set_layer(-9)
        local serenade_anim = serenade:get_animation()
        serenade_anim:load(SERENADE_ANIMPATH)
        if not ref.tile:is_hole() then
            print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") is NOT a hole!")
            serenade_anim:set_state("SPAWN")
            serenade_anim:refresh(serenade_sprite)
        else
            print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") IS a hole!")
            serenade_anim:set_state("SPAWN_HOLE")
            serenade_anim:refresh(serenade_sprite)
        end
        serenade_anim:on_frame(1, function()
            Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
        end)
        serenade_anim:on_complete(function()
            if not ref.tile:is_hole() then
                if ref.loops1 > 0 then
                    serenade_anim:set_playback(Playback.Loop)
                    ref.loops1 = ref.loops1 - 1
                else
                    serenade_anim:set_state("START")
                    serenade_anim:refresh(serenade_sprite)
                end
            else
                serenade:erase()
                step1:complete_step()
            end
        end)

        local color = Color.new(0, 0, 255, 0)
        serenade:set_color(color)

        local transparent_time = 6
        local transparent_counter = 0

        local blue_time = 26
        local blue_counter = 26

        local extra_counter = 0
        local wait = 14


        local do_once = true
        local do_once_2 = true
        local do_once_3 = true
        local clr_start2 = false
        serenade.update_func = function(self, dt)
            if transparent_counter ~= transparent_time+1 then
                color.a = math.floor(255 * (transparent_counter / transparent_time))
                transparent_counter = transparent_counter+1

            else              
            
                if extra_counter == wait then 
                    if blue_counter ~= -1 then 
                    color.b = math.floor(255 * (blue_counter / blue_time))
                    blue_counter = blue_counter-1

                    else
                        serenade.update_func = function()
                        end
                    end
                else
                    extra_counter = extra_counter+1
                end
            end

            serenade:set_color(color)

            if serenade_anim:get_state() == "START" then
                if do_once_2 then
                    do_once_2 = false
                    serenade_anim:on_complete(function()
                        serenade_anim:set_state("ATTACK")
                        serenade_anim:refresh(serenade_sprite)
                        create_holyshock(user, props, direction, team, field, trg_count, ref.tile:get_tile(direction, 1), targets, serenade)
                        serenade_anim:on_complete(function()
                            serenade_anim:set_playback(Playback.Loop)
                        end)
                    end)
                end
            end
            if serenade_anim:get_state() == "END" then
                if do_once_3 then
                    do_once_3 = false
                    
                    serenade_anim:on_complete(function()
                        if ref.loops3 > -6 then
                            serenade_anim:set_playback(Playback.Loop)
                            ref.loops3 = ref.loops3 - 1
                        else
                            serenade:erase()
                            step1:complete_step()
                        end
                    end)

                    transparent_counter = transparent_time
                    blue_counter = 0
                    extra_counter = 0
                    
                    serenade_anim:on_frame(4, function()
                        if ref.loops3 < 0 then

                            serenade.update_func = function()
                                if blue_counter ~= blue_time+1 then 
                                    color.b = math.floor(255 * (blue_counter / blue_time))
                                    blue_counter = blue_counter+1
                                
                                else
                                
                                    if extra_counter == wait then 
                                        if transparent_counter ~= -1 then
                                            color.a = math.floor(255 * (transparent_counter / transparent_time))
                                            transparent_counter = transparent_counter-1
                                        end
                                    else
                                        extra_counter = extra_counter+1
                                    end
                                end
                            
                                serenade:set_color(color)
                            end
                        end
                    end)
                end
            end
        end
        --[[step1.update_func = function(self, dt)
            
            if transparent_counter ~= transparent_time+1 then
                color.a = math.floor(255 * (transparent_counter / transparent_time))
                transparent_counter = transparent_counter+1
            else              
                if extra_counter == wait then 
                    if blue_counter ~= -1 then 
                    color.b = math.floor(255 * (blue_counter / blue_time))
                    blue_counter = blue_counter-1
                    else
                        ref.serenade.update_func = function()
                        end
                    end
                else
                    extra_counter = extra_counter+1
                end
            end

            ref.serenade:set_color(color)

            if do_once then
                do_once = false
                
                
                
            end

            local anim = ref.serenade:get_animation()
            
        end
        self:add_step(step1)]]
        field:spawn(serenade, ref.tile)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_holyshock(user, props, direction, team, field, numberend, tile_spawn, tile_table, navi)
    local fx = Battle.Artifact.new()
    fx:set_facing(direction)
    fx.numbers = 1
    fx.tiles   = tile_table
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-9)
    fx_sprite:set_texture(HOLYSHOCK_TEXTURE, true)
    local fx_anim = fx:get_animation()
    fx_anim:load(HOLYSHOCK_ANIMPATH)
    fx_anim:set_state("0")
    fx_anim:refresh(fx_sprite)
    local do_once = true
    fx.update_func = function(self, dt)
        if do_once then
            fx_anim:on_frame(1, function()
                if fx.numbers < numberend then
                    create_flash(user, props, team, field, fx.tiles[fx.numbers], 1, true)
                    fx.numbers = fx.numbers + 1
                    create_flash(user, props, team, field, fx.tiles[fx.numbers], 2, false)
                    fx.numbers = fx.numbers + 1
                else
                    navi:get_animation():set_state("END")
		    	    navi:get_animation():refresh(navi:sprite())
                    fx:erase()
                end
            end)
            fx_anim:on_complete(function()
                fx_anim:set_playback(Playback.Loop)
            end)
        end
    end
    fx_anim:on_frame(1, function()
        fx:shake_camera(12, 5)
    end)

    Engine.play_audio(HOLYSHOCK_AUDIO, AudioPriority.High)

    field:spawn(fx, tile_spawn)

    return fx
end

function create_flash(user, props, team, field, tile, number, play)
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Flash)
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_frame(2, function()
        create_explosion(user, props, team, field, tile, number, play)
    end)
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    field:spawn(spell, tile)

    print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_explosion(user, props, team, field, tile, number, play)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Shake, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
    spell.crack = math.random(1,3)
    local sprite = spell:sprite()
    sprite:set_texture(EXPLOSION_TEXTURE, true)
    sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(EXPLOSION_ANIMPATH)
    if spell.crack == 1 then
        anim:set_state("1")
    else
        anim:set_state("0")
    end
    anim:refresh(sprite)
    anim:on_frame(1, function()
        if spell.crack == 1 then
            if not tile:is_hole() and tile:get_state() ~= TileState.Cracked then
                tile:set_state(TileState.Cracked)
            elseif tile:get_state() ~= TileState.Cracked then
                tile:set_state(TileState.Broken)
            end
        end
    end)
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self)
        Engine.play_audio(Engine.load_audio(_modpath.."hitsound"..number..".ogg"), AudioPriority.High)
        --create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "WOOD", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    if play then
        Engine.play_audio(Engine.load_audio(_modpath.."explosion1.ogg"), AudioPriority.Highest)
    end

    field:spawn(spell, tile)

	return spell
end