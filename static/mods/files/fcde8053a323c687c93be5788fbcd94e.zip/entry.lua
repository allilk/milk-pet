nonce = function() end

local DRAGONFLAME1_FIRE = Engine.load_texture(_modpath.."fire1.png")
local DRAGONFLAME1_HEAD = Engine.load_texture(_modpath.."head1.png")

local DRAGONFLAME1_FIRE_ANIMATION_PATH = _modpath.."fire1.animation"
local DRAGONFLAME1_HEAD_ANIMATION_PATH = _modpath.."head1.animation"
local DRAGONFLAME_FIRE_SOUND = Engine.load_audio(_modpath.."fire.ogg") 

local DRAGONFLAME_HIT_SOUND = Engine.load_audio(_modpath.."damageenemy.ogg")



function package_init(package) 
    package:declare_package_id("com.alrysc.card.DragonFlame1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon1.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview1.png"))
    package:set_codes({'D', 'G', 'N', '*'})
  
    local props = package:get_card_props()
    props.shortname = "DrgnFlm1"
    props.damage = 150
    props.time_freeze = false
    props.element = Element.Fire
    props.card_class = CardClass.Standard
    props.description = "Spreading breath burns!"
    props.limit = 3 --2, 1, 1
  
  end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    -- I gave myself a headache and made all of these to be the time before what I want. Whoops
    local NO_HEAD = {0, 0.0667}
    local BEFORE_BACK = {1, 0.1667}
    local BEFORE_LEAN = {1, 0.016}
    local BEFORE_OFFSET = {2, 0.016}
    local BEFORE_LEAN2 = {2, 0.033}
    local BEFORE_ATTACK1 = {1, 0.1}
    local BEFORE_FORWARD = {2, 0.084}
    local BEFORE_ATTACK2 = {1, 0.067}
    local BEFORE_FORWARD2 = {2, 0.067}
    local BEFORE_ATTACK3 = {1, 0.067}
    local BEFORE_FORWARD3 = {2, 0.084}
    local BEFORE_BACK2 = {1, 0.067}
    local BEFORE_FORWARD4 = {2, 0.084}
    local BEFORE_BACK3 = {1, 0.067}
    local BEFORE_FORWARD5 = {2, 0.084}
    local BEFORE_BACK4 = {1, 0.067}
    local BEFORE_FINISH = {2, 0.084}

    local FRAMES = make_frame_data({ NO_HEAD, BEFORE_BACK, BEFORE_LEAN, BEFORE_OFFSET, BEFORE_LEAN2, BEFORE_ATTACK1,
        BEFORE_FORWARD, BEFORE_ATTACK2, BEFORE_FORWARD2, BEFORE_ATTACK3, BEFORE_FORWARD3, BEFORE_BACK2, BEFORE_FORWARD4, 
        BEFORE_BACK3, BEFORE_FORWARD5, BEFORE_BACK4, BEFORE_FINISH })

    action:override_animation_frames(FRAMES)

--4 before head, 
-- 10, then head moves back
--1, then lean back
--1, then offset player back
--2, then lean forward
--6, then attack and lean back
--5, then lean forward
--4, then lean back, attack again
--4, then lean forward
--4, then lean back and attack again
--5, then lean forward
--4, then lean back
--5, then lean forward
--4, back
--5, forward
--4, back
--5, done
    local fire_count = 1

    local function create_spell(user, curX, curY, X, Y)
        if user:get_facing() == Direction.Left then 
            X = X * -1
        end

        local tile = user:get_field():tile_at(curX+X, curY+Y)

        if tile and (tile:x() > 0 and tile:x() < 7) and (tile:y() < 4 and tile:y() > 0) then 
            local hasHit = false
            local spell = Battle.Spell.new(user:get_team())
            local offsetY = 20

            spell:sprite():set_layer(-1)
            spell:set_facing(user:get_facing())
            spell:set_texture(DRAGONFLAME1_FIRE, true)
            spell:set_offset(0, offsetY)
            spell:get_animation():load(DRAGONFLAME1_FIRE_ANIMATION_PATH)
            spell:get_animation():set_state("FIRE"..fire_count)
    
            spell:get_animation():refresh(spell:sprite())
    
            spell:get_animation():on_complete(function()
                spell:get_animation():set_state("FADE")

                spell:get_animation():on_complete(function()
                    spell:erase()
                    
                end)
            end)

            local counter = 0

            spell:highlight_tile(Highlight.Solid)

            spell:set_hit_props(
                HitProps.new(
                props.damage,
                Hit.Flinch | Hit.Flash | Hit.Impact,
                props.element,
                user:get_context(),
                Drag.None
                )
            )

            
            spell.can_move_to_func = function()
                return true
            end

            spell.update_func = function(self)
                if counter > 64 then 
                  --  self:erase()
                  spell:highlight_tile(Highlight.None)
                else 
                    counter = counter + 1
                
                    if not hasHit then
                        spell:get_current_tile():attack_entities(self)
                    end
                end

            end


            spell.attack_func = function()
                Engine.play_audio(DRAGONFLAME_HIT_SOUND, AudioPriority.Low)
                hasHit = true
            end

            user:get_field():spawn(spell, tile)

        end
    end

    action.execute_func = function(self)

        local actor = self:get_actor()

        actor:get_animation():on_frame(2, function()
            local head = action:add_attachment("BUSTER")
            head:sprite():set_texture(DRAGONFLAME1_HEAD, true)
            head:sprite():set_layer(-1)
            
            local head_anim = head:get_animation()
            head_anim:load(DRAGONFLAME1_HEAD_ANIMATION_PATH)
            head_anim:set_state("HEAD")

            actor:get_animation():on_frame(3, function()
                local offsetX = -4
                if actor:get_facing() == Direction.Left then 
                    offsetX = offsetX * -1
                end
                head:sprite():set_offset(offsetX, 0)

            end)
        
        end)

        actor:get_animation():on_frame(5, function()
            local offsetX = -4
            if actor:get_facing() == Direction.Left then 
                offsetX = offsetX * -1
            end

            actor:set_offset(offsetX, 0)

        end)


        actor:get_animation():on_frame(7, function()

            local currentX = user:get_current_tile():x()
            local currentY = user:get_current_tile():y()
            Engine.play_audio(DRAGONFLAME_FIRE_SOUND, AudioPriority.Low)

            create_spell(user, currentX, currentY, 1, 0)
        end)

        actor:get_animation():on_frame(9, function()
            fire_count = fire_count+1

            local currentX = user:get_current_tile():x()
            local currentY = user:get_current_tile():y()
        
            create_spell(user, currentX, currentY, 2, 0)
            create_spell(user, currentX, currentY, 2, 1)
            create_spell(user, currentX, currentY, 2, -1)


        end)

        actor:get_animation():on_frame(11, function()
            fire_count = fire_count+1

            local currentX = user:get_current_tile():x()
            local currentY = user:get_current_tile():y()
        
            create_spell(user, currentX, currentY, 3, 0)
            create_spell(user, currentX, currentY, 3, 1)
            create_spell(user, currentX, currentY, 3, -1)


        end)
    
    end

    action.action_end_func = function()
        user:set_offset(0, 0)

      end

    return action
end