
local SHOT_TEXTURE = Engine.load_texture(_modpath.."wideshot.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
local f = 0.016
local FRAME1 = {1,4*f}
local FRAME2 = {1,1*f}
local FRAME3 = {1,21*f}
local FRAMES = make_frame_data({FRAME1, FRAME2, FRAME3})

function package_init(package) 
    package:declare_package_id("com.seabitty.sfwidewave1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"H","N","Q"})

    local props = package:get_card_props()
    props.shortname = "WideWav1"
    props.damage = 70
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Fires row wide wave."
    props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(FRAMES)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
        local buster_attachment = self:add_attachment("BUSTER")
        local buster_sprite = buster_attachment:sprite()
        buster_sprite:set_texture(user:get_texture(), false)
        buster_sprite:set_layer(-2)
        local buster_animation = buster_attachment:get_animation()
        buster_animation:copy_from(user:get_animation())
        buster_animation:set_state("BUSTER")
        buster_animation:refresh(buster_sprite)

		action:add_anim_action(2, function()
			local shot = create_wideshot(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			actor:get_field():spawn(shot, tile)
		end)
	end
    return action
end


function create_wideshot(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local attacking = false
	local anim = spell:get_animation()
	spell:set_texture(SHOT_TEXTURE, true)
	anim:load(_modpath.."wideshot.animation")
	anim:set_state("STARTUP")
	anim:on_complete(function()
		anim:set_state("DEFAULT")
		anim:set_playback(Playback.Loop)
		attacking = true
	end)

	spell.update_func = function(self, dt)
		if not attacking then return end

		self:get_tile():get_tile(Direction.Up, 1):attack_entities(self)
		self:get_tile():attack_entities(self)
		self:get_tile():get_tile(Direction.Down, 1):attack_entities(self)

		if self:is_sliding() == false then
			if self:get_current_tile():is_edge() then 
				self:delete()
			end 
			local dest = self:get_tile(spell:get_facing(), 1)
			local ref = self
			self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, nil)
		end
	end
    spell.collision_func = function(self, other) 
		self:delete()
    end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end