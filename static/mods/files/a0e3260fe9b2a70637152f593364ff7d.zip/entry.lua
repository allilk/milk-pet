local add_Dark_Element_component = include('Dark_Element_component/Dark_Element_component.lua')

function package_init(block)
    block:declare_package_id("Rubedo.DarkElement")
    block:set_name("DarkElement")
    block:set_description("EmbraceEvil")
    block:set_color(Blocks.Red)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end



function modify(player)
    player:sprite():set_color_mode(ColorMode.Multiply)
    player:set_color(Color.new(150, 150, 150, 255))
    add_Dark_Element_component.add_component(player)
end

