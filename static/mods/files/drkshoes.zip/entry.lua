nonce = function() end
 
local DARKSHOES_USE = Engine.load_audio(_modpath.."dark.ogg")
 
function package_init(package)
    package:declare_package_id("com.alrysc.dorkshoes")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"*"})
 
    local props = package:get_card_props()
    props.shortname = "DrkShoes"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "COMPLETE TERRAIN SUPREMACY"
    props.card_class = CardClass.Dark
    props.limit = 1

end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")

	action.execute_func = function(self, user)
        actor:set_color(Color.new(88,9,255,225))


        actor:set_air_shoe(true)
        actor:set_float_shoe(true)

        local component = Battle.Component.new(user, Lifetimes.Local)
        local prev_panel = user:get_current_tile()
        local randomNumber = nil
        local tile_state = nil

        component.update_func = function(self)
            if user:get_current_tile() ~= prev_panel then 
                randomNumber = math.random(1, 13)
                
                if randomNumber ~= 7 and randomNumber ~= 1 and randomNumber ~= 2 then 
                    if randomNumber > 9 and randomNumber < 13 then 
                        randomNumber = prev_panel:get_state()
                        
                    
                    else 
                        if randomNumber == 9 then 
                            randomNumber = math.random(9, 12)
                        end
                    end
                    
                    print(randomNumber)

                    prev_panel:set_state(randomNumber)
                    prev_panel = user:get_current_tile()
                end
            end
        end

        actor:register_component(component)

        Engine.play_audio(DARKSHOES_USE, AudioPriority.Low)    
    end


    return action
end
