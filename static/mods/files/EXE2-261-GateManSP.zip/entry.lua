local DAMAGE = 300

local TEXTURE_GATEMAN = Engine.load_texture(_modpath.."gateman.png")
local TEXTURE_GATECANNON = Engine.load_texture(_modpath.."gatecannon.png")
local ANIMPATH_GATEMAN = _modpath.."gateman.animation"
local ANIMPATH_GATECANNON = _modpath.."gatecannon.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_GATEOPEN = Engine.load_audio(_modpath.."gateopen.ogg")
local AUDIO_GATECANNON = Engine.load_audio(_modpath.."gatecannon.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-261-GateManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G"})

    local props = package:get_card_props()
    props.shortname = "GateManSP"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "GateCanon attacks enemy!"
    props.long_description = "Gate Cannon of another dimension!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

		local step1 = Battle.Step.new()

        self.gateman = nil
        self.tile    = user:get_current_tile()
        
        local field = user:get_field()
        local direction = user:get_facing()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.gateman = Battle.Artifact.new()
                ref.gateman:set_facing(user:get_facing())
		    	ref.gateman:set_texture(TEXTURE_GATEMAN, true)
		    	ref.gateman:sprite():set_layer(-1)

                gate_anim = ref.gateman:get_animation()
                gate_anim:load(ANIMPATH_GATEMAN)
                gate_anim:set_state("SPAWN")
		    	gate_anim:refresh(ref.gateman:sprite())
                gate_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.Low)
                end)
		    	gate_anim:on_complete(function()
		    		gate_anim:set_state("ATTACK")
		    		gate_anim:refresh(ref.gateman:sprite())
		    	end)
                field:spawn(ref.gateman, ref.tile)
            end
            local anim = ref.gateman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_frame(4, function()
                        Engine.play_audio(AUDIO_GATEOPEN, AudioPriority.Low)
                    end)
                    anim:on_frame(9, function()
                        print("GateMan: GateCannon!")
                        Engine.play_audio(AUDIO_GATECANNON, AudioPriority.Low)
                        spawn_gatecannon(user, props, field, user:get_tile(direction, 1))
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
                        anim:refresh(ref.gateman:sprite())
                        anim:on_complete(function()
                            ref.gateman:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function spawn_gatecannon(user, props, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        Engine.play_audio(AUDIO_GATECANNON, AudioPriority.Highest)

        local spell = Battle.Spell.new(user:get_team())
        local direction = user:get_facing()
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                Element.None, 
                user:get_id(), 
                Drag.None
            )
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_GATECANNON)

        local anim = spell:get_animation()
        anim:load(ANIMPATH_GATECANNON)
        anim:set_state("DEFAULT")
        anim:refresh(sprite)
        anim:on_frame(6, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        anim:on_complete(function() spell:erase() end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        end

        spell.collision_func = function(self, other)
            spell:erase()
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end