-- TODO: Overworld, aile, HX Ball does not account for target disappearing, add facing to artifact init (see groundman) and spell, to clean up bulky code

function package_init(package)
    package:declare_package_id("com.alrysc.player.ZX_Aile")
    package:set_special_description("Model X Chosen One!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    --package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."ow.animation")
    package:set_overworld_texture_path(_folderpath.."ow.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
end

function player_init(player)
    player:set_name("Aile")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(50.0)
    player:set_shadow(1)
  --  player:show_shadow(true)

    local base_texture = Engine.load_texture(_folderpath.."ZX.png")
    local hx3_texture = Engine.load_texture(_folderpath.."Hx3.png")
    local base_animation_path = _folderpath.."ZX.animation"
    local base_charge_color = Color.new(57, 198, 243, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    player.combo = nil
    player.Fx_Side = nil
    player.Px_Target = nil
    player.node = nil
    player.energy_bar = nil
    player.empty_bar = nil
    player.ENERGY_MAX = nil
  --  player.Hx_energy = ENERGY_MAX
   -- player.Fx_energy = ENERGY_MAX
   -- player.Px_energy = ENERGY_MAX
    --player.Lx_energy = ENERGY_MAX

    
    -- Making lists of all the important things for each transformation
        -- That is, name, element, buster, CS, and state names for skills, which will be used later. Also setting energy to cap
  --  local Zx = {name = "Zx", element = Element.None, normal_attack = ZX_Attack, skill1 = "NO_SPECIAL", skill2 = "NO_SPECIAL", charged_attack = ZX_Attack}
    --local Hx = {name = "Hx", element = Element.Wind, energy = player.ENERGY_MAX, skill1 = "HX_SKILL1", skill2 = "HX_SKILL2", normal_attack = Hx_Attack, charged_attack = Hx_Tornado}
    --local Fx = {name = "Fx", element = Element.Fire, energy = player.ENERGY_MAX, skill1 = "NO_SPECIAL", skill2 = "NO_SPECIAL", normal_attack = FX_Shot, charged_attack = FX_Attack}
    --local Px = {name = "Px", element = Element.Cursor, energy = player.ENERGY_MAX, skill1 = "PX_SKILL1", skill2 = "PX_SKILL2", normal_attack = PX_Attack, charged_attack = PX_Charge}
    --local Lx = {name = "Lx", element = Element.Aqua, energy = player.ENERGY_MAX, skill1 = "LX_SKILL1", skill2 = "NO_SPECIAL", normal_attack = LX_Attack, charged_attack = LX_Ice}

    
    -- Setting up some lists of sond effects I use everywhere
    local common_sounds = { hit = Engine.load_audio(_modpath.."sounds/hit.ogg"), 
                            pose = Engine.load_audio(_modpath.."sounds/voice/overdrive.ogg"),
                            selected = Engine.load_audio(_modpath.."sounds/modelselected.ogg"),
                            transform = Engine.load_audio(_modpath.."sounds/voice/rockon.ogg"), 
                            overdrive = pose
                        }

    local Zx_sounds = { shot1 = Engine.load_audio(_modpath.."sounds/zxshot1.ogg"), 
                        shot2 = Engine.load_audio(_modpath.."sounds/zxshot2.ogg"), 
                        shot3 = Engine.load_audio(_modpath.."sounds/zxshot3.ogg"), 
                        smash = Engine.load_audio(_modpath.."sounds/voice/zxsmash.ogg")
                    }


    local Hx_sounds = { slash1 = Engine.load_audio(_modpath.."sounds/voice/hxslash1.ogg"), 
                        slash2 = Engine.load_audio(_modpath.."sounds/voice/hxslash2.ogg"), 
                        slash3 = Engine.load_audio(_modpath.."sounds/voice/hxslash3.ogg"),
                        sonicboom = nil, 
                        tornado = Engine.load_audio(_modpath.."sounds/hxtornado.ogg"),
                        ball = Engine.load_audio(_modpath.."sounds/hxball.ogg"),
                        flight = Engine.load_audio(_modpath.."sounds/hxflight.ogg")
                    }

    local Fx_sounds = { shot = Engine.load_audio(_modpath.."sounds/fxshot.ogg"), 
                        punch = Engine.load_audio(_modpath.."sounds/voice/fxpunch.ogg"), 
                        fireball = Engine.load_audio(_modpath.."sounds/fxfireball.ogg"), 
                        firetrail = Engine.load_audio(_modpath.."sounds/fxfire.ogg")
                    }

    local Px_sounds = { kunai = Engine.load_audio(_modpath.."sounds/voice/pxkunai.ogg"), 
                        shuriken = Engine.load_audio(_modpath.."sounds/voice/pxshuriken.ogg"), 
                        shield = Engine.load_audio(_modpath.."sounds/voice/pxshield.ogg"), 
                        dash = Engine.load_audio(_modpath.."sounds/dash.ogg")
                    }

    local Lx_sounds = { slash = Engine.load_audio(_modpath.."sounds/voice/lxslash.ogg"), 
                        spin = Engine.load_audio(_modpath.."sounds/voice/lxspin.ogg"),
                        iceform = Engine.load_audio(_modpath.."sounds/iceform.ogg"),
                        icebreak = Engine.load_audio(_modpath.."sounds/icebreak.ogg"),
                        dragon = Engine.load_audio(_modpath.."sounds/lxdragon.ogg")
                    }

    -- Lots of variables used for tracking or actioning later. They will be initialized in update if not here
    player.current_trans = Zx

    player.charging = nil
    player.charge_shot = nil
    player.trans_time = nil
    player.first_update = nil
    player.size_change = nil
    player.node = player:create_sync_node("origin")
    player.node:sprite():set_texture(Engine.load_texture(_folderpath.."Hx3.png"), false)
    player.node:sprite():set_layer(1)
    player.node:get_animation():load(_folderpath.."ZX.animation")
    local initial_height = player.node:sprite():get_height()
    local initial_width = player.node:sprite():get_width()

   -- player:remove_sync_node(player.node)
    player.special_action_queued = nil
    player.special_queue_counter = nil
    player.special_pre_input = nil

    --player.node:sprite():hide()

    player.overdrive = nil
    player.overdrive_component = nil
    player.transforming = nil

    player.overdrive_tick = nil
    player.overdrive_count = nil
    player.overdrive_during_action = nil

    -- This is the time it takes for an action to execute. Need it later
    local action_queue = 5
    player.action_queue_counter = nil
    
    player.combo_time = nil

    player.label_list = nil
    player.label_counter = nil

    player.transparent_bar = false

    -- Updates energy bar. Also hides it if in Zx, since it doesn't use energy
        -- Will also turn Overdrive off when energy hits 0
    function redraw_energy(user)
        if user.current_trans == user.Zx then
            user.empty_bar:sprite():set_width(0)
            if not user.transparent_bar then 
                user.energy_bar:hide()
                user.empty_bar:hide()
                user.transparent_bar = true
            end

        else
            if user.current_trans.energy then 
                user.empty_bar:sprite():set_width(8*(user.ENERGY_MAX-user.current_trans.energy))
                if user:get_facing() == Direction.Left then 
                    user.empty_bar:sprite():set_width(user.empty_bar:sprite():get_width()*-1)
                end

            end
            if user.transparent_bar then 
                user.energy_bar:reveal()
                user.empty_bar:reveal()
                user.transparent_bar = false
            end

        end

        if user.current_trans.energy == 0 and user.overdrive then 
            overdrive_toggle(user)
        end

     --   print("Energy is", player.current_trans.energy)

    end

    -- Creates and returns an artifact given some parameters
    function artifact_init(x, y, texture, animation, layer, state, user, flip)
        flip = flip or false

        local artifact = Battle.Artifact.new()

        artifact:sprite():set_layer(layer)
        artifact:never_flip(flip)
        artifact:set_texture(Engine.load_texture(_folderpath..texture), false)
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        artifact:set_offset(x, y)
        artifact:get_animation():load(_folderpath..animation)

        artifact:get_animation():set_state(state)
        artifact:get_animation():refresh(artifact:sprite())

        return artifact
    end

    player.skill_label1 = nil
    player.skill_label2 = nil
    player.cooldown_bar1 = nil
    player.cooldown_bar2 = nil

    
    player.hidden_cooldown1 = false
    player.hidden_cooldown2 = false
    
    -- Updates skill icons with a shading to represent cooldown
        -- Stretches a 1 pixel tall slightly transparent black line, scaling based on current cooldown left and starting cooldown
        -- Also changes skill icon state depending on if it is on cooldown or not
            -- Dimmer when on cooldown
    function draw_cooldown(user)
        if user.skill_label1:get_animation():get_state() ~= "NO_SPECIAL" and user.current_trans.cooldown1 > 0 then 
            user.cooldown_bar1:sprite():set_height(-40*user.current_trans.cooldown1/user.current_trans.special_cooldown1)
            if user.hidden_cooldown1 then 
                user.cooldown_bar1:reveal()
                user.hidden_cooldown1 = false
            end
        else
            if not user.hidden_cooldown1 then 
                user.cooldown_bar1:sprite():set_height(0)
                user.cooldown_bar1:hide()
                user.hidden_cooldown1 = true
            end

            if user.current_trans == user.Px and not user.current_trans.onCooldown1  then 
                if user.Px_Target then 
                   -- print("Target is on")
                    user.skill_label1:get_animation():set_state("PX_SKILL1_LOCK")
                else
                   -- print("Target is off")
                    user.skill_label1:get_animation():set_state(user.current_trans.skill1)
                end
            end

            if user.current_trans ~= user.Px and user.current_trans.onCooldown1 then 
                user.skill_label1:get_animation():set_state(user.current_trans.skill1)
            end
        end

        if user.skill_label2:get_animation():get_state() ~= "NO_SPECIAL" and user.current_trans.cooldown2 > 0 then 
            user.cooldown_bar2:sprite():set_height(-40*user.current_trans.cooldown2/user.current_trans.special_cooldown2)
            if user.hidden_cooldown2 then 
                user.cooldown_bar2:reveal()
                user.hidden_cooldown2 = false
            end

        else
            if not user.hidden_cooldown2 then 
                user.cooldown_bar2:sprite():set_height(0)
                user.cooldown_bar2:hide()
                user.hidden_cooldown2 = true
            end

            if not user.current_trans.onCooldown2 then 
                user.skill_label2:get_animation():set_state(user.current_trans.skill2)
            end

        end
            
    end


    -- Creates one of several possible special actions when Special is released
        -- If Special held long enough, transform starts
        -- If released without input, toggles Overdrive
        -- If released with input, may activate special depending on form
    function create_special_action(player)
        local action = Battle.CardAction.new(player, "")
        action:set_lockout(make_sequence_lockout())

        local step = Battle.Step.new()
        local pose_step = Battle.Step.new()
        local pose_step_first = true

        local select_step = Battle.Step.new()
        local select_step_first = true

        local tranform = false
        local ready = false
        local transform_target = nil
        player.transforming = true

    -- Begin transformation steps
        select_step.update_func = function()
           --- print("In select step")
            if select_step_first then 
                player:get_animation():set_state("TRANS_LOOP")
                player:get_animation():refresh(player:sprite())
                create_labels(player)
                Engine.play_audio(common_sounds.pose, AudioPriority.Low)

                player:get_animation():on_complete(function()
                    player:get_animation():set_state("TRANS_LOOP")
                    player:get_animation():refresh(player:sprite())
                    player:get_animation():set_playback(Playback.Loop)
                    ready = true
                end)

                select_step_first = false
            end

            
            -- Based on held direction, choose model to transform into
                -- Would be a shame if keyboard ghosting messed things up, wouldn't it
            if player.input_has(player, Input.Held.Up) then
                player.label_list[1].selected = true
                if player.input_has(player, Input.Released.Special) then 
                    transform_target = player.Zx 
                end
            else
                player.label_list[1].selected = false
            end
            
            if player.input_has(player, Input.Held.Up) and player.input_has(player, Input.Held.Right) then 
                player.label_list[2].selected = true
                player.label_list[1].selected = false
                if player.input_has(player, Input.Released.Special) then 
                    transform_target = player.Hx
                end
            else 
                player.label_list[2].selected = false
            end

            if player.input_has(player, Input.Held.Down) and player.input_has(player, Input.Held.Right) then 
                player.label_list[3].selected = true
                if player.input_has(player, Input.Released.Special) then 
                    transform_target = player.Fx
                end

            else
                player.label_list[3].selected = false
            end

            if player.input_has(player, Input.Held.Down) and player.input_has(player, Input.Held.Left) then 
                player.label_list[4].selected = true
                if player.input_has(player, Input.Released.Special) then 
                    transform_target = player.Px
                end
            else
                player.label_list[4].selected = false
            end

            if player.input_has(player, Input.Held.Up) and player.input_has(player, Input.Held.Left) then 
                player.label_list[5].selected = true
                player.label_list[1].selected = false
                if player.input_has(player, Input.Released.Special) then 
                    transform_target = player.Lx
                end

            else
                player.label_list[5].selected = false
            end

            -- When player lets go of special
            if not player.input_has(player, Input.Held.Special) and not transform and ready then
               -- print("Tried to transform")
                transform = true
                
                -- If player didn't chose a model to transform into
                    -- In other words, they let go of special without holding a direction
                -- Else, transform to selected model
                if not transform_target or player.current_trans == transform_target then 
                    cleanup(player)
                    player.transforming = false
                    transform = false
                    select_step:complete_step()

                else
                    cleanup(player)
                --    player.transforming = false
                    transform = false
                    Engine.play_audio(common_sounds.selected, AudioPriority.Low)

                    -- Create time freeze action to transform
                    local transform_action = Battle.CardAction.new(player, "TRANS")
                    transform_action:set_lockout(make_animation_lockout())

                    local meta = transform_action:copy_metadata()
                    meta.time_freeze = true
                    meta.skip_time_freeze_intro = true
                    meta.shortname = "RockOn!"
                    transform_action:set_metadata(meta)

                    transform_action.execute_func = function(self)
                        local actor = self:get_actor()
                       -- print("Transform start")

                        player.normal_attack_func = transform_target.normal_attack
                        player.charged_attack_func = transform_target.charged_attack
                        actor:get_animation():on_frame(3, function()
                            Engine.play_audio(common_sounds.transform, AudioPriority.Low)
                        end)
                        actor:get_animation():on_frame(14, function()
                            local new_texture = Engine.load_texture(_folderpath..transform_target.name..".png")

                            player:set_texture(new_texture)
                            actor:set_texture(new_texture)
                            if transform_target ~= player.Zx then 
                                player.node:sprite():set_texture(Engine.load_texture(_folderpath..transform_target.name.."3.png"), false)
                            end

                            player.skill_label1:get_animation():set_state(transform_target.skill1)
                            player.skill_label2:get_animation():set_state(transform_target.skill2)


                            player:get_animation():refresh(player:sprite())
                            player.current_trans = transform_target
                            player:set_element(player.current_trans.element)
                            redraw_energy(player)
                            draw_cooldown(player)

                        end)
                    end
                    transform_action.action_end_func = function()
                        --print("Finished transforming")
                    end
                    select_step:complete_step()

                    -- There was some annoying thing where player animation restarted on "TRANS" for a few frames after the action.
                        -- This fixes it
                    player:get_animation():set_state("PLAYER_IDLE")
                    player:card_action_event(transform_action, ActionOrder.Immediate)
                end

            end

        end
       

        pose_step.update_func = function()
            if pose_step_first then 
                if player.overdrive then 
                    overdrive_toggle(player)
                end
                player:get_animation():set_state("TRANS_START")
                player:get_animation():on_complete(function()
                    pose_step:complete_step()
                    action:add_step(select_step)
                
                end)

                pose_step_first = false
            end

        end
    -- End transformation steps

        -- Toggle Overdrive if not in Zx, else use Zx special move
        -- Select special move to use based on current transformation and directional pressed 
        step.update_func = function()
            if not player:input_has(Input.Held.Special) then 
                step:complete_step()

                if player.current_trans == player.Zx then 
                    player:card_action_event(ZX_Special(player), ActionOrder.Immediate)  
                    -- Setting true again in all of these actions so that the player can't mash Special and queue special several times
                    player.special_action_queued = true
                    
                else
                    player.node:sprite():set_texture(Engine.load_texture(_folderpath..player.current_trans.name.."3.png"), false)
                    player.node:get_animation():refresh(player.node:sprite())

                    overdrive_toggle(player)
                    
                end
            end
      --      print("In special", player.trans_time)
        --    print("Special pre-input is", player.special_pre_input)

            if (player.current_trans ~= player.Zx) and (player:input_has(Input.Pressed.Right) or player.special_pre_input == Input.Pressed.Right) then 
                if player.current_trans == player.Hx then 
                    if player.current_trans.cooldown1 == 0 then 
                        player:card_action_event(HX_Ball(player), ActionOrder.Immediate)  
                        player.special_action_queued = true

                    end

                elseif player.current_trans == player.Px then 
                    player:card_action_event(PX_Dash(player), ActionOrder.Immediate)  
                    player.special_action_queued = true

                elseif player.current_trans == player.Lx then 
                    if player.current_trans.cooldown1 == 0 then 
                        player:card_action_event(LX_Dragon(player), ActionOrder.Immediate)  
                        player.special_action_queued = true

                    end
                end
                step:complete_step()

            elseif (player.current_trans ~= player.Zx) and (player:input_has(Input.Pressed.Down) or player.special_pre_input == Input.Pressed.Down) then
                if player.current_trans == player.Px then 
                    player:card_action_event(PX_Swap(player), ActionOrder.Immediate) 
                    player.special_action_queued = true
 
                end
                step:complete_step()

            elseif (player.current_trans ~= player.Zx) and (player:input_has(Input.Pressed.Left) or player.special_pre_input == Input.Pressed.Left) then
                if player.current_trans == player.Px then 
                    if player.current_trans.cooldown2 == 0 then 
                        player:card_action_event(PX_Shield(player), ActionOrder.Immediate)  
                        player.special_action_queued = true

                    end
                end
                step:complete_step()

            elseif (player.current_trans ~= player.Zx) and (player:input_has(Input.Pressed.Up) or player.special_pre_input == Input.Pressed.Up) then
                if player.current_trans == player.Hx then
                    if player.current_trans.cooldown2 == 0 then 
                        player:card_action_event(HX_Flight(player), ActionOrder.Immediate)  
                        player.special_action_queued = true

                    end  
                end
                step:complete_step()

            end  

            player.trans_time = player.trans_time + 1
            if player.trans_time == 25 then
                step:complete_step()
                action:add_step(pose_step)

            end
        end


        action:add_step(step)

        
        action.action_end_func = function()
            player.trans_time = 0
            cleanup(player)
            player.transforming = false

        end

        player:card_action_event(action, ActionOrder.Immediate)

    end

    -- For Zx level 2 charge animation
    function create_charge_node(user)
        user.charge_effect = user:create_node()
        user.charge_effect:set_texture(Engine.load_texture(_folderpath.."charge.png"), false)
        user.charge_animation = Engine.Animation.new(_folderpath.."charge.animation")
        user.charge_animation:load(_folderpath.."charge.animation")
        user.charge_animation:set_state("CHARGE")
        user.charge_animation:refresh(user.charge_effect)
        user.charge_effect:set_offset(0, -16)
        user.charge_animation:set_playback(Playback.Loop)
        user.charge_effect:set_layer(-2)
    end
    
    player.update_func = function(self, dt)

       -- I have to do all this setting in here because globals are crazy
        if not self.is_not_first_update then 
            --player:get_field():spawn(char, player:get_current_tile())
            self.combo = false
            self.Fx_Side = "L"
            self.Px_Target = false
            self.Lx_Ice = {}
            self.Lx_ice_count = 0
            self.node = player.node
            self.node:sprite():set_texture(Engine.load_texture(_folderpath.."Hx3.png"), false)
            self.node:sprite():set_layer(1)
            self.node:get_animation():load(_folderpath.."ZX.animation")
            --self.energy_bar = Battle.Artifact.new()
            --self.empty_bar = Battle.Artifact.new()
            self.ENERGY_MAX = 32

            self.Zx = {name = "Zx", element = Element.None, normal_attack = ZX_Attack, skill1 = "NO_SPECIAL", skill2 = "NO_SPECIAL", charged_attack = ZX_Attack}
            self.Hx = {name = "Hx", element = Element.Wind, energy = self.ENERGY_MAX, skill1 = "HX_SKILL1", skill2 = "HX_SKILL2", cooldown1 = 0, cooldown2 = 0, special_cooldown1 = 700, special_cooldown2 = 120, onCooldown1 = false, onCooldown2 = false, normal_attack = Hx_Attack, charged_attack = Hx_Tornado}
            self.Fx = {name = "Fx", element = Element.Fire, energy = self.ENERGY_MAX, skill1 = "NO_SPECIAL", skill2 = "NO_SPECIAL", normal_attack = FX_Shot, charged_attack = FX_Attack}
            self.Px = {name = "Px", element = Element.Cursor, energy = self.ENERGY_MAX, skill1 = "PX_SKILL1", skill2 = "PX_SKILL2", cooldown1 = 0, cooldown2 = 0, special_cooldown1 = 30, special_cooldown2 = 700, onCooldown1, onCooldown2, normal_attack = PX_Attack, charged_attack = PX_Charge}
            self.Lx = {name = "Lx", element = Element.Aqua, energy = self.ENERGY_MAX, skill1 = "LX_SKILL1", skill2 = "NO_SPECIAL", cooldown1 = 0, special_cooldown1 = 520, onCooldown1, normal_attack = LX_Attack, charged_attack = LX_Ice}
            self.current_trans = self.Zx

            self.charging = 0
            self.charge_shot = 1
            self.trans_time = 0
            self.size_change = 3
            self.special_action_queued = false
            self.special_queue_counter = 0
            self.special_pre_input = nil

            self.node:sprite():hide()

            self.overdrive = false
            self.overdrive_component = nil
            self.transforming = false

            self.overdrive_tick = 32
            self.overdrive_count = 1
            self.overdrive_during_action = false

            action_queue = 5
            self.action_queue_counter = 0
            
            self.combo_time = 0

            self.label_list = {}
            self.label_counter = 0

            self.skill_label1 = artifact_init(-16, -48, "special_labels.png", "special_labels.animation", -1, self.current_trans.skill1, self)
            self.skill_label2 = artifact_init(30, -48, "special_labels.png", "special_labels.animation", -1, self.current_trans.skill2, self)
            self.cooldown_bar1 = artifact_init(-16, -28, "special_labels.png", "special_labels.animation", -2, "COOLDOWN_BAR", self)
            self.cooldown_bar2 = artifact_init(30, -28, "special_labels.png", "special_labels.animation", -2, "COOLDOWN_BAR", self)

            self.hidden_cooldown1 = false
            self.hidden_cooldown2 = false
       --     print("Player is facing "..player:get_facing()..", while self is facing "..self:get_facing()..". Weird, isn't it?")
            
           -- print(player:get_field():spawn(char, player:get_field():tile_at(4, 3)))

            self.node:get_animation():refresh(self.node:sprite())

            self.energy_bar = artifact_init(32, -80, "energy.png", "energy.animation", -5, "ENERGY_BAR", self)
            self.empty_bar = artifact_init(98, -78, "energy.png", "energy.animation", -6, "EMPTY_BAR", self)

          -- self.charge_animation = artifact_init(0, 0, "charge.png", "charge.animation", -1, "CHARGE", self)
          -- self.charge_animation:get_animation():set_playback(Playback.Loop)

            

            if self:get_facing() == Direction.Left then 
                player:get_field():spawn(self.energy_bar, player:get_field():tile_at(6, 0))
                player:get_field():spawn(self.empty_bar, player:get_field():tile_at(6, 0))
                player:get_field():spawn(self.skill_label1, player:get_field():tile_at(6, 0))
                player:get_field():spawn(self.skill_label2, player:get_field():tile_at(6, 0))
                player:get_field():spawn(self.cooldown_bar1, player:get_field():tile_at(6, 0))
                player:get_field():spawn(self.cooldown_bar2, player:get_field():tile_at(6, 0))


            else 
                player:get_field():spawn(self.energy_bar, player:get_field():tile_at(1, 0))
                player:get_field():spawn(self.empty_bar, player:get_field():tile_at(1, 0))
                player:get_field():spawn(self.skill_label1, player:get_field():tile_at(1, 0))
                player:get_field():spawn(self.skill_label2, player:get_field():tile_at(1, 0))
                player:get_field():spawn(self.cooldown_bar1, player:get_field():tile_at(1, 0))
                player:get_field():spawn(self.cooldown_bar2, player:get_field():tile_at(1, 0))

            end

            local intro = artifact_init(0, 0, "aile.png", "human.animation", -6, "INTRO1", self)
            local intro_component = Battle.Component.new(player, Lifetimes.Scene)
            local intro_handler = Battle.Component.new(player, Lifetimes.Scene)

            -- List of the duration, in frames, of each animation frame I want
            local frames = {7, 3, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1}
            local current_frame = 0
            local current_frame_time = 4

            local enemy_filter = function(character)
                return character:get_team() ~= self:get_team()
            end
        
            local enemy_list = nil
            local target_tile = nil
            local begin = false
        
        
            intro_component.update_func = function()
                if begin then 
                    current_frame_time = current_frame_time - 1
                    if current_frame_time == 0 then
                        current_frame = current_frame+1
                        if current_frame == 3 then 
                            Engine.play_audio(common_sounds.transform, AudioPriority.Low)
                        end
                        if current_frame > 22 then 
                            self:reveal()
                            intro:get_animation():set_state("INTRO"..current_frame) 
                            intro:get_animation():refresh(intro:sprite())
                            intro:delete()
                            intro_component:eject()
                        else
                            if current_frame == 14 then 
                                intro:set_texture(base_texture)
                            end
                            intro:get_animation():set_state("INTRO"..current_frame) 
                            intro:get_animation():refresh(intro:sprite())

                            current_frame_time = frames[current_frame]
                        end

                    end
                end

            end

            -- Checks when an enemy appears. This happens to line of with the Custom screen moving in, 
                -- so we wait until then to start transforming
            intro_handler.update_func = function()
                enemy_list = player:get_field():find_nearest_characters(self, enemy_filter)
                if enemy_list[1] then
                    begin = true
                    enemy_list = nil
                    intro_handler:eject()
                end

            end

            self:hide()
            player:get_field():spawn(intro, self:get_current_tile())
            self:register_component(intro_handler)
            self:register_component(intro_component)

            self.special_component = Battle.Component.new(self, Lifetimes.Battlestep)


            self.special_component.update_func = function()
                if self:input_has(Input.Released.Use) or self:input_has(Input.Released.Shoot) then 
                    self.action_queue_counter = 5
                end

                if self.action_queue_counter > 0 then 
                    self.action_queue_counter = self.action_queue_counter - 1
                end


                if not self.special_action_queued and (self:input_has(Input.Pressed.Special) and (self:get_animation():get_state() == "PLAYER_IDLE" or self:is_moving())) and self.action_queue_counter == 0 then
               --     print("Queue special")
                    if not self.overdrive_during_action then
                        create_special_action(self)
                        self.special_action_queued = true
                    end
                elseif not self.overdrive_during_action and not self.special_action_queued and self:input_has(Input.Pressed.Special) and self.current_trans ~= player.Zx and not self.transforming then 
                   -- print("Toggling overdrive during an action")
                    overdrive_toggle(self)
                    self.overdrive_during_action = true
                end

                -- Reset that when no longer in an action. Hopefully can use :is_actionable() in a later build
                if self.overdrive_during_action and self:input_has(Input.Released.Special) then 
                    self.overdrive_during_action = false
                end


                -- Accepts player input before action is processed
                    -- It was really annoying trying to special and inputting before the special action began, so this should help
                if self.special_action_queued and self.special_queue_counter < 6 and not self.special_pre_input then 
                    if self:input_has(Input.Pressed.Up) then 
                        self.special_pre_input = Input.Pressed.Up
                    elseif self:input_has(Input.Pressed.Right) then 
                        self.special_pre_input = Input.Pressed.Right
                    elseif self:input_has(Input.Pressed.Down) then 
                        self.special_pre_input = Input.Pressed.Down
                    elseif self:input_has(Input.Pressed.Left) then 
                        self.special_pre_input = Input.Pressed.Left
                    end


                    if self.special_pre_input then 
                        --print("Received input before special update")
                    end
                end

                if self.special_action_queued then 
                    self.special_queue_counter = self.special_queue_counter + 1
                    if self.special_queue_counter == 6 then 
                        self.special_action_queued = nil
                        self.special_pre_input = nil
                        self.special_queue_counter = 0

                    end
                end


                -- and player:get_animation():get_state() == "PLAYER_IDLE"
                
            end

            self:register_component(self.special_component)
            self.is_not_first_update = true
        else
            if self.charge_animation then 
                self.charge_animation:update(dt, self.charge_effect)
            end
            if self.overdrive and self.current_trans.energy ~= 0 then 
                if self.overdrive_count == 0 then 
                    self.current_trans.energy = self.current_trans.energy - 1
                    self.overdrive_count = self.overdrive_tick
                end

                self.overdrive_count = self.overdrive_count-1
            end
        end

        redraw_energy(self)
        draw_cooldown(self)

        if self.Hx.onCooldown1 and self.Hx.cooldown1 > 0 then 
            self.Hx.cooldown1 = self.Hx.cooldown1 - 1
        else
            self.Hx.onCooldown1 = false
        end

        if self.Hx.onCooldown2 and self.Hx.cooldown2 > 0 then 
            self.Hx.cooldown2 = self.Hx.cooldown2 - 1
        else
            self.Hx.onCooldown2 = false
        end

        if self.Px.onCooldown1 and self.Px.cooldown1 > 0 then 
            self.Px.cooldown1 = self.Px.cooldown1 - 1
        else
            self.Px.onCooldown1 = false
        end

        if self.Px.onCooldown2 and self.Px.cooldown2 > 0 then 
            self.Px.cooldown2 = self.Px.cooldown2 - 1
        else
            self.Px.onCooldown2 = false
        end

        if self.Lx.onCooldown1 and self.Lx.cooldown1 > 0 then 
            self.Lx.cooldown1 = self.Lx.cooldown1 - 1
        else
            self.Lx.onCooldown1 = false
        end

        if self.combo and self.current_trans == self.Zx then 
            self.combo_time = self.combo_time+1
        --    print("combo time")
            if self.combo_time == 35 then
                self.combo = false
                self.combo_time = 0
            end
        end

        if self:input_has(Input.Held.Shoot) and (self:get_animation():get_state() == "PLAYER_IDLE" or self:is_moving()) then 
            self.charging = self.charging + 1
        else
            self.charging = 0
            self.charge_shot = 1
            if player.charge_animation then 
                player.charge_animation = nil
                player:sprite():remove_node(player.charge_effect)
            end
        end


        -- This formula is probably correct, but charge level in the engine is wonky right now. v2.5 will likely fix this
        if self.charging >= (110 - self:get_charge_level() * 10) then 
            self.charge_shot = 2
         --   print("Charge level 2!")
        end

        if self.charging >= (200 - self:get_charge_level() * 15) then 
            self.charge_shot = 3
            if not self.charge_animation and self.current_trans == self.Zx then 
                create_charge_node(self)
            end
           -- print("Charge level 3!")

        end

        

    end


    -- If I mash B a lot, I end up stopping here after step3? May be fixed now
    -- But I left it out anyway because the combo stuff was a bit finnicky and it's easier to play without
    -- So I create steps 2 and 3, but do not add them in

        -- I don't know what this TODO means anymore, but I left it
        -- TODO: Instead, have combo turn on in these functions, and action end turns it off
    function ZX_Attack(player)
        local action = Battle.CardAction.new(player, "ZX_ATTACK")
        action:set_lockout(make_sequence_lockout())
        local charge_value = player.charge_shot
        local sound_target
        if charge_value == 1 then 
            sound_target = Zx_sounds.shot1
        elseif charge_value == 2 then 
            sound_target = Zx_sounds.shot2
        else
            sound_target = Zx_sounds.shot3
        end

        if player.charge_animation then 
            player.charge_animation = nil
            player:sprite():remove_node(player.charge_effect)
        end

        
        action.execute_func = function(self, user)
            local tile = player:get_tile(player:get_facing(), 1)
            local step1 = Battle.Step.new()
            local step1_first = true
            local next_step1 = false

            local step2 = Battle.Step.new()
            local step2_first = true
            local next_step2 = false

            local step3 = Battle.Step.new()
            local step3_first = true

            local actor = self:get_actor()
            

            step1.update_func = function(self)
                if step1_first then 
                 --   print("In step 1")
                    action:add_anim_action(2, function()
                        local shot = create_shot(player, charge_value)
                        player:get_field():spawn(shot, tile)
                        Engine.play_audio(sound_target, AudioPriority.Low)
                    end)

                    player:get_animation():on_frame(5, function()
                   --     print("Step 1 done")
                        if next_step1 then 
                         ---   action:add_step(step2)
                        end

                        step1:complete_step()
                    end)

                    step1_first = false
                end

                if player:input_has(Input.Pressed.Shoot) then 
                    next_step1 = true

                end
            end

            step2.update_func = function(self)
                if step2_first then
                    --print("Step2")
                    player:get_animation():set_state("ZX_ATTACK")
                    player:get_animation():on_frame(2, function()
                        local shot = create_shot(player, 1)
                        player:get_field():spawn(shot, tile)
                    end)
                    
                 --   actor:get_animation():refresh(player:sprite())

                    player:get_animation():on_frame(5, function()
                      --  print("Step 2 done")
                        if next_step2 then
                            action:add_step(step3)
                        end
                        step2:complete_step()
                    
                    end)
                    step2_first = false
                end

                if player:input_has(Input.Pressed.Shoot) then 
                    next_step2 = true

                end


            end

            step3.update_func = function(self)
                if step3_first then
                    --print("Step 3")
                    player:get_animation():set_state("ZX_ATTACK")
                    player:get_animation():refresh(player:sprite())
                    player:get_animation():on_frame(2, function()
                        local shot = create_shot(player, 1)
                        player:get_field():spawn(shot, tile)

                    end)

                    player:get_animation():on_complete(function()
                      --  print("Step 3 done")
                        player:get_animation():set_state("PLAYER_IDLE")
                        player:get_animation():refresh(player:sprite())
                        step3:complete_step()
                    
                    end)
                    step3_first = false
                end
                
            end

            action:add_step(step1)            
         --   player:get_field():spawn(artifact, tile)

        end

        return action
    end


    function create_shot(user, charge_shot)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())

        spell:set_texture(Engine.load_texture(_folderpath.."ZX.png"), true)
      --  spell:highlight_tile(Highlight.Solid)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("ZX_SHOT"..charge_shot)

        spell:get_animation():set_playback(Playback.Loop)

    
        spell.slide_started = false
    
        local damage = user:get_attack_level()
        local flags = Hit.Impact
        local element = Element.None


        if charge_shot == 1 and user.combo then 
            flags = Hit.Impact | Hit.Pierce
        end

        -- 20 to 60
        if charge_shot == 2 then 
            damage = damage * 10 + 10
            flags = Hit.Impact | Hit.Flinch | Hit.Flash
        else
            -- 30 to 110
            if charge_shot == 3 then 
                damage = damage * 20 + 10
                flags = Hit.Impact | Hit.Flinch | Hit.Flash
            end
        end
        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )
        
        local speed = 6

        if charge_shot == 3 then 

            spell:get_animation():on_frame(7, function()
                speed = 4
            end)
        end
        spell.update_func = function(self, dt) 
            
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true 
                    end
                )
            end
        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
            if charge_shot == 3 then 
                user.combo = true
                --player.combo_time = 
            end

            if charge_shot == 2 then 
                user.combo = true
            end

        end
    
        spell.collision_func = function(self, other)             
            if charge_shot ~= 3 then 

                self:erase()
            end
        end
        
        spell.can_move_to_func = function(tile)
            return true
        end
    
    
        return spell
    end


    function Hx_Attack(player)
        local action = Battle.CardAction.new(player, "HX_SWING1")
        action:set_lockout(make_sequence_lockout())
        print("Hx Attack")

        -- The full combo will be 50 to 160 damage

        action.execute_func = function(self)
            player.combo = false
            local step1 = Battle.Step.new()
            local step1_first = true
            local next_step1 = false

            local step2 = Battle.Step.new()
            local step2_first = true
            local next_step2 = false

            local step3 = Battle.Step.new()
            local step3_first = true

            local actor = self:get_actor()

            -- spell_list collects the spells as I make them
                -- Each spell will self delete after 4 frames, but I will also delete them using this
                -- in the action_end_func.
            local spell_list = {}
            local field = player:get_field()
            local tile_in_front = player:get_tile(player:get_facing(), 1)
            local steps_used = 0

            step1.update_func = function(self)
                if step1_first then 
                    action:add_anim_action(2, function()
                        spell_list[1] = create_HX_Slash(player, tile_in_front, player.combo, player.overdrive)
                        field:spawn(spell_list[1], tile_in_front) 
                        Engine.play_audio(Hx_sounds.slash1, AudioPriority.Low)
                        steps_used = steps_used+1

                        player.combo = false
                    end)

                    player:get_animation():on_complete(function()
                        if next_step1 then 
                            action:add_step(step2)
                        end

                        step1:complete_step()
                    end)

                    step1_first = false
                end

                if player:input_has(Input.Pressed.Use) then 
                    next_step1 = true

                end
            end

            step2.update_func = function(self)
                if step2_first then
                    player:get_animation():set_state("HX_SWING2")
                    player:get_animation():on_frame(3, function()
                        spell_list[2] = create_HX_Slash(player, tile_in_front, player.combo, player.overdrive)
                        field:spawn(spell_list[2], tile_in_front) 
                        Engine.play_audio(Hx_sounds.slash2, AudioPriority.Low)
                        steps_used = steps_used+1

                        player.combo = false
                
                    end)
                    
                 --   actor:get_animation():refresh(player:sprite())

                    player:get_animation():on_complete(function()
                        if next_step2 then
                            action:add_step(step3)
                        end
                        step2:complete_step()
                    
                    end)
                    step2_first = false
                end

                if player:input_has(Input.Pressed.Shoot) then 
                    next_step2 = true

                end

            end

            step3.update_func = function(self)
                if step3_first then
                    player:get_animation():set_state("HX_SWING3")
                    player:get_animation():on_frame(3, function()
                        spell_list[3] = create_HX_Slash(player, tile_in_front, player.combo, player.overdrive)
                        field:spawn(spell_list[3], tile_in_front) 
                        Engine.play_audio(Hx_sounds.slash3, AudioPriority.Low)
                        steps_used = steps_used+1

                        create_HX_sonic_boom(player, tile_in_front, player.combo, player.overdrive)
                        
                        player.combo = false

                    end)

                    player:get_animation():on_complete(function()
                        step3:complete_step()
                    
                    end)
                    step3_first = false
                end

            end

            action:add_step(step1)

            action.action_end_func = function()
                -- For each spell, delete if it isn't already deleted.
                    -- Stops potential trades 2-3f after getting hit
                for i=1, steps_used, 1
                do
                    if not spell_list[i]:is_deleted() then 
                        spell_list[i]:delete()
                    end
                end
                player.combo = false
            end

        end

        
        return action
    end

    function create_HX_Slash(user, tile, combo, overdrive)
        local hasHit = false
        local counter = 0
        local spell = Battle.Spell.new(user:get_team())
        --spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())


        -- 5 to 25 damage
        local damage = user:get_attack_level() * 5
        local flags = Hit.Impact | Hit.Flinch | Hit.Flash
        if combo then 
            flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
        end

        local element = Element.Sword
     --   if overdrive then 

       -- end
        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )

        spell.update_func = function(self)
            if counter == 4 then 
                self:erase()
            else 
                counter = counter + 1
            end
            if not hasHit then
                spell:get_current_tile():attack_entities(self)
                spell:get_current_tile():highlight(Highlight.Solid)
                if overdrive then 
                    spell:get_tile(user:get_facing(), 1):attack_entities(self)
                    spell:get_tile(user:get_facing(), 1):highlight(Highlight.Solid)
                end
            end

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
            user.combo = true

        end

        spell.collision_func = function(self, other) 
            self:erase()
        end
        spell.can_move_to_func = function(tile)
            return true
        end

        return spell
      --  user:get_field():spawn(spell, tile)
        
    end

    function create_HX_sonic_boom(user, tile, combo, overdrive)
        local hasHit = false
        local counter = 0
        local spell = Battle.Spell.new(user:get_team())
        -- lifetime decrements every slide, so this also controls how many tiles it moves. 
            -- First tile is user's, so it goes lifetime tiles ahead of the user, moving a total of lifetime+1 tiems
        local lifetime = 2
        spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())

        spell:set_texture(Engine.load_texture(_folderpath.."Hx.png"), true)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("HX_BOOM")


        -- 35 to 95 damage
        local damage = 20 + user:get_attack_level() * 15
        local flags = Hit.Impact | Hit.Flinch | Hit.Flash
        if combo then
            flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
        end

        local element = Element.None
        -- Covers two more panels if in overdrive
        if overdrive then 
            lifetime = 5
        end

        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )


        spell.update_func = function(self)
            if not hasHit then
                spell:get_current_tile():attack_entities(self)
            end

            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, 
                    function()
                        hasHit = false
                        self.slide_started = true
                        lifetime = lifetime - 1
                        if lifetime == 0 then 
                            self:erase()
                        end
                    end
                )
            end

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)

        end

        spell.collision_func = function(self, other) 
            hasHit = true
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        user:get_field():spawn(spell, tile)

    end


    function Hx_Tornado(player)
        local action = Battle.CardAction.new(player, "HX_SWING2")
        action:set_lockout(make_animation_lockout())
        local overdrive = player.overdrive


        local loop_counter = 0
        local should_attack = true
        local tornado = Battle.Spell.new(player:get_team())
        tornado:sprite():set_layer(-1)
        tornado:set_facing(player:get_facing())
        tornado:set_texture(Engine.load_texture(_folderpath.."Hx.png"))
        tornado:set_offset(0, -20)
        tornado:get_animation():load(base_animation_path)
        tornado:get_animation():set_state("HX_TORNADO")
    
        tornado:get_animation():refresh(tornado:sprite())

        tornado.can_move_to_func = function()
            return true
        end


        local lifetime = 126
        -- I was originally going to give it this extra lifetime if overdrive was on. That gets like 3 extra hits
            -- I stuck to changing element instead, but I'll leave this here
        --if overdrive then 
           -- lifetime = 156
        --end
        local initial_lifetime = lifetime
        
        tornado:get_animation():on_complete(function()            
            tornado:get_animation():set_state("HX_TORNADO_LOOP")
            tornado:get_animation():refresh(tornado:sprite())
            tornado:get_animation():set_playback(Playback.Loop)


            tornado.update_func = function()
                lifetime = lifetime-1
                if lifetime == initial_lifetime-1 then 
                    tornado_attack(player, tornado:get_current_tile(), lifetime, false, initial_lifetime, overdrive)
                    if player.overdrive then 
                        player.current_trans.energy = math.max(player.current_trans.energy - 3, 0)
                    end
                end

                if lifetime == initial_lifetime-11 then 
                    tornado:slide(tornado:get_tile(player:get_facing(), 1), frames(20), frames(0), ActionOrder.Voluntary, nil)
                end

                if lifetime == 0 then 
                    tornado:erase() 
                end

            end
        
        end)
        
        action:add_anim_action(5, function()
            player:get_field():spawn(tornado, player:get_tile(player:get_facing(), 1))
            Engine.play_audio(Hx_sounds.tornado, AudioPriority.Low)
        end)


        return action
    end


    function tornado_attack(user, tile, lifetime, hit, initial_lifetime, overdrive)
     --   hit = hit or false
        local spell = Battle.Spell.new(user:get_team())
     --   spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())
        local attack_tile = tile
        -- Since the spell is created and is sliding independently of the graphic, I move it manually here
        if lifetime < initial_lifetime-26 then 
            attack_tile = attack_tile:get_tile(spell:get_facing(), 1)
        end

        -- 2 to 10 damage per hit
        -- Column in front gets hit 3 times, next column gets hit 9 times
            -- That's a max damage of 90
        local damage = user:get_attack_level() * 2
        local flags = Hit.Impact | Hit.Flinch
        -- If the previous spell hit, don't flinch
            -- This stops it from flinch locking someone, so they can walk about instead of being stuck for two seconds
        if hit then
            flags = Hit.Impact
        end
      --  if combo then
        --    flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
        --end

        local element = Element.None
        if player.overdrive then 
            element = Element.Wind
            --lifetime = 5
        end

        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )


        spell.update_func = function(self)
            lifetime = lifetime-1
            
            -- Every 10 frames, spawn another spell with the same parameters
                -- lifetime actually does change and is passed. 
                -- This is done because we can't attack the same tile with the same spell more than once
            if (lifetime+1) % 10 == 0 then
                tornado_attack(user, spell:get_current_tile(), lifetime, hit, initial_lifetime, overdrive)
                self:delete()
            end

            -- Attack the whole column. If one of the tiles adjacent to tile is an edge, we know we're at the bottom/top, so 
                -- we know where to spawn the attack to cover the column
            if lifetime % 10 == 0 and lifetime ~= 0 then
                attack_tile:attack_entities(self)
                if attack_tile:get_tile(Direction.Up, 1):is_edge() then 
                    attack_tile:get_tile(Direction.Down, 2):attack_entities(self)
                else
                    attack_tile:get_tile(Direction.Up, 1):attack_entities(self)
                end

                if attack_tile:get_tile(Direction.Down, 1):is_edge() then 
                    attack_tile:get_tile(Direction.Up, 2):attack_entities(self)
                else
                    attack_tile:get_tile(Direction.Down, 1):attack_entities(self)
                end

            end
            
            -- Deletes so that no more spells are spawned
            if lifetime == 0 then
                self:delete()
            end

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)

        end
        
        spell.collision_func = function(self, other) 
            hit = true
         --   self:delete()
        end

    --   spell.delete_func = function()

       -- end

        spell.can_move_to_func = function(tile)
            return true
        end

        user:get_field():spawn(spell, tile)

    end


    function HX_Ball(player)
        if player.current_trans.energy == 0 then 
            return nil
        end
        local action = Battle.CardAction.new(player, "HX_SWING1")
        action:set_lockout(make_animation_lockout())


        action:add_anim_action(3, function()
            player.current_trans.cooldown1 = player.current_trans.special_cooldown1
            player.skill_label1:get_animation():set_state("HX_SKILL1_COOLDOWN")
            create_hx_ball(player, player:get_current_tile(), player.overdrive)
            Engine.play_audio(Hx_sounds.ball, AudioPriority.Low)
            player.current_trans.energy = math.max(player.current_trans.energy - 3, 0)
            if overdrive then 
                player.current_trans.energy = math.max(player.current_trans.energy - 5, 0)
            end
        end)

        action.action_end_func = function()
            player.current_trans.onCooldown1 = true
        end

        return action
    end

    function create_hx_ball(user, tile, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        --spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())
        local lifetime = 360
        -- Lasts long enough to move an extra tile in overdrive
        if overdrive then 
            lifetime = 480
        end
        local field = user:get_field()
      --  if lifetime < 100 then 
        --    attack_tile = attack_tile:get_tile(spell:get_facing(), 1)
        --end

        spell:set_texture(Engine.load_texture(_folderpath.."Hx.png"), true)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("HX_BALL")
        spell:get_animation():refresh(spell:sprite())


        spell:get_animation():on_complete(function()
            spell:get_animation():set_state("HX_BALL_LOOP")
            spell:get_animation():refresh(spell:sprite())
            spell:get_animation():set_playback(Playback.Loop)
        
        end)

        -- 15 to 35 damage
        local damage = 10 + user:get_attack_level() * 5
        local flags = Hit.Impact | Hit.Flinch | Hit.Root
       -- if hit then
         --   flags = Hit.Impact
        --end
      --  if combo then
        --    flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
        --end

        local element = Element.Wind
        if player.overdrive then 
           -- element = Element.Aqua
            --lifetime = 5
        end

        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )


        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)


        local target = enemy_list[1]
        local dest = tile:get_tile(spell:get_facing(), 1)

        local targetX = 0
        local targetY = 0

        local distance_check = nil 
        
        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)

            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                self:slide(dest, frames(7), frames(120), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true
                    end
                )
            end

            lifetime = lifetime-1

            if lifetime == 0 then
                self:delete()
            end


            distance_check = target:get_current_tile():x() - spell:get_current_tile():x()

            if distance_check < 0 then 
                targetX = -1
            elseif distance_check > 0 then 
                targetX = 1
            else 
                targetX = 0 
            end

            distance_check = target:get_current_tile():y() - spell:get_current_tile():y()

            if distance_check < 0 then 
                targetY = -1
            elseif distance_check > 0 then 
                targetY = 1
            else 
                targetY = 0 
            end


            dest = field:tile_at((spell:get_current_tile():x() + targetX), (spell:get_current_tile():y() + targetY))

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)

        end

        spell.collision_func = function(self, other) 
            self:delete()
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        user:get_field():spawn(spell, tile)
    end


    function HX_Flight(player)
        local action = Battle.CardAction.new(player, "HX_FLIGHT")
        action:set_lockout(make_animation_lockout())
        local time = 1
        local velocity = 30
        local height = 0
        local peak = nil


        local step = Battle.Step.new()

        local step1_first = true


        action.execute_func = function()
            player:set_shadow(1)
            player:show_shadow(true)
            Engine.play_audio(Hx_sounds.flight, AudioPriority.Low)
        end

        action:add_anim_action(2, function()
            player.current_trans.cooldown2 = player.current_trans.special_cooldown2
            player.skill_label2:get_animation():set_state("HX_SKILL2_COOLDOWN")

            action.update_func = function()
              --  print(height)
                if height >= 0 then 
                    height = math.floor((10 + time*time*0.2))

                    player:set_elevation(height)
                    time = time+1
                end
            end
        end)

        -- Invul starts here
        action:add_anim_action(7, function()
            player:toggle_hitbox(false)

        end)

        -- Invul ends here
        action:add_anim_action(20, function()
            player:toggle_hitbox(true)

        end)

        action:add_anim_action(14, function()
            time = 0
            peak = height

            action.update_func = function()
               -- print(height)
                if height >= 0 then 
                    height = math.floor(peak + (5.4*time + time*time*-0.2))

                    player:set_elevation(height)
                    time = time+1
                else 
                    player:set_elevation(0)
                end
            end
        end)

        action.action_end_func = function()
            player:toggle_hitbox(true)
            player:set_elevation(0)
            player.current_trans.onCooldown2 = true
            player:show_shadow(false)

        end

        return action

    end

    function swap_side(player)
        if player.Fx_Side == "L" then 
            player.Fx_Side = "R"
        else 
            player.Fx_Side = "L"
        end

    end

    function create_FX_shot(user, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        
        spell:set_texture(Engine.load_texture(_folderpath.."Fx.png"), true)
        spell:highlight_tile(Highlight.Solid)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("FX_SHOT")

        spell:get_animation():set_playback(Playback.Loop)

    
        spell.slide_started = false
    
        -- 2 to 10 damage
        local damage = user:get_attack_level() * 2
        local flags = Hit.Impact
        local element = Element.None

       -- if overdrive then 
         --   damage = damage + user:get_attack_level()
        --end

        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )
        
        
        local speed = 6

        spell.update_func = function(self, dt) 
            
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true 
                    end
                )
            end
        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end
    
        spell.collision_func = function(self, other) 
            self:erase()
          
        end
        
        spell.can_move_to_func = function(tile)
            return true
        end
    
    
        return spell
    end

    function FX_Shot(player)
        local action = nil
        if not player.overdrive then 
            action = Battle.CardAction.new(player, "FX_SHOT_"..player.Fx_Side)
        else
            action = Battle.CardAction.new(player, "FX_SHOT_OVERDRIVE_"..player.Fx_Side)
        end

        action:set_lockout(make_animation_lockout())

        action.execute_func = function(self, user)
            local tile = player:get_tile(player:get_facing(), 1)
            local spell = create_FX_shot(player, player.overdrive)

            player:get_field():spawn(spell, player:get_current_tile():get_tile(player:get_facing(), 1))
            Engine.play_audio(Fx_sounds.shot, AudioPriority.Low)
        end


        action.action_end_func = function()
            swap_side(player)
        end


        return action
    end


    function step_create(attack, player)
        local punch = Battle.Step.new()
        local punch_first = true   
        local punch_next = false
            
        local fireball = Battle.Step.new()
        local fireball_first = true
        local fireball_next = false

        local fire = Battle.Step.new()
        local fire_first = true
        local fire_next = false

        local list = {}
        list[1] = nil
        list[2] = nil

        punch.update_func = function(self)
            if punch_first then 
                player:get_animation():set_state("FX_PUNCH_"..player.Fx_Side)
                player:get_animation():refresh(player:sprite())

                player:get_animation():on_frame(3, function()
                    list[2] = punch_attack(player, player.overdrive)
                    Engine.play_audio(Fx_sounds.punch, AudioPriority.Low)
                    player:get_field():spawn(list[2], player:get_current_tile():get_tile(player:get_facing(), 1))
                    if player.overdrive then 
                        player.current_trans.energy = math.max(player.current_trans.energy - 2, 0)
                    end

                end)

                player:get_animation():on_complete(function()
                    player:get_animation():set_state("PLAYER_IDLE")
                    punch:complete_step()
                
                end)

                punch_first = false
            end

        end

        fireball.update_func = function(self)
            if fireball_first then 
                player:get_animation():set_state("FX_PUNCH_"..player.Fx_Side)
                player:get_animation():refresh(player:sprite())

                player:get_animation():on_frame(3, function()
                    fire_attack(player, player.overdrive)
                    Engine.play_audio(Fx_sounds.fireball, AudioPriority.Low)
                    if player.overdrive then 
                        player.current_trans.energy = math.max(player.current_trans.energy - 3, 0)
                    end
                    
                end)

                player:get_animation():on_complete(function()
                    player:get_animation():set_state("PLAYER_IDLE")
                    self:complete_step()
                
                end)

                fireball_first = false
            end

        end

        fire.update_func = function(self)
            if fire_first then 
                player:get_animation():set_state("FX_PUNCH_DOWN_"..player.Fx_Side)
                player:get_animation():refresh(player:sprite())

                player:get_animation():on_frame(3, function()
                    trail_attack(player, player.overdrive)
                    Engine.play_audio(Fx_sounds.firetrail, AudioPriority.Low)
                    if player.overdrive then 
                        player.current_trans.energy = math.max(player.current_trans.energy - 4, 0)
                    end

                end)

                player:get_animation():on_complete(function()
                    player:get_animation():set_state("PLAYER_IDLE")
                    self:complete_step()
                
                end)

                fire_first = false
            end

        end

        if attack == "punch" then 
            list[1] = punch
        elseif attack == "fireball" then 
            list[1] = fireball
        elseif attack == "fire" then 
            list[1] = fire
        end

        return list
    end

    function create_burn_component(other)
        local burn = Battle.Component.new(other, Lifetimes.Battlestep)

        local burn_counter = 120
        local red = Color.new(120, 0, 0, 255)
        local normal = Color.new(0, 0, 0, 0)

        burn.update_func = function()
            burn_counter = burn_counter - 1
            if burn_counter % 15 == 0 then 
                other:set_health(other:get_health()-4)

            end

            if burn_counter % 3 == 0 or burn_counter % 3 == 1 then 
                other:sprite():set_color(red)
            end

            if burn_counter == 0 then 
                burn:eject()
            end
        end

        other:register_component(burn)
    end

    function FX_Attack(player)
        local action = Battle.CardAction.new(player, "FX_ATTACK_START")
        action:set_lockout(make_sequence_lockout())
        local list = {}
        local list2 = {}
        local input_happened = false

        action.execute_func = function()
            local inputPhase = Battle.Step.new()
            local inputPhase_first = true
            local inputPhaseNext = false

            -- If no energy, just skip straight to punch
            inputPhase.update_func = function()
                if inputPhase_first then 
                    --player:get_animation():set_state("FX_ATTACK_START")
                    player:get_animation():on_complete(function()
                        list = step_create("punch", player)
                        action:add_step(list[1])

                        inputPhase:complete_step()
                    end)

                    inputPhase_first = false
                end

                if player:input_has(Input.Held.Left) or player:input_has(Input.Pressed.Left) then 
                    list = step_create("punch", player)
                    action:add_step(list[1])
                    inputPhase:complete_step()
                    input_happened = true
                
                elseif player:input_has(Input.Held.Right) or player:input_has(Input.Pressed.Right) then 
                    list = step_create("fireball", player)
                    action:add_step(list[1])
                    inputPhase:complete_step()
                    input_happened = true

                elseif player:input_has(Input.Held.Down) or player:input_has(Input.Pressed.Down) then 
                    list = step_create("fire", player)
                    action:add_step(list[1])
                    inputPhase:complete_step()
                    input_happened = true

                    
                end
                

            end


            action:add_step(inputPhase)

        end

        action.update_func = function()
            if input_happened then 
                if (player:input_has(Input.Held.Left) or player:input_has(Input.Pressed.Left)) and player:input_has(Input.Held.Shoot) then 
                    swap_side(player)
                    list2 = step_create("punch", player)
                    action:add_step(list2[1])
                    input_happened = false
                
                elseif (player:input_has(Input.Held.Right) or player:input_has(Input.Pressed.Right)) and player:input_has(Input.Held.Shoot) then 
                    swap_side(player)
                    list2 = step_create("fireball",player)
                    action:add_step(list2[1])
                    input_happened = false


                elseif (player:input_has(Input.Held.Down) or player:input_has(Input.Pressed.Down)) and player:input_has(Input.Held.Shoot) then 
                    swap_side(player)
                    list2 = step_create("fire", player)
                    action:add_step(list2[1])
                    input_happened = false

                end

            end


        end


        action.action_end_func = function()
            swap_side(player)
            if list[2] and not list[2]:is_deleted() then 
                list[2]:delete()
            end

            if list2[2] and not list2[2]:is_deleted() then 
                list2[2]:delete()
            end

        end
        
        return action
    end

    function punch_attack(user, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())
        local field = user:get_field()
        
        local lifetime = 6

        -- 35 to 95 damage
        local damage = 20 + user:get_attack_level() * 15
        local flags = Hit.Impact | Hit.Flinch | Hit.Drag
        if user.combo then 
            flags = Hit.Impact | Hit.Flinch | Hit.Drag | Hit.Pierce
        end

        local element = Element.None
        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.new(spell:get_facing(), 6) 
            )
        )

        spell.update_func = function(self)
            if lifetime == 0 then 
                self:erase()
            else 
                lifetime = lifetime - 1
            end
            spell:get_current_tile():attack_entities(self)
 

        end

        spell.attack_func = function(self, other)
            print("Did damage")
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
            if overdrive then 
                create_burn_component(other)
            end

        end

        spell.collision_func = function(self, other) 
            self:erase()
           -- player.combo = true
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        return spell
    end


    function fire_attack(user, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())

        spell:set_texture(Engine.load_texture(_folderpath.."Fx.png"), true)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("FX_FIREBALL")
        spell:get_animation():refresh(spell:sprite())


        spell:get_animation():on_complete(function()
            spell:get_animation():set_playback(Playback.Loop)
        
        end)


        local shockwave = Battle.Artifact.new()
        shockwave:set_texture(Engine.load_texture(_folderpath.."Fx.png"), true)
        shockwave:get_animation():load(_folderpath.."ZX.animation")
        shockwave:get_animation():set_state("FX_WAVE")
        shockwave:get_animation():refresh(shockwave:sprite())


        shockwave:get_animation():on_complete(function()
            shockwave:delete()
        
        end)

        local field = user:get_field()
        local speed = 6

        local lifetime = speed * 2 + 5
        if overdrive then 
            lifetime = speed * 4 + 5
        end

        -- 40 to 120 damage
        local damage = 20 + user:get_attack_level() * 20
        local flags = Hit.Impact | Hit.Flinch | Hit.Flash
        if user.combo then 
            flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
        end

        local element = Element.Fire
        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true 
                    end
                )
            end
            if lifetime == 0 then 
                self:erase()
            else 
                lifetime = lifetime - 1
            end
            spell:get_current_tile():attack_entities(self)
 

        end

        spell.attack_func = function(self, other)
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
            user.combo = true
            if overdrive then 
                create_burn_component(other)
            end

        end

        spell.collision_func = function(self, other) 
            self:erase()
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, user:get_current_tile():get_tile(user:get_facing(), 1))
        field:spawn(shockwave, user:get_current_tile())

    end
        
    function spawn_firering(user, tile, overdrive)
        local fire = Battle.Spell.new(user:get_team())
        fire:set_texture(Engine.load_texture(_folderpath.."firering.png"), true)
        
    
        local ringanim = fire:get_animation()
        ringanim:load(_modpath.."firering.animation")
        ringanim:set_state("IDLE")
        ringanim:set_playback(Playback.Loop)
        fire:highlight_tile(Highlight.Solid)
        
        fire:sprite():set_layer(0)
        
        fire:set_hit_props(HitProps.new(
            user:get_attack_level() * 10, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.Fire, 
            user:get_context(),
            Drag.None
            )
        )
        
        local expiration = 200
    
        fire.update_func = function(self, dt) 
            fire:get_tile():attack_entities(self)
            if fire:get_tile():is_reserved({}) and expiration < 200 then
                self:delete()
            end
            expiration = expiration - 1
            if expiration <= 0 then
                self:delete()
            end
        end

        fire.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end
        
        fire.collision_func = function(self, other)
            self:delete()
        end

        user:get_field():spawn(fire, tile)

    end

    function trail_attack(user, overdrive)
        local first = true
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())

        spell:set_texture(Engine.load_texture(_folderpath.."Fx.png"), true)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("FX_TRAIL")
        spell:get_animation():refresh(spell:sprite())


        spell:get_animation():on_complete(function()
            
        
        end)


        local burst = Battle.Artifact.new()
        local offsetX = 0
        if player.Fx_Side == "R" then 
            offsetX = 8
            if player:get_facing() == Direction.Left then 
                offsetX = offsetX * -1
            end
        end

        burst:set_texture(Engine.load_texture(_folderpath.."Fx.png"), true)
        burst:get_animation():load(_folderpath.."ZX.animation")
        burst:get_animation():set_state("FX_BURST")
        burst:get_animation():refresh(burst:sprite())
        burst:set_offset(offsetX, 0)


        burst:get_animation():on_complete(function()
            burst:delete()
        
        end)

        local field = user:get_field()
        local speed = 12

        local lifetime = speed * 3 + 5
        if overdrive then 
            lifetime = lifetime + speed
        end

      --  if combo then 
        --    flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce
       -- end

        local direction = spell:get_facing()
       

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true 
                        if first then 
                            first = false
                        else
                            spawn_firering(user, spell:get_current_tile(), overdrive)
                        end
                    end
                )
            end
            if lifetime == 0 then 
                self:erase()
            else 
                lifetime = lifetime - 1
            end
 

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function(self, other) 
           -- player.combo = true
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, user:get_current_tile())
        field:spawn(burst, user:get_current_tile())


    end

    
    function PX_Swap(player)
        local action = Battle.CardAction.new(player, "PLAYER_IDLE")
        -- Consider animation lockout
        -- I would sequence lockout, but oh well. Unfortunately can't stop snapping, even with "" state
        local update_count = 0

        action.execute_func = function()
            player.current_trans.cooldown1 = player.current_trans.special_cooldown1
            -- May want a sound here
            if player.Px_Target then 
                player.Px_Target = false
                player.skill_label1:get_animation():set_state("PX_SKILL1_COOLDOWN")
            else
                player.Px_Target = true
                player.skill_label1:get_animation():set_state("PX_SKILL1_LOCK_COOLDOWN")
            end

            action.action_end_func = function()
                player.current_trans.onCooldown1 = true
            end
        end

        action.update_func = function()
            -- Count > 5 to account for the execute not starting until 5 frames in. 
                -- Other check is to be nice and not let the player accidentally move down as often after using this.
                -- Giving time to let go of down before the action ends, basically
            if (update_count > 5 and not player:input_has(Input.Held.Down)) or update_count > 15 then 
                action:end_action()
            else 
                update_count = update_count + 1
            end
        end


        return action
    end

    function create_kunai(user, speed, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        
        spell:set_texture(Engine.load_texture(_folderpath.."Px.png"), true)
      --  spell:highlight_tile(Highlight.Solid)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("PX_SHOT")

        spell:set_offset(speed * 1, speed * 3)
        spell:sprite():set_layer(-1)
    
        spell.slide_started = false
    
        local damage = math.max(user:get_attack_level()-(speed-6), 1)
        if overdrive then 
            damage = damage + 1
        end
        local flags = Hit.Impact
        local element = Element.None

        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )
        
        
        --local speed = 6

        spell.update_func = function(self, dt) 
            
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
                end 
                
                local dest = self:get_tile(direction, 1)
             --   local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true 
                    end
                )
            end
        end
        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function(self, other) 
            self:erase()
          
        end
        
        spell.can_move_to_func = function(tile)
            return true
        end


        user:get_field():spawn(spell, user:get_current_tile())

    end

    function create_homing_kunai(user, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        
        spell:set_texture(Engine.load_texture(_folderpath.."Px.png"), true)
      --  spell:highlight_tile(Highlight.Solid)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("PX_SHOT")

        local field = user:get_field()
        local offsetX = -6
        if user:get_facing() == Direction.Left then 
            offsetX = offsetX * -1
        end

        spell:set_offset(offsetX, 18)
        spell:sprite():set_layer(-1)
    
        spell.slide_started = false

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        local target_tile = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)
        local distanceX = nil
        local distanceY = nil
        local travel_time = 6
        local tile = user:get_current_tile()
        local target_found = false
        local counter = -1


        if enemy_list[1] then 
            target_tile = enemy_list[1]:get_current_tile()
            distanceX = target_tile:x() - tile:x()
            distanceY = target_tile:y() - tile:y()

           -- distance = (distanceX * distanceX + distanceY * distanceY)
           travel_time = travel_time * math.max(math.abs(distanceX), math.abs(distanceY))
           target_found = true
           
        end


        if target_found then 
            
        end

        local damage = user:get_attack_level()
        if overdrive then 
            damage = damage * 2
        end
        local flags = Hit.Impact
        local element = Element.None

        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                user:get_context(),
                Drag.None
            )
        )
        
        
        --local speed = 6
        local first_time = true
        spell.update_func = function(self, dt) 
            if target_found then 
                target_tile:highlight(Highlight.Flash)
                if first_time then 
                    self:slide(target_tile, frames(travel_time), frames(0), ActionOrder.Voluntary, function() 
                        counter = travel_time
                    
                    end)
                    first_time = false
                end
                if counter == 0 then 
                    self:get_current_tile():attack_entities(self)
                    self:delete()
                end

                counter = counter - 1
            else
            
                self:get_current_tile():attack_entities(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        self:delete()
                    end 
                    
                    local dest = self:get_tile(direction, 1)
                --   local ref = self
                    self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, 
                        function()
                            self.slide_started = true 
                        end
                    )
                end
            end
        end
        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function(self, other) 
            self:erase()
          
        end
        
        spell.can_move_to_func = function(tile)
            return true
        end


        field:spawn(spell, user:get_current_tile())


    end


    function PX_Attack(player)
        local action = Battle.CardAction.new(player, "PX_ATTACK")
        action:set_lockout(make_animation_lockout())

        action.execute_func = function()
            local overdrive = player.overdrive
            local end_index = 4
            if overdrive then 
                end_index = 5
            end
            if not player.Px_Target then 
                for i=2, end_index, 1
                do
                    action:add_anim_action(i, function()
                        create_kunai(player, 4+i, overdrive)
                        if i == 2 then 
                            Engine.play_audio(Px_sounds.kunai, AudioPriority.Low)
                        end
                    
                    end)
                end
            else 
                action:add_anim_action(2, function()
                    create_homing_kunai(player, overdrive)
                    Engine.play_audio(Px_sounds.kunai, AudioPriority.Low)
                end)
            end

        end

        return action
    end


    function create_shuriken_attack(user, tile, context, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        local field = user:get_field()

        local damage = user:get_attack_level() 
        if overdrive then 
            damage = user:get_attack_level() + 2
        end
        local flags = Hit.Impact | Hit.Flinch
        local element = Element.None

        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                context,
                Drag.None
            )
        )

        spell.update_func = function(self, dt) 
            self:get_current_tile():attack_entities(self)
            self:delete()
        end

        --spell.delete_func = function()

        --end

        field:spawn(spell, tile)
    end

    function create_shuriken(user, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        local field = user:get_field()
        local times_moved = 0
        local count = 0
        local first_hit = 0
        local has_hit = false
        local context = user:get_context()

        spell:set_facing(user:get_facing()) 
        local direction = spell:get_facing()
       
        spell:set_texture(Engine.load_texture(_folderpath.."Px.png"), true)
        spell:highlight_tile(Highlight.Solid)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("PX_SHURIKEN")

        spell:get_animation():on_complete(function()
            spell:get_animation():set_state("PX_SHURIKEN_LOOP")
            spell:get_animation():refresh(spell:sprite())
            spell:get_animation():set_playback(Playback.Loop)


        end)

        local last_direction = nil
        spell.update_func = function(self, dt) 
            if count % 4 == 0 then
                create_shuriken_attack(user, spell:get_current_tile(), context, overdrive)
            end

            if times_moved < 3 then 
                self:get_current_tile():attack_entities(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        self:delete()
                    end 
                    
                    local dest = self:get_tile(direction, 1)
                    if has_hit then 
                        dest = self:get_current_tile()
                    end
                --   local ref = self
                    self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, 
                        function()
                            self.slide_started = true 
                            times_moved = times_moved + 1

                        end
                    )
                end
            end

            if (count > 64 and not has_hit) or (has_hit and first_hit > 43) then 
                if self:is_sliding() == false then
                    if self:get_current_tile() == user:get_current_tile() --or (self:get_current_tile():is_edge() and self.slide_started) then 
                    then
                        self:delete()
                    end 
                    if times_moved % 2 == 1 then 
                        local distance_check = user:get_current_tile():x() - spell:get_current_tile():x()
                        local targetX
                        local targetY

                        if distance_check < 0 then 
                            targetX = -1
                        elseif distance_check > 0 then 
                                targetX = 1
                        else 
                            targetX = 0 
                        end
            
                        distance_check = user:get_current_tile():y() - spell:get_current_tile():y()
            
                        if distance_check < 0 then 
                            targetY = -1
                        elseif distance_check > 0 then 
                                targetY = 1
                        else 
                            targetY = 0 
                        end

                        if targetY > 0 and targetX < 0 then 
                            last_direction = Direction.DownLeft
                        elseif targetY < 0 and targetX < 0 then 
                            last_direction = Direction.UpLeft
                        elseif targetY == 0 and targetX < 0 then 
                            last_direction = Direction.Left
                        elseif targetY > 0 and targetX > 0 then
                            last_direction = Direction.DownRight
                        elseif targetY < 0 and targetX > 0 then 
                            last_direction = Direction.UpRight
                        elseif targetY == 0 and targetX > 0 then 
                            last_direction = Direction.Right
                        end
                    end

                --  local dest = field:tile_at((spell:get_current_tile():x() + targetX), (spell:get_current_tile():y() + targetY))
                local dest = self:get_tile(last_direction, 1)
                if not dest then 
                    dest = self:get_tile(Direction.reverse(last_direction), 1)
                end
                if dest:is_edge() then 
                    if last_direction == Direction.DownLeft or last_direction == Direction.UpLeft then 
                        last_direction = Direction.Left
                    elseif last_direction == Direction.UpRight or last_direction == Direction.DownRight then 
                        last_direction = Direction.Right
                    end
                    dest = self:get_tile(last_direction, 1)
                end
                     
                --   local ref = self
                    self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, 
                        function()
                            self.slide_started = true 
                            times_moved = times_moved + 1

                        end
                    )
                end

            end

            count = count + 1
            if has_hit then 
                first_hit = first_hit + 1
            end

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function(self, other) 
            has_hit = true
        end
        
        spell.can_move_to_func = function(tile)
            return true
        end


        field:spawn(spell, user:get_current_tile())

    end

    function PX_Charge(player)
        local action = Battle.CardAction.new(player, "PX_ATTACK")
        action:set_lockout(make_animation_lockout())
        action.execute_func = function()
            action:add_anim_action(2, function()
                create_shuriken(player, player.overdrive)
                Engine.play_audio(Px_sounds.shuriken, AudioPriority.Low)
                if player.overdrive then 
                    player.current_trans.energy = math.max(player.current_trans.energy - 2, 0)
                end
            end)

        
        end

        return action
    end


    function PX_Dash(player)
        local action = Battle.CardAction.new(player, "PX_DASH_START")
        action:set_lockout(make_sequence_lockout())
        local start = Battle.Step.new()
        local start_first = true
        local start_next = false

        local dash = Battle.Step.new()
        local dash_first = true
        local dash_next = false

        local ending = Battle.Step.new()
        local ending_first = true

        local final_tile = nil
        local starting_tile = player:get_current_tile()

        local actor_copy = Battle.Spell.new(player:get_team())
        actor_copy:set_facing(player:get_facing()) 
       
        actor_copy:set_texture(Engine.load_texture(_folderpath.."Px.png"), true)
        actor_copy:get_animation():load(_folderpath.."ZX.animation")
        actor_copy:get_animation():set_state("PX_DASH_LOOP")

        local component = Battle.Component.new(player, Lifetimes.Scene)

        component.update_func = function()
            starting_tile:remove_entity_by_id(player:get_id())
            final_tile:add_entity(player)
            player:reveal()
            player:toggle_hitbox(true)

            component:eject()
          --  player.copy_storage:erase()

        end

        action.execute_func = function(self)
            local actor = self:get_actor()
            local current_tile = starting_tile
            actor_copy.update_func = function()
                if actor_copy:is_sliding() == false then
                    --print("Still updating that thing that should have been erased")
                    local dest = actor_copy:get_tile(actor_copy:get_facing(), 1)
    
                    -- This looks very ugly and confusing and might not be needed anymore, since the can_move_to_func should have me covered
                    if actor_copy:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, function()
                        current_tile:remove_entity_by_id(player:get_id())

                        actor_copy:get_current_tile():add_entity(player)

                        current_tile = actor_copy:get_current_tile()

                    end) then 
                       -- actor_copy:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, nil)
    
                    else dash_next = true
                    end
                end
    
    
            end
    
            actor_copy.can_move_to_func = function()
                local tile = actor_copy:get_tile(actor_copy:get_facing(), 1)
                if not tile:is_edge() and tile:get_team() == actor_copy:get_team() and tile:is_walkable() then 
                    return true
                else 
                    final_tile = actor_copy:get_current_tile()
                    dash_next = true
                    return false
                end
            end
            start.update_func = function()
                if start_first then 
                    player:get_animation():on_complete(function()
                        player:get_animation():set_state("PX_DASH_LOOP")
                        player:get_animation():refresh(player:sprite())
                        player:get_animation():set_playback(Playback.Loop)
                        
                        start_next = true
                    end)

                    start_first = false
                end

                if start_next then 
                    action:add_step(dash)
                    start:complete_step()
                end


            end


            dash.update_func = function()             
                if dash_first then 
                    actor:hide()
                    player:toggle_hitbox(false)
                    player:get_field():spawn(actor_copy, player:get_current_tile())
                    Engine.play_audio(Px_sounds.dash, AudioPriority.Low)
                    dash_first = false
                end

                if dash_next then 
                    action:add_step(ending)
                    dash:complete_step()
                end
            end


            ending.update_func = function()
                if ending_first then 
                    actor_copy:get_animation():set_state("PX_DASH_END")
                    player:get_animation():set_state("PX_DASH_END")

                    actor_copy:get_animation():on_complete(function()
                        player:register_component(component)

                        ending:complete_step()
                        actor_copy:erase()

                    end)

                    ending_first = false
                end

            end
        
        end

        local tile_check = player:get_current_tile():get_tile(player:get_facing(), 1)
        if tile_check:is_walkable() and (tile_check:get_team() == Team.Other or tile_check:get_team() == player:get_team()) then
            action:add_step(start)
        end

        action.action_end_func = function()
            if final_tile then 
                starting_tile:remove_entity_by_id(player:get_id())
                --player:register_component(component)
            end

        end

        return action
    end


    function PX_Shield(player)
        if player.current_trans.energy == 0 then 
            return nil
        end
        local action = Battle.CardAction.new(player, "PX_ATTACK")
        action:set_lockout(make_animation_lockout())
        local fading = false
        local offsetY = -30

        local shield = artifact_init(0, offsetY, "Px.png", "Zx.animation", -2, "PX_SHIELD_LOOP", player, true)
      
        shield:set_float_shoe(true)
        shield.lifetime = 360
        shield.counter = 0
        shield.hp = 10

        shield:get_animation():set_playback(Playback.Loop)
        shield:get_animation():refresh(shield:sprite())

        local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always) -- Keristero's Guard is 0
    
        barrier_defense_rule.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage >= shield.hp then 
                shield.lifetime = 0
            end

            judge:block_damage()
            
        end
        local shield_component = Battle.Component.new(shield, Lifetimes.Battlestep)

        -- Since the shield is an artifact, I can't have this in its update or else it can time out during time freeze
        shield_component.update_func = function()
            shield.lifetime = shield.lifetime - 1
        end

        local function remove_barrier()
            fading = true
            player:remove_defense_rule(barrier_defense_rule)
            shield_component:eject()
            shield:get_animation():set_state("PX_SHIELD_FADE")
            shield:get_animation():refresh(shield:sprite())
    
            shield:get_animation():on_complete(function()
                shield:delete()
            end)
        end

        

        player:register_component(shield_component)


        shield.update_func = function()
            if shield.counter % 2 == 0 then
                shield:hide()
            else
                shield:reveal()
            end

            shield.counter = shield.counter+1
            
            if shield:get_current_tile() ~= player:get_current_tile() then 
                shield:teleport(player:get_current_tile(), ActionOrder.Immediate, nil)
            end
    
            if (shield.lifetime <= 0 and not fading) or (shield.hp <= 0 and not fading) then
                remove_barrier()
                
            end
            
            if barrier_defense_rule:is_replaced() then
                shield:delete()
            end


        end


        shield.can_move_to_func = function()
            return true
        end

        
        local shield_start = Battle.Spell.new(player:get_team())
        shield_start:set_float_shoe(true)
        shield_start:set_offset(0, offsetY)
        shield_start:sprite():set_layer(-1)
        shield_start:set_texture(Engine.load_texture(_folderpath.."Px.png"), true)
        shield_start:get_animation():load(_folderpath.."ZX.animation")
        shield_start:get_animation():set_state("PX_SHIELD_START")
        shield_start:get_animation():refresh(shield_start:sprite())
        shield_start:get_animation():on_complete(function()
            player:get_field():spawn(shield, player:get_current_tile())
            player:add_defense_rule(barrier_defense_rule)
            shield_start:erase()        
        end)

        -- This should not be necessary in most cases, but I guess you can be pushed. Though it won't have smooth movement in that case, so.
        shield_start.update_func = function()
            if shield_start:get_current_tile() ~= player:get_current_tile() then 
                shield_start:teleport(player:get_current_tile(), ActionOrder.Immediate, nil)
            end
        end

        shield_start.can_move_to_func = function()
            return true
        end

        action.execute_func = function()
            action:add_anim_action(2, function()
                if player.current_trans.energy > 0 then 
                    player:get_field():spawn(shield_start, player:get_current_tile())
                    Engine.play_audio(Px_sounds.shield, AudioPriority.Low)
                    player.current_trans.energy = math.max(player.current_trans.energy - 4, 0)
                    player.current_trans.cooldown2 = player.current_trans.special_cooldown2
                    player.skill_label2:get_animation():set_state("PX_SKILL2_COOLDOWN")

                end

            end)
        end

        action.action_end_func = function()
            if not shield_start:is_deleted() then 
                shield_start:erase()
            end
            player.current_trans.onCooldown2 = true
        end

        return action
    end


    function create_LX_slash(user, tile, context, overdrive)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        local field = user:get_field()
        local has_hit = false
        local lifetime = 4

        local tile1 = tile
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)

        -- 10 to 30 damage
        local damage = 5 + user:get_attack_level() * 5
        local element = Element.None
        if overdrive then 
            damage = damage + 10
            element = Element.Aqua
        end

        spell:set_hit_props(
            HitProps.new(
                damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                element, 
                context,
                Drag.None
            )
        )

        spell.update_func = function(self, dt)
            if not has_hit then 
                tile1:highlight(Highlight.Solid)
                tile2:highlight(Highlight.Solid)
                tile3:highlight(Highlight.Solid)

                tile1:attack_entities(self)
                tile2:attack_entities(self)
                tile3:attack_entities(self)
            end

            lifetime = lifetime - 1
            if lifetime == 0 then 
                self:erase()
            end
        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function()
            has_hit = true
            user.combo = true

        end

        return spell
    end

    function create_LX_spin_slash(user, tile, context, overdrive, combo)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        local field = user:get_field()
        local has_hit = false
        local lifetime = 4

        local tile1 = tile
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)

        -- 1 to 5
        local damage = user:get_attack_level()
        local element = Element.None
        local flags = Hit.Impact

        if overdrive then 
            damage = damage+1
            element = Element.Aqua
        end

        if combo then 
            flags = Hit.Impact | Hit.Pierce | Hit.Retangible
        end

        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                context,
                Drag.None
            )
        )

        spell.update_func = function(self, dt)
            if not has_hit then 
                tile1:highlight(Highlight.Solid)
                tile2:highlight(Highlight.Solid)
                tile3:highlight(Highlight.Solid)

                tile1:attack_entities(self)
                tile2:attack_entities(self)
                tile3:attack_entities(self)
            end

            lifetime = lifetime - 1
            if lifetime == 0 then 
                self:erase()
            end
        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function()
            has_hit = true

        end

        return spell
    end

    -- 1x3 attack. If player pressed Shoot two times while attacking, initiates spin
        -- Spin will continue as long as player keeps maching Shoot
        -- The window to continue is like 26f or something, so very lenient
    function LX_Attack(player)
        local action = Battle.CardAction.new(player, "LX_ATTACK")
        action:set_lockout(make_sequence_lockout())
        local spell_list = {}
        local spell_counter = 0
        local counter = 0
        local attacking = false
        local first_press = false
        local second_press = false
        local pressed_shoot = false
        local prev_pressed_shoot = false
        local looped = false
        local isOver = false

        local slash_step = Battle.Step.new()
        local slash_step_first = true

        local spin_step = Battle.Step.new()
        local spin_step_first = true

        local end_step = Battle.Step.new()
        local end_step_first = true

        slash_step.update_func = function()
            if slash_step_first then 
                action:add_anim_action(3, function()
                    spell_counter = spell_counter + 1
                    spell_list[spell_counter] = create_LX_slash(player, player:get_tile(player:get_facing(), 1), player:get_context(), player.overdrive)
                    player:get_field():spawn(spell_list[spell_counter], player:get_tile(player:get_facing(), 1))
                    spell_counter = spell_counter + 1

                    Engine.play_audio(Lx_sounds.slash, AudioPriority.Low)
                end)

                player:get_animation():on_complete(function()
                    slash_step:complete_step()
                    if second_press then 
                        action:add_step(spin_step)
                    end
                end)

                slash_step_first = false
            end

            if player:input_has(Input.Pressed.Shoot) then 
                if not first_press then 
                    first_press = true
                else
                    second_press = true
                    prev_pressed_shoot = true
                end
            end
        end

        spin_step.update_func = function()
            if spin_step_first then 
                player:set_shadow(1)
                player:show_shadow(true)
                player:get_animation():set_state("LX_SPIN_START")
                player:get_animation():refresh(player:sprite())
                player:get_animation():on_complete(function()
                    Engine.play_audio(Lx_sounds.spin, AudioPriority.Low)
                    player:get_animation():set_state("LX_SPIN_LOOP")
                    player:get_animation():refresh(player:sprite())
                    player:get_animation():set_playback(Playback.Loop)
                   
                    -- Every animation loop, I check to see if the player pressed Shoot again 
                        -- during the loop that just finished or the previous loop
                        -- If they pressed Shoot during either of those, the animation will loop again
                    player:get_animation():on_complete(function()
                        if not looped then 
                            if not (prev_pressed_shoot or pressed_shoot) then 
                                isOver = true
                            end
                            prev_pressed_shoot = pressed_shoot
                            pressed_shoot = false
                            looped = true
                        else
                            looped = false
                        end
                    end)
                    attacking = true
                
                end)
                spin_step_first = false
            end

            if player:input_has(Input.Released.Shoot) then 
                pressed_shoot = true
            end

            if attacking then 
                if counter % 13 == 0 then 
                    spell_counter = spell_counter + 1
                    spell_list[spell_counter] = create_LX_spin_slash(player, player:get_tile(player:get_facing(), 1), player:get_context(), player.overdrive, player.combo)
                    player:get_field():spawn(spell_list[spell_counter], player:get_tile(player:get_facing(), 1))
                end
                counter = counter + 1
            end

            if isOver then 
                spin_step:complete_step()
                action:add_step(end_step)

            end

        end

        end_step.update_func = function()
            if end_step_first then 
                player:get_animation():on_complete(function()
                    player:get_animation():set_state("LX_SPIN_END")
                    player:get_animation():refresh(player:sprite())
                    player:get_animation():on_frame(12, function()
                        player:show_shadow(false)
                    end)
                    player:get_animation():on_complete(function()
                        end_step:complete_step()
                    end)
                
                end)
                
                end_step_first = false
            end
        end

        action.execute_func = function()
            action:add_step(slash_step)

        end

        action.action_end_func = function()
            player.combo = false
            player:show_shadow(false)
            if spell_counter > 0 then 
                for i=1, spell_counter, 1
                do
                    if spell_list[i] and not spell_list[i]:is_deleted() then 
                        spell_list[i]:delete()
                    end 
                end
            end
        end
    
        return action
    end


    function create_LX_dragon(user, tile, context)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(user:get_facing())
        local field = player:get_field()
        local has_hit = false
        local end_offset = 3.5
        if spell:get_facing() == Direction.Left then 
            end_offset = end_offset * -1
        end

        local counter = 0

        spell:sprite():set_layer(-1)
        spell:set_texture(Engine.load_texture(_folderpath.."Lx.png"), true)
        spell:get_animation():load(_folderpath.."ZX.animation")
        spell:get_animation():set_state("LX_DRAGON")
        spell:get_animation():refresh(spell:sprite())

        -- 30 to 70, or 50 to 90 damage
        local damage = 20 + user:get_attack_level() * 10
        if user.overdrive then 
            damage = damage+20
        end

        -- 30 to 70 damage
        spell:set_hit_props(
            HitProps.new(
                20 + user:get_attack_level() * 10, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                Element.Aqua, 
                context,
                Drag.None
            )
        )

        spell.update_func = function(self)
            local tile1 = spell:get_current_tile()
            local tile2 = spell:get_tile(Direction.reverse(spell:get_facing()), 1)
           -- local tile3 = spell:get_tile(Direction.reverse(spell:get_facing()), 2)

            tile1:highlight(Highlight.Solid)
            -- These two attacks are set up like this because I want to prevent both attacks from hitting the same panel
                -- counter > 12 starts the second tile's highlight mid-movement, so until the first slide is finished, tile1 and tile2 attack the same tile
            if counter % 2 == 0 and not has_hit then 
                tile1:attack_entities(self)
            end
            if counter > 12 then 
              --  tile2:highlight(Highlight.Solid)
                if counter % 2 == 1 and not has_hit then 
                    tile2:attack_entities(self)
                end
            end

            if self:is_sliding() == false then
                -- Reached the end of the slide and need to get the graphic safely off the screen
                    -- Deleting immediately would be messy. 3.5 is pretty close to the speed it was sliding at
                if self:get_current_tile():is_edge() and self.slide_started then
                    spell:set_offset(spell:get_offset().x+end_offset, 0)
                   -- tile2:highlight(Highlight.Solid)
                    if counter % 2 == 1 and not has_hit then 
                        tile2:attack_entities(self)
                    end
                    
                    spell.update_func = function(self)
                        spell:set_offset(spell:get_offset().x+end_offset, 0)

                        -- TODO: This part also
                            -- But now I guess > -75
                        if (spell:get_facing() == Direction.Left and spell:get_offset().x > -75) or spell:get_offset().x < 75 then 
                           -- tile2:highlight(Highlight.Solid)
                            if counter % 2 == 1 and not has_hit then 
                                tile2:attack_entities(self)
                            end
                        end

                        -- TODO: Find out where this is on the other way
                            -- I guess it should just be -200, since initial offset is 0
                        if (spell:get_facing() == Direction.Left and spell:get_offset().x < -200) or spell:get_offset().x > 200 then 
                            self:erase()
                        end

                    end
                end 
                
                local dest = self:get_tile(spell:get_facing(), 1)
                self:slide(dest, frames(23), frames(0), ActionOrder.Voluntary, 
                    function()
                        self.slide_started = true
                        if spell:get_current_tile():get_state() ~= TileState.Broken then 
                            spell:get_current_tile():set_state(TileState.Ice)
                        end
                        has_hit = false
                    end)
            end

            counter = counter + 1

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function()
            has_hit = true
        end


        spell.can_move_to_func = function()
            return true
        end



        field:spawn(spell, tile)
    end

    function LX_Dragon(player)
        if player.current_trans.energy == 0 then 
            return nil
        end
        local action = Battle.CardAction.new(player, "LX_ATTACK")
        action:set_lockout(make_animation_lockout())

        action.execute_func = function()
            action:add_anim_action(3, function()
                create_LX_dragon(player, player:get_tile(player:get_facing(), 1), player:get_context())
                Engine.play_audio(Lx_sounds.dragon, AudioPriority.Low)
                player.skill_label1:get_animation():set_state("LX_SKILL1_COOLDOWN")
                player.current_trans.cooldown1 = player.current_trans.special_cooldown1

                player.current_trans.energy = math.max(player.current_trans.energy - 5, 0)
                if player.overdrive then 
                    player.current_trans.energy = math.max(player.current_trans.energy - 7, 0)
                end
            
            end)

        end

        action.action_end_func = function()
            player.current_trans.onCooldown1 = true
        end
    
        return action
    end


    function create_LX_ice(user, tile2, context)
        local ice = Battle.Obstacle.new(Team.Other)
        local melting = false

		ice:set_facing(user:get_facing())
        ice:set_name("Ice")
		ice:set_texture(Engine.load_texture(_folderpath.."Lx.png"), true)
		local anim = ice:get_animation()
		anim:load(_modpath.."ZX.animation")
		anim:set_state("LX_ICE")
		anim:refresh(ice:sprite())
		--anim:on_complete(function()
		--	anim:set_state("DEFAULT")
		--	anim:refresh(ice:sprite())
		--	anim:set_playback(Playback.Loop)
		-- end)
        -- 
		ice:set_health(20 + user:get_attack_level() * 10)

        local delete_self = nil
		local spawned_hitbox = false
		local countdown = 6000

        local continue_slide = false
		local prev_tile = {}
		local ice_speed = 4

        local block_drag_damage = true

        local ice_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    
        local function ice_break(ice)
            local iceA = Battle.Artifact.new()
            iceA:sprite():set_layer(-1)
            iceA:set_texture(Engine.load_texture(_folderpath.."Lx.png", true))
           -- iceA:set_offset(offsetX, offsetY)
            iceA:get_animation():load(_folderpath.."ZX.animation")
            iceA:get_animation():set_state("LX_ICE_BREAK_A0")

            iceA:get_animation():refresh(iceA:sprite())

            local iceB = Battle.Artifact.new()
            iceB:sprite():set_layer(-1)
            iceB:set_texture(Engine.load_texture(_folderpath.."Lx.png", true))
          --  iceB:set_offset(offsetX, offsetY)
            iceB:get_animation():load(_folderpath.."ZX.animation")
            iceB:get_animation():set_state("LX_ICE_BREAK_B0")

            iceB:get_animation():refresh(iceB:sprite())
            Engine.play_audio(Lx_sounds.icebreak, AudioPriority.Low)


            local offset_table = {}
            local ice_counter = 1
          --  print("Making math")
            for i=1, 126, 3
            do
                offset_table[ice_counter] = math.floor(((i-60)^2)/75 - 70)
            --    print(offset_table[ice_counter])
                ice_counter = ice_counter+1
            end

            local ice_counterA = 0
            local ice_counterB = 0
            iceA.update_func = function()
                ice_counterA = ice_counterA+1
                if ice_counterA > 42 then 
                    iceA:delete()
                else
                    iceA:set_offset(ice_counterA+20, offset_table[ice_counterA])
                    if ice_counterA % 2 == 0 then 
                        iceA:set_offset(iceA:get_offset().x + 10 + math.floor(ice_counterA/2), offset_table[ice_counterA]-10)
                    end
                    iceA:get_animation():set_state("LX_ICE_BREAK_A"..ice_counterA%2)
                end

            end

            iceB.update_func = function()
                ice_counterB = ice_counterB+1
                if ice_counterB > 42 then 
                    iceB:delete()
                else
                    iceB:set_offset(-1*ice_counterB-20, offset_table[ice_counterB]-10)
                    if ice_counterB % 2 == 0 then 
                        iceB:set_offset(iceB:get_offset().x - 10 - math.floor(15 + ice_counterB/2), offset_table[ice_counterB]-15)
                    end
                    iceB:get_animation():set_state("LX_ICE_BREAK_B"..ice_counterB%2)

                end
            end

            user:get_field():spawn(iceA, ice:get_current_tile())
            user:get_field():spawn(iceB, ice:get_current_tile())

        end

        ice_defense_rule.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()

            if attacker_hit_props.flags & Hit.Drag == Hit.Drag or attacker:get_team() == user:get_team() then
                judge:block_damage()
                ice:slide(ice:get_tile(attacker:get_facing(), 1), frames(ice_speed), frames(0), ActionOrder.Voluntary, function() end)

            end


            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then 
            end

            if attacker_hit_props.element == Element.Fire then 
                ice:get_animation():set_state("LX_ICE_MELT")
                ice:remove_defense_rule(ice_defense_rule)
                ice:toggle_hitbox(false)
                ice:get_animation():on_complete(function()
                    ice:set_health(0)

                end)
                melting = true
            end
            
        end

        -- Adding the defense rule overrides obstacle body, or something, so I need to filter statuses myself
            -- Maybe add confuse too, maybe
        ice_defense_rule.filter_statuses_func = function(statuses)
                statuses.flags = statuses.flags & ~Hit.Freeze
                statuses.flags = statuses.flags & ~Hit.Flash
                statuses.flags = statuses.flags & ~Hit.Flinch
                statuses.flags = statuses.flags & ~Hit.Stun
                statuses.flags = statuses.flags & ~Hit.Blind
                statuses.flags = statuses.flags & ~Hit.Root


            return statuses
        end
        
        ice:add_defense_rule(ice_defense_rule)

        -- 30 to 70 damage
        local props = HitProps.new(
			20 + user:get_attack_level() * 10,
			Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
			Element.Aqua,
			context,
			Drag.None
        )


        ice.collision_func = function(self)
			-- define the hitbox with its props every frame
			local hitbox = Battle.Hitbox.new(ice:get_team())
			hitbox:set_hit_props(props)

			if not spawned_hitbox then
				ice:get_field():spawn(hitbox, ice:get_current_tile())
				spawned_hitbox = true
			end
			ice_break(self)
            self:delete()
		end

        ice.can_move_to_func = function(tile)
            --print("It tried to move")
            -- I stole this part
			if tile then
				-- get a list of every obstacle with Team.Other on the field
				local field = ice:get_field()
				local ice_team = ice:get_team()
				local Other_obstacles = function(obstacle)
					return obstacle:get_team() == ice_team
				end
				local obstacles_here = field:find_obstacles(Other_obstacles)
				local donotmove = false
				-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
				for ii=1,#obstacles_here do
					if tile == obstacles_here[ii]:get_tile() then
						donotmove = true
					end
				end

				if tile:is_edge() or donotmove or not tile:is_walkable() then
					return false
				end
			end
			return true
		end

        ice.update_func = function(self, dt)
			local tile = ice:get_current_tile()
			if not tile then
				ice.delete_func()
			end
			if not tile:is_walkable() or tile:is_edge() then
				ice.delete_func()
			end
			if not delete_self then
				tile:attack_entities(ice)
			end
			local direction = self:get_facing()
			if self:is_sliding() then
				table.insert(prev_tile,1, tile)
				prev_tile[ice_speed+1] = nil
				local target_tile = tile:get_tile(direction, 1)
				if self.can_move_to_func(target_tile) then
					continue_slide = true
				else
					continue_slide = false
				end
			else
				-- become aware of which direction you just moved in, turn to face that direction
				if prev_tile[ice_speed] then
					if prev_tile[ice_speed]:get_tile(direction, 1):x() ~= tile:x() then
						direction = self:get_facing_away()
						self:set_facing(direction)
					end
				end
			end
			if not self:is_sliding() and continue_slide then
				self:slide(self:get_tile(direction, 1), frames(ice_speed), frames(0), ActionOrder.Voluntary, function() end)
			end
			if not melting and self:get_health() <= 0 then
                ice_break(self)
                self:delete()
            end
			if countdown > 0 then 
                countdown = countdown - 1 
            else 
                ice_break(self) 
                self:delete()
            end
			
			-- deletion handler in main loop, starts running once something in here has requested deletion
                -- This part was also stolen but I have absolutely no idea what it does
			if delete_self then
				if type(delete_self) ~= "number" then
					delete_self = 2
				end
				if delete_self > 0 then
					delete_self = delete_self - 1
				elseif delete_self == 0 then
					delete_self = -1
					self:erase()
				end
			end
		end
		ice.delete_func = function(self)
			if type(delete_self) ~= "number" then
				delete_self = true
               -- ice_break(self)
			end
		end
		local query = function(ent)
			return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
		end
        -- This had #user:get_tile(user:get_facing(), 1):find_entities(query) == 0 and   at the start. Removed so I could spawn and hit someone immediately
		if user:get_tile(user:get_facing(), 1):is_walkable() and not user:get_tile(user:get_facing(), 1):is_edge() then
			user:get_field():spawn(ice, user:get_tile(user:get_facing(), 1))
         --   local index = ((user.Lx_ice_count % 2) + 1)
            ice.number = user.Lx_ice_count
            local older_ice = 1
            
            -- I have two slots that can have ice. I'll check if slot 1 is filled. If it is, I check if slot 2 is filled. 
                -- If slot 2 is also filled, then I delete the older ice, indicated by ice.number, then fill that slot
                -- If either slot is empty, I simply place the new ice into there
                -- This should keep a maximum of 2 ice blocks owned by the player at one time
            -- Have to check for is_deleted() because the object is being referenced, so it still exists after deletion
                -- As a result of this, the else statements will only run the first time each slot is filled
                -- Checking if the ice exists is important so that I can short circuit and avoid passing nil to is_deleted()
            if user.Lx_Ice[1] and not user.Lx_Ice[1]:is_deleted() then 
                if user.Lx_Ice[2] and not user.Lx_Ice[2]:is_deleted() then 
                    if user.Lx_Ice[2].number < user.Lx_Ice[1].number then 
                        older_ice = 2
                    end
                    
                    ice_break(user.Lx_Ice[older_ice])
                    user.Lx_Ice[older_ice]:delete()
                    user.Lx_Ice[older_ice] = ice
                else
                    user.Lx_Ice[2] = ice

                end
            else
                user.Lx_Ice[1] = ice
            end

            user.Lx_ice_count = user.Lx_ice_count+1

		end

    end


    function LX_Ice(player)
        local action = Battle.CardAction.new(player, "LX_ATTACK")

        action.execute_func = function()
            action:add_anim_action(3, function()
                create_LX_ice(player, player:get_tile(player:get_facing(), 1), player:get_context())
                Engine.play_audio(Lx_sounds.iceform, AudioPriority.Low)
            
            end)

        end
    
        return action

    end
    
    

    player.normal_attack_func = ZX_Attack

    player.charged_attack_func = ZX_Attack

    -- Delete the labels
    function cleanup(player)
        if player.label_counter > 0 then 
            for i=1, player.label_counter, 1
            do
                player.label_list[i]:erase()
            end
            player.label_counter = 0
        end

    end

    function create_labels(user)
        local model_texture = "model.png"
        local model_animation_path = "model.animation"

        user.label_list[1] = artifact_init(0, -100, model_texture, model_animation_path, -1, "Zx1", user, true)
        user.label_list[2] = artifact_init(66, -50, model_texture, model_animation_path, -1, "Hx1", user, true)
        user.label_list[3] = artifact_init(66, 20, model_texture, model_animation_path, -1, "Fx1", user, true)
        user.label_list[4] = artifact_init(-66, 20, model_texture, model_animation_path, -1, "Px1", user, true)
        user.label_list[5] = artifact_init(-66, -50, model_texture, model_animation_path, -1, "Lx1", user, true)

        user.label_list[1].name = "Zx"
        user.label_list[2].name = "Hx"
        user.label_list[3].name = "Fx"
        user.label_list[4].name = "Px"
        user.label_list[5].name = "Lx"

        user.label_counter = 5
        local current_label = nil

        for i=1, user.label_counter, 1
        do
            current_label = user.label_list[i]
            current_label.brightness = 1
            current_label.selected = false
            current_label.counter = 2
            current_label.prev_selected = false
            current_label.update_func = function(self)
                if self.prev_selected ~= self.selected then 
                    self.counter = 4
                end
                if self.selected then 
                    self.prev_selected = true
                    if self.counter == 0 then 
                        if self.brightness < 3 then 
                            self.brightness = self.brightness + 1
                        end
                        self.counter = 5
                    end
                else
                    self.prev_selected = false
                    if self.counter == 0 then 
                        if self.brightness > 1 then 
                            self.brightness = self.brightness - 1
                        end
                        self.counter = 5
                    end
                end

                self.counter = self.counter - 1
                self:get_animation():set_state(self.name..self.brightness)
            end

            user:get_field():spawn(user.label_list[i], user:get_current_tile())
        end
    
        
    end


    function create_ZX_Slash(user, tile, combo, context)
        local hasHit = false
        local counter = 0
        local spell = Battle.Spell.new(user:get_team())
        spell:highlight_tile(Highlight.Solid)
        spell:set_facing(user:get_facing())


        -- 40 to 80 damage
        local damage = 30 + user:get_attack_level() * 10
        local flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking
        if combo then 
            flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking | Hit.Pierce
        end

        local element = Element.None
        
        local direction = spell:get_facing()
        spell:set_hit_props(
            HitProps.new(
                damage, 
                flags, 
                element, 
                context,
                Drag.None
            )
        )

        spell.update_func = function(self)
            if counter == 8 then 
                self:erase()
            else 
                counter = counter + 1
            end
            if not hasHit then
                spell:get_current_tile():attack_entities(self)
            end

        end

        spell.attack_func = function()
            Engine.play_audio(common_sounds.hit, AudioPriority.Low)
        end

        spell.collision_func = function(self, other) 
            self:erase()
           -- user.combo = true
        end
        spell.can_move_to_func = function(tile)
            return true
        end

        
        return spell

    end
    
    function ZX_Special(player)
        local action = Battle.CardAction.new(player, "ZX_SMASH")
        action:set_lockout(make_animation_lockout())
        local spell = nil

        action.execute_func = function(user)
            local context = user:get_actor():get_context()

            action:add_anim_action(3, function()
                spell = create_ZX_Slash(player, player:get_tile(player:get_facing(), 1), player.combo, context)
                player:get_field():spawn(spell, player:get_tile(player:get_facing(), 1))
                player.combo = false
                Engine.play_audio(Zx_sounds.smash, AudioPriority.Low)
            end)

        end

        action.action_end_func = function()
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
        

        return action
        
    end


    -- Turns overdrive on and handles the sprite node sizing
    function overdrive_toggle(user)
        if not user.overdrive then 

            if user.current_trans.energy > 0 then 
                user.overdrive = true
                user.node:sprite():show()
                Engine.play_audio(common_sounds.pose, AudioPriority.Low)

                
                user.overdrive_component = Battle.Component.new(user, Lifetimes.Battlestep)

                user.overdrive_component.update_func = function()
                
                -- I had this on before but it doesn't seem to affect anything off
                --    user.node:sprite():set_texture(Engine.load_texture(_folderpath..user.current_trans.name.."3.png"), false)
                    user.node:get_animation():refresh(user.node:sprite())


                    user.node:sprite():set_height(user.node:sprite():get_height() + (20 - 5*user.size_change))
                    user.node:sprite():set_width(user.node:sprite():get_width() + (20 - 5*user.size_change))

                    user.size_change = user.size_change - 1
                    if user.size_change == 0 then 
                        user.size_change = 3
                    -- user.node:sprite():set_texture(Engine.load_texture(_folderpath..user.current_trans.."3.png"), false)
                        user.node:sprite():set_texture(Engine.load_texture(_folderpath..user.current_trans.name.."3.png"), false)
                        user.node:sprite():set_width(initial_width)
                        user.node:sprite():set_height(initial_height)

                        user.node:get_animation():refresh(user.node:sprite())

                    end

                end
                user:register_component(user.overdrive_component)
            end
    

        else
            user.overdrive_count = 1
            user.overdrive_component:eject()
            user.overdrive_component = nil
            user.node:sprite():hide()
            user.overdrive = false
        end

    end

end