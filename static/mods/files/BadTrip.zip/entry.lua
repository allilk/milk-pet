local seed = include('seed.lua')
function package_init(package)
    package:declare_package_id("com.mars.card.BadTrip")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'*'})

    local props = package:get_card_props()
    props.shortname = "BadTrip"
    props.damage = 10
    props.can_boost = false
    props.time_freeze = false
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Take you for a ride!"
    props.limit = 1
end

local panel_type = {
    -- null types
    [1] = TileState.Normal,
    [2] = TileState.Cracked,
    [3] = TileState.Broken,
    -- element types
    [4] = TileState.Ice,
    [5] = TileState.Grass,
    [6] = TileState.Lava,
    [7] = TileState.Poison,
    [8] = TileState.Holy,
    [9] = TileState.Volcano,
    -- conveyors
    [10] = TileState.DirectionDown,
    [11] = TileState.DirectionUp,
    [12] = TileState.DirectionLeft,
    [13] = TileState.DirectionRight,
    -- permahole 
    [14] = TileState.Empty,
    -- invisible permahole
    [15] = TileState.Hidden,
    -- cursed and evil "chaotic randomness" option
    [16] = 15,
}

-- set the panel type here, this will be the type of panel it creates
seed.panel_type = panel_type[16] -- <-- change this number

seed.card_props = props
card_create_action = seed.card_create_action
