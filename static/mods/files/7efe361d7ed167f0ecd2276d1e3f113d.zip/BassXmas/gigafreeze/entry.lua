local AUDIO = nil
local BUSTER_AUDIO = nil
local BUSTER_TEXTURE = nil
local ATTACK_TEXTURE = nil

AUDIO = Engine.load_audio(_folderpath .. "blizzard.ogg")
BUSTER_TEXTURE = Engine.load_texture(_folderpath .. "gregar.png")
ATTACK_TEXTURE = Engine.load_texture(_folderpath .. "attack.png")


local chip = {}

local chrg = { 1, 0.6 }
local frame1 = { 1, 0.04 }
local frame2 = { 1, 0.05 }
local frame3 = { 1, 0.06 }
local frame4 = { 1, 0.04 }
local endframe = { 1, 0.6 }
local frame_data = make_frame_data({ chrg,
    frame1, frame2, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4, frame3, frame4,
    frame3, frame4, endframe
})

chip.execute = function(character, props)
    character:card_action_event(chip.card_create_action(character, props), ActionOrder.Immediate)
end

chip.card_create_action = function(character, props)
    print("in create_card_action()!")

    local action = Battle.CardAction.new(character, "GREGARBREATH")
    action:override_animation_frames(frame_data)
    action:set_lockout(make_animation_lockout())
    local warning_component = Battle.Component.new(character, Lifetimes.Battlestep)
    action.execute_func = function(self, user)
        local actor = self:get_actor()
        character.cape_anim:set_state("GREGAR_BREATH_CAPE")
        character.cape_anim:set_playback(Playback.Loop)
        character.hat_anim:set_state("GREGAR_BREATH")
        local elec_2 = nil
        local elec_3 = nil
        local elec_4 = nil

        if user:get_facing() == Direction.Right then
            elec_2 = Direction.UpRight
            elec_3 = Direction.Right
            elec_4 = Direction.DownRight
        elseif user:get_facing() == Direction.Left then
            elec_2 = Direction.UpLeft
            elec_3 = Direction.Left
            elec_4 = Direction.DownLeft
        end



        local field = user:get_field()
        local tile = user:get_tile(user:get_facing(), 1)
        local tile2 = tile:get_tile(elec_2, 1)
        local tile3 = tile:get_tile(elec_3, 1)
        local tile4 = tile:get_tile(elec_4, 1)

        local tile5 = tile3:get_tile(elec_2, 1)
        local tile6 = tile3:get_tile(elec_3, 1)
        local tile7 = tile3:get_tile(elec_4, 1)

        warning_component.update_func = function(self)
            tile:highlight(Highlight.Solid)
            tile2:highlight(Highlight.Solid)
            tile3:highlight(Highlight.Solid)
            tile4:highlight(Highlight.Solid)
            tile5:highlight(Highlight.Solid)
            tile6:highlight(Highlight.Solid)
            tile7:highlight(Highlight.Solid)

        end
        user:register_component(warning_component)
        self.elec1 = create_attack(user, props)
        self.elec2 = create_attack(user, props)
        self.elec3 = create_attack(user, props)
        self.elec4 = create_attack(user, props)
        self.elec5 = create_attack(user, props)
        self.elec6 = create_attack(user, props)
        self.elec7 = create_attack(user, props)

        local point = user:get_animation():point("BUSTER")
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster_sprite)

        self:add_anim_action(1, function()
            buster_sprite:set_texture(BUSTER_TEXTURE, true)
            buster_sprite:set_layer(-2)

            buster_anim:load(_folderpath .. "gregar.animation", true)
            buster_anim:set_state("DEFAULT")
            buster_anim:refresh(buster_sprite)
            --Engine.play_audio(BUSTER_AUDIO, AudioPriority.High)
        end)
        self:add_anim_action(2, function()
            warning_component:eject()
            warning_component = nil
            character:toggle_counter(true)
        end)

        self:add_anim_action(3, function()

            if not tile:is_edge() and tile:get_state() ~= TileState.Broken and tile:get_state() ~= TileState.Empty then
                field:spawn(self.elec1, tile)
                Engine.play_audio(AUDIO, AudioPriority.High)
            end
        end)

        self:add_anim_action(5, function()
            character:toggle_counter(false)
            if self.elec1.has_spawned then
                self.elec1:get_animation():on_frame(8, function()
                    if not tile3:is_edge() and tile3:get_state() ~= TileState.Broken and
                        tile3:get_state() ~= TileState.Empty then
                        field:spawn(self.elec3, tile3)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                    if not tile2:is_edge() and tile2:get_state() ~= TileState.Broken and
                        tile2:get_state() ~= TileState.Empty then
                        field:spawn(self.elec2, tile2)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                    if not tile4:is_edge() and tile4:get_state() ~= TileState.Broken and
                        tile4:get_state() ~= TileState.Empty then
                        field:spawn(self.elec4, tile4)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                end)
            end
        end)
        self:add_anim_action(12, function()
            if self.elec3.has_spawned then
                self.elec3:get_animation():on_frame(8, function()
                    if not tile5:is_edge() and tile5:get_state() ~= TileState.Broken and
                        tile5:get_state() ~= TileState.Empty then
                        field:spawn(self.elec5, tile5)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                    if not tile6:is_edge() and tile6:get_state() ~= TileState.Broken and
                        tile6:get_state() ~= TileState.Empty then
                        field:spawn(self.elec6, tile6)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                    if not tile7:is_edge() and tile7:get_state() ~= TileState.Broken and
                        tile7:get_state() ~= TileState.Empty then
                        field:spawn(self.elec7, tile7)
                        --Engine.play_audio(AUDIO, AudioPriority.High)
                    end
                end)
            end
        end)
    end
    action.action_end_func = function()
        if (warning_component ~= nil) then
            warning_component:eject()
        end
        character:idle()
        character.set_current_action(character.action_wait_cooldown)
    end
    return action
end

function create_attack(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_texture(ATTACK_TEXTURE, true)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Aqua,
            user:get_context(),
            Drag.None
        )
    )
    local anim = spell:get_animation()
    anim:load(_folderpath .. "attack.animation")
    anim:set_state("ATTACK")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-1)

    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if tile:is_walkable() then
            tile:set_state(TileState.Ice)
        end
    end

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    --Engine.play_audio(Engine.load_audio(_folderpath.."elecshock.ogg"), AudioPriority.High)
    return spell
end

return chip
