-- Imports
---@type EnemyUtils
local enemy_utils = include("lib/enemy_utils.lua")

---@type BusterRake
local buster_rake = include("spells/buster_rake.lua")

---@type Lifesword
local life_sword = include("lifesword/entry.lua")

---@type HellzRolling
local hellz_rolling = include("hellzrolling/entry.lua")

---@type TankCannon
local tank_cannon = include("tankcannon/entry.lua")

local gigafreeze = include("gigafreeze/entry.lua")

---@type BattleHelpers
local battle_helpers = include("lib/battle_helpers.lua")

-- Animations, Textures and Sounds
local CHARACTER_ANIMATION = _folderpath .. "bass.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "bass.png")

local attacks = { BusterRake = 1, DarkSword = 2, HellzRolling = 3, TankCannon = 4, GigaFreeze = 5 }

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Set up character meta
    self:set_name(character_info.name)
    self.name = character_info.name
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = (character_info.damage)
    self:set_element(character_info.element)
    self:set_explosion_behavior(4, 1, false)
    self:show_shadow(true)
    self:set_air_shoe(true)
    self:set_float_shoe(true)
    self.air_shoe = true
    self.animation:set_state("SPAWN")
    self.move_speed = character_info.move_speed
    self.pause_frames = character_info.pause_frames
    self.move_for_attack_speed = character_info.move_for_attack_speed
    self.move_index = 1


    --cape node
    self.capeNode = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.capeNode:set_texture(Engine.load_texture(_folderpath .. "bass_fx.png")) --Just set their texture...
    self.cape_anim = Engine.Animation.new(_folderpath .. "bass_fx.animation") --And they have no get_animation, so we create one...
    self.capeNode:set_layer(-1) --Set their layer, they're already a sprite...
    self.cape_anim:set_state("SPAWN_CAPE")
    self.cape_anim:refresh(self.capeNode)
    self.cape_anim:set_playback(Playback.Loop)
    self.capeNode:enable_parent_shader(true)

    --hat node
    self.hatNode = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.hatNode:set_texture(Engine.load_texture(_folderpath .. "hat.png")) --Just set their texture...
    self.hat_anim = Engine.Animation.new(_folderpath .. "hat.animation") --And they have no get_animation, so we create one...
    self.hatNode:set_layer(-1) --Set their layer, they're already a sprite...
    self.hat_anim:set_state("HAT")
    self.hat_anim:refresh(self.hatNode)
    self.hat_anim:set_playback(Playback.Loop)
    self.hatNode:enable_parent_shader(true)

    self.battle_start_func = function()
        longswords = 0
    end

    self:register_status_callback(Hit.Flinch, function()
        self.set_anim_states("HURT")
        self.old_frames = self.frame_counter - 10
        self.animation:on_complete(function()
            self.idle()
            self.frame_counter = self.old_frames
            if (self.current_action == self.action_wait) then
                self.set_current_action(self.action_move)
            end
        end)
        self.frame_counter = -40
    end)

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)

    end
    self:register_component(self.animate_component)

    self.update_hook = function(dt)
        ref.cape_anim:update(dt, ref.capeNode)
        ref.hat_anim:update(dt, ref.hatNode)
    end


    self.action_move = enemy_utils.slide_at_random_bass(self, 1, self.move_speed, self.pause_frames, pick_random_attack,
        Engine.load_texture(_folderpath .. "bass_AI.png"),
        _folderpath .. "bass_AI.animation", battle_helpers.getRandomTile)

    self.position_any = enemy_utils.slide_at_random_bass(self, 0, self.move_for_attack_speed, self.pause_frames / 2,
        action_attack,
        Engine.load_texture(_folderpath .. "bass_AI.png"),
        _folderpath .. "bass_AI.animation", battle_helpers.getRandomTile)

    self.position_front = enemy_utils.slide_at_random_bass(self, 0, self.move_for_attack_speed, self.pause_frames / 2,
        action_attack,
        Engine.load_texture(_folderpath .. "bass_AI.png"),
        _folderpath .. "bass_AI.animation", battle_helpers.select_front_center_tile)

    self.position_back = enemy_utils.slide_at_random_bass(self, 0, self.move_for_attack_speed, self.pause_frames / 2,
        action_attack,
        Engine.load_texture(_folderpath .. "bass_AI.png"),
        _folderpath .. "bass_AI.animation", battle_helpers.select_back_center_tile)

    self.action_wait = enemy_utils.wait

    self.action_wait_cooldown = enemy_utils.wait_for_frames(self, 40, function()
        self.idle()
        self.set_current_action(self.action_move)
    end)

    self.set_anim_states = function(state)
        self.animation:set_state(state)
        self.cape_anim:set_state(state .. "_CAPE")
        self.hat_anim:set_state(state)
    end
    self.idle = function()
        self.animation:set_state("IDLE")
        self.cape_anim:set_state("IDLE_CAPE")
        self.hat_anim:set_state("IDLE")
        self.hat_anim:set_playback(Playback.Loop)
        self.cape_anim:set_playback(Playback.Loop)
        self.animation:set_playback(Playback.Loop)
    end

    enemy_utils.use_enemy_framework(self)
    self.init_func = function()
        self.set_current_action(self.action_move)
        self.idle()
    end
end

function position_for_attack(ent, next_attack)
    if (next_attack == attacks.DarkSword or next_attack == attacks.GigaFreeze) then
        ent.set_current_action(ent.position_front)
    elseif (next_attack == attacks.HellzRolling) then
        ent.set_current_action(ent.position_back)
    else
        ent.set_current_action(ent.position_any)
    end
    ent.next_attack = next_attack
end

local movepool = { attacks.BusterRake, attacks.BusterRake, attacks.DarkSword, attacks.HellzRolling, attacks.HellzRolling,
    attacks.TankCannon, attacks.GigaFreeze }

function pick_random_attack(character)
    character.move_index = character.move_index + 1
    if (character.move_index > #movepool) then
        shuffle(movepool)
        character.move_index = 1
    end
    local next_move = movepool[character.move_index]


    position_for_attack(character, next_move)
end

--shuffle function to provide some randomness
function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

function action_attack(character)
    character.jumps = 3
    character.set_current_action(character.action_wait)
    local action = nil
    local props = {}

    if (character.next_attack == attacks.BusterRake) then
        action = buster_rake.card_create_action
        props.damage = character.damage.rake
    elseif (character.next_attack == attacks.HellzRolling) then
        props.damage = character.damage.rolling
        action = hellz_rolling.card_create_action
    elseif (character.next_attack == attacks.TankCannon) then
        props.damage = character.damage.tank_cannon
        action = tank_cannon.execute
    elseif (character.next_attack == attacks.GigaFreeze) then
        props.damage = character.damage.breath
        action = gigafreeze.execute
    else
        props.damage = character.damage.lifesword
        props.element = Element.Aqua
        action = life_sword.execute
    end
    action(character, props)
end

return package_init
