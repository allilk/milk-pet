local RAKE_TEXTURE = Engine.load_texture(_folderpath .. "burst.png")
local BUSTER_FX = Engine.load_texture(_folderpath .. "buster_fx.png")
local BUSTER_FX_ANIM = _folderpath .. "buster_fx.animation"
local RAKE_ANIMATION = _folderpath .. "burst.animation"
local AUDIO_BUSTERRAKE = Engine.load_audio(_folderpath .. "BusterRake.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_folderpath .. "hitsound.ogg")

---@class BusterRake
local chip = {}

local grass_tint = Color.new(28, 147, 32, 255)
local poison_tint = Color.new(102, 19, 128, 255)
local ice_tint = Color.new(96, 255, 247, 255)
local fire_tint = Color.new(174, 0, 0, 255)

local tints = { grass_tint, poison_tint, ice_tint, fire_tint }


chip.card_create_action = function(user, props)
    print("in create_card_action()!")
    user.set_anim_states("START_RAKE")
    user.animation:on_frame(1, function()
        user:toggle_counter(true)
    end)
    local field = user:get_field()
    local center_tile = nil
    local targeted_tiles = {}
    user.rake_index = 1
    if (user:get_facing() == Direction.Right) then
        center_tile = field:tile_at(5, 2)
    else
        center_tile = field:tile_at(2, 2)
    end

    add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
        center_tile:get_tile(Direction.UpLeft, 1),
        center_tile:get_tile(Direction.Left, 1),
        center_tile:get_tile(Direction.DownLeft, 1))
    add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
        center_tile:get_tile(Direction.Up, 1),
        center_tile,
        center_tile:get_tile(Direction.Down, 1))
    add_targeted_row(user:get_team(), user:get_tile():x(), user:get_facing(), targeted_tiles,
        center_tile:get_tile(Direction.UpRight, 1),
        center_tile:get_tile(Direction.Right, 1),
        center_tile:get_tile(Direction.DownRight, 1))
    shuffle(targeted_tiles)

    -- base speed = 4
    local speed = 4
    if (user:get_rank() == Rank.NM) then
        speed = 2
    end

    user.buster_count = 0
    user.animation:on_complete(function()
        user.set_anim_states("BUSTER_RAKE")
        user.animation:on_frame(2, function()
            user:toggle_counter(false)
        end)
        user.animation:set_playback(Playback.Loop)
        user.cape_anim:set_playback(Playback.Loop)
        user.rounds = 0
        user.animation:on_complete(function()
            user.buster_count = user.buster_count + 1
            if (user.buster_count % speed == 0) then
                Engine.play_audio(AUDIO_BUSTERRAKE, AudioPriority.Highest)
            end
            if (user.buster_count % speed == 0) then
                fire_buster_rake(user, targeted_tiles, props.damage)
                user.rounds = user.rounds + 1
                user.buster_count = 0
                if (user.rounds == 7) then
                    user.idle()
                    user.set_current_action(user.action_wait_cooldown)
                end
            end
        end)
    end)
end

function fire_buster_rake(character, targeted_tiles, damage)
    create_buster_rake(character, targeted_tiles[character.rake_index], damage)
    character.rake_index = character.rake_index + 1
    if (character.rake_index > #targeted_tiles) then
        character.rake_index = 1
    end
    create_buster_rake(character, targeted_tiles[character.rake_index], damage)
    character.rake_index = character.rake_index + 1
    if (character.rake_index > #targeted_tiles) then
        character.rake_index = 1
    end
    --this is an effect shown on bass
    local buster_fx = Battle.Artifact.new()
    buster_fx:set_texture(BUSTER_FX)
    local buster_fx_anim = buster_fx:get_animation()
    local fx_offset = 15
    if (character:get_facing() == Direction.Left) then
        fx_offset = -fx_offset
    end
    buster_fx:set_offset(fx_offset + math.random(-8, 8), -54 + math.random(-15, 15))
    buster_fx_anim:load(BUSTER_FX_ANIM)
    buster_fx_anim:set_state("DEFAULT")
    buster_fx:sprite():set_layer(-2)
    buster_fx_anim:on_complete(function()
        buster_fx:erase()
    end)
    buster_fx_anim:refresh(buster_fx:sprite())
    character:get_field():spawn(buster_fx, character:get_tile())
end

function add_targeted_row(team, userX, facing, targeted_tiles, tile1, tile2, tile3)
    if (facing == Direction.Right) then
        if (userX >= tile1:x()) then
            return -- bass does not target his own row or any rows to the left
        end
    else
        if (userX <= tile1:x()) then
            return -- bass does not target his own row or any rows to the left
        end
    end
    if (tile1:get_team() ~= team or tile2:get_team() ~= team or tile3:get_team() ~= team) then
        targeted_tiles[#targeted_tiles + 1] = tile1
        targeted_tiles[#targeted_tiles + 1] = tile2
        targeted_tiles[#targeted_tiles + 1] = tile3
    else
        return
    end

end

function create_buster_rake(owner, tile, damage)
    local spell = Battle.Spell.new(owner:get_team())
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            owner:get_context(),
            Drag.None
        )
    )
    local do_once = true
    local field = owner:get_field()
    local flash_before_strike = 10

    spell.update_func = function(self, dt)
        if flash_before_strike <= 0 then
            if do_once then
                do_once = false
                if (not self:get_tile():is_hole()) then

                    local blast_fx = Battle.Spell.new(spell:get_team())
                    blast_fx:set_texture(RAKE_TEXTURE)
                    local blast_anim = blast_fx:get_animation()
                    local tint = tints[math.random(#tints)]

                    blast_anim:load(RAKE_ANIMATION)
                    blast_anim:set_state("DEFAULT")
                    blast_anim:on_frame(3, function()
                        spell:get_current_tile():attack_entities(spell)
                    end)
                    blast_fx:sprite():set_layer(-2)
                    blast_fx.update_func = function()
                        blast_fx:sprite():set_color_mode(ColorMode.Multiply)
                        blast_fx:sprite():set_color(tint)
                    end
                    field:spawn(blast_fx, self:get_tile())
                    blast_anim:on_complete(function()
                        blast_fx:erase()
                        self:erase()
                    end)

                else
                    self:erase()
                end
            end
        else
            flash_before_strike = flash_before_strike - 1
        end
    end
    spell.attack_func = function(self, other)
        if (not self:get_tile():is_hole()) then
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        end
    end

    field:spawn(spell, tile)
end

--shuffle function to provide some randomness
function shuffle(tbl)
    for i = #tbl, 2, -1 do
        local j = math.random(i)
        tbl[i], tbl[j] = tbl[j], tbl[i]
    end
    return tbl
end

return chip
