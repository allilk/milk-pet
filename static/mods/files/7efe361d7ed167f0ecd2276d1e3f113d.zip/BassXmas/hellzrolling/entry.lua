local AUDIO_SHOOT = Engine.load_audio(_folderpath .. "HellzRolling.ogg")
local HIT_SOUND = Engine.load_audio(_folderpath .. "hitsound.ogg")

local RING = Engine.load_texture(_folderpath .. "ring.png")
local RING_ANIM = _folderpath .. "ring.animation"

---@class HellzRolling
local chip = {}

chip.card_create_action = function(user, props)
    print("in create_card_action()!")
    user.set_anim_states("CHARGE_WHEEL")
    user.animation:on_complete(function()
        user.set_anim_states("SPELL")
        user.animation:on_frame(1, function()
            user:toggle_counter(true)
        end)
        user.animation:on_complete(function()
            user:toggle_counter(false)
            create_ring(user, user:get_tile(Direction.Up, 1), props)
            create_ring(user, user:get_tile(Direction.Down, 1), props)
            user.idle()
            user.set_current_action(user.action_wait_cooldown)
        end)
    end)
end

---@param owner Entity
function create_ring(owner, start_tile, props)
    local team = owner:get_team()
    local field = owner:get_field()
    local direction = owner:get_facing()
    local speed = 8
    Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
    ---@type Spell
    local spell = Battle.Spell.new(team)
    spell.starttile = start_tile
    spell:set_facing(owner:get_facing())
    spell:set_hit_props(HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flash,
        Element.Aqua,
        owner:get_context(),
        Drag.new()
    ))

    local spell_animation = spell:get_animation()
    spell:set_facing(owner:get_facing())
    spell_animation:load(RING_ANIM)
    spell_animation:set_state("DEFAULT")
    spell_animation:set_playback(Playback.Loop)
    spell:set_texture(RING)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-2)

    local has_enemies = function(tile, spell)

        local occupants = tile:find_characters(function(ent)
            if (ent:get_team() ~= spell:get_team()) then
                return true
            end
            return false
        end)
        if (#occupants >= 1) then
            return true
        end
    end

    local get_next_tile = function(spell)
        local tile1 = spell:get_tile(spell:get_facing(), 1)
        if (has_enemies(tile1, spell)) then return tile1 end
        local tile2 = spell:get_tile(Direction.join(spell:get_facing(), Direction.Down), 1)
        if (has_enemies(tile2, spell)) then return tile2 end
        local tile3 = spell:get_tile(Direction.join(spell:get_facing(), Direction.Up), 1)
        if (has_enemies(tile3, spell)) then return tile3 end
        return tile1
    end

    spell.update_func = function()

        if not (spell:is_sliding()) then
            local next_tile = get_next_tile(spell)
            if (next_tile:is_edge() or (not next_tile:is_walkable())) then
                spell:erase()
            end
            spell:slide(next_tile, frames(speed), frames(0), ActionOrder.Immediate)
        end
        spell:get_current_tile():attack_entities(spell)
        spell:get_current_tile():highlight(Highlight.Solid)
    end

    spell.can_move_to_func = function(self)
        return true
    end

    spell.collision_func = function(self, other)

    end

    spell.attack_func = function()
        create_hit_effect(field, spell:get_current_tile())
    end

    field:spawn(spell, spell.starttile)

    function tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end


end

function create_hit_effect(field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(Engine.load_texture(_folderpath .. "effect.png"), true)
    hitfx:set_offset(math.random(-10, 10), math.random(-10, 10))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(_folderpath .. "effect.animation")
    hitfx_anim:set_state("AQUA")
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(HIT_SOUND, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return chip
