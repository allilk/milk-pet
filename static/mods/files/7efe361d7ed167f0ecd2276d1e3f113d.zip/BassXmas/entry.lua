local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "Bass",
        hp = 1800,
        damage = {
            rake = 60,
            rolling = 100,
            tank_cannon = 150,
            lifesword = 200,
            breath = 200,
        },
        height = 44,
        move_speed = 30,
        move_for_attack_speed = 20,
        pause_frames = 35,

        element = Element.None,
    }

    if character:get_rank() == Rank.EX then
        character_info.hp = 2700
        character_info.damage.rake = 150
        character_info.damage.rolling = 150
        character_info.damage.tank_cannon = 220
        character_info.lifesword = 250
        character_info.breath = 300
        character_info.move_speed = 25
        character_info.move_for_attack_speed = 15
        character_info.pause_frames = 25
    end

    if character:get_rank() == Rank.SP then
        character_info.hp = 3400
        character_info.damage.rake = 260
        character_info.damage.rolling = 220
        character_info.damage.tank_cannon = 330
        character_info.damage.lifesword = 450
        character_info.damage.breath = 550
        character_info.move_speed = 20
        character_info.move_for_attack_speed = 10
        character_info.pause_frames = 20
    end

    if character:get_rank() == Rank.NM then
        character_info.hp = 5000
        character_info.damage.rake = 400
        character_info.damage.rolling = 300
        character_info.damage.tank_cannon = 500
        character_info.damage.lifesword = 800
        character_info.damage.breath = 1000
        character_info.move_speed = 16
        character_info.move_for_attack_speed = 8
        character_info.pause_frames = 10
    end


    shared_package_init(character, character_info)
end
