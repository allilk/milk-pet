local SLASH_TEXTURE = Engine.load_texture(_folderpath .. "spell_darksword.png")
local BLADE_TEXTURE = Engine.load_texture(_folderpath .. "spell_sword_blades.png")
local AUDIO = Engine.load_audio(_folderpath .. "sfx.ogg")

function package_init(package)
	package:declare_package_id("com.claris.lifesrd")
	package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
	package:set_codes({ 'Z' })

	local props = package:get_card_props()

end

---@class Lifesword
local chip = {}

chip.execute = function(character, props)
	character:card_action_event(chip.card_create_action(character, props), ActionOrder.Immediate)
end

chip.card_create_action = function(actor, inputprops)
	local props = {}
	props.shortname = "LifeSword"
	props.damage = inputprops.damage
	props.time_freeze = false
	props.element = inputprops.element
	props.description = "3x2 Slash!"
	props.card_class = CardClass.Mega
	props.limit = 1
	props.long_description = "Slashes 3x2."
	props.can_boost = false

	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "SWORD")
	local warning_component = Battle.Component.new(actor, Lifetimes.Battlestep)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		actor.cape_anim:set_state("SWORD_CAPE")
		actor.hat_anim:set_state("SWORD")
		self:add_anim_action(1, function()

			local tile = user:get_tile(user:get_facing(), 1)
			local tile_next = tile:get_tile(user:get_facing(), 1)
			local tile_up = tile:get_tile(Direction.Up, 1)
			local tile_down = tile:get_tile(Direction.Down, 1)
			local tile_up_next = tile:get_tile(Direction.join(user:get_facing(), Direction.Up), 1)
			local tile_down_next = tile:get_tile(Direction.join(user:get_facing(), Direction.Down), 1)

			warning_component.update_func = function(self)
				tile:highlight(Highlight.Flash)
				tile_next:highlight(Highlight.Flash)
				tile_up:highlight(Highlight.Flash)
				tile_down:highlight(Highlight.Flash)
				tile_up_next:highlight(Highlight.Flash)
				tile_down_next:highlight(Highlight.Flash)
			end
			user:register_component(warning_component)
		end)
		self:add_anim_action(2,
			function()
				user:toggle_counter(true)
				local hilt = self:add_attachment("HILT")
				local hilt_sprite = hilt:sprite()
				hilt_sprite:set_texture(actor:get_texture())
				hilt_sprite:set_layer(-2)
				hilt_sprite:enable_parent_shader(true)

				local hilt_anim = hilt:get_animation()
				hilt_anim:copy_from(actor:get_animation())
				hilt_anim:set_state("HILT")

				local blade = hilt:add_attachment("ENDPOINT")
				local blade_sprite = blade:sprite()
				blade_sprite:set_texture(BLADE_TEXTURE)
				blade_sprite:set_layer(-1)

				local blade_anim = blade:get_animation()
				blade_anim:load(_folderpath .. "spell_sword_blades.animation")
				blade_anim:set_state("DEFAULT")
			end
		)

		self:add_anim_action(3, function()
			local sword = create_slash(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			local fx = Battle.Spell.new(user:get_team())
			local field = user:get_field()
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(SLASH_TEXTURE, true)
			anim:load(_folderpath .. "spell_darksword.animation")
			anim:set_state("DEFAULT")
			anim:on_complete(function()
				fx:erase()
				if not sword:is_deleted() then sword:delete() end
			end)
			field:spawn(sword, tile)
			field:spawn(fx, tile)
			warning_component:eject()
			warning_component = nil
		end)
	end
	action.action_end_func = function()
		actor:toggle_counter(false)
		if (warning_component ~= nil) then
			warning_component:eject()
		end
		actor.idle()
		actor.set_current_action(actor.action_wait_cooldown)
	end
	return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = user:get_field()
	spell.timer = 2
	spell.update_func = function(self, dt)
		if not self:is_deleted() and self.timer <= 0 then self:delete() return end
		self.timer = self.timer - 1

		local tile = user:get_tile(user:get_facing(), 1)
		local tile_next = tile:get_tile(user:get_facing(), 1)
		local tile_up = tile:get_tile(Direction.Up, 1)
		local tile_down = tile:get_tile(Direction.Down, 1)
		local tile_up_next = tile:get_tile(Direction.join(user:get_facing(), Direction.Up), 1)
		local tile_down_next = tile:get_tile(Direction.join(user:get_facing(), Direction.Down), 1)

		if attack_once then
			if tile_next then
				local hitbox_r = Battle.Hitbox.new(user:get_team())
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile_next)
			end
			if tile_up then
				local hitbox_u = Battle.Hitbox.new(user:get_team())
				hitbox_u:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_u, tile_up)
			end
			if tile_down then
				local hitbox_d = Battle.Hitbox.new(user:get_team())
				hitbox_d:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_d, tile_down)
			end
			if tile_up_next then
				local hitbox_ur = Battle.Hitbox.new(user:get_team())
				hitbox_ur:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_ur, tile_up_next)
			end
			if tile_down_next then
				local hitbox_dl = Battle.Hitbox.new(user:get_team())
				hitbox_dl:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_dl, tile_down_next)
			end
			tile:attack_entities(self)
			attack_once = false
		end
	end
	spell.collision_func = function(self, other)
		if not self:is_deleted() then self:delete() end
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

return chip
