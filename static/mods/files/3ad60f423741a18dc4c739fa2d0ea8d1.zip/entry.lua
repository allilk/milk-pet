function package_init(package)
    package:declare_package_id("com.alrysc.player.Yuki")
    package:set_special_description("Mai's navi!")
  --  package:set_speed(1.0)
    package:set_attack(1)
   -- package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
 --   package:set_icon_texture(Engine.load_texture(_modpath.."NormalNavi_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
  --  package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Yuki")
    player:set_health(1000)
    player:set_element(Element.Fire)
    player:set_height(58.0)

    local base_texture = Engine.load_texture(_modpath.."yuki.png")
    local base_animation_path = _modpath.."yuki.animation"

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -23)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        fire_projectile = Engine.load_audio(_modpath.."FireProjectile.ogg"),
        apollo = Engine.load_audio(_modpath.."ApolloSoul.ogg"),
        spin = Engine.load_audio(_modpath.."Spin.ogg")
    }
    

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()
    
        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())
    
        end
    
        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(texture, false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(animation)
    
        anim:set_state(state)
        anim:refresh(graphic:sprite())
    
        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end
    
        return graphic
    end

    


    local function normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    


    local function create_fire_shot(self)
        local field = self:get_field()
        local spell = graphic_init("spell", 0, 0, base_texture, base_animation_path, -4, "FIRE1", self, self:get_facing())
        spell:get_animation():on_complete(function()
            spell:get_animation():set_state("FIRE1_LOOP")
            spell:get_animation():refresh(spell:sprite())
            spell:get_animation():set_playback(Playback.Loop)
            spell.start_moving = true
        end)
        local facing = self:get_facing()
    
        local damage = 10 + self:get_attack_level() * 20
        if self.apollo_active then 
            damage = damage + 30
        end
        local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch,
                Element.Fire, 
                self:get_context(), 
                Drag.None
            )
    
        spell:set_hit_props(hit_props)
    
        local speed = 6
        if self.apollo_active then 
            speed = 4
        end
        spell.update_func = function(self, dt)
            if not self.start_moving then 
                return 
            end
            self:get_tile():attack_entities(self)
            spell:get_current_tile():highlight(Highlight.Solid)
    
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
    
                end 
                
                local dest = self:get_tile(facing, 1)
                local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end
            
        end
    
        spell.attack_func = function()
            Engine.play_audio(self.sounds.hit, AudioPriority.Low)
            
        end
    
    
        spell.collision_func = function()
            local hit_effect = graphic_init("artifact", 0, 0, base_texture, base_animation_path, -4, "FIRE1_HIT", self, spell:get_facing(), true)
            field:spawn(hit_effect, spell:get_current_tile())
            spell:delete()
        end
    
        spell.can_move_to_func = function()
            return true
        end
    
       -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
        local tile = self:get_tile(facing, 1)
    
        if tile then 
            field:spawn(spell, tile)
        end

        return spell
    end

    local function can_slide_to(self, tile)
        if not tile:is_walkable() then 
            return false
        end

        if tile:get_team() ~= Team.Other and tile:get_team() ~= self:get_team() then 
            return false
        end

        local list = tile:find_characters(function(c)
            return c:get_id() ~= self:get_id()
        end)

        if #list > 0 then 
            return false
        end

        list = tile:find_obstacles(function(o)
            return o:get_health() > 0
        end)

        return #list < 1
    end

    local function move_slide(self, direction, time, anim, action)
        time = time or nil
        self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
        local startPosition = 0
        local target = -50
        if direction == Direction.Down then 
            target = target * -1
        end
        local moveTime = 18
        if time then 
            moveTime = time
        end
        local elapsedMoveTime = 0
        local delta = 0
    
        local interp = 0
        local tileOffset = 0 
        local t = self:get_tile(direction, 1);
        self.slide_dest = t
        self.dest_tile_backup = self.slide_dest
        self.orig_tile = self:get_current_tile()
        t:reserve_entity_by_id(self:get_id())
    
        local moved = false;
        local already_moved = false;
        
        anim:on_interrupt(function()
            if not self.slide_component then return end
            self.slide_component:eject()
            self.slide_component = nil
            t:add_entity(self)
            self.orig_tile:remove_entity_by_id(self:get_id())
            self:set_offset(0, 0)

        end)

        self.slide_component.update_func = function()
            if delta >= 0.5 and not moved then 
                target = 0
            end
            
            delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
            interp =  target * delta + (startPosition * (1 - delta))
            
            tileOffset = interp - startPosition
            if delta >= 0.5 then
                tileOffset = -1*target + startPosition + tileOffset
            end
    
            if not already_moved then 
                t:reserve_entity_by_id(self:get_id())
            end
    
            -- Offsets are reflected a frame later than they're set
                -- So this moves us a frame later than we set an offset 
                -- for the new panel
            if moved and not already_moved then 
                already_moved = true
                start_tile = self:get_current_tile()
                start_tile:get_tile(direction, 1):add_entity(self)
                start_tile:remove_entity_by_id(self:get_id())
                self.slide_dest = nil
            end
    
            if delta >=0.5 and not moved then             
                moved = true
    
            end
    
            self:set_offset(0, tileOffset)
    
    
            if elapsedMoveTime == moveTime then 
                self.slide_component:eject()
                self.slide_component = nil
                self:set_offset(0, 0)
    
    
            end
    
            elapsedMoveTime = elapsedMoveTime + 1
    
        end
    
    
        self:register_component(self.slide_component)
    
      
    end

    local function move_slide_horizontal(self, direction, moveTime, anim, action)
        self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
        local startPosition = 0
        local target = -80
        if direction == Direction.Right then 
            target = target * -1
        end
        local elapsedMoveTime = 0
        local delta = 0
    
        local interp = 0
        local tileOffset = 0 
        local t = self:get_tile(direction, 1);
        self.slide_dest = t
        self.dest_tile_backup = self.slide_dest
        self.orig_tile = self:get_current_tile()
        t:reserve_entity_by_id(self:get_id())
    
        local moved = false;
        local already_moved = false;

        anim:on_interrupt(function()
            if not self.slide_component then return end
            self.slide_component:eject()
            self.slide_component = nil
            t:add_entity(self)
            self.orig_tile:remove_entity_by_id(self:get_id())
            self:set_offset(0, 0)

        end)

        self.slide_component.update_func = function()
            if delta >= 0.5 and not moved then 
                target = 0
            end
            
            delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
            interp =  target * delta + (startPosition * (1 - delta))
            
            tileOffset = interp - startPosition
            if delta >= 0.5 then
                tileOffset = -1*target + startPosition + tileOffset
            end
    
            if not already_moved then 
                t:reserve_entity_by_id(self:get_id())
            end
    
            -- Offsets are reflected a frame later than they're set
                -- So this moves us a frame later than we set an offset 
                -- for the new panel
            if moved and not already_moved then 
                already_moved = true
                start_tile = self:get_current_tile()
                start_tile:get_tile(direction, 1):add_entity(self)
                start_tile:remove_entity_by_id(self:get_id())
                self.slide_dest = nil
            end
    
            if delta >=0.5 and not moved then             
                moved = true
    
            end
    
            self:set_offset(tileOffset, 0)
    
    
            if elapsedMoveTime == moveTime then 
                self.slide_component:eject()
                self.slide_component = nil
                self:set_offset(0, 0)
    
    
            end
    
            elapsedMoveTime = elapsedMoveTime + 1
    
        end
    
    
        self:register_component(self.slide_component)
    
      
    end

    local function create_fire_wave(self, dir)
        local field = self:get_field()
        local state = "FIRE_WAVE"
        local last = 4
        local dir2 = Direction.Down
        if dir == Direction.Left or dir == Direction.Right then 
            state = "FIRE_SPIKE"
            last = 3
            dir2 = self:get_facing()
        end
        local spell = graphic_init("spell", 0, 0, base_texture, base_animation_path, -4, state, self, self:get_facing())
        spell:get_animation():on_frame(last, function()
            spell.start_moving = true
        end)
        local facing = self:get_facing()
        
        local damage = self:get_attack_level()*10
        if self.apollo_active then 
            damage = damage + 10
        end
        local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch,
                Element.Fire, 
                self:get_id(), 
                Drag.None
            )
    
        spell:set_hit_props(hit_props)
    
        spell.update_func = function(self, dt)
            if not self.start_moving then 
                return 
            end
            self:get_tile():attack_entities(self)
            local t2 = spell:get_tile(dir2, 1)
            
            if t2 and not t2:is_edge() then
                t2:attack_entities(self)
                t2:highlight(Highlight.Solid)
            end
    
            spell:get_current_tile():highlight(Highlight.Solid)
    
    
            if self:is_sliding() == false then
                if not self:get_tile(facing, 1) and self.slide_started then 
                    self:delete()
    
                end 
                
                local dest = self:get_tile(facing, 1)
                local ref = self
                self:slide(dest, frames(9), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end
            
        end
    
    
    --    anim:on_interrupt(function()
      --      if not spell.start_moving then 
        --        spell:delete()
          --  end
        --end)
    
        spell.attack_func = function()
            Engine.play_audio(self.sounds.hit, AudioPriority.Low)
        end
    
    
        spell.collision_func = function()
           -- spell:delete()
        end
    
        spell.can_move_to_func = function()
            return true
        end
    
       -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
        local tile = self:get_tile(facing, 1)
        if dir == Direction.Up then 
            tile = tile:get_tile(Direction.Up, 1)
        end
    
        if dir == Direction.Left or dir == Direction.Right then 
            tile = self:get_current_tile()
        end
    
        if tile then 
            field:spawn(spell, tile)
        end
    end

    local function fire_shot(player)
        local action = Battle.CardAction.new(player, "CHARGE_ATTACK")
        local spell = nil
        local direction = nil
        local actor = nil
        local anim = nil
        local action_check_input = false
        local still_holding = true
        local did_slide = false

        action:set_lockout(make_sequence_lockout())

        local function make_kick_step()
            local step = Battle.Step.new()
            local first = true
            step.update_func = function()
                if first then
                    local selection = direction
                    direction = nil                    

                    anim:set_state("SPIN_KICK")

                    anim:on_frame(1, function()
                        create_fire_wave(player, selection)
                        Engine.play_audio(player.sounds.spin, AudioPriority.Low)

                        if selection == Direction.Up or selection == Direction.Down then
                            if can_slide_to(player, player:get_tile(selection, 1)) then 
                                did_slide = true
                                move_slide(player, selection, 18, anim, action)
                            end
    
                        else
                            if can_slide_to(player, player:get_tile(selection, 1)) then 
                                did_slide = true
                                move_slide_horizontal(player, selection, 18, anim, action)
                            end
    
                        end
                    end)

                

                    anim:on_complete(function()
                        step:complete_step()
                        local c= Battle.Component.new(player, Lifetimes.Battlestep)
                        c.update_func = function()
                            if did_slide then 
                                player.dest_tile_backup:add_entity(player)
                                player.orig_tile:remove_entity_by_id(player:get_id())
                                c:eject()
                              --  player:set_offset(0, 0)
                          --      player.slide_component:eject()
                            --    player.slide_component = nil
                            end
                        end
            
                        player:register_component(c)
                    
                        if direction then 
                            print("Adding new step")
                            make_kick_step()
                        end
                    
                    end)

                    anim:refresh(actor:sprite())
                    first = false
                end
            end

            action:add_step(step)
        end

        action.update_func = function()
            if action_check_input then 
                if player:input_has(Input.Held.Special) and not still_holding then 
                    if player:input_has(Input.Held.Up) then 
                        direction = Direction.Up
                    elseif player:input_has(Input.Held.Down) then 
                        direction = Direction.Down
                    elseif player:input_has(Input.Held.Left) then 
                        direction = player:get_facing_away()
                    end

                    if direction then still_holding = true end

                elseif not direction and not player:input_has(Input.Held.Up) and not player:input_has(Input.Held.Down) and not player:input_has(Input.Held.Down) then 
                    still_holding = false
                end

            end
        end

        local step = Battle.Step.new()
        local start_kick_step = Battle.Step.new()
        
        step.update_func = function()
            if not direction then 
                if player:input_has(Input.Held.Special) then 
                    if player:input_has(Input.Held.Up) then 
                        direction = Direction.Up
                    elseif player:input_has(Input.Held.Down) then 
                        direction = Direction.Down
                    elseif player:input_has(Input.Held.Left) then 
                        direction = player:get_facing_away()
                    end

                    if direction then still_holding = true end
                end

            end
        end

        action:add_anim_action(5, function()
            step:complete_step()

            if direction then 
                action:add_step(start_kick_step)
                anim:set_state("START_KICK")
                anim:on_complete(function()
                  --  action_check_input = true
                    make_kick_step()
                    start_kick_step:complete_step()

                end)

                anim:refresh(actor:sprite())
            end
        end)

        action.execute_func = function()
            actor = action:get_actor()
            anim = actor:get_animation()
            Engine.play_audio(player.sounds.fire_projectile, AudioPriority.Low)
            spell = create_fire_shot(player)
            action:add_step(step)
        end

        action.action_end_func = function()
            if spell and not spell:is_deleted() and not spell.start_moving then 
                spell:delete()
            end
        end

        return action
    end

    player.normal_attack_func = normal_attack
    player.charged_attack_func = fire_shot

    

    local function activate_apollo(self)
        Engine.play_audio(self.sounds.apollo, AudioPriority.Low)
       -- self.behavior = "APOLLO" -- I should not set this here, since it'll happen in the middle of actions and break animation checks
        self.apollo_active = true

        self.ring1 = self:create_node()
        self.ring2 = self:create_node()
        self.ring3 = self:create_node()
        self.ring1_anim = 1
        self.ring2_anim = 1
        self.ring3_anim = 1

        self.rings = {
            self.ring1,
            self.ring2,
            self.ring3
        }
    
        self.ring_anims = {
            self.ring1_anim,
            self.ring2_anim,
            self.ring3_anim
        }
    
        self.ring1:set_layer(-1)
        self.ring2:set_layer(2)
        self.ring3:set_layer(1)
    
        for i=1, 3
        do
            self.rings[i]:set_texture(base_texture, false)
            self.ring_anims[i] = Engine.Animation.new(base_animation_path)
          --  print("Animation is now not nil")
            local an = self.ring_anims[i]
            an:set_state("FIRE_RING_"..i.."_START")
            an:refresh(self.rings[i])
    
            an:on_complete(function()
                an:set_state("FIRE_RING_"..i.."_LOOP")
                an:refresh(self.rings[i])
                an:set_playback(Playback.Loop)
            
            end)
    
        end
    
        local anim_component = Battle.Component.new(self, Lifetimes.Scene)
    
        anim_component.update_func = function(com, dt)
            if self.battle_over then 
                anim_component:eject()
                return
            end
            for i=1, 3
            do
                self.ring_anims[i]:update(dt, self.rings[i])
            end
    
        end
    
        self:register_component(anim_component)

    end


    player.first = true
    player.update_func = function(self)
        if self.first then 
            local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

            defense.can_block_func = function(judge, attacker, defender)
                local attacker_hit_props = attacker:copy_hit_props()
                if attacker_hit_props.damage > 0 then
                    if self.apollo_active and attacker_hit_props.element == Element.Aqua then 
                        attacker_hit_props.damage = math.floor(attacker_hit_props.damage*0.9)
                        attacker:set_hit_props(attacker_hit_props)

                    end

                    if attacker:get_name() == "Element.Earth" then 
                        attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                        attacker:set_hit_props(attacker_hit_props)

                        local alert = graphic_init("artifact", 32, 0, "overlay_fx07_animations.png", "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                        local y = defender:get_height()+14
                        if y < 20 then 
                            y = 40
                        end
                        alert:set_elevation(y)
                        defender:get_field():spawn(alert, defender:get_current_tile())

                    end

                end


            end

            self:add_defense_rule(defense)

            self.first = false
        end

        if not self.apollo_active then 
            if self:get_health() <= self:get_max_health()/2 then 
                activate_apollo(self)
            end
        end

    end

    player.battle_end_func = function(self)
        self.battle_over = true
    end
end