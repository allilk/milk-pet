function package_init(package)
    package:declare_package_id("com.D3stroy3d.player.Groundman")
    package:set_special_description("A ground breaking experience")
    package:set_speed(5.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    --package:set_icon_texture(Engine.load_texture(_modpath.."face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."groundmanOW.animation")
    package:set_overworld_texture_path(_modpath.."groundmanOW.png")
    package:set_mugshot_texture_path(_modpath.."GroundMan.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Groundman")
    player:set_health(1000)
    player:set_element(Element.Break)
    player:set_height (60.0)
    player:set_animation(_modpath.."battle.animation")
    player:set_texture(Engine.load_texture(_modpath.."groundman_atlas.png"), true)
    player:set_fully_charged_color(Color.new(255,0,0,255))

    local hit_sound = Engine.load_audio(_modpath.."hit.ogg")
    local drill_sound = Engine.load_audio(_modpath.."drill.ogg")


    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end


    function graphic_init(type, x, y, texture, animation, layer, state, user, facing, flip)
        flip = flip or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type =="spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        graphic:get_animation():load(_folderpath..animation)

        graphic:get_animation():set_state(state)
        graphic:get_animation():refresh(graphic:sprite())

        return graphic
    end

    -- For some reason there's like an 11f gap between the first and second hit but a 10f gap to the third
        -- I just kept 11f on each because it makes nearly no difference

    player.charged_attack_func = function()
        -- 71 frames
        local action = Battle.CardAction.new(player, "GROUNDMAN_CS")

        local field = player:get_field()
        local drills = {}
        
        -- Create drill graphics and initialize important variables
            -- Startup is the time that passes before the drill moves
                -- Note that I attach these times to the individual drill
                -- This means that using the CS at the top row will fire only two drills; one will move after 3f, the other after 26f
            -- Hit will be toggled when the drill hits something for the first time
                -- GroundMan's drills stop moving once they hit something
        drills[1] = graphic_init("spell", 0, 0, "groundman_atlas.png", "battle.animation", -1, "DRILL_HEAD", player, player:get_facing())
        drills[1].startup = 3
        drills[1].lifetime = 44
        drills[1].state = "HEAD"

        drills[2] = graphic_init("spell", 0, 0, "groundman_atlas.png", "battle.animation", -1, "DRILL_ARM", player, player:get_facing())
        drills[2].startup = 14
        drills[2].lifetime = 55
        drills[2].state = "ARM"

        drills[3] = graphic_init("spell", 0, 0, "groundman_atlas.png", "battle.animation", -1, "DRILL_ARM", player, player:get_facing())
        drills[3].startup = 26
        drills[3].lifetime = 67
        drills[3].state = "ARM"

        local function drill_init(player, drill, tile)
            drill.hit = false
            --drill.facing = player:get_facing()
            drill.offset_dir = -1
            drill.started_moving = false 
            drill.hit_cooldown = 0
            drill.hit_count = 0
            drill.attack_tile = tile
            drill.moves = 0

            if drill:get_facing() == Direction.Left then 
                drill.offset_dir = drill.offset_dir * -1
            end
            drill.max_move = -160 * drill.offset_dir

            drill:set_hit_props(
                HitProps.new(
                    10 + player:get_attack_level() * 10, 
                    Hit.Impact | Hit.Flinch | Hit.Breaking, 
                    Element.None, 
                    player:get_context(),
                    Drag.None
                )
            )

            local function drill_hit(drill)
                drill.hit = true
                drill.hit_count = drill.hit_count + 1
                drill.hit_cooldown = 10
                -- This is the wrong hit effect
                local hit_effect = graphic_init("artifact", 0, -32, "artifact_impact_fx.png", "artifact_impact_fx.animation", -1, "BLUE", player, player:get_facing())
                hit_effect:get_animation():on_complete(function()
                    hit_effect:delete()
                end)

                field:spawn(hit_effect, drill.attack_tile)
                print("Hit")

            end
            
            drill.collision_func = function(self)
                drill_hit(self)
            end

            drill.attack_func = function(self)
                Engine.play_audio(hit_sound, AudioPriority.Low)
            end

            drill.update_func = function(self)
                if self.hit_cooldown == 0 and self.hit_count < 3 then 
                    self.attack_tile:attack_entities(self)
                    
                    -- Since a spell can only hit the same panel one time, I just create another one here when I need it
                    if self.hit_count > 0 then 
                        local spell = Battle.Spell.new(self:get_team())
                        --spell:set_hit_props(spell:copy_hit_props(self))
                        spell:set_hit_props(
                            HitProps.new(
                                10 + player:get_attack_level() * 10, 
                                Hit.Impact | Hit.Flinch | Hit.Breaking, 
                                Element.None, 
                                player:get_context(),
                                Drag.None
                            )
                        )
                        spell.update_func = function(self)
                            self:get_current_tile():attack_entities(self)
                            self:delete()
                        end

                        spell.collision_func = function()
                            drill_hit(drill)
                        end
                        spell.attack_func = function(self)
                            Engine.play_audio(hit_sound, AudioPriority.Low)
                        end

                        field:spawn(spell, self.attack_tile)
                    end
                else
                    self.hit_cooldown = self.hit_cooldown - 1
                end

                if not self.hit and self.started_moving then 
                    self:get_animation():set_state("DRILL_"..self.state.."_MOVE")
                    self:get_animation():set_playback(Playback.Loop)
                    self:get_animation():refresh(self:sprite())
                    Engine.play_audio(drill_sound, AudioPriority.Low)

                    self.started_moving = false
                end

                -- Moving the drills 16 (8) pixels per frame
                    -- Since I move by offsets, I have to control where the attack hits manually. I base that off where the offsets are
                    -- Hopefully absolute value function doesn't have ridiculous overhead for no reason
                if not self.hit and self.startup == 0 and math.abs(self:get_offset().x) < math.abs(drill.max_move) then
                    self:set_offset((self:get_offset().x + (-16 * self.offset_dir)), 0)
                    
                    if self.moves == 0 and math.abs(self:get_offset().x) > math.abs(drill.max_move/4) then 
                        local next_tile = self.attack_tile:get_tile(self:get_facing(), 1)
                        if next_tile then 
                            self.attack_tile = next_tile
                        end
                        self.moves = self.moves + 1
                    end

                    if self.moves == 1 and math.abs(self:get_offset().x) > math.abs(drill.max_move/1.5) then 
                        local next_tile = self.attack_tile:get_tile(self:get_facing(), 1)
                        if next_tile then 
                            self.attack_tile = next_tile
                        end
                        self.moves = self.moves + 1

                    end
                else
                    self.startup = self.startup - 1
                    if self.startup == 0 then 
                        self.started_moving = true
                    end
                end

                self.lifetime = self.lifetime - 1
                if self.lifetime == -1 then 
                    self:delete()
                end
            end

        
        end

        -- The drills' first movement seems to be 18 pixels, then it moves by 16 every frame for nine more frames
            -- I might drop that 18 to another 16. 16 * 10 is 160, the length of two panels
                -- 80 is the actual length, but all the numbers I used here are *2, since ONB scales that much. Offsets are not scaled

        action.execute_func = function()
            -- Grab 1x3 in front of player
            local tiles = {}
            tiles[1] = player:get_tile(player:get_facing(), 1)
            tiles[2] = player:get_tile(Direction.join(player:get_facing(), Direction.Up), 1)
            tiles[3] = player:get_tile(Direction.join(player:get_facing(), Direction.Down), 1)

            for i=1, 3, 1
            do
                -- We won't spawn in the drills that would be off the visible field
                if tiles[i] and not tiles[i]:is_edge() then 
                    drill_init(player, drills[i], tiles[i])
                    field:spawn(drills[i], tiles[i])
                end
            end

            
        end

        -- Delete things if they aren't already deleted
        action.action_end_func = function()
            for i=1, 3, 1
            do
                -- First check should never be false, but checking anyway
                    -- If I'm right about action_end_func being able to run only once the execute_func has triggered, anyway
                if drills[i] and not drills[i]:is_deleted() then 
                    drills[i]:delete()
                end
            end
        end

        return action
    end
end