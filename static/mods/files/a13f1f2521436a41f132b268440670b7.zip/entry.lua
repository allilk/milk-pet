function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.WaveDash.white")
    block:set_name("WaveDash")
    block:set_description("B + Left/Right to dash")
    block:set_color(Blocks.White)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 1, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

local function create_dust(texture, direction)
    local artifact = Battle.Artifact.new()
    artifact:set_texture(texture)
    artifact:set_facing(direction)

    local artifact_anim = artifact:get_animation()
    artifact_anim:load(_modpath.."dust.animation")
    artifact_anim:set_state("DEFAULT")
    artifact_anim:on_complete(function()
        artifact:erase()
    end)

    return artifact
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    local dust_texture = Engine.load_texture(_modpath.."dust.png")

    component.update_func = function()
        local forward_direction_input = Input.Pressed.Right
        local reversed_direction_input = Input.Pressed.Left

        if player:get_facing() == Direction.Left then
            forward_direction_input = Input.Pressed.Left
            reversed_direction_input = Input.Pressed.Right
        end

        local has_forward = player:input_has(forward_direction_input)
        local has_reverse = player:input_has(reversed_direction_input)
        local holding_side_direction = (has_forward or has_reverse) and not (has_forward and has_reverse)

        if player:input_has(Input.Held.Shoot) and holding_side_direction then
            if has_reverse then
                local new_direction = player:get_facing_away()
                player:set_facing(new_direction)
            end

            local dust = create_dust(dust_texture, player:get_facing_away())
            dust:sprite():set_layer(1)
            player:get_field():spawn(dust, player:get_tile())
        end
    end

    player:register_component(component)
end
