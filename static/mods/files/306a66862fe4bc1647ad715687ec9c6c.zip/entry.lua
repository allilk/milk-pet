local DAMAGE = 130

local TEXTURE_FLAMETOWER = Engine.load_texture(_modpath.."flametower.png")
local ANIMPATH_FLAMETOWER = _modpath .. "flametower.animation"
local AUDIO_FLAMETOWER = Engine.load_audio(_modpath.."flametower.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath .. "effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.Rework.Y.066")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"W"})

    local props = package:get_card_props()
    props.shortname = "DarkBurn"
    props.damage = 360
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "LET IT ALL BURN TO ASH"
	props.long_description = "ENVELOPS ALL IN FLAMES OF HELL."
	props.can_boost = false
    props.card_class = CardClass.Dark
	props.limit = 1
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_HIT")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.1},{2,0.050},{2,0.050},{2,0.050},{2,0.255}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    
    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        local tile = user:get_current_tile()
        self:add_anim_action(2,function()
            user:toggle_counter(true)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self:add_anim_action(5,function()
            spawn_flametower(user, props, tile, team, direction, field)
        end)
    end
    return action
end

function spawn_flametower(owner, props, tile, team, direction, field)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(AUDIO_FLAMETOWER, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.new())
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_FLAMETOWER)
        sprite:set_layer(-999)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_FLAMETOWER)
        animation:set_state("SPAWN")
        animation:refresh(sprite)

        animation:on_complete(function()
            animation:set_state("DEFAULT")
            animation:on_frame(11, function()
                local tile_U = tile:get_tile(Direction.Up, 1)
                local tile_D = tile:get_tile(Direction.Down, 1)
                local tile_L = tile:get_tile(Direction.Left, 1)
                local tile_R = tile:get_tile(Direction.Right, 1)
                spawn_flametower_next(owner, props, tile_U, team, direction, field)
                spawn_flametower_next(owner, props, tile_D, team, direction, field)
                spawn_flametower_next(owner, props, tile_L, team, direction, field)
                spawn_flametower_next(owner, props, tile_R, team, direction, field)
            end, true)
            animation:on_complete(function()
                animation:set_state("FADE")
                animation:on_complete(function()
                    spell:erase()
                end)
            end)
        end)

        spell.update_func = function()
            if animation:get_state() == "DEFAULT" then
                spell:get_current_tile():attack_entities(spell)
            end
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function spawn_flametower_next(owner, props, tile, team, direction, field)
    local spawn_next
    local is_continue = true
    spawn_next = function()
        if not tile:is_walkable() then return end
        is_continue = false
        Engine.play_audio(AUDIO_FLAMETOWER, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.new())
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_FLAMETOWER)
        sprite:set_layer(-999)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_FLAMETOWER)
        animation:set_state("SPAWN")
        animation:refresh(sprite)

        animation:on_complete(function()
            animation:set_state("DEFAULT")
            animation:on_frame(11, function()
                tile = tile:get_tile(direction, 1)
                spawn_next()
            end, true)
            animation:on_complete(function()
                animation:set_state("FADE")
                animation:on_complete(function()
                    spell:erase()
                end)
            end)
        end)

        spell.update_func = function()
            if animation:get_state() == "DEFAULT" then
                spell:get_current_tile():attack_entities(spell)
            end
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-30,30), math.random(-30,30), field, spell:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end
    if is_continue then
        spawn_next()
    end
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end