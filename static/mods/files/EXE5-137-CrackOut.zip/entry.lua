local crackout = include("crackout/crackout.lua")

local DAMAGE = 0

crackout.type = 1

crackout.codes = {"*"}
crackout.shortname = "CrackOut"
crackout.damage = DAMAGE
crackout.time_freeze = false
crackout.element = Element.None
crackout.description = "Erases 1 panel in front"
crackout.long_description = "Panel destroying attack! Erases 1 square in front of you"
crackout.can_boost = true
crackout.card_class = CardClass.Standard
crackout.memory = 4
crackout.limit = 4

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE5-137-CrackOut")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(crackout.codes)

    local props = package:get_card_props()
    props.shortname = crackout.shortname
    props.damage = crackout.damage
    props.time_freeze = crackout.time_freeze
    props.element = crackout.element
    props.description = crackout.description
    props.long_description = crackout.long_description
    props.can_boost = crackout.can_boost
	props.card_class = crackout.card_class
	props.limit = crackout.limit
end

card_create_action = crackout.card_create_action