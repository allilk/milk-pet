local DAMAGE = 0

local TEXTURE_HARDHEAD = Engine.load_texture(_modpath .. "hardhead.png")
local ANIMPATH_HARDHEAD = _modpath .. "hardhead.animation"
local TEXTURE_BUTTON = Engine.load_texture(_modpath .. "button.png")
local ANIMPATH_BUTTON = _modpath .. "button.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath .. "spawn.ogg")
local AUDIO_SCAN = Engine.load_audio(_modpath .. "scan.ogg")
local AUDIO_CANNON = Engine.load_audio(_modpath .. "cannon.ogg")
local ball_texture = Engine.load_texture(_folderpath .. "ball.png")
local ball_anim = _modpath .. "ball.animation"
local AUDIO_FIREPANEL = Engine.load_audio(_modpath .. "fire.ogg")
local AUDIO_ICEPANEL = Engine.load_audio(_modpath .. "fire.ogg")
local AUDIO_CRACKPANEL = Engine.load_audio(_modpath .. "fire.ogg")

function package_init(package)
	package:declare_package_id("com.louise.hardheadchip")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ "A", "D", "E", "H", "R" })

	local props = package:get_card_props()
	props.shortname = "HardHead"
	props.damage = DAMAGE
	props.time_freeze = true
	props.element = Element.None
	props.description = "Summons a HardHead to fight!"
	props.long_description = "Summons a HardHead to attack!"
	props.can_boost = false
	props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local step1 = Battle.Step.new()
		local hardHead = Battle.Artifact.new()
		local do_once0 = true
		local do_once = true
		local do_once2 = true
		local max_duration = 490
		local current_time = 0
		local hardHead_type = 1;
		local end_attack = -1
		local attacked = false
		step1.update_func = function(self, dt)
			if do_once0 then
				do_once0 = false
				hardHead:set_facing(direction)
				hardHead:set_texture(TEXTURE_HARDHEAD, true)
				--hardHead:set_offset(-8, -38)
				local hardhead_sprite = hardHead:sprite()
				hardhead_sprite:set_layer(-3)
				local hardhead_anim = hardHead:get_animation()
				hardhead_anim:load(ANIMPATH_HARDHEAD)
				hardhead_anim:set_state("SPAWN")
				hardhead_anim:refresh(hardhead_sprite)
				hardhead_anim:on_frame(2, function()
					Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
				end)
				hardhead_anim:on_complete(function()
					hardhead_anim:set_state("SEARCH")
					hardhead_anim:set_playback(Playback.Loop)
					hardhead_anim:refresh(hardhead_sprite)
				end)
				local query = function() return true end
				local tile = user:get_tile(direction, 1)
				if not tile:is_walkable() or #tile:find_characters(query) ~= 0 then
					hardHead:delete()
					step1:complete_step()
				else
					field:spawn(hardHead, tile)
				end
			end
			local anim = hardHead:get_animation()
			if anim:get_state() == "SEARCH" then
				if do_once then
					do_once = false
					local query = function() return true end
					local tile = user:get_tile(direction, 1)

					local button_gui = Battle.Artifact.new()
					button_gui:set_facing(Direction.Right)
					button_gui:set_texture(TEXTURE_BUTTON, true)
					local button_sprite = button_gui:sprite()
					button_sprite:set_layer(-9999999)
					local button_anim = button_gui:get_animation()
					button_anim:load(ANIMPATH_BUTTON)
					button_anim:set_state("0")
					button_anim:set_playback(Playback.Loop)
					button_anim:refresh(button_sprite)
					field:spawn(button_gui, tile)

					anim:on_frame(1, function()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						hardHead_type = 1
					end)
					anim:on_frame(2, function()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						hardHead_type = 2
					end)
					anim:on_frame(3, function()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						hardHead_type = 3
					end)
					anim:on_frame(4, function()
						Engine.play_audio(AUDIO_SCAN, AudioPriority.High)
						hardHead_type = 4
					end)

					hardHead.update_func = function(self, dt)
						current_time = current_time + 1
						if not attacked then
							if (user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot)) or current_time >= max_duration then
								if (do_once2) then
									button_gui:erase()
									anim:set_state("V" .. hardHead_type .. "_ATTACK")
									anim:refresh(hardHead:sprite())
									anim:on_frame(5, function()
										attack(hardHead, hardHead_type, actor)
										Engine.play_audio(AUDIO_CANNON, AudioPriority.High)
									end)
									end_attack = 100
									attacked = true
									do_once2 = false
								end
							end
						end
					end
				end
			end
			if (end_attack == 100) then
				end_attack = end_attack - 1
			elseif (end_attack == 35) then
				hardHead:delete()
				step1:complete_step()
			elseif (end_attack > 0) then
				end_attack = end_attack - 1
			end
		end
		self:add_step(step1)
	end
	return action

end

function attack(attacker, version, actor)
	local target_char = find_target(actor)
	if (not target_char) then
		return nil
	end
	local props = get_props(version)
	local target_tile = target_char:get_tile()
	toss_spell(attacker, 60, ball_texture, ball_anim, target_tile, 40, function()
		cannonball_impact(attacker, target_tile, ball_texture, ball_anim, props.sfx, props)
	end, props)
end

function get_props(version)
	local props = {}
	if (version == 1) then
		props.anim = "NORMAL"
		props.damage = 50
		props.tileChange = TileState.Cracked
		props.element = Element.Break
		props.sfx = AUDIO_CRACKPANEL
	elseif (version == 2) then
		props.anim = "ICE"
		props.damage = 100
		props.tileChange = TileState.Ice
		props.element = Element.Aqua
		props.sfx = AUDIO_ICEPANEL
	elseif (version == 3) then
		props.anim = "FIRE"
		props.damage = 100
		props.tileChange = TileState.Lava
		props.element = Element.Fire
		props.sfx = AUDIO_FIREPANEL
	else
		props.anim = "NORMAL"
		props.damage = 200
		props.tileChange = TileState.Cracked
		props.element = Element.Break
		props.sfx = AUDIO_CRACKPANEL
	end
	return props
end

--find a target character
function find_target(self)
	local field = self:get_field()
	local team = self:get_team()
	local target_list = field:find_characters(function(other_character)
		return other_character:get_team() ~= team and not other_character:is_deleted()
	end)
	if #target_list == 0 then
		return
	end
	local target_character = target_list[1]
	return target_character
end

function cannonball_impact(user, target_tile, texture, anim_path, explosion_sound, props)
	local field = user:get_field()
	local spell = Battle.Spell.new(user:get_team())
	local spell_animation = spell:get_animation()
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	spell_animation:load(anim_path)
	spell_animation:set_state("POOF")
	spell:set_texture(texture)
	spell:sprite():set_layer(-2)
	spell_animation:refresh(spell:sprite())
	spell_animation:set_playback(Playback.Loop)
	spell.hits = 1
	local do_once = true
	spell.update_func = function(self, dt)
		if do_once then
			spell:get_current_tile():attack_entities(self)
			spell_animation:refresh(spell:sprite())
			spell_animation:on_frame(1, function()
				self:get_current_tile():attack_entities(self)

			end)
			spell_animation:on_frame(2, function()
				target_tile:set_state(props.tileChange)
				spell:delete()
			end)
			do_once = false
		end

	end
	Engine.play_audio(explosion_sound, AudioPriority.Highest)
	spell.collision_func = function(self, other)
	end
	spell.attack_func = function(self, other)
	end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	field:spawn(spell, target_tile)
end

function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback, props)
	local starting_height = -50
	local start_tile = tosser:get_current_tile()

	local field = tosser:get_field()
	local spell = Battle.Spell.new(tosser:get_team())
	local spell_animation = spell:get_animation()
	spell_animation:load(animation_path)
	spell_animation:set_state(props.anim)
	spell_animation:set_playback(Playback.Loop)
	spell.jump_started = false
	spell.starting_y_offset = starting_height
	spell.starting_x_offset = 38
	if tosser:get_facing() == Direction.Left then
		spell.starting_x_offset = -38
	end
	spell.y_offset = spell.starting_y_offset
	spell.x_offset = spell.starting_x_offset
	local sprite = spell:sprite()
	sprite:set_texture(texture)
	spell:set_offset(spell.x_offset, spell.y_offset)

	spell.update_func = function(self)
		target_tile:highlight(Highlight.Flash)
		if not spell.jump_started then
			self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
			self.jump_started = true
		end
		if self.y_offset < 0 then
			self.y_offset = self.y_offset + math.abs(self.starting_y_offset / frames_in_air)
			self.x_offset = self.x_offset - math.abs(self.starting_x_offset / frames_in_air)
			self:set_offset(self.x_offset, self.y_offset)
		else
			arrival_callback()
			self:delete()
		end
	end
	spell.can_move_to_func = function(tile)
		return true
	end
	field:spawn(spell, start_tile)
end
