local DAMAGE = 105

local VOICE_COSMOGATE = Engine.load_audio(_modpath.."cosumogeeto.ogg")

local COSMOMAN_TEXTURE = Engine.load_texture(_modpath.."cosmoman.png")
local COSMOMAN_ANIMPATH = _modpath.."cosmoman.animation"
local COSMOGATE_TEXTURE = Engine.load_texture(_modpath.."cosmogate.png")
local COSMOGATE_ANIMPATH = _modpath.."cosmogate.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_COSMOGATE = Engine.load_audio(_modpath.."cosmogate.ogg")
local AUDIO_METEOR = Engine.load_audio(_modpath.."meteor.ogg")
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")
local BOOM_TEXTURE = Engine.load_texture(_modpath.."boom.png")
local BOOM_ANIMPATH = _modpath.."boom.animation"
local BOOM1_TEXTURE = Engine.load_texture(_modpath.."boom1.png")
local BOOM1_ANIMPATH = _modpath.."boom1.animation"
local BOOM2_TEXTURE = Engine.load_texture(_modpath.."boom2.png")
local BOOM2_ANIMPATH = _modpath.."boom2.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE5-269-CosmoManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C'})

    local props = package:get_card_props()
    props.shortname = "CosmoMnSP"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Meteors hit   enemy"
    props.long_description = "Make a hole in sky and let it rain"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 40
        local voiceline_number = 0

        local NOT_HOLE_1 = nil

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        local self_tile = user:get_current_tile()

		local step1 = Battle.Step.new()

        self.cosmoman = nil
        self.tile     = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                --print("READING")
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    --print("VOICE")
                    VOICEACTING = true
                end
            end

            if self_tile ~= nil or not self_tile:is_hole() then
                NOT_HOLE_1 = true
            else
                NOT_HOLE_1 = false
            end

            if do_once then
                do_once = false
                ref.cosmoman = Battle.Artifact.new()
                ref.cosmoman:set_facing(direction)
                local cosmo_sprite = ref.cosmoman:sprite()
		    	cosmo_sprite:set_texture(COSMOMAN_TEXTURE, true)
		    	cosmo_sprite:set_layer(-2)
                local cosmo_anim = ref.cosmoman:get_animation()
                cosmo_anim:load(COSMOMAN_ANIMPATH)
                if NOT_HOLE_1 then
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
                    cosmo_anim:set_state("0")
		    	    cosmo_anim:refresh(cosmo_sprite)
				else
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
                    cosmo_anim:set_state("1")
		    	    cosmo_anim:refresh(cosmo_sprite)
				end
                cosmo_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                cosmo_anim:on_frame(7, function()
                    if NOT_HOLE_1 then
                        if VOICEACTING then
                            print("CosmoMan: CosmoGate!")
                            Engine.play_audio(VOICE_COSMOGATE, AudioPriority.High)
                        end
                    end
                end)
                cosmo_anim:on_frame(8, function()
                    if NOT_HOLE_1 then
                        if not VOICEACTING then
                            print("CosmoMan: CosmoGate!")
                        end
                        if direction == Direction.Right then
                            Engine.play_audio(AUDIO_COSMOGATE, AudioPriority.Highest)
                            create_cosmogate(user, props, team, direction, field, field:tile_at(5,2))
                        else
                            Engine.play_audio(AUDIO_COSMOGATE, AudioPriority.Highest)
                            create_cosmogate(user, props, team, direction, field, field:tile_at(2,2))
                        end
                    end
                end)
		    	cosmo_anim:on_complete(function()
		    		ref.cosmoman:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.cosmoman, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_cosmogate(owner, props, team, direction, field, tile)
    local query = function(ent)
        if not owner:is_team(ent:get_team()) then
            return true
        end
    end

    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(COSMOGATE_TEXTURE, true)
    sprite:set_layer(-2)
    local anim = spell:get_animation()
	anim:load(COSMOGATE_ANIMPATH)
	anim:set_state("0")
	anim:on_frame(8, function()
        Engine.play_audio(AUDIO_METEOR, AudioPriority.High)
    end)
	anim:on_frame(19, function()
        if not tile:is_hole() then
            create_attack(owner, team, props, tile, field)
        elseif #tile:find_characters(query) > 0 then
            create_attack(owner, team, props, tile, field)
        end
    end)
	anim:on_frame(22, function()
        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
    end)
	anim:on_frame(33, function()
        if not tile:is_hole() then
            create_attack(owner, team, props, tile, field)
        elseif #tile:find_characters(query) > 0 then
            create_attack(owner, team, props, tile, field)
        end
    end)
	anim:on_frame(36, function()
        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)
    end)
	anim:on_frame(47, function()
        if not tile:is_hole() then
            create_attack(owner, team, props, tile, field)
        elseif #tile:find_characters(query) > 0 then
            create_attack(owner, team, props, tile, field)
        end
    end)
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt) 
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

    field:spawn(spell, tile)

	return spell
end

function create_attack(owner, team, props, tile, field)
    local spawn_boom
    spawn_boom = function()
        --if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:get_facing(Direction.Right)
        spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Flinch | Hit.Flash | Hit.Impact,
                props.element,
                owner:get_id(),
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(BOOM2_TEXTURE)
        boom_sprite:set_layer(-3)
        local boom_anim = spell:get_animation()
        boom_anim:load(BOOM2_ANIMPATH)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_complete(function() spell:erase() end)

        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.can_move_to_func = function(tile)
	    	return true
	    end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.attack_func = function(self, other)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
			create_effect(BOOM_TEXTURE, BOOM_ANIMPATH, "0", math.random(-7,7), math.random(-7,7), field, self:get_current_tile())
        end

        spell.delete_func = function(self)
	    	self:erase()
        end

        Engine.play_audio(AUDIO_BOOM, AudioPriority.Highest)

        field:spawn(spell, tile)
    end

    spawn_boom()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end