nonce = function() end
 
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
local TEXTURE = Engine.load_texture(_modpath.."present.png")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."spell_explosion.png")

 
function package_init(package)
    package:declare_package_id("rune.legacy.nrthwind.pvp")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"*"})
 
    local props = package:get_card_props()
    props.shortname = "NrthWind"
    props.damage = 0-0
    props.time_freeze = true
    props.element = Element.Wind
    props.secondary_element = Element.None
    props.description = "Wind blows off auras, barriers"
end

function card_create_action(actor, props)
 --   print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	
    action.execute_func = function(self)
			Engine.play_audio(AUDIO, AudioPriority.Highest)
			local field = actor:get_field()
			local tile = nil
			for i = 0, 6, 1 do
				for j = 0, 6, 1 do
					tile = field:tile_at(i, j)
					if tile and not tile:is_edge() then
						local explosion = create_boom(actor)
						field:spawn(explosion, tile)
					end
				end
			end
	end
    return action
end

function create_boom(actor)
	local spell = Battle.Spell.new(actor:get_team())
	spell:set_texture(EXPLOSION_TEXTURE, true)
	spell:set_facing(actor:get_facing())
    spell:set_hit_props(
        HitProps.new(
            10, 
            Hit.None, 
            Element.Wind,
            actor:get_context(),
            Drag.None
        )
    )
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
    end
	
	local anim = spell:get_animation()
    anim:load(_modpath.."spell_explosion.animation")
    anim:set_state("Default")
	anim:on_complete(function()
		spell:erase()
	end)
	
	spell.collision_func = function(self, other)
	end
	spell.can_move_to_func = function(self, other)
		return true
	end
	return spell
end