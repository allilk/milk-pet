function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.HP400.yellow.bn6")
    block:set_name("HP+400")
    block:set_description("MAX HP\n+400!")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        1, 1, 1, 1, 0,
        1, 1, 1, 1, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:mod_max_health(400)
end
