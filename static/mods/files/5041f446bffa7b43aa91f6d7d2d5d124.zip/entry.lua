local targettexture = Engine.load_texture(_modpath .. "targettexture.png")
local targetanim = _modpath .. "target.animation"
local explodetexture = Engine.load_texture(_modpath .. "impact.png") 
local explodeanim = _modpath .. "impact.animation"
local bustertexture = Engine.load_texture(_modpath .. "buster.png") 
local busteranim = _modpath .. "buster.animation"
local targetsound = Engine.load_audio(_folderpath .. "target.ogg")
local blastsound = Engine.load_audio(_folderpath .. "heatShotImpact.ogg")
local shotsound = Engine.load_audio(_folderpath .. "cannon.ogg")
local cursormove = false
local yettofire = false

local frame1 = {1, 0.43}
local frame2 = {2, 0.43}
local frame3 = {3, 0.43}
local frame4 = {4, 0.43}
local frame5 = {5, 0.43}
local frame6 = {6, 0.43}
local frame7 = {7, 0.43}
local frame8 = {8, 0.43}
local frame9 = {9, 0.43}
local frame10 = {10, 0.43}
local frame11 = {11, 0.43}
local frame12 = {12, 0.43} --{12, 0.23}
local FRAMES = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10, frame11, frame12})

--Big thanks to Alrysc and Alcor for helping me with this chip. You two we're a big help!

function package_init(package) 
    package:declare_package_id("hoov.cards.montar1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon1.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."temppreview1.png"))
	package:set_codes({'J','T','X','*'})

    local props = package:get_card_props()
    props.shortname = "Montar"
    props.damage = 100
    props.time_freeze = false
    props.element = Element.Cursor
    props.description = "Cursor w/ D-Pad, B to Atk"
	props.can_boost = true
    props.limit = 4
end

function card_create_action(self, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
    action:override_animation_frames(FRAMES)
    local aimmode = Battle.Step.new()
    local firemode = Battle.Step.new()
    local spell = nil
    action:set_lockout(make_sequence_lockout()) --sequence_lockout
    action.execute_func = function (self, user)
        --buster sprite
        action:add_step(aimmode)
        action:add_step(firemode)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
		buster_sprite:set_texture(bustertexture, true)
		buster_sprite:set_layer(-1)

        local buster_anim = buster:get_animation()
		buster_anim:load(busteranim)
		buster_anim:set_state("AIM") --need to edit this to be longer
        buster_anim:refresh(buster_sprite)
        buster_anim:set_playback(Playback.Loop)
       -- buster_anim:on_complete(function()
            --buster_anim:set_state("Cannon1")
            
        --end)
        local direction = user:get_facing()
        local tile = user:get_tile(user:get_facing(), 1)
        --gotta add the create shot functions. use code from 3way 
        spell = create_cursor(user, tile, props)
        --local shot2 = create_shot(user, tile, 2, props)
        --user:get_animation():on_frame(1, function() --might be a lil early to redo it, but think I might swap out the on frame thing for a update_func
            --user:toggle_counter(true)
        cursormove = true
        yettofire = true
        user:get_field():spawn(spell, tile)
        local leftdirec = nil
        local rightdirec = nil
        if user:get_team() == Team.Red then
            leftdirec = Direction.Left
            rightdirec = Direction.Right
            print("teamred")
        elseif user:get_team() == Team.Blue then
            leftdirec = Direction.Right
            rightdirec = Direction.Left
            print("teamblue")
        end
        local usercounter = 0
        aimmode.update_func = function()
            usercounter = usercounter + 1
            --print("cursormove")
            if usercounter % 140 == 0 then
            
                print("times up")
                cursormove = false
                --aimmode:complete_step()
            end
            
            if cursormove == true then
                if user:input_has(Input.Pressed.Up) then 
                    local tile = spell:get_tile(Direction.Up, 1)
                    if tile ~= nil and not tile:is_edge() then
                        spell:slide(tile, frames(4), frames(2), ActionOrder.Voluntary, nil)
                    end
                    print("move up")
                end
                if user:input_has(Input.Pressed.Down) then 
                    local tile = spell:get_tile(Direction.Down, 1)
                    if tile ~= nil and not tile:is_edge() then
                        spell:slide(tile, frames(4), frames(2), ActionOrder.Voluntary, nil)
                    end
                    print("move down")
                end
                if user:input_has(Input.Pressed.Left) then 
                    local tile = spell:get_tile(leftdirec, 1)
                    if tile ~= nil and not tile:is_edge() then
                        spell:slide(tile, frames(4), frames(2), ActionOrder.Voluntary, nil)
                    end
                    print("move left")
                end
                if user:input_has(Input.Pressed.Right) then 
                    local tile = spell:get_tile(rightdirec, 1)
                    if tile ~= nil and not tile:is_edge() then
                        spell:slide(tile, frames(4), frames(2), ActionOrder.Voluntary, nil)
                    end
                    print("move right")
                end
                if user:input_has(Input.Pressed.Shoot) then 
    
                    cursormove = false
                    --aimmode:complete_step()
                    
                end
            end
    
            if cursormove == false then
                --buster_anim:set_state("FIRE") --crashes the game
                --print("animation change")
                aimmode:complete_step()
            end
        end
        local doonce = true
        firemode.update_func = function()
            if doonce then
                buster_anim:set_state("FIRE")
                buster_anim:refresh(buster_sprite)
                doonce = false
                buster_anim:on_complete(function()
                    --print("wedone!!!!!")
                    firemode:complete_step()
                end)
            end
            
        end


    end
    action.action_end_func = function()
        if yettofire == true or cursormove == true then
            spell:delete()
        end
        --print("lockout should end")
    end
    return action
end



function create_cursor(user, tile, props)

    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local sprite = spell:sprite()
    sprite:set_texture(targettexture)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(targetanim)
    anim:set_state("TARGETING")
    anim:refresh(spell:sprite())
    anim:set_playback(Playback.Loop)

    local doonce = true
    local firetimer = false
    local firecount = 0
    spell:set_float_shoe(true)

    spell.update_func = function(self, dt)
        
        if cursormove == false then
            local tile = spell:get_current_tile()
            if doonce then
                anim:set_state("FIRE")
                anim:set_playback(Playback.Loop)
                firetimer = true
                print("firing...")
                cursormove = false
                doonce = false
            end
        end
        if firetimer == true then
            firecount = firecount + 1
            --spell:highlight_tile(Highlight.Solid)
            if firecount % 15 == 0 then
                --play sound effect
                Engine.play_audio(targetsound, AudioPriority.High)
            end
            if firecount == 21 then
                --play sound effect
                Engine.play_audio(shotsound, AudioPriority.High)
                yettofire = false
            end
            if firecount % 40 == 0 then
                local tile = spell:get_current_tile()
                Engine.play_audio(blastsound, AudioPriority.High)
                local attack1 = create_atk(user, tile, props, 2)
                self:get_field():spawn(attack1, tile)
                if tile:is_walkable() then
                    if tile:get_state() == TileState.Cracked then
                        tile:set_state(TileState.Broken)
                    else
                        tile:set_state(TileState.Cracked)
                    end
                end
                self:erase()
                
            end
        end

    end
    spell.collision_func = function(self, other)
        --a
        spell:erase()
        
    end
    spell.attack_func = function(self, other)
        --Engine.play_audio(HIT_AUDIO, AudioPriority.Low)
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    return spell
end

function create_atk(user, tile, props, animtype)

    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    -- make it crack panels
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    local sprite = spell:sprite()
    sprite:set_texture(explodetexture)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(explodeanim)
    if animtype == 1 then 
        anim:set_state("TYPEA")
        --print("typea")
    elseif animtype == 2 then
        anim:set_state("TYPEB")
        --print("typeb")
    else
        anim:set_state("TYPEA")
        print("default safeguard")
    end
    anim:refresh(spell:sprite())
    anim:on_complete(function()

        spell:erase()
    end)
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end



    return spell
end