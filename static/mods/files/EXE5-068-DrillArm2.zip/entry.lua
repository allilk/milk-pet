local DAMAGE = 70

local TEXTURE_DRILLARM = Engine.load_texture(_modpath.."drillarm.png")
local ANIMPATH_DRILLARM = _modpath.."drillarm.animation"
local AUDIO_DRILLARM = Engine.load_audio(_modpath.."drillarm.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-068-DrillArm2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"D","L","S"})

    local props = package:get_card_props()
    props.shortname = "DrilArm2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Break
    props.description = "Knocks enmy 2sq away"
    props.long_description = "Drill attacks 2 squares in front of you! Knocks the enemy away!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

local frame1 = {1, 0.05}
local frame2 = {1, 0.017}
local frame3 = {1, 0.153}
local frame_data = make_frame_data({
    frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame2, frame3
})

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset_1 = nil
        local X_offset_2 = nil

        if direction == Direction.Right then
            X_offset_1 = X + 1
            X_offset_2 = X + 2
        else
            X_offset_1 = X - 1
            X_offset_2 = X - 2
        end

        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(TEXTURE_DRILLARM, true)
		buster_sprite:set_layer(-2)

        local buster_anim = buster:get_animation()
        buster_anim:load(ANIMPATH_DRILLARM, true)
		buster_anim:set_state("0")
        buster_anim:refresh(buster_sprite)

        self:add_anim_action(1, function()
            Engine.play_audio(AUDIO_DRILLARM, AudioPriority.High)
            user:toggle_counter(true)
        end)

        self:add_anim_action(3, function()
            create_drillarm_1(user, props, team, direction, field, X_offset_1, Y)
            create_drillarm_2(user, props, team, direction, field, X_offset_2, Y)
		end)

        self:add_anim_action(4, function()
            user:toggle_counter(false)
		end)

        self:add_anim_action(7, function()
            create_drillarm_1(user, props, team, direction, field, X_offset_1, Y)
            create_drillarm_2(user, props, team, direction, field, X_offset_2, Y)
		end)

        self:add_anim_action(11, function()
            create_drillarm_1(user, props, team, direction, field, X_offset_1, Y)
            create_drillarm_2(user, props, team, direction, field, X_offset_2, Y)
		end)
    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

function create_drillarm_1(owner, props, team, direction, field, spell_X, spell_Y)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Impact | Hit.Drag | Hit.Breaking,
            props.element,
            owner:get_context(),
            Drag.new(direction, 2)
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
        spell:shake_camera(3, 0.33)
    end

    field:spawn(spell, spell_X, spell_Y)

    return spell
end

function create_drillarm_2(owner, props, team, direction, field, spell_X, spell_Y)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Impact | Hit.Drag | Hit.Breaking,
            props.element,
            owner:get_context(),
            Drag.new(direction, 1)
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
        spell:shake_camera(3, 0.33)
    end

    field:spawn(spell, spell_X, spell_Y)

    return spell
end