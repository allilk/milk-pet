nonce = function() end
local AUDIO1 = Engine.load_audio(_modpath.."PanelFinalChange.ogg")
local AUDIO2 = Engine.load_audio(_modpath.."PanalChange.wav")

function package_init(package) 
	package:declare_package_id("com.ShrekXL.card.IceLine")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"B","E","J","N","Q","*"})

	local props = package:get_card_props()
	props.shortname = "IceLine"
	props.time_freeze = true
	props.element = Element.Aqua
	props.description = "Changes your line to ice"
	props.limit = 5
end


function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	
	action.execute_func = function(self, user)
		local c_tile = actor:get_current_tile()
		local c_row = c_tile:y()
		local panel1 = user:get_field():tile_at( 1, c_row )
		local panel2 = user:get_field():tile_at( 2, c_row )
		local panel3 = user:get_field():tile_at( 3, c_row )
		local panel4 = user:get_field():tile_at( 4, c_row )
		local panel5 = user:get_field():tile_at( 5, c_row )
		local panel6 = user:get_field():tile_at( 6, c_row )
		
		
		
		local k = 0
		local cooldown = 0
		local step1 = Battle.Step.new()
		step1.update_func = function(self, dt)
			if cooldown <= 0 then
				k = k + 1
				cooldown = 0.05
				Engine.play_audio(AUDIO2, AudioPriority.Low)
				if user:get_tile():get_state() == TileState.Ice then
					panel1:set_state(TileState.Normal)
					panel2:set_state(TileState.Normal)
					panel3:set_state(TileState.Normal)
					panel4:set_state(TileState.Normal)
					panel5:set_state(TileState.Normal)
					panel6:set_state(TileState.Normal)
					
				else
					panel1:set_state(TileState.Ice)
					panel2:set_state(TileState.Ice)
					panel3:set_state(TileState.Ice)
					panel4:set_state(TileState.Ice)
					panel5:set_state(TileState.Ice)
					panel6:set_state(TileState.Ice)
					
				end
			else
				cooldown = cooldown - dt
			end
			
			if k == 14 then
				self:complete_step()
			end	
		end
		self:add_step(step1)		
		
		panel1:set_state(TileState.Ice)
		panel2:set_state(TileState.Ice)
		panel3:set_state(TileState.Ice)
		panel4:set_state(TileState.Ice)
		panel5:set_state(TileState.Ice)
		panel6:set_state(TileState.Ice)
		Engine.play_audio(AUDIO1, AudioPriority.Low)
	end
	return action
end