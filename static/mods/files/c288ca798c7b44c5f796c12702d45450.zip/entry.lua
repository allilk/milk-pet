local DAMAGE = 200

local MAGMADRAGON_TEXTURE = Engine.load_texture(_modpath.."magmadragon.png")
local MAGMADRAGON_ANIMPATH = _modpath.."magmadragon.animation"
local FLAME_TEXTURE = Engine.load_texture(_modpath.."flame.png")
local FLAME_ANIMPATH = _modpath.."flame.animation"
local FLAME_AUDIO = Engine.load_audio(_modpath.."exe2-magmadragon-flame.ogg")
local AREASTEAL_AUDIO = Engine.load_audio(_modpath.."exe2-areasteal.ogg")
local SPAWN_AUDIO = Engine.load_audio(_modpath.."exe2-spawn.ogg")

local HIT_TEXTURE = Engine.load_texture(_modpath.."guard_hit.png")
local HIT_ANIMPATH = _modpath.."guard_hit.animation"
local HIT_AUDIO = Engine.load_audio(_modpath.."exe2-tink.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-111-MagmaDragon")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F","G","O","R","Y"})

    local props = package:get_card_props()
    props.shortname = "MagmDrag"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Summons     a Magma Dragon!"
    props.long_description = "Summon a Magma Dragon from the hole in front of you!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()
        local spawn_tile = user:get_tile(direction, 1)

        local tile_array = {}
        local query = function(ent)
			if not user:is_team(ent:get_team()) then
				return true
			end
		end
		for i = 1, 6, 1 do
			for j = 1, 3, 1 do
				local tile = field:tile_at(i, j)
                if #tile:find_characters(query) > 0 then
					table.insert(tile_array, tile)
				end
			end
		end

		local step1 = Battle.Step.new()

        self.navi = nil
        self.hits = 23
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_2 = true
        local do_once_3 = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
		    	ref.navi:sprite():set_texture(MAGMADRAGON_TEXTURE, true)
		    	ref.navi:sprite():set_layer(-3)
                ref.navi:set_offset(0.0, -356.0)

                local anim = ref.navi:get_animation()
                anim:load(MAGMADRAGON_ANIMPATH)
                anim:set_state("DELAY1")
                anim:set_playback(Playback.Loop)
		    	anim:refresh(ref.navi:sprite())
		    	anim:on_complete(function()
                    print("Sphere spawned")
                    Engine.play_audio(AREASTEAL_AUDIO, AudioPriority.High)
		    		anim:set_state("SPHERE")
		    		anim:refresh(ref.navi:sprite())
		    	end)
                field:spawn(ref.navi, spawn_tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "SPHERE" then
                if ref.navi:get_offset().y >= -13 then
                    if do_once_2 then
                        do_once_2 = false
                        ref.navi:set_offset(0.0, 0.0)
                        if spawn_tile:is_hole() then
                            print("Spawn tile IS a hole!")
                            print("MagmaDragon spawned")
                            Engine.play_audio(SPAWN_AUDIO, AudioPriority.Highest)
		    		        anim:set_state("MAGMADRAGON_SPAWN")
		    		        anim:refresh(ref.navi:sprite())
                        else
                            print("Spawn tile is NOT a hole!")
                            Engine.play_audio(HIT_AUDIO, AudioPriority.Highest)
                            create_effect(HIT_TEXTURE, HIT_ANIMPATH, "0", 0, 0, field, spawn_tile)
                            anim:set_state("DELAY2")
		    		        anim:refresh(ref.navi:sprite())
                            anim:on_complete(function()
                                ref.navi:erase()
                                step1:complete_step()
                            end)
                        end
                    end
                else
                    ref.navi:set_offset(0.0, ref.navi:get_offset().y + 13.0)
                end
            end
            if anim:get_state() == "MAGMADRAGON_SPAWN" then
		    	anim:on_complete(function()
		    		anim:set_state("MAGMADRAGON_ATTACK")
		    		anim:refresh(ref.navi:sprite())
		    	end)
            end
            if anim:get_state() == "MAGMADRAGON_ATTACK" then
                if do_once_3 then
                    do_once_3 = false
                    anim:on_frame(1, function()
                        if ref.hits == 23 then
                            Engine.play_audio(FLAME_AUDIO, AudioPriority.High)
                            for k = 1, #tile_array, 1 do
                                create_flash(user, props, team, direction, field, tile_array[k])
                            end
                        end
                    end)
		    	    anim:on_complete(function()
                        if ref.hits > 1 then
                            anim:set_playback(Playback.Loop)
                            ref.hits = ref.hits - 1
                        else
                            anim:set_state("MAGMADRAGON_DELETE")
                            anim:refresh(ref.navi:sprite())
                            anim:on_complete(function()
                                ref.navi:erase()
                                step1:complete_step()
                            end)
                        end
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_flash(user, props, team, direction, field, tile)
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Flash)
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_frame(2, function()
        create_flame(user, props, team, direction, field, tile)
    end)
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    field:spawn(spell, tile)

    print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end

function create_flame(user, props, team, direction, field, tile)
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Shake, 
            props.element,
            user:get_id(), 
            Drag.None
        )
    )
    spell.attacking = false
    spell.hits = 9
    local sprite = spell:sprite()
    sprite:set_texture(FLAME_TEXTURE, true)
    sprite:set_layer(-3)
    local anim = spell:get_animation()
    anim:load(FLAME_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    local do_once = true
    local do_once_2 = true

    spell.update_func = function(self, dt)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if anim:get_state() == "0" then
            anim:on_complete(function()
                anim:set_state("1")
                anim:refresh(sprite)
            end)
        end
        if anim:get_state() == "1" then
            self.attacking = true
            if do_once then
                anim:on_complete(function()
		    		if self.hits > 1 then
		    			anim:set_playback(Playback.Loop)
		    			self.hits = self.hits - 1
		    		else
                        anim:set_state("2")
                        anim:refresh(sprite)
		    		end
		    	end)
            end
        end
        if anim:get_state() == "2" then
            anim:on_complete(function()
                self:erase()
            end)
        end
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    field:spawn(spell, tile)

	return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end