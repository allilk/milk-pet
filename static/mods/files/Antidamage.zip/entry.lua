function package_init(package) 
    package:declare_package_id("com.Dawn.CardBN6.189")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_codes({'G', 'R', 'V', '*'}) --The codes the chip comes in.
  
    local props = package:get_card_props()
    props.shortname = "AntiDmg"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.None
    props.description = "Sets trap and throw a star"
    props.limit = 3
	props.card_class = CardClass.Standard
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local new_props = action:copy_metadata()
    new_props.shortname = "????"
    action:set_metadata(new_props)
    action:set_lockout(make_sequence_lockout()) --Sequence lockout required to use steps & avoid issues with idle
    action.execute_func = function(self, user)
        local step1 = Battle.Step.new()
        local antidamage_rule = Battle.DefenseRule.new(777, DefenseOrder.CollisionOnly) -- Keristero's Guard is 0
        antidamage_rule.has_blocked = false
        local field = user:get_field()
        antidamage_rule.can_block_func = function(judge, attacker, defender)
            local hit_props = attacker:copy_hit_props()
            local temp_action = poof_user(user, field:get_entity(hit_props.aggressor), props)
            if temp_action ~= nil then antidamage_rule.second_action = temp_action else return end
            if hit_props.element == Element.Cursor then defender:remove_defense_rule(antidamage_rule) return end --Simulate cursor removing traps
            if hit_props.damage >= 10 then
                judge:block_damage()
                if not antidamage_rule.has_blocked then
                    Battle.Player.from(defender):card_action_event(antidamage_rule.second_action, ActionOrder.Involuntary)
                    defender:remove_defense_rule(antidamage_rule)
                end
            end
        end
        step1.update_func = function(self, dt)
            user:add_defense_rule(antidamage_rule)
            self:complete_step()
        end
        self:add_step(step1)
    end
    return action
end

function poof_user(user, aggressor, props)
    if user:is_deleted() or aggressor == nil then return nil end
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local spell_texture = Engine.load_texture(_folderpath.."shuriken.png")
    local field = user:get_field()
    local tile = targeting(user, aggressor, field)
    if tile == nil then
        print("FUCK")
        return action
    end
    local spell = create_shuriken_spell(user, spell_texture, props, tile)
    action:set_lockout(make_sequence_lockout()) --Sequence lockout required to use steps & avoid issues with idle
    action.execute_func = function(self, user)
        local step1 = Battle.Step.new()
        local fx = Battle.ParticlePoof.new()
        user:hide()
        user:toggle_hitbox(false)
        field:spawn(fx, user:get_tile())
        field:spawn(spell, user:get_tile())
        local cooldown = 60
        step1.update_func = function(self, dt)
            if cooldown > 0 then cooldown = cooldown - 1 return end
            user:reveal()
            user:toggle_hitbox(true)
            self:complete_step()
        end
        self:add_step(step1)
    end
    return action
end

function create_shuriken_spell(user, texture, props, desired_tile)
    if user:is_deleted() then return Battle.Spell.new(Team.Other) end
    local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            Element.Sword, --Change to props.element later and set secondary element.
            user:get_context(),
            Drag.None
        )
    )
    desired_tile:highlight(Highlight.Flash)
    spell.slide_rate = 8
    local y = 192
    local user_tile = user:get_tile()
    local distance = math.abs((user_tile:x() + user_tile:y()) - (desired_tile:x() + desired_tile:y())) * 8
    print(distance)
    spell.increment_y = math.floor(y/distance)
    print(spell.increment_y)
    local field = user:get_field()
    spell:set_offset(spell:get_offset().x, spell:get_offset().y-y)
    spell.animate_once = true
    spell.dest = desired_tile
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.update_func = function(self, dt)
        if not self:is_sliding() then
            local ref = self
            self:slide(self.dest, frames(self.slide_rate), frames(0), ActionOrder.Voluntary, nil)
        end
        if self:get_tile() == self.dest and self.dest:is_walkable() then
            self:get_tile():attack_entities(self)
            if self.animate_once then
                self.animate_once = false
                local fx = Battle.Spell.new(self:get_team())
                fx:set_texture(texture)
                local fx_anim = fx:get_animation()
                fx_anim:load(_folderpath.."shuriken.animation")
                fx_anim:set_state("SHINE")
                fx_anim:on_frame(5, function()
                    fx:hide()
                end)
                fx_anim:on_frame(7, function()
                    fx:reveal()
                end)
                fx_anim:on_frame(9, function()
                    fx:hide()
                end)
                fx_anim:on_frame(11, function()
                    fx:reveal()
                end)
                fx_anim:on_complete(function()
                    fx:erase()
                end)
                field:spawn(fx, self.dest)
            end
            self:erase()
        end
    end
    return spell
end

function targeting(user, target, field)
    local tile
    if not target or target and target:is_deleted() then 
        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)
        if #enemy_list > 0 then tile = enemy_list[1]:get_current_tile() else tile = nil end
    else
        tile = target:get_tile()
    end
    if not tile then 
        return nil
    end
    return tile
end