function package_init(package)
    package:declare_package_id("com.mars.card.PoisSeed") -- remember to choose a unique package id
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'*'})
 
    local props = package:get_card_props()
    props.shortname = "PoisSeed"
    props.damage = 10           -- seeds deal 10 damage when they directly hit something
    props.can_boost = false     -- but the damage value can't be increased by other chips!
    props.time_freeze = false
    props.element = Element.None
    props.description = "Makes 9sq poisn swp 3sq ahead"
    -- The long description will show up on the mod website, so make sure to edit it before releasing your chip.
    props.long_description = "PoisSeed from the seed template" 
    props.limit = 3
end


--[[
     OPTIONAL: Do you want every single affected tile to be a different TileState?
    If so then you can populate this table with the desired values and then 
    pass along the table.
    Syntax: panel_type_to_create = 17

    The tiles on the field are changed in this order, with each bracket representing a tile on a 3x3 field.
    [5][2][8]
    [4][1][7]
    [6][3][9]
]]
-- you will probably want to explicitly write out the named Enums for the TileState values
-- instead of trying to remember what the number values are.
local unique_combos = {
    -- left column, top to bottom
    [5] = TileState.Ice ,
    [4] = TileState.Grass ,
    [6] = TileState.Lava ,
    -- middle column, top to bottom
    [2] = TileState.Poison ,
    [1] = TileState.Holy ,
    [3] = TileState.Volcano ,
    -- right column, top to bottom
    [8] = TileState.Lava ,
    [7] = TileState.Grass ,
    [9] = TileState.Ice ,
}


--[[ 
    This is a list of all the panel types that exist in the game so far. 
    You can select which panel type the seed will change the panels to by 
    using one of the numbers in brackets, for example [4] points to Ice panels.
    So you can choose Ice panels by assigning panel_type_to_create = 4

    Note: the color of the seed while it's being thrown is also decided by this value.
    Every valid panel has a seed color assigned to it.
    So you don't need to manually provide the seed sprite or the value for its color.
]]
panel_type_to_create = 7  -- change me!

local panel_type = {
    -- null types
    [1] = TileState.Normal,
    [2] = TileState.Cracked,
    [3] = TileState.Broken,
    -- element types
    [4] = TileState.Ice,
    [5] = TileState.Grass,
    [6] = TileState.Lava,
    [7] = TileState.Poison,
    [8] = TileState.Holy,
    [9] = TileState.Volcano,
    -- conveyors
    [10] = TileState.DirectionDown,
    [11] = TileState.DirectionUp,
    [12] = TileState.DirectionLeft,
    [13] = TileState.DirectionRight,
    -- permahole 
    [14] = TileState.Empty,
    -- invisible permahole
    [15] = TileState.Hidden,
    -- cursed and evil "chaotic randomness" option
    [16] = 666,
    -- unique panel types for each tile, make sure to fill out the unique_combos table
    [17] = unique_combos,
}

--[[
    OPTIONAL: Do you want to affect tiles in a specific shape that isn't the full 3x3 grid?
    Using the above field diagram as a reference for the order that tiles are changed, 
    you can enter values into this table to make it skip specific tiles, indicated by the 
    order in which the tile is affected.
    Just populate this table with your desired values. It will handle the rest.
    Example: skip_tiles = {5,6,8,9}
    This will make it spread panels in a plus shape (+) instead of the full 3x3 square.
]]
local skip_tiles = {}


-- Nothing below this line needs to be edited.

local seed = include('seed.lua')

-- It passes along the panel type here, this will be the type of panel it creates. 
-- It uses the variable that we defined right before creating the table full of panel values.
seed.panel_type = panel_type[panel_type_to_create]
seed.card_props = props
seed.skip_tiles = skip_tiles
local run_at_start = seed.set_seed_palette(seed.panel_type)

card_create_action = seed.card_create_action
