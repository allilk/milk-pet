local DAMAGE = 260

local NIGHTMARE_TEXTURE = Engine.load_texture(_modpath.."nightmare.png")
local NIGHTMARE_ANIMPATH = _modpath.."nightmare.animation"
local SLASH_TEXTURE = Engine.load_texture(_modpath.."slash.png")
local SLASH_ANIMPATH = _modpath.."slash.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_NIGHTMARE_SPAWN = Engine.load_audio(_modpath.."nightmare_spawn.ogg")
local AUDIO_NIGHTMARE_SLASH = Engine.load_audio(_modpath.."nightmare_slash.ogg")

local WARP_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local WARP_ANIMPATH = _modpath.."mob_move.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = true

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-102-SummonBlack3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"W","Y","Z"})

    local props = package:get_card_props()
    props.shortname = "SumnBlk3"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Summon Darkmare from hole"
    props.long_description = "Summon Darkmare from the hole in front and cut the nearest target"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 2
end

function card_create_action(user, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local front_tile = user:get_tile(direction,1)

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)
        local target_tile = enemy_list[1]:get_tile(Direction.reverse(direction),1)
        if not target_tile then
            return
        end

        local dark_query = function(o)
            return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
        end

		local step1 = Battle.Step.new()

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                local blocked = false
                local hitbox1 = create_attack(user, props, team, direction)
                local hitbox2 = create_attack(user, props, team, direction)
                local hitbox3 = create_attack(user, props, team, direction)
                local slash_fx = Battle.Artifact.new()
                slash_fx:set_facing(direction)
                local slash_sprite = slash_fx:sprite()
                slash_sprite:set_texture(SLASH_TEXTURE)
                slash_sprite:set_layer(-9)
                local slash_anim = slash_fx:get_animation()
                slash_anim:load(SLASH_ANIMPATH)
                slash_anim:set_state("0")
                slash_anim:refresh(slash_sprite)
                slash_anim:on_frame(1, function()
                    field:spawn(hitbox1, slash_fx:get_tile(Direction.Up,1))
                    field:spawn(hitbox2, slash_fx:get_current_tile())
                    field:spawn(hitbox3, slash_fx:get_tile(Direction.Down,1))
                end)
                slash_anim:on_complete(function()
                    hitbox1:erase()
                    hitbox2:erase()
                    hitbox3:erase()
		    		slash_fx:delete()
		    	end)
                local nightmare2 = Battle.Artifact.new()
                nightmare2:set_facing(direction)
                local nightmare2_sprite = nightmare2:sprite()
                nightmare2_sprite:set_texture(NIGHTMARE_TEXTURE)
                nightmare2_sprite:set_layer(-3)
                local nightmare2_anim = nightmare2:get_animation()
                nightmare2_anim:load(NIGHTMARE_ANIMPATH)
                nightmare2_anim:set_state("1")
                nightmare2_anim:refresh(nightmare2_sprite)
                nightmare2_anim:on_frame(1, function()
                    if SHOW_DEBUG_TEXT then
                        print("TARGED LOCKED")
                    end
                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "3", 0, -10, field, target_tile)
		    	end)
                nightmare2_anim:on_frame(7, function()
                    Engine.play_audio(AUDIO_NIGHTMARE_SLASH, AudioPriority.High)
                    field:spawn(slash_fx, nightmare2:get_tile(direction, 1))
                end)
                nightmare2_anim:on_frame(10, function()
                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -10, field, target_tile)
                end)
		    	nightmare2_anim:on_complete(function()
		    		nightmare2:delete()
                    step1:complete_step()
		    	end)
                local nightmare1 = Battle.Artifact.new()
                nightmare1:set_facing(direction)
                local nightmare1_sprite = nightmare1:sprite()
                nightmare1_sprite:set_texture(NIGHTMARE_TEXTURE)
                nightmare1_sprite:set_layer(-3)
                local nightmare1_anim = nightmare1:get_animation()
                nightmare1_anim:load(NIGHTMARE_ANIMPATH)
                nightmare1_anim:set_state("0")
                nightmare1_anim:refresh(nightmare1_sprite)
                nightmare1_anim:on_frame(5, function()
                    Engine.play_audio(AUDIO_NIGHTMARE_SPAWN, AudioPriority.High)
                end)
		    	nightmare1_anim:on_frame(15, function()
                    create_effect(WARP_TEXTURE, WARP_ANIMPATH, "2", 0, -10, field, front_tile)
                    if #target_tile:find_entities(dark_query) <= 0 then
                        field:spawn(nightmare2, target_tile)
                    else
		    		    blocked = true
                    end
		    	end)
                nightmare1_anim:on_complete(function()
		    		nightmare1:delete()
                    if blocked then
                        step1:complete_step()
                    end
		    	end)
                if front_tile:is_hole() then
                    if SHOW_DEBUG_TEXT then
                        print("The front tile IS a hole!")
                        print("Darkmare spawned")
                    end
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                    field:spawn(nightmare1, front_tile)
                else
                    if SHOW_DEBUG_TEXT then
                        print("The front tile is NOT a hole!")
                    end
                    step1:complete_step()
                end
            end
        end
        self:add_step(step1)
    end
	return action
end

function create_attack(owner, props, team, direction)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:set_hit_props(HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        Element.Sword, 
        owner:get_id(), 
        Drag.new())
    )

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-9)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end