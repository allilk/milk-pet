local DAMAGE = 140

local PIKARAA_TEXTURE = Engine.load_texture(_modpath.."pikaraa.png")
local PIKARAA_ANIMPATH = _modpath.."pikaraa.animation"
local AUDIO_PIKARAA_FALL = Engine.load_audio(_modpath.."pikaraa_fall.ogg")
local AUDIO_PIKARAA_ATTACK = Engine.load_audio(_modpath.."thunder.ogg")
local THUNDERBALL_TEXTURE = Engine.load_texture(_modpath.."thunderball.png")
local THUNDERBALL_ANIMPATH = _modpath.."thunderball.animation"

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-101-InazumaKing3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A","H","V"})

    local props = package:get_card_props()
    props.shortname = "LghtKng3"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Pikaraaza cross atk 3sq ahd!"
    props.long_description = "Pikaraaza appears 3 squares ahead! Cross electric discharge"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(1.000))
    local override_frames = {{1,0.015}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local spawn_tile = user:get_tile(direction, 3)

        self:add_anim_action(1,function()
            print("Pikaraaza spawned at tile ("..spawn_tile:x()..";"..spawn_tile:y()..")")
            spawn_pikaraa(user, props, team, direction, field, spawn_tile)
        end)
    end
    return action
end

function spawn_pikaraa(owner, props, team, direction, field, pikaraa_tile)
    local pikaraa = Battle.Spell.new(team)
    pikaraa:set_facing(direction)
    local pikaraa_sprite = pikaraa:sprite()
    pikaraa_sprite:set_layer(-2)
    pikaraa_sprite:set_texture(PIKARAA_TEXTURE, true)
    local pikaraa_anim = pikaraa:get_animation()
    pikaraa_anim:load(PIKARAA_ANIMPATH)
    pikaraa_anim:set_state("0")
    pikaraa_anim:refresh(pikaraa_sprite)
    pikaraa:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            owner:get_context(),
            Drag.None
        )
    )
    local pikaraa_attack = false

    pikaraa_anim:on_frame(5, function()
        Engine.play_audio(AUDIO_PIKARAA_FALL, AudioPriority.High)
    end)
    pikaraa_anim:on_frame(43, function()
        Engine.play_audio(AUDIO_PIKARAA_ATTACK, AudioPriority.High)
        create_thunderball(owner, props, pikaraa:get_tile(Direction.Up, 1), team, Direction.Up, field)
        create_thunderball(owner, props, pikaraa:get_tile(Direction.Down, 1), team, Direction.Down, field)
        create_thunderball(owner, props, pikaraa:get_tile(Direction.Left, 1), team, Direction.Left, field)
        create_thunderball(owner, props, pikaraa:get_tile(Direction.Right, 1), team, Direction.Right, field)
    end)
    pikaraa_anim:on_complete(function()
        pikaraa:erase()
    end)

    pikaraa.update_func = function(self, dt)
        pikaraa_anim:on_frame(36, function()
            pikaraa_attack = true
        end)
        pikaraa_anim:on_frame(53, function()
            pikaraa_attack = false
        end)
        if pikaraa_attack then
            self:get_current_tile():attack_entities(self)
        end
    end

    pikaraa.collision_func = function(self, other)
		self:erase()
	end

    pikaraa.can_move_to_func = function(tile)
		return true
	end

    --[[pikaraa.battle_end_func = function(self)
		self:delete()
	end]]

    pikaraa.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "ELEC", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

    field:spawn(pikaraa, pikaraa_tile)

    return pikaraa
end

function create_thunderball(owner, props, tile, team, new_dir, field)
    local spawn_next
    spawn_next = function()
        if tile == nil or tile:is_edge() or tile:get_team() == team then return end

        local spell = Battle.Spell.new(team)
        local spell_sprite = spell:sprite()
        spell_sprite:set_layer(-5)
        spell_sprite:set_texture(THUNDERBALL_TEXTURE, true)
        local spell_anim = spell:get_animation()
        spell_anim:load(THUNDERBALL_ANIMPATH)
        spell_anim:set_state("0")
        spell_anim:refresh(spell_sprite)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element, 
            owner:get_context(), 
            Drag.new())
        )

        spell_anim:on_frame(11, function()
            tile = tile:get_tile(new_dir, 1)
            spawn_next()
        end, true)
        spell_anim:on_complete(function() spell:erase() end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "ELEC", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end