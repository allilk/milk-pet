local DAMAGE = 0

local TEXTURE_THUNDER = Engine.load_texture(_modpath.."thunder.png")
local ANIMPATH_THUNDER = _modpath.."thunder.animation"
local ANIMPATH_ATTACK = _modpath.."attack.animation"
local AUDIO_RYOUSEIBAI = Engine.load_audio(_modpath.."ryouseibai.ogg")

local TEXTURE_FLASH = Engine.load_texture(_modpath.."flash.png")
local ANIMPATH_FLASH = _modpath.."flash.animation"

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE3-294-Ryouseibai")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"Y"})

    local props = package:get_card_props()
    props.shortname = "Balance"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Both HP reduced by half!"
    props.long_description = "Both sides are losing half their HP due to the falling heavens!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		--actor:hide()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local offset_tile = user:get_tile(direction, 3)

		local step1 = Battle.Step.new()

        self.ryouseibai = nil
        self.tile       = user:get_current_tile()

        local check = function(c)
            return Battle.Character.from(c) ~= nil or Battle.Player.from(c) ~= nil
        end

        local ref = self
        local do_once = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.ryouseibai = Battle.Artifact.new()
                ref.ryouseibai:set_facing(direction)

                ryouseibai_anim = ref.ryouseibai:get_animation()
                ryouseibai_anim:load(ANIMPATH_ATTACK)
                ryouseibai_anim:set_state("0")
		    	ryouseibai_anim:refresh(ref.ryouseibai:sprite())
                ryouseibai_anim:on_frame(1, function()
                    Engine.play_audio(AUDIO_RYOUSEIBAI, AudioPriority.High)
                    ref.ryouseibai:shake_camera(30, 1.3)
                    create_flashlight(field)
                    ryouseibai_thunder(field, 5, 2)
                end)
                ryouseibai_anim:on_frame(2, function()
                    ryouseibai_thunder(field, 1, 2)
                end)
                ryouseibai_anim:on_frame(3, function()
                    ryouseibai_thunder(field, 6, 3)
                end)
                ryouseibai_anim:on_frame(4, function()
                    ryouseibai_thunder(field, 6, 1)
                end)
                ryouseibai_anim:on_frame(5, function()
                    ryouseibai_thunder(field, 5, 3)
                end)
                ryouseibai_anim:on_frame(6, function()
                    ryouseibai_thunder(field, 5, 1)
                end)
                ryouseibai_anim:on_frame(7, function()
                    ryouseibai_thunder(field, 6, 2)
                end)
                ryouseibai_anim:on_frame(8, function()
                    ryouseibai_thunder(field, 2, 3)
                end)
                ryouseibai_anim:on_frame(9, function()
                    ryouseibai_thunder(field, 4, 1)
                end)
                ryouseibai_anim:on_frame(10, function()
                    ryouseibai_thunder(field, 4, 2)
                end)
                ryouseibai_anim:on_frame(11, function()
                    ryouseibai_thunder(field, 3, 1)
                end)
                ryouseibai_anim:on_frame(12, function()
                    ryouseibai_thunder(field, 1, 1)
                end)
                ryouseibai_anim:on_frame(13, function()
                    ryouseibai_thunder(field, 2, 1)
                end)
                ryouseibai_anim:on_frame(14, function()
                    ryouseibai_thunder(field, 3, 2)
                end)
                ryouseibai_anim:on_frame(15, function()
                    ryouseibai_thunder(field, 3, 1)
                end)
                ryouseibai_anim:on_frame(16, function()
                    ryouseibai_thunder(field, 2, 2)
                end)
                ryouseibai_anim:on_frame(17, function()
                    ryouseibai_thunder(field, 3, 3)
                end)
                ryouseibai_anim:on_frame(18, function()
                    ryouseibai_thunder(field, 4, 3)
                end)
                ryouseibai_anim:on_frame(19, function()
                    ref.ryouseibai:shake_camera(30, 1.3)
                    create_flashlight(field)
                end)
                ryouseibai_anim:on_frame(20, function()
                    create_flashlight(field)
                    ryouseibai_thunder(field, 1, 3)
                    for i = 1, 6, 1 do
                        for j = 1, 3, 1 do
                            local tile = field:tile_at(i, j)
                            local list = tile:find_entities(check)
                            if #list > 0 then
                                for i = 1, #list, 1 do
                                    local target = list[i]
                                    target:set_health(math.floor(target:get_health()/2))
                                end
                            end
                        end
                    end
                end)
                ryouseibai_anim:on_frame(21, function()
                    ryouseibai_thunder(field, 4, 2)
                end)
                ryouseibai_anim:on_frame(22, function()
                    ryouseibai_thunder(field, 1, 1)
                end)
                ryouseibai_anim:on_frame(23, function()
                    ryouseibai_thunder(field, 4, 1)
                end)
                ryouseibai_anim:on_frame(24, function()
                    ryouseibai_thunder(field, 3, 2)
                end)
                ryouseibai_anim:on_frame(25, function()
                    ryouseibai_thunder(field, 5, 2)
                end)
                ryouseibai_anim:on_frame(26, function()
                    ryouseibai_thunder(field, 5, 1)
                end)
                ryouseibai_anim:on_frame(27, function()
                    ryouseibai_thunder(field, 2, 2)
                end)
                ryouseibai_anim:on_frame(28, function()
                    ryouseibai_thunder(field, 5, 3)
                end)
                ryouseibai_anim:on_frame(29, function()
                    ryouseibai_thunder(field, 2, 1)
                end)
                ryouseibai_anim:on_frame(30, function()
                    ryouseibai_thunder(field, 6, 1)
                end)
                ryouseibai_anim:on_frame(31, function()
                    ryouseibai_thunder(field, 6, 3)
                end)
                ryouseibai_anim:on_frame(32, function()
                    ryouseibai_thunder(field, 3, 1)
                end)
                ryouseibai_anim:on_frame(33, function()
                    ryouseibai_thunder(field, 1, 2)
                end)
                ryouseibai_anim:on_frame(34, function()
                    ryouseibai_thunder(field, 3, 3)
                end)
                ryouseibai_anim:on_frame(35, function()
                    ryouseibai_thunder(field, 6, 2)
                end)
                ryouseibai_anim:on_frame(36, function()
                    ryouseibai_thunder(field, 4, 3)
                end)
                ryouseibai_anim:on_frame(37, function()
                    ryouseibai_thunder(field, 2, 3)
                end)
		    	ryouseibai_anim:on_complete(function()
		    		ref.ryouseibai:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.ryouseibai, ref.tile)
            end
        end
        self:add_step(step1)
    end
	action.action_end_func = function(self)
		--self:get_actor():reveal()
	end
	return action
end

function ryouseibai_thunder(field, X, Y)
    local thunder_fx = Battle.Artifact.new()
	thunder_fx:set_facing(Direction.Right)
    thunder_fx:sprite():set_layer(-3)
    thunder_fx:set_texture(TEXTURE_THUNDER, true)
	local thunder_anim = thunder_fx:get_animation()
	thunder_anim:load(ANIMPATH_THUNDER)
	thunder_anim:set_state("0")
    thunder_anim:on_complete(function()
        thunder_fx:erase()
    end)

    field:spawn(thunder_fx, X, Y)
end

function create_flashlight(field)
    local flashlight = Battle.Artifact.new()
    flashlight:set_facing(Direction.Right)
    flashlight:sprite():set_layer(10)
    flashlight:set_texture(TEXTURE_FLASH, true)
    local flashlight_anim = flashlight:get_animation()
	flashlight_anim:load(ANIMPATH_FLASH)
	flashlight_anim:set_state("0")
	flashlight_anim:refresh(flashlight:sprite())
    flashlight_anim:on_complete(function()
        flashlight:erase()
    end)

    field:spawn(flashlight, 3, 2)
end