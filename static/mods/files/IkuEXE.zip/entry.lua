function package_init(package) 
    package:declare_package_id("com.alrysc.player.IkuEXE")
    package:set_special_description("Tenshi Hinanawi's navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")

end

function player_init(player)
    player:set_name("Iku")
    player:set_health(1000)
    player:set_element(Element.Elec)
    player:set_height(62.0)
    player:set_animation(_modpath.."iku.animation")
    player:set_texture(Engine.load_texture(_modpath.."iku.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -28)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        drill = Engine.load_audio(_modpath.."drill.ogg"),
        thunder = Engine.load_audio(_modpath.."thunder.ogg"),
        bright = Engine.load_audio(_modpath.."bright.ogg")
    }
    

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()
    
        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())
    
        end
    
        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)
    
        anim:set_state(state)
        anim:refresh(graphic:sprite())
    
        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end
    
        return graphic
    end

    local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then

            if attacker:get_name() == "Element.Earth" then 
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 32, 0, "overlay_fx07_animations.png", "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())

            end

        end


    end

    player:add_defense_rule(defense)

    local function dragon_fish_strike(player)
        local action = Battle.CardAction.new(player, "PLAYER_LANCE")

        -- Only two at a time
        local spell_list = {}

        local function attack(tile, num)
            local spell = Battle.Spell.new(player:get_team())
            spell:highlight_tile(Highlight.Solid)


            local hit_props = HitProps.new(
                (10 * player:get_attack_level()),
                Hit.Impact | Hit.Flinch | Hit.Breaking | Hit.Drag,
                Element.Elec, 
                player:get_context(), 
                Drag.new(player:get_facing(), 1)
            )
        
            spell:set_hit_props(hit_props)


            spell.delay = 12
            spell.has_hit = false

            -- I want the spell to hit something, wait 12f, then spawn another one
            -- It clears references to the spells from the last attack, and deletes them at that time
            spell.update_func = function(self)
                local can_hit = true
                
                for i=1, #spell_list
                do
                    can_hit = can_hit and not spell_list[i].has_hit
                end

                if can_hit then
                    self:get_tile():attack_entities(self)
                else

                    self.delay = self.delay - 1

                

                    if spell_list[1].delay <= 0 and spell_list[2].delay <= 0 then 
                        local s = spell_list[1]
                        local s2 = spell_list[2]

                        spell_list = {}
                        if num > 1 then
                            attack(s:get_current_tile(), num-1)
                            attack(s2:get_current_tile(), num-1)

                            s:delete()
                            s2:delete()
                        end
                    end
                end
            end

            spell.attack_func = function()
                Engine.play_audio(player.sounds.hit, AudioPriority.Low)

            end

            spell.collision_func = function(self, other)
                self.has_hit = true
            end


            table.insert(spell_list, spell)
            player:get_field():spawn(spell,tile)
        end

        action.execute_func = function(self)
            self:add_anim_action(2, function()
                local hilt = self:add_attachment("HILT")
                local hilt_sprite = hilt:sprite()
                hilt_sprite:set_texture(player:get_texture())
                hilt_sprite:set_layer(-2)
                hilt_sprite:enable_parent_shader(true)
                
                local hilt_anim = hilt:get_animation()
                hilt_anim:copy_from(player:get_animation())
                hilt_anim:set_state("LANCE")

                hilt_anim:on_frame(2, function()
                    Engine.play_audio(player.sounds.drill, AudioPriority.Low)
                    attack(player:get_tile(player:get_facing(), 1), 3)
                    attack(player:get_tile(player:get_facing(), 2), 3)
                end)

            end)
            
        
        end


        action.action_end_func = function()
            for i=1, #spell_list
            do
                local s = spell_list[i]
                if s and not s:is_deleted() then 
                    s:delete()
                end
            end
        end

        return action
    end

    local function dragon_god_wrath(player)
        if player.bolt_used then return end
        local action = Battle.CardAction.new(player, "DISCO")
        local context = nil
        local field = player:get_field()

        local function find_tile(player)
            local list = field:find_characters(function(c)
                return c:get_team() ~= player:get_team()
            end)
        

            if list[1] then 
                return list[1]:get_current_tile()
            end


            return nil
        end

        local function create_bolt(player, tile)
            local spell = graphic_init("spell", 0, 0, "effects.png", "effects.animation", -5, "LIGHTNING", player, player:get_facing(), true)

            local hit_props = HitProps.new(
                (10 * player:get_attack_level() + 20),
                Hit.Impact | Hit.Flinch | Hit.Stun,
                Element.Elec, 
                context, 
                Drag.None
            )
        
            spell:set_hit_props(hit_props)

            spell:get_animation():on_complete(function()
                spell:delete()
            end)

            spell.on_spawn_func = function()
                Engine.play_audio(player.sounds.thunder, AudioPriority.Low)
            end

            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
            end


            spell.attack_func = function(self, other)
                Engine.play_audio(player.sounds.hit, AudioPriority.Low)

                field:spawn(graphic_init("artifact", 0, 0, "effects.png", "effects.animation", -5, "ELEC_HIT", player, player:get_facing(), true), other:get_current_tile())
            end

            field:spawn(spell, tile)
        end

        local function queue_bolt(player)
            local comp = Battle.Component.new(player, Lifetimes.Battlestep)
            comp.delay = 200
            comp.warning = 20
            comp.target = nil
            comp.update_func = function()
                if player:is_deleted() then 
                    comp:eject()
                    return
                end

                if comp.target then 
                    comp.target:highlight(Highlight.Flash)
                    comp.warning = comp.warning - 1

                    if comp.warning == 0 then 
                        create_bolt(player, comp.target)

                        comp:eject() 
                    end


                    return
                end
                comp.delay = comp.delay - 1


                if comp.delay == 0 then 
                    if not comp.target then 
                        comp.target = find_tile(player)
                        if not comp.target then 
                            local x = field:width()
                            if player:get_facing() == Direction.Left then 
                                x = 1
                            end

                            comp.target = field:tile_at(x, player:get_current_tile():y())
                        end

                    end
                end
            end
            player:register_component(comp)
        end


        action.execute_func = function()
            context = player:get_context()
            action:add_anim_action(3, function()
                queue_bolt(player)
                Engine.play_audio(player.sounds.bright, AudioPriority.Low)
            
                player.bolt_used = true
            end)

        end


        return action
    end



    local function normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.normal_attack_func = normal_attack

    player.charged_attack_func = dragon_fish_strike

    player.special_attack_func = dragon_god_wrath

    player.first = true
    player.turn1 = true
    player.turn1_ = true

    player.bolt_used = false

    player.battle_start_func = function(self)
        self.turn1 = false
        
    end

    player.update_func = function(self)
        if self.first then 
            local turn_checker2 = Battle.Component.new(player, Lifetimes.Scene)

            local turn_checker1 = Battle.Artifact.new()
            turn_checker1.time = 0
            local time2 = 0
            turn_checker1.updated = false
        
            turn_checker1.update_func = function()
                if not turn_checker1.updated then 
                    turn_checker1.time = turn_checker1.time + 1
                    turn_checker1.updated = true
                end

            end
        
            turn_checker2.update_func = function()
                if turn_checker1.updated and time2 ~= turn_checker1.time then 
                    turn_checker1.time = 0
                    time2 = 0
                    if not self.turn1_ then 
                        self.bolt_used = false
                    elseif not self.turn1 then
                        self.turn1_ = false
                    end

                end
                time2 = time2+1
                turn_checker1.updated = false

            end
        
          
            self:register_component(turn_checker2)
            self:get_field():spawn(turn_checker1, 0, 0)

            self.first = false


        
        end


    end
    
    
end