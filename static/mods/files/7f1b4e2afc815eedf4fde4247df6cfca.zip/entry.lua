
local attacktexture = Engine.load_texture(_modpath.."ivythorntexture.png")
local despawntexture = Engine.load_texture(_modpath.."teleport.png")

local shootsound = Engine.load_audio(_modpath.."shoot.ogg")
local hitsound = Engine.load_audio(_modpath.."hurt.ogg")

--rename may be called for
function package_init(package) 
    package:declare_package_id("hoov.cards.thorngun2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon2.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview2.png"))
	package:set_codes({'A','B','C'})

    local props = package:get_card_props()
    props.shortname = "PsnThorn"
    props.damage = 30
    props.time_freeze = false
    props.element = Element.Wood
    props.description = "Burr shot sticks in Enmy"
	props.can_boost = true
    props.limit = 4
end


function card_create_action(self, props)
    print("in create_card_action()!")
    
    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function (self, user)
        local buster = action:add_attachment("Buster")
        buster:sprite():set_texture(user:get_texture(), true)
        buster:sprite():set_layer(-1)
        buster:sprite():enable_parent_shader(true)
      
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        --local direction = user:get_facing()
        local tile = user:get_tile(user:get_facing(), 1)
        

        local shot1 = create_shot(user, tile, props)
        user:get_field():spawn(shot1, tile)
        Engine.play_audio(shootsound, AudioPriority.Low)


    end

    return action
end

function create_shot(user, tile, props)
    print ("Created")
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            user:get_id(),
            Drag.None
        )
    )
    --animation stuff here
    local sprite = spell:sprite()
    sprite:set_texture(attacktexture)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_modpath.."ivythorn.animation")
    anim:set_state("FLY")
    --anim:refresh(spell:sprite())
    anim:set_playback(Playback.Loop)
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell:set_elevation(45)
    local stuck = false
    local direction = user:get_facing()
    local target = nil
    local deletetimer = 0
    local myheight = 45

    spell.collision_func = function(self, other)
        target = other
        stuck = true
        print("hit")
        spell:show_shadow(false)
        Engine.play_audio(hitsound, AudioPriority.Low)
        if target:get_height() < 40 then
            spell:set_elevation(20)
            myheight = 20
        end
        anim:set_state("HIT")
        anim:set_playback(Playback.Loop)
        
        
    end
    spell.attack_func = function(self, other)
        --unused, just leaving here for the sake of the future maybe
    end
    spell.update_func = function (self, dt)
        if stuck == true then
            --print("stuck")
            if spell:get_current_tile() ~= target:get_current_tile() then 
                spell:teleport(target:get_current_tile(), ActionOrder.Immediate, nil)
            end
            if target:is_deleted() then
                spell:erase()
            end
            if deletetimer % 50 == 0 then
                print("damage")
                --self:get_current_tile():attack_entities(self)
                if deletetimer ~= 0 then
                    local hitbox = Battle.Hitbox.new(spell:get_team())
                    hitbox:set_hit_props(spell:copy_hit_props())
                    spell:get_field():spawn(hitbox, spell:get_current_tile())
                end
                Engine.play_audio(hitsound, AudioPriority.Low)
            end
            if deletetimer == 130 then
                local tile = spell:get_current_tile()
                create_poof (user, myheight, tile)
                spell:erase()
            end
            deletetimer = deletetimer + 1

            
        else
            local tile = spell:get_tile(direction, 1)
        
            if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
                --print("erased")
                spell:erase()
            return
            end
            --- Makes the spell slide to the next tile over a certain number of frames.
            spell:slide(tile, frames(4), frames(0), ActionOrder.Voluntary, nil)
            --tilecount = tilecount + 1
            --- Attacks the entities this spell collides with.
            self:get_current_tile():attack_entities(self)
        end
        
    end


    spell.can_move_to_func = function(tile)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end


    return spell
end

function create_poof (user, height, tile)
    local fx = Battle.Artifact.new()
    fx:set_texture(despawntexture, true)
    fx:get_animation():load(_modpath.."teleport.animation")
    fx:get_animation():set_state("SMALL_TELEPORT_TO")
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_height(-16.0)
    print(height)
    fx:set_elevation(height)
    local field = user:get_field()
    --local tile = user:get_current_tile()
    field:spawn(fx, tile)
end