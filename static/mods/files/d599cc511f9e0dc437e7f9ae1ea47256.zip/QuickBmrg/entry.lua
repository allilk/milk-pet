-- Insert imports here..

local BOOMERANG_SOUND = Engine.load_audio(_folderpath .. "boomer.ogg")
local BOOMERANG_SPRITE = Engine.load_texture(_folderpath .. "quickboomer.png")
local BOOMERANG_ANIM = _folderpath .. "quickboomer.animation"
local effects_texture = Engine.load_texture(_folderpath .. "effect.png")
local effects_anim = _folderpath .. "effect.animation"
local quick_buster = Engine.load_texture(_folderpath .. "quickbuster.png")
local quick_buster_anim = _folderpath .. "quickbuster.animation"

local DAMAGE = 90

local quickboomer = {}

function package_init(package)
    local props = package:get_card_props()
    props.shortname = "QuickBmrg"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "QuickM Boomerang Atk!"
    props.long_description = "A boomerang attack that arcs out and returns"
    props.limit = 4
    package:declare_package_id("com.louis.QuickBmrg")
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_codes({ 'C', 'I', 'K', 'Q', 'U' })
end

local frame1 = { 1, 0.033 }
local frame2 = { 2, 0.033 }
local frame3 = { 3, 0.033 }
local frame_data = make_frame_data({
    frame1, frame2, frame3, frame3
})

quickboomer.card_create_action = function(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:override_animation_frames(frame_data)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(quick_buster, true)
        buster:sprite():set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(quick_buster_anim)
        buster_anim:set_state("0")
        self:add_anim_action(2, function()
            local boomer_Hitprops = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                props.element,
                user:get_context(),
                Drag.None
            )
            Engine.play_audio(BOOMERANG_SOUND, AudioPriority.High)
            boomerang(user, boomer_Hitprops)
        end)
    end
    action.action_end_func = function(self)
    end

    return action
end

---Boomerang!
---@param user Entity
function boomerang(user, hit_props)
    local field = user:get_field()
    ---@class Spell
    local spell = Battle.Spell.new(user:get_team())
    local spell_animation = spell:get_animation()
    local start_tile = user:get_tile(user:get_facing(), 1)
    -- Spell Hit Properties
    spell:set_hit_props(hit_props)
    spell:set_facing(user:get_facing())
    spell:set_shadow(Shadow.Small)
    spell:show_shadow(true)
    spell_animation:load(BOOMERANG_ANIM)
    spell_animation:set_state("DEFAULT")
    spell_animation:set_playback(Playback.Loop)
    spell:set_texture(BOOMERANG_SPRITE)
    spell_animation:refresh(spell:sprite())
    spell:sprite():set_layer(-5)
    -- Starting direction is user's facing
    spell.xdirection = user:get_facing()
    spell.ydirection = Direction.Down
    if (user:get_tile():y() == 3) then
        spell.ydirection = Direction.Up
    end
    spell.userfacing = user:get_facing()
    spell.returning = false
    spell.boomer_speed = 6
    local joineddirection = Direction.join(spell.xdirection, spell.ydirection)
    spell.next_tile = start_tile:get_tile(joineddirection, 1)
    spell.update_func = function(self, dt)
        if (spell.returning and spell:get_tile() == start_tile) then
            spell:erase()
        end
        if (is_edgeX(spell.next_tile)) then
            if (spell:get_tile():get_team() == user:get_team()) then
                spell:erase()
            else
                spell.xdirection = Direction.reverse(spell.xdirection)
                spell.returning = true
            end
        end
        if (is_edgeY(spell.next_tile)) then
            spell.ydirection = Direction.reverse(spell.ydirection)
        end
        spell:slide(spell.next_tile, frames(spell.boomer_speed), frames(0), ActionOrder.Voluntary, nil)
        local joineddirection = Direction.join(spell.xdirection, spell.ydirection)
        spell.next_tile = spell:get_current_tile():get_tile(joineddirection, 1)
        spell:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
        spawn_visual_artifact(self:get_field(), self:get_tile(), effects_texture, effects_anim, "8"
            , 0, 0)
        spell:erase()
    end
    spell.attack_func = function(self, other)

    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function is_edgeX(tile)
    return tile == nil or tile:x() < 1 or tile:x() > 6
end

function is_edgeY(tile)
    return tile == nil or tile:y() < 1 or tile:y() > 3
end

-- This function spawns a visual effect that will remove itself once the effect animation completes.
function spawn_visual_artifact(field, tile, texture, animation_path, animation_state, position_x,
                               position_y)
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    anim:refresh(visual_artifact:sprite())
    field:spawn(visual_artifact, tile:x(), tile:y())
end
return quickboomer