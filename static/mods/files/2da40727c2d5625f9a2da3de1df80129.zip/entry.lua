local blade = include("spinning_blade.lua")
local cut_fx = Engine.load_audio(_folderpath .. "cut_fx.ogg")
local special_attack_cooldown_frames = 360
local remaining_special_cooldown = 0

function package_init(package)
    package:declare_package_id("com.navi.Cutman.full")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_special_description("cutman with moves")
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_overworld_animation_path(_modpath .. "ow.animation")
    package:set_overworld_texture_path(_modpath .. "ow.png")
    package:set_mugshot_animation_path(_modpath .. "mug.animation")
    package:set_mugshot_texture_path(_modpath .. "mug.png")
end

function player_init(player)
    player:set_name("Cutman")
    player:set_health(1000)
    player:set_element(Element.Sword)
    player:set_height(60)
    player:set_charge_position(0, -14)

    local base_animation_path = _modpath .. "battle.animation"
    local base_texture = Engine.load_texture(_modpath .. "battle.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(255, 55, 198, 255))

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        blade.throw(player, player:get_attack_level() * 10 + 20);
    end

    player.update_func = function(self, dt)
        if remaining_special_cooldown > 0 then
            remaining_special_cooldown = remaining_special_cooldown - 1
        end
    end

    player.special_attack_func = cut
end

local cutman_special = {}
cutman_special.card_create_action = function(user, props)

    local action = Battle.CardAction.new(user, "PLAYER_CUT")
    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.Sword,
        user:get_context(),
        Drag.None
    )
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2, function()
            Engine.play_audio(cut_fx, AudioPriority.Highest)
            local spell = Battle.Spell.new(user:get_team())
            spell:set_hit_props(hit_props)
            user:get_field():spawn(spell, user:get_tile(user:get_facing(), 1))
            spell.frame = 0
            spell.update_func = function()
                spell.frame = spell.frame + 1
                if (spell.frame == 3) then
                    spell:get_current_tile():attack_entities(spell)
                    spell:erase()
                end
            end
        end)

    end
    user:card_action_event(action, ActionOrder.Involuntary)
end

function cut(player)
    local cutman_action = nil
    if remaining_special_cooldown == 0 then
        local props = Battle.CardProperties:new()
        props.damage = player:get_attack_level() * 20 + 100
        cutman_action = cutman_special.card_create_action(player, props)
        remaining_special_cooldown = special_attack_cooldown_frames
    end
    return cutman_action
end
