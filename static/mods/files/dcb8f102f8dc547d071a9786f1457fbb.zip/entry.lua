nonce = function() end

local TEXTURE = Engine.load_texture(_modpath.."RockCube.png")

function package_init(package) 
    package:declare_package_id("com.Dawn.CardBN1.S105")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'A', 'C', 'I', 'L', 'M'})

    local props = package:get_card_props()
    props.shortname = "IceCube"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Aqua
    props.description = "Create an ice cube. Range=1"
	props.can_boost = false
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
		local step1 = Battle.Step.new()
		local cube = Battle.Obstacle.new(Team.Other)
		local do_once = true
		step1.update_func = function(self, dt)
			if do_once then
				do_once = false
				Engine.play_audio(Engine.load_audio(_modpath.."sfx.ogg"), AudioPriority.High)
				cube:set_facing(user:get_facing())
				cube:set_texture(TEXTURE, true)
				local anim = cube:get_animation()
				anim:load(_modpath.."RockCube.animation")
				anim:set_state("SPAWN")
				anim:refresh(cube:sprite())
				anim:on_complete(function()
					local tile = cube:get_tile()
					if tile:is_walkable() then
						anim:set_state("DEFAULT")
						anim:refresh(cube:sprite())
						anim:set_playback(Playback.Loop)
					else
						cube:delete()
					end
				end)
				cube:set_health(60)

				-- deletion process var
				local delete_self = nil
				local spawned_hitbox = false
				local countdown = 6000
				-- slide tracker
				local continue_slide = false
				local prev_tile = {}
				local cube_speed = 4

				-- define cube collision hitprops
				local props = HitProps.new(
					200,
					Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
					Element.Aqua,
					user:get_context(),
					Drag.None
				)


				-- upon tangible collision
				cube.collision_func = function(self)
					-- define the hitbox with its props every frame
					local hitbox = Battle.Hitbox.new(cube:get_team())
					hitbox:set_hit_props(props)

					if not spawned_hitbox then
						cube:get_field():spawn(hitbox, cube:get_current_tile())
						spawned_hitbox = true
					end
					cube.delete_func()
				end
				-- upon passing the defense check
				cube.attack_func = function(self)
				end

				cube.can_move_to_func = function(tile)
					if tile then
						-- get a list of every obstacle with Team.Other on the field
						local field = cube:get_field()
						local cube_team = cube:get_team()
						local Other_obstacles = function(obstacle)
							return obstacle:get_team() == cube_team
						end
						local obstacles_here = field:find_obstacles(Other_obstacles)
						local donotmove = false
						-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
						for ii=1,#obstacles_here do
							if tile == obstacles_here[ii]:get_tile() then
								donotmove = true
							end
						end

						if tile:is_edge() or donotmove or not tile:is_walkable() then
							return false
						end
					end
					return true
				end
				cube.update_func = function(self, dt)
					local tile = cube:get_current_tile()
					if not tile then
						cube.delete_func()
					end
					if tile:is_edge() then
						cube.delete_func()
					end
					if not delete_self then
						tile:attack_entities(cube)
					end
					local direction = self:get_facing()
					if self:is_sliding() then
						table.insert(prev_tile,1, tile)
						prev_tile[cube_speed+1] = nil
						local target_tile = tile:get_tile(direction, 1)
						if self.can_move_to_func(target_tile) then
							continue_slide = true
						else
							continue_slide = false
						end
					else
						-- become aware of which direction you just moved in, turn to face that direction
						if prev_tile[cube_speed] then
							if prev_tile[cube_speed]:get_tile(direction, 1):x() ~= tile:x() then
								direction = self:get_facing_away()
								self:set_facing(direction)
							end
						end
					end
					if not self:is_sliding() and continue_slide then
						self:slide(self:get_tile(direction, 1), frames(cube_speed), frames(0), ActionOrder.Voluntary, function() end)
					end
					if self:get_health() <= 0 then
						cube.delete_func()
					end
					if countdown > 0 then countdown = countdown - 1 else cube.delete_func() end
					
					-- deletion handler in main loop, starts running once something in here has requested deletion
					if delete_self then
						if type(delete_self) ~= "number" then
							delete_self = 2
						end
						if delete_self > 0 then
							delete_self = delete_self - 1
						elseif delete_self == 0 then
							delete_self = -1
							self:erase()
						end
					end
				end
				cube.delete_func = function(self)
					if type(delete_self) ~= "number" then
						delete_self = true
					end
				end
				local desired_tile = user:get_tile(user:get_facing(), 1)
				if not desired_tile:is_edge() then
					user:get_field():spawn(cube, user:get_tile(user:get_facing(), 1))
				end
				self:complete_step()
			end
		end
		self:add_step(step1)
	end
    return action
end