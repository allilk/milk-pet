local HIT_SFX = nil
local APPEAR_SFX = nil
local ATTACK_SFX = nil
local SUCCESS_SFX = nil


function package_init(package) 
    package:declare_package_id("com.alrysc.card.YorihimeV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'Y','W'})

    local props = package:get_card_props()
    props.shortname = "YorihimV3"
    props.damage = 60
    props.time_freeze = true
    props.element = Element.Sword
    props.description = "5 slashes from many swords!"
    props.card_class = CardClass.Mega
    props.limit = 1
end


function card_create_action(user, props)
    local max_attacks = 5
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true
    local facing = nil

    local count = 0
    local finish_delay = 10
    local can_end = false
    local changed = false

    local actor = nil
    local yorihime = nil
    local anim = nil
    local attack_count = 0
    local command_time = 60
    local command_success = false
    local command = 0
    local can_input = true
    local anim_done = false

    local target_tiles = {}
    local spell_list = {}

    local cmd = {
        2,
        Input.Held.Down,
        Input.Pressed.Left,
        Input.Pressed.Up,
        Input.Pressed.Right,
        Input.Pressed.Down
    }

    local cmd2 = {
        2,
        Input.Held.Left,
        Input.Pressed.Shoot,
        Input.Pressed.Right,
        Input.Pressed.Shoot
    }


    local commands = {
        cmd,
        cmd2
    }



    local fighter = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            0,
            22,
            t, 
            t:get_tile(facing, 1),
            t:get_tile(facing, 2)
        }


        return l
    end

    local sword = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            1,
            10,
            t, 
            t:get_tile(Direction.Up, 1),
            t:get_tile(Direction.Down, 1)
        }


        return l
    end


    -- 20, 10?
    local cross = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            2,
            nil,
            t:get_tile(Direction.join(facing, Direction.Up), 1),
            t:get_tile(Direction.join(facing, Direction.Down), 1),
            t:get_tile(Direction.join(Direction.reverse(facing), Direction.Up), 1),
            t:get_tile(Direction.join(Direction.reverse(facing), Direction.Down), 1),
        }


        return l
    end

    local halberd = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            3,
            22,
            t,
            t:get_tile(Direction.join(facing, Direction.Up), 1),
            t:get_tile(Direction.join(facing, Direction.Down), 1),
            t:get_tile(Direction.Up, 1),
            t:get_tile(Direction.Down, 1),
            t:get_tile(facing, 1)
        }


        return l
    end

    local sonic = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            4,
            nil,
            t, 
            t:get_tile(Direction.Up, 1),
            t:get_tile(Direction.Down, 1)
        }


        return l

    end

    local aura = function()
        local t = yorihime:get_tile(facing, 1)
        local l = {
            5,
            nil,
            t, 
            t:get_tile(Direction.Up, 1),
            t:get_tile(Direction.Down, 1)
        }


        return l

    end

    local attack_pattern = {
        sword, sword, cross, halberd, aura
    }



    local function move()
        local tile = nil

        local x = 1
        local iter = 1
        local done = false 
        local found_adj = false
        local found_front = false
        local user_y = yorihime:get_current_tile():y()

        local target_x = yorihime:get_current_tile():x()
        local adj_x = target_x
        local target_y = user_y
        if facing == Direction.Left then 
            x = field:width()
            iter = -1
        end

        local function search(c)
            return c:get_team() ~= user:get_team()
        end

        for i=1, field:width()
        do
            for y=1, field:height()
            do
                local t = field:tile_at(x, y)
                if #t:find_characters(search) > 0 then 
                    if y == user_y then 
                       -- target_y = y
                        target_x = x
                        done = true
                        found_front = true
                        break
                    elseif not found_adj then 
                        found_adj = true
                        adj_x = x 
                    end
                end
            end

            if done then break end
            x = x + iter
        end

        if not found_front and found_adj then 
            target_x = adj_x
        end
        tile = field:tile_at(target_x, target_y)

        if tile ~= yorihime:get_current_tile() then 
            local t = tile:get_tile(Direction.reverse(facing), 1)

            if t and not t:is_edge() then 
                tile = t
            end
        end  

        yorihime:get_current_tile():remove_entity_by_id(yorihime:get_id())
        tile:add_entity(yorihime)
        -- Start search from back of field
        -- When I find a character, head to their tile, then to the tile in front, if possible
            -- This will make it so that Yorihime can stand on top of someone at the back
        -- While searching, also check up and down. Note the first found, but keep looking forward
            -- Use that one if nothing else is found

    end


    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local function create_hitbox(tile, spell_list, time, cross)
        cross = cross or false
        if not tile or tile:is_edge() then 
            return
        end

        local spell = Battle.Spell.new(yorihime:get_team())

        local damage = props.damage

        if cross then 
            damage = math.floor(props.damage/2)
        end

        local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake,
            Element.Sword, 
            user:get_context(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)
        spell:set_facing(facing)
        
        local lifetime = time
        spell.has_hit = false
        spell.update_func = function(self, dt)
            local can_hit = true
            for i=1, #spell_list
            do
                if not spell_list[i]:is_deleted() then 
                    can_hit = can_hit and not spell_list[i].has_hit

                    if not can_hit then 
                        break
                    end
                end
            end

            self:get_tile():highlight(Highlight.Solid)
            if lifetime == 0 then 
                self:delete()
            end
            lifetime = lifetime - 1

            if not can_hit then 
                return 
            end

            self:get_tile():attack_entities(self)
    
        end
    
        spell.can_move_to_func = function(tile)
            return true
        end
    
        spell.attack_func = function(self, other)
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

        end
    
        spell.collision_func = function(self, other)
            self.has_hit = true
        end

        table.insert(spell_list, spell)
        field:spawn(spell, tile)
    end


    -- I need to also slide the slash.
    -- Also, I guess I want the spell list after all, because the side spells
        -- keep moving

    local function create_sonic(tile, spell_list, graphic, pierce)
        if not tile or tile:is_edge() then 
            return
        end

        local spell = Battle.Spell.new(yorihime:get_team())

        local damage = props.damage

        local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake,
            Element.Sword, 
            user:get_context(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)
        spell:set_facing(facing)
        
        local dir = spell:get_facing()
        local dest = tile:get_tile(dir, 1)
        spell.has_hit = false

        spell.update_func = function(self, dt)
            local can_hit = true
            for i=1, #spell_list
            do
                -- This is really bad, because for every enemy, I add an extra 1-3 iterations
                    -- If we had a million enemies, it would be bad
                if spell_list[i]:is_deleted() then 
                    can_hit = false 
                else
                    can_hit = can_hit and not spell_list[i].has_hit
                end

                if not can_hit then 
                    self:delete()
                    if not graphic:is_deleted() then 
                        graphic:delete()
                    end
                    return
                end
                
            end

            if dest then 
                dest:highlight(Highlight.Solid)
            end

            self:get_tile():attack_entities(self)
            
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()

                    if not graphic:is_deleted() then 
                        graphic:delete()
                    end
                end 
                
                dest = self:get_tile(dir, 1)
                self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary,
                    function()
                        self.slide_started = true 
                    end
                )
            end
        end
    
        spell.can_move_to_func = function(tile)
            return true
        end

        spell:set_float_shoe(true)
    
        spell.attack_func = function(self, other)
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

        end
    
        spell.collision_func = function(self, other)

            if not pierce and not graphic:is_deleted() then 
                self.has_hit = true
                graphic:delete()
              --  if not self:is_deleted() then 
                --    self:delete()
                --end
            end
        end

        table.insert(spell_list, spell)
        field:spawn(spell, tile)
    end

    local function attack()
        Engine.play_audio(ATTACK_SFX, AudioPriority.Low)
        
        local instruction = attack_pattern[attack_count]()
        local num = instruction[1]

        local slash = graphic_init("spell", 0, 0, "yorihime.png", "yorihime.animation", -5, "SWORD_"..num, user, facing, (num < 4))

        local list = {}

        local t = yorihime:get_tile(facing, 1)

        if num == 2 then 
            create_hitbox(t, list, 22)
            local an = slash:get_animation()

            an:on_frame(2, function()
                create_hitbox(t:get_tile(Direction.join(facing, Direction.Up), 1), list, 10, true)
                create_hitbox(t:get_tile(Direction.join(facing, Direction.Down), 1), list, 10, true)
                create_hitbox(t:get_tile(Direction.join(Direction.reverse(facing), Direction.Up), 1), list, 10, true)
                create_hitbox(t:get_tile(Direction.join(Direction.reverse(facing), Direction.Down), 1), list, 10, true)


            end)

        elseif num == 4 or num == 5 then 
            create_sonic(t, list, slash, (num == 5))
            create_sonic(t:get_tile(Direction.Up, 1), list, slash, (num == 5))
            create_sonic(t:get_tile(Direction.Down, 1), list, slash, (num == 5))

            slash.can_move_to_func = function()
                return true
            end
            local dir = slash:get_facing()
            slash:set_float_shoe(true)
            slash.update_func = function(self)
                if self:is_sliding() == false then
                    if self:get_current_tile():is_edge() and self.slide_started then 
                        self:delete()

                        if not self:is_deleted() then 
                            self:delete()
                        end
                    end 
                    
                    local dest = self:get_tile(dir, 1)
                    self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary,
                        function()
                            self.slide_started = true 
                        end
                    )
                end
            end
        else
            for i=3, #instruction
            do
                create_hitbox(instruction[i], list, instruction[2])
            end
        end

        
        if instruction[1] ~= 2 then 
            
        else
            

        end

        field:spawn(slash, yorihime:get_tile(facing, 1))
    end



    local function next_attack()
        local state = 1 + (attack_count % 4)
        attack_count = attack_count + 1
        anim:set_state("ATTACK_LOOP_"..state)


        anim:on_frame(2, function()
            if not command_success then 
                if user:input_has(Input.Held.Left) then 
                    attack_pattern = {
                        cross, cross, cross, cross, cross
                    }
                    command_success = true

                elseif user:input_has(Input.Held.Up) then 
                    attack_pattern = {
                        sword, sword, sword, sword, sword
                    }
                    command_success = true

                elseif user:input_has(Input.Held.Right) then 
                    attack_pattern = {
                        fighter, fighter, fighter, fighter, fighter
                    }
                    command_success = true

                end


                if command_success then 
                    Engine.play_audio(SUCCESS_SFX, AudioPriority.Low)
                end
            end
            attack()
        end)

        anim:on_complete(function()
            if attack_count < max_attacks then 
                next_attack()
            else
                if max_attacks == 3 then 
                    state = 5
                end
                anim:set_state("END_"..state)

                anim:on_complete(function()
                    can_end = true
                
                    field:spawn(graphic_init("artifact", 0, 0, "yorihime.png", "yorihime.animation", -5, "LEAVE", user, facing, true), yorihime:get_current_tile())

                    yorihime:delete()
                end)

                anim:refresh(yorihime:sprite())

            end

        end)
    

        anim:refresh(yorihime:sprite())

    end


    step.update_func = function()
        if count == 3 then 
            actor:hide()
            local tile = user:get_current_tile()
            field:spawn(yorihime, tile)

            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
        end

      --  print("Holding A?", user:input_has(Input.Held.Use))

        if can_input and user:input_has(Input.Held.Use) then 
            command_time = command_time - 1
            for i=1, #commands
            do
                local cur_cmd = commands[i]
                local progress = cur_cmd[1]

                if user:input_has(cur_cmd[progress]) then 
                    cur_cmd[1] = progress+1

                    if (progress+1) > #cur_cmd then 
                        command_success = true
                        command = i
                        if command == 1 then 
                            attack_pattern = {
                                halberd, halberd, halberd, halberd, halberd
                            }
                        else
                            attack_pattern = {
                                sonic, sonic, sonic, sonic, sonic
                            }
                        end
                        Engine.play_audio(SUCCESS_SFX, AudioPriority.Low)
                        can_input = false
                    end
                end
            end

            if command_time == 0 then 
                can_input = false
            end
        else
         --   print("Let go of A", user:input_has(Input.Held.Use))
            can_input = false
        end

        if not changed and not can_input and anim_done then 
            changed = true

            if command ~= 2 then 
                anim:set_state("MOVE")
                anim:refresh(yorihime:sprite())

                anim:on_frame(3, function()
                    move()
                end)

                anim:on_complete(function()
                    next_attack()
                    can_input = false
                    --yorihime:delete()
                end)
            else
                next_attack()
            end
        end

        if can_end then 
            finish_delay = finish_delay - 1

            if finish_delay == 0 then 
                step:complete_step()
            end
        end
        

        count = count + 1
    end


    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        facing = user:get_facing()
        

        

        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
        ATTACK_SFX = Engine.load_audio(_folderpath.."swing_sword.ogg")
        SUCCESS_SFX = Engine.load_audio(_folderpath.."CommandSuccess.ogg")

        
        yorihime = graphic_init("spell", 0, 0, "yorihime.png", "yorihime.animation", -5, "START", user, facing)


        anim = yorihime:get_animation()

        anim:on_complete(function()
            anim_done = true
        end)
        


    end


    return action
end