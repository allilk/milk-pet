local bombtexture = Engine.load_texture(_modpath .. "flashbom.png")
local bombanim = _modpath .. "flashbom.animation"
local flashlighttexture = Engine.load_texture(_modpath .. "flashlight.png")
local flashlightanim = _modpath .. "flashlight.animation"
local tossaudio = Engine.load_audio(_modpath .. "toss_item.ogg")
local small_shadow = Engine.load_texture(_modpath .. "small_shadow.png")
local FLASH_SFX = Engine.load_audio(_folderpath .. "flashlight.ogg")
local ATTACHMENT_TEXTURE = Engine.load_texture(_folderpath .. "attachments.png")
local ATTACHMENT_ANIM = _folderpath .. "attachments.animation"
local HIT_SFX = Engine.load_audio(_folderpath .. "hit.ogg")

-- insert package init here

local attachment_anim_state = "v2"

function package_init(package)
    package:declare_package_id("com.loui.flashbom2")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'G', 'K', 'R' })
    local props = package:get_card_props()
    props.shortname = "FlshBom2"
    props.damage = 70
    props.limit = 3
    props.time_freeze = false
    props.element = Element.None
    props.description = "Thrw dlyd stun bomb 3sq fwd."
    props.long_description = "Throw delayed stunbomb 3tiles forward!"
    props.can_boost = true
end



function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        { 1, 0.064 }, { 2, 0.064 }, { 3, 0.064 }, { 4, 0.064 }, { 5, 0.064 }
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        -- local props = self:copy_metadata()
        local field = user:get_field()
        --local tile = user:get_tile()
        local tile_list = {}
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(ATTACHMENT_TEXTURE)
        attachment_sprite:set_layer(-2)
        attachment_sprite:enable_parent_shader(true)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(ATTACHMENT_ANIM)
        attachment_animation:set_state("DEFAULT")
        local query = function(ent)
            return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
        end

        local flashbom = Battle.Obstacle.new(Team.Other)
        flashbom:set_texture(bombtexture, true)
        flashbom:set_facing(user:get_facing())
        flashbom:never_flip(true)
        flashbom:set_shadow(small_shadow)
        flashbom:set_palette(Engine.load_texture(_folderpath .. "palette.png"))
        flashbom:show_shadow(true)
        local anim = flashbom:get_animation()
        anim:load(bombanim)
        anim:set_state("DEFAULT")
        anim:set_playback(Playback.Loop)
        flashbom:set_health(100)
        flashbom.can_move_to_func = function(tile)
            if not tile then
                return false
            end
            if not tile:is_walkable() or tile:is_edge() or #tile:find_entities(query) > 0 then
                return false
            end
            return true
        end
        flashbom.frames = 60
        flashbom.update_func = function(self, dt) --might need to move defense_rule junk here, need to test
            if (flashbom.frames > 0) then
                flashbom.frames = flashbom.frames - 1
            else
                create_explosion(user, props.damage)
                flashbom:erase()
            end
        end
        --throwing stuff
        self:add_anim_action(3, function()
            attachment_sprite:hide()
            -- self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 50
            local toss_height = 70
            local facing = user:get_facing()
            local target_tile = user:get_tile(facing, tiles_ahead)
            if not target_tile then return end
            action.on_landing = function()
                if target_tile:is_walkable() then
                    if #target_tile:find_entities(query) == 0 then --not working right for some reason
                        user:get_field():spawn(flashbom, target_tile)
                    else
                        local tester = Battle.Spell.new(user:get_team())
                        local getelement
                        tester:set_hit_props(
                            HitProps.new(
                                0,
                                Hit.None,
                                Element.None,
                                user:get_context(),
                                Drag.None
                            )
                        )
                        tester.attack_func = function(self, other)
                            getelement = other:get_element()
                            --tester:erase()
                            local spell = create_attack(user, props, 10, user:get_team(), Element.None,
                                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking)
                            user:get_field():spawn(spell, target_tile)
                            Engine.play_audio(HIT_SFX, AudioPriority.High)
                            print("wiff")
                        end
                        local runonce = true
                        tester.update_func = function(self, dt)
                            if runonce then
                                tester:get_current_tile():attack_entities(tester)
                                runonce = false
                            else
                                tester:erase()
                            end
                        end
                        user:get_field():spawn(tester, target_tile)
                        --tester:get_current_tile():attack_entities(tester) ---not
                    end

                end
            end
            toss_spell(user, toss_height, target_tile, frames_in_air,
                action.on_landing)
        end)

        Engine.play_audio(tossaudio, AudioPriority.Highest)
    end

    return action
end

function toss_spell(tosser, toss_height, target_tile,
                    frames_in_air, arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(bombanim)
    spell_animation:set_state("0")

    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height() + 40)
    end

    spell.jump_started = false
    spell:set_shadow(small_shadow)
    spell:show_shadow(true)
    spell:set_palette(Engine.load_texture(_folderpath .. "palette.png"))
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(bombtexture)
    spell:set_offset(spell.x_offset, spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air),
                frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset +
                math.abs(self.starting_y_offset / frames_in_air)
            self.x_offset = self.x_offset -
                self.starting_x_offset / frames_in_air
            self:set_elevation(-self.y_offset)
            self:set_offset(self.x_offset, 0)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile) return true end
    field:spawn(spell, start_tile)
end

function create_attack(user, props, attack, team, element, hitprops) --Attack Properties
    local spell = Battle.Spell.new(team)

    spell:set_hit_props(
        HitProps.new(
            attack,
            hitprops,
            element,
            user:get_context(),
            Drag.None
        )
    )

    local runonce = true
    spell.update_func = function(self, dt)
        if runonce then
            self:get_current_tile():attack_entities(self)
            runonce = false
        else
            spell:erase()
        end
    end

    spell.collision_func = function(self, other)
    end
    spell.attack_func = function(self, other)
        --Engine.play_audio(HITAUDIO, AudioPriority.Highest)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    --Engine.play_audio(AUDIO, AudioPriority.Low)
    return spell
end

---function to create a spell to root all enemies
---@param team #The team of the attacker.
function stun_all_enemies(team, field, spelldmg)
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team and other_character:get_tile():get_team() ~= team
    end)
    for index, entity in ipairs(target_list) do
        local spell = Battle.Spell.new(team)
        spell:set_hit_props(HitProps.new(spelldmg, Hit.Stun | Hit.Impact | Hit.Retangible, Element.None, 0, Drag.new()))
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
            spell:erase()
        end
        entity:get_field():spawn(spell, entity:get_tile())
    end
end

--make the explosion fx
function create_explosion(user, spelldmg)
    local fx = Battle.Artifact.new()
    fx:set_texture(flashlighttexture, true)
    fx:get_animation():load(flashlightanim)
    Engine.play_audio(FLASH_SFX, AudioPriority.Highest)
    fx:get_animation():set_state("DEFAULT")
    fx:get_animation():on_frame(1, function()
        stun_all_enemies(user:get_team(), user:get_field(), spelldmg)
    end)
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_height(-16.0)
    local field = user:get_field()
    --local tile = user:get_current_tile()
    field:spawn(fx, field:tile_at(1, 1))
end