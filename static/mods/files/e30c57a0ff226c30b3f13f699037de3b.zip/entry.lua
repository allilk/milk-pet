nonce = function() end

function package_init(package) 
    package:declare_package_id("com.Dawn.card.AntiRecovery")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'A','D','G','V'})

    local props = package:get_card_props()
    props.shortname = "AntiHeal"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Punish fr enmy health up!"
	props.card_class = CardClass.Standard
	props.limit = 3
	props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	local field = actor:get_field()
	local target_array = {}
	action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local Anti_Recover_Rule = Battle.DefenseRule.new(713, DefenseOrder.CollisionOnly)
		local Anti_Recover_Component = Battle.Component.new(user, Lifetimes.Battlestep)
		local is_attack = false
		local damage = 0
		local previous_hp_array = {}
		local target = nil
		local query = function(ent)
			return ent ~= nil and not ent:is_deleted() and ent:get_team() ~= user:get_team()
		end
		local targets = user:get_field():find_characters(query)
		for i = 1, #targets, 1 do
			table.insert(target_array, targets[i])
			table.insert(previous_hp_array, targets[i]:get_health())
		end
		Anti_Recover_Component.update_func = function(self, dt)
			for t = 1, #targets, 1 do
				if not targets[t]:is_deleted() then
					if targets[t]:get_health() > previous_hp_array[t] then
						is_attack = true
						target = targets[t]
						damage = (targets[t]:get_health() - previous_hp_array[t]) * 2
						if target:get_health() - damage <= 0 then
							damage = target:get_health() - 1
						end
						local hitbox = Battle.Spell.new(Team.Other)
						hitbox:set_hit_props(
							HitProps.new(
								damage,
								Hit.Impact | Hit.Pierce,
								Element.None,
								self:get_owner():get_context(),
								Drag.None
							)
						)
						target:get_field():spawn(hitbox, target:get_tile())
						target:remove_defense_rule(Anti_Recover_Rule)
						hitbox.update_func = function(self, dt)
							self:get_tile():attack_entities(self)
							self:erase()
						end
						self:eject()
						break
					elseif targets[t]:get_health() < previous_hp_array[t] then
						previous_hp_array[t] = targets[t]:get_health()
					end
				end
			end
			if Anti_Recover_Rule:is_replaced() then
				user:remove_defense_rule(Anti_Recover_Rule)
				Anti_Recover_Component:eject()
			end
		end
		user:add_defense_rule(Anti_Recover_Rule)
		user:register_component(Anti_Recover_Component)
	end
	return action
end