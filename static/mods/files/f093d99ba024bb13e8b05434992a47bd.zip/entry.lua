local package_prefix = "OctoChris"
local package_name = "Gemini"

--Everything under this comment is standard and does not need to be edited
local character_package_prefix = "com."..package_prefix..".char."
local mob_package_id = "com."..package_prefix..".mob."..package_name

function define_package(name)
    local id = character_package_prefix..name
    Engine.define_character(id, _modpath..name)
end

function get_package(name) 
    return character_package_prefix..name
end

local modify, spawn_enemy, spawn_encounter

function package_init(block)
    define_package(package_name)

    block:declare_package_id("com."..package_prefix..".block."..package_name..".red")
    block:set_name(package_name)
    block:set_description("Spawns after- image!")
    block:set_color(Blocks.Red)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 1, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function spawn_enemy(player, folder, rank, x, y)
    local field = player:get_field()
    local team = player:get_team()

    if player:get_facing() == Direction.Left then
        print("[Encounter NCP] need to flip enemy spawn")
        x = field:width() - x + 1
    end

    local tile = field:tile_at(x, y)

    if not tile:is_walkable() or #tile:find_characters(function(c) return Battle.Player.from(c) ~= nil	end) ~= 0 then
        print("[Encounter NCP] could not spawn enemy at ("..x..", "..y..")")
        return
    end

    local enemy = Battle.Character.from_package(get_package(folder), team, rank)
    field:spawn(enemy, tile)
end

function spawn_encounter(player)
    spawn_enemy(player, "Gemini", Rank.V1, 2, 3)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    component.update_func = function()
		if player:get_facing() == Direction.Left then
			player:teleport(player:get_field():tile_at(5, 1))
		else
			player:teleport(player:get_field():tile_at(2, 1))
		end
        spawn_encounter(player)
        component:eject()
    end

	player:share_tile(true)
    player:register_component(component)
end
