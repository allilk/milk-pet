local function find_ally(self)
    local target = self:get_target()
    local field = self:get_field()
    local query = function(c)
        return c:get_team() == self:get_team() and Battle.Player.from(c) ~= nil
    end
    local potential_threats = {}
	local success,err = pcall(function()
		potential_threats = field:find_characters(query)
	end)
	if not success then
		print(err)
	end
    if #potential_threats > 0 then
        return potential_threats[1]
    end
    return nil
end

local function spawn_mob_move(dark_rock)
    local fx = Battle.Artifact.new()
    fx:set_texture(Engine.load_texture(_modpath.."mob_move.png", true))
    local anim = fx:get_animation()
    anim:load(_modpath.."mob_move.animation")
    anim:set_state("DEFAULT")
    anim:refresh(fx:sprite())
    anim:on_complete(function()
        fx:erase()
    end)
    local field = dark_rock:get_field()
    field:spawn(fx, dark_rock:get_tile())
end

local function find_best_target(self)
    local target = self:get_target()
    local field = self:get_field()
    local query = function(c)
        return c:get_team() ~= self:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 9999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

local move_cooldown = 0
local function move_at_random(self,player)
	local current_tile = self:get_tile()
	local field = self:get_field()
	local target_tile_x = current_tile:x()
	local target_tile_y = current_tile:y()
	local target_tile = field:tile_at(target_tile_x, target_tile_y)
	local player_moved = false
	if (player:input_has(Input.Held.Up) or player:input_has(Input.Pressed.Up)) and not player_moved then
		player_moved = true
		target_tile = target_tile:get_tile(Direction.Down,1)
	end
	if (player:input_has(Input.Held.Down) or player:input_has(Input.Pressed.Down)) and not player_moved then
		player_moved = true
		target_tile = target_tile:get_tile(Direction.Up,1)
	end
	if (player:input_has(Input.Held.Right) or player:input_has(Input.Pressed.Right)) and not player_moved then
		player_moved = true
		target_tile = target_tile:get_tile(player:get_facing_away(),1)
	end
	if (player:input_has(Input.Held.Left) or player:input_has(Input.Pressed.Left)) and not player_moved then
		player_moved = true
		target_tile = target_tile:get_tile(player:get_facing(),1)
	end
	if target_tile ~= nil and player_moved and self.can_move_to_func(target_tile) then
		moved = self:teleport(target_tile, ActionOrder.Voluntary, function()
            spawn_mob_move(self)
        end)
		move_cooldown = 15
	else
		return false
	end
	return moved
end

function enemy_exists(self)
    local field = self:get_field()
    local query = function(c)
        return c:get_team() ~= self:get_team()
    end
	return #field:find_characters(query) > 0
end

function package_init(self)
    --meta
	self:set_name("Gemini")
    --Give him immunity to all statuses and nullify damage. After all, he's just an after-image.
    local DarkDefense = Battle.DefenseRule.new(313, DefenseOrder.CollisionOnly)
    DarkDefense.filter_statuses_func = function(statuses)
		statuses.damage = 0
        statuses.flags = Hit.None
        return statuses
    end
    self:add_defense_rule(DarkDefense)
    self._movement_wait = 0
    self._should_move = true
    local attack_list = {}
    local attack_list_index = 1
    local attack_list_inner_index = 1
    local attack_once = false
    local chosen_attack = nil
    local buster_spam_cooldown = 4
    local current_spam_counter = 0
    local frame1 = {1, 0.05}
    local frame2 = {2, 0.05}
    local frame3 = {3, 0.05}
    local frame4 = {1, 0.05}
    local frame5 = {2, 0.05}
    local frame6 = {3, 0.05}
    local frame7 = {1, 0.05}
    local frame8 = {2, 0.05}
    local frame9 = {3, 0.05}
    local frame10 = {4, 0.1}
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
    local tile_array = {}
    local do_once = true
    self._teleports = 0 --How many times has he moved? 0 by default, since he hasn't yet.
    self._goal_teleports = 4 --How many times does he move before going back to attacking? He wants to move 4 times by default.
    local entity_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        --Tile exists, tile team is compatible, tile is not an edge tile, and no matching entities exist on tile?
        --Then he can move to it.
		if tile then
			return self:is_team(tile:get_team()) and not tile:is_edge() and #tile:find_entities(entity_query) == 0 and not tile:is_hole()
		else
			return false
		end
    end
    local anim = nil
    local idle_counter = 0
	local copied = false
    local target
	self:share_tile(true)
	self:set_health(5000)
	self.on_spawn_func = function(self)
		target = find_ally(self)
		if target:get_health() > 5000 then
			target:set_health(5000)
		end
		self:set_texture(target:get_texture())
		anim = self:get_animation()
		anim:copy_from(target:get_animation())
		anim:set_state("PLAYER_IDLE")
		copied = true
	end
	local health_depleted = false
    self.update_func = function(self, dt)
		if target:get_health() == 0 and not health_depleted then
			health_depleted = true
			self:delete()
			return
		end
		self:remove_defense_rule(DarkDefense)
		self:add_defense_rule(DarkDefense)
		self:set_health(target:get_health())
		if not enemy_exists(self) then return end
		if move_cooldown > 0 then
			move_cooldown = move_cooldown - 1
		end
		if not self:is_teleporting() and move_cooldown == 0 then
			pcall(move_at_random,self,target)
        end
    end
end