nonce = function() end

local DAMAGE = 10
local TEXTURE = Engine.load_texture(_modpath.."tornado.png")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster_fan.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

local FRAME1 = {1, 0.1}
local FRAME2 = {2, 0.05}
local FRAME3 = {3, 0.05}
local FRAMES = make_frame_data({FRAME1, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME1, FRAME3, FRAME2, FRAME3, FRAME2})

function package_init(package) 
    package:declare_package_id("com.blaxun.chip.PoisonTwister")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'P','A','J','*'})

    local props = package:get_card_props()
    props.shortname = "PsnTwstr"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Wind
    props.description = "Create 2 poison twister or heal 10 each"
end

function get_enemy_tiles(field, user)
	local enemy_tiles = field:find_tiles(function(t)
	  return not t:is_edge() and t:get_team() ~= user:get_team()
	end)
	
	return enemy_tiles
end

function get_random_enemy_tile(field, user)

	local enemy_tiles = get_enemy_tiles(field, user)
	local random_tile = nil -- Or a default tile, in case there are no valid tiles
	if #enemy_tiles > 0 then
	  random_tile = enemy_tiles[math.random(1, #enemy_tiles)]
	end
	
	return random_tile
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(FRAMES)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		self:add_anim_action(1, function()
			user:toggle_counter(true)
		end)
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."buster_fan.animation")
		buster_anim:set_state("DEFAULT")
		buster_anim:refresh(buster:sprite())
		buster_anim:set_playback(Playback.Loop)
		self:add_anim_action(4, function()
			user:toggle_counter(false)
			local tornados = create_attack(user, props)
			Engine.play_audio(AUDIO, AudioPriority.High)
			local _enemy_tiles = get_enemy_tiles(actor:get_field(), user)
			local _available_tiles = {}	
			if #_enemy_tiles == 0 then
				return
			end
			
			for k, v in pairs(_enemy_tiles) do
				local _state = v:get_state()
				if _state == TileState.Broken or _state == TileState.Empty or _state == TileState.Poison then
					goto continue
				end
				table.insert(_available_tiles,v)
				::continue::
			end
				

			for i=1, 2 do
			
				if #_available_tiles == 0 then
				
					local heal = create_heal("DEFAULT", user)
					actor:get_field():spawn(heal, actor:get_current_tile())
					actor:set_health(actor:get_health() + 10)
					return
				end
			
				local _tornado = tornados[i]
				local _index = math.random(1, #_available_tiles)
				local _target_tile = _available_tiles[_index]
				table.remove(_available_tiles,_index)

				actor:get_field():spawn(_tornado, _target_tile)
				_target_tile:set_state(TileState.Poison)
			end
			
		end)
	end
    return action
end

function create_heal(animation_state, user)
    local spell = Battle.Spell.new(Team.Other)

    spell:set_texture(Engine.load_texture(_modpath.."heal.png"), true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            0,
			Hit.None,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell:sprite():set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_modpath.."heal.animation")
    anim:set_state(animation_state)
	spell:get_animation():on_complete(
		function()
			spell:erase()
		end
	)

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(Engine.load_audio(_modpath.."heal.ogg"), AudioPriority.High)

    return spell
end

function create_attack(user, props)
	local tornados = {Battle.Spell.new(user:get_team()),Battle.Spell.new(user:get_team())}
	local direction = user:get_facing()
	for i=1, 2 do
		local _tornado = tornados[i]
		_tornado.hits = 3
		_tornado:set_facing(user:get_facing())
		_tornado:highlight_tile(Highlight.Solid)
		_tornado:set_texture(TEXTURE, true)
		_tornado:sprite():set_layer(-1)
		
		_tornado:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact | Hit.Flinch, 
				props.element,
				user:get_context(),
				Drag.None
			)
		)
		
		local do_once = true
		_tornado.update_func = function(self, dt) 
			if do_once then
				local anim = _tornado:get_animation()
				anim:load(_modpath.."tornado.animation")
				anim:set_state("DEFAULT")
				local spare_props = _tornado:copy_hit_props()
				local cur_tile = _tornado:get_current_tile()			
				anim:refresh(_tornado:sprite())
				anim:on_complete(function()
					if _tornado.hits > 1 then
						anim:set_playback(Playback.Loop)
						_tornado.hits = _tornado.hits - 1
						local hitbox = Battle.Hitbox.new(_tornado:get_team())
						hitbox:set_hit_props(_tornado:copy_hit_props())
						_tornado:get_field():spawn(hitbox, _tornado:get_current_tile())
					else
						_tornado:erase()
					end
				end)
				do_once = false
			end
			self:get_current_tile():attack_entities(self)
		end
		
		_tornado.collision_func = function(self, other)
		end
		
		_tornado.attack_func = function(self, other) 
		end

		_tornado.delete_func = function(self)
			self:erase()
		end

		_tornado.can_move_to_func = function(tile)
			return true
		end
	
	end
	return tornados
end