local DAMAGE = 260

local AUDIO_SHOOT = Engine.load_audio(_modpath .. "beam.ogg")
local HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")
local tint1 = Color.new(66, 239, 247, 255)
local tint2 = Color.new(123, 165, 247, 255)
local tint3 = Color.new(189, 140, 247, 255)
local tint4 = Color.new(255, 132, 255, 255)

function package_init(package)
    package:declare_package_id("com.louise.card.nobeam2")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "E", "I", "S", "U", "Y" })

    local props = package:get_card_props()
    props.shortname = "NoBeam2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "Fires if something behind"
    props.long_description = "Fires if obstacle behind you."
    props.can_boost = true
    props.card_class = CardClass.Standard
    props.limit = 3
end

local frame_data = make_frame_data({
    { 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})


function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    action:override_animation_frames(frame_data)
    action:set_lockout(make_animation_lockout())

    local frame1 = { 1, 0.033 }
    local frame2 = { 1, 0.305 }
    action.frames = { frame1, frame1, frame1, frame2 }
    action.execute_func = function(self, user)
        local field = user:get_field()
        local direction = user:get_facing()

        local attacking = false

        self:add_anim_action(1, function()
            user:toggle_counter(true)
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(user:get_texture())
            hilt_sprite:set_layer(-2)
            hilt_sprite:enable_parent_shader(true)
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(user:get_animation())
            hilt_anim:set_state("HAND")
            hilt_anim:refresh(hilt_sprite)
            attacking = true
        end)
        self:add_anim_action(3, function()
            if attacking then
                local t = user:get_tile(Direction.reverse(user:get_facing()), 1)
                local filter = function() return true end
                local obstacles = t:find_entities(filter)
                if (#obstacles >= 1) then
                    Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                    create_nobeam(user)
                end
            end
        end)
        self:add_anim_action(4, function()
            user:toggle_counter(false)
            attacking = false
        end)

    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

---@param owner Entity
function create_nobeam(owner)
    local team = owner:get_team()
    local field = owner:get_field()
    local direction = owner:get_facing()

    ---@type Spell
    local spell = Battle.Spell.new(team)
    spell.starttile = owner:get_tile(direction, 1)
    spell:set_facing(owner:get_facing())
    spell:set_hit_props(HitProps.new(
        DAMAGE,
        Hit.Stun, Hit.Pierce,
        Element.None,
        owner:get_context(),
        Drag.new()
    ))


    local player_texture = owner:get_texture();

    spell.current_tile_index = 1
    spell.nextile = spell.starttile:get_tile(direction, 1)
    spell.wait_frames = 0
    spawn_fading_artifact(owner, player_texture, spell.starttile, true)
    spell.update_func = function()

        if (spell.wait_frames == 8) then
            if (spell:get_current_tile():is_edge()) then
                spell:erase()
            else
                if (spell.current_tile_index == 4) then
                    spell.current_tile_index = 0
                end
                spell.current_tile_index = spell.current_tile_index + 1
                spell:teleport(spell.nextile, ActionOrder.Immediate, nil)
                spell.current_tile = spell.nextile
                spell.nextile = spell.current_tile:get_tile(direction, 1)
                spell.wait_frames = 0
                spawn_fading_artifact(owner, player_texture, spell.current_tile, true)
            end
        elseif (spell.wait_frames == 4) then
        end
        spell.wait_frames = spell.wait_frames + 1
        spell:get_current_tile():attack_entities(spell)
        spell:get_current_tile():highlight(Highlight.Solid)
    end

    spell.can_move_to_func = function(self)
        return true
    end

    spell.collision_func = function(self, other)

    end

    spell.attack_func = function()
        create_hit_effect(field, spell:get_current_tile())
    end

    field:spawn(spell, spell.starttile)

    function tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end


end

function spawn_fading_artifact(owner, texture, tile, main)
    local visual_artifact = Battle.Artifact.new()
    --visual_artifact:hide()
    visual_artifact:set_facing(owner:get_facing())
    local sprite = visual_artifact:sprite()
    sprite:set_texture(texture)
    sprite:set_layer(-1)

    local animation = visual_artifact:get_animation()
    animation:copy_from(owner:get_animation())
    animation:set_state("PLAYER_IDLE")
    local frames = 0
    animation:refresh(sprite)
    visual_artifact.update_func = function()
        if (frames < 6) then
            visual_artifact:set_color(tint1)
        elseif (frames < 8) then
            if (main) then
                spawn_fading_artifact(owner, texture, tile, false)
            end
            visual_artifact:set_color(tint2)
        elseif (frames < 10) then
            visual_artifact:set_color(tint3)
        elseif (frames < 12) then
            visual_artifact:set_color(tint4)
        else
            visual_artifact:erase()
        end
        frames = frames + 1
    end
    if (not main) then
        if (owner:get_facing() == Direction.Right) then
            visual_artifact:set_offset(tile:width() / 2, 0)
        else
            visual_artifact:set_offset(-tile:width() / 2, 0)
        end
    end
    animation:refresh(sprite)
    owner:get_field():spawn(visual_artifact, tile:x(), tile:y())
    return visual_artifact
end

function create_hit_effect(field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(Engine.load_texture(_folderpath .. "effect.png"), true)
    hitfx:set_offset(math.random(-10, 10), math.random(-10, 10))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(_folderpath .. "effect.animation")
    hitfx_anim:set_state("8")
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(Engine.load_audio(_folderpath .. "hitsound.ogg"), AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end
