nonce = function() end

local BARRIER_TEXTURE = Engine.load_texture(_modpath.."barrier.png") 
local BARRIER_ANIMATION_PATH = _modpath.."barrier.animation" 
local BARRIER_UP_SOUND = Engine.load_audio(_modpath.."Barrier.ogg") -- Normalized -0.1

function package_init(package)
    package:declare_package_id("rune.legacy.lifeaur1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"B","G","I","O","Q","*"})
 
    local props = package:get_card_props()
    props.shortname = "LifeAur1"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Repels attacks under 100"
   
end

function card_create_action(user, props)
    local PRESTEP = {0, 0.05}
    local END = {0, 0.5}
    local FRAMES = make_frame_data({PRESTEP, END})

    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_animation_lockout())
    action:override_animation_frames(FRAMES)

	action:add_anim_action(2, function() 
		Engine.play_audio(BARRIER_UP_SOUND, AudioPriority.Low)
		create_barrier(user)
	end)

    return action
end

function create_barrier(user)
	local offsetY = -2*(user:get_height()-48) -- MegaMan is 48 and I built around that, so I'm just offsetting for different heights by a bit
	print(offsetY)
    if offsetY > 0 then offsetY = 0 end
    local fading = false
    local isWind = false
	
	local remove_barrier = false
	
    local barrier = user:create_node()
    local HP = 100
    barrier:set_layer(3)
    barrier:set_texture(BARRIER_TEXTURE, true)
	local barrier_animation = Engine.Animation.new(BARRIER_ANIMATION_PATH)
    barrier_animation:set_state("BARRIER_IDLE")
	barrier_animation:refresh(barrier)
	if offsetY < 0 then
		barrier:set_offset(0, offsetY+(user:get_height()-barrier_animation:point("origin").y))
	end
    barrier_animation:set_playback(Playback.Loop)
	
	local number = user:create_node()
	number:set_texture(BARRIER_TEXTURE, true)
	local number_animation = Engine.Animation.new(BARRIER_ANIMATION_PATH)
	number_animation:load(BARRIER_ANIMATION_PATH)
	number_animation:set_state("NUMBER")
	number_animation:refresh(number)
	number:set_offset(0, 12)
	number_animation:set_playback(Playback.Loop)
	number:set_layer(-2)
	
    local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always) -- Keristero's Guard is 0
    barrier_defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
		if attacker_hit_props.damage >= HP then
			HP = HP - attacker_hit_props.damage
		end
        judge:block_damage()
        if attacker_hit_props.element == Element.Wind then
            isWind = true
        end
    end
	
	local aura_animate_component = Battle.Component.new(user, Lifetimes.Scene)
	
	aura_animate_component.update_func = function(self, dt)
		barrier_animation:update(dt, barrier)
	end
	
	local aura_fade_countdown = 3000
	local aura_fade_component = Battle.Component.new(user, Lifetimes.Battlestep)
	aura_fade_component.update_func = function(self, dt)
		if aura_fade_countdown <= 0 then
			destroy_aura = true
		else
			aura_fade_countdown = aura_fade_countdown - 1
		end
	end
	
	local aura_destroy_component = Battle.Component.new(user, Lifetimes.Scene)
	local destroy_aura = false
	aura_destroy_component.update_func = function(self, dt)
		if isWind and not fading then 
            remove_barrier = true
        end
		
		if destroy_aura and not fading then
			remove_barrier = true
		end
		
        if HP <= 0 and not fading then
            remove_barrier = true
        end
        
        if barrier_defense_rule:is_replaced() then
            remove_barrier = true
        end
		
		if remove_barrier and not fading then
			user:sprite():remove_node(number)
			fading = true
			user:remove_defense_rule(barrier_defense_rule)
			
			barrier_animation:set_state("BARRIER_FADE")
			barrier_animation:refresh(barrier)
			barrier_animation:set_playback(Playback.Once)
			
			barrier_animation:on_complete(function()
				user:sprite():remove_node(barrier)
				aura_fade_component:eject()
				aura_animate_component:eject()
				aura_destroy_component:eject()
			end)

			if isWind then
				local initialX = barrier:get_offset().x
				local initialY = barrier:get_offset().y
				local facing_check = 1
				if user:get_facing() == Direction.Left then
					facing_check = -1
				end
				
				barrier_animation:on_frame(1, function() 
					barrier:set_offset(facing_check*(-25-initialX), -20+initialY)
				end)

				barrier_animation:on_frame(2, function() 
					barrier:set_offset(facing_check*(-50-initialX), -40+initialY)
				end)

				barrier_animation:on_frame(3, function() 
					barrier:set_offset(facing_check*(-75-initialX), -60+initialY)
				end)
			end
		end
	end
	
    user:add_defense_rule(barrier_defense_rule)
	user:register_component(aura_fade_component)
	user:register_component(aura_destroy_component)
	user:register_component(aura_animate_component)
end