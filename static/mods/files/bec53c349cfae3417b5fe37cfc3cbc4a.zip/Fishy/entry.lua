local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Fishy",
        hp = 90,
        damage = 50,
        palette = _folderpath .. "V1.png",
        height = 80,
        flydelay = 7,
        floatdelay = 30,
        dashes = 2,
    }
    if character:get_rank() == Rank.V2 then
        character_info.damage = 60
        character_info.flydelay = 7
        character_info.floatdelay = 30
        character_info.dashes = 1
        character_info.hp = 150
        character_info.element = "fire"
        character_info.flame_trail = true
        character_info.palette = _folderpath .. "V2.png"
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 90
        character_info.flydelay = 13
        character_info.floatdelay = 30
        character_info.dashes = 3
        character_info.palette = _folderpath .. "V3.png"
        character_info.hp = 240
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 120
        character_info.flydelay = 20
        character_info.floatdelay = 30
        character_info.dashes = 4
        character_info.palette = _folderpath .. "rare1.png"
        character_info.hp = 280
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 220
        character_info.flydelay = 22
        character_info.floatdelay = 30
        character_info.dashes = 5
        character_info.palette = _folderpath .. "rare2.png"
        character_info.hp = 350
    elseif character:get_rank() == Rank.SP then
        character_info.damage = 150
        character_info.flydelay = 20
        character_info.floatdelay = 30
        character_info.dashes = 5
        character_info.palette = _folderpath .. "SP.png"
        character_info.hp = 300
    elseif character:get_rank() == Rank.NM then
        character_info.damage = 180
        character_info.flydelay = 40
        character_info.floatdelay = 20
        character_info.dashes = 7
        character_info.palette = _folderpath .. "NM.png"
        character_info.hp = 500
        -- elseif character:get_rank() == Rank.Rare1 then
        --     character_info.damage = 50
        --     character_info.palette=_folderpath.."battle_vrare1.palette.png"
        --     character_info.hp = 120
        --     character_info.cascade_frame = 3
        --     character_info.move_delay = 22
        -- elseif character:get_rank() == Rank.Rare2 then
        --     character_info.damage = 100
        --     character_info.palette=_folderpath.."battle_vrare2.palette.png"
        --     character_info.hp = 180
        --     character_info.cascade_frame = 3
        --     character_info.move_delay = 20
    end
    shared_package_init(character, character_info)
end
