local guard = include("guard/guard.lua")

guard.name = "ShockWav"
guard.codes = {"D","H","J","L","R"}
guard.damage = 60
guard.duration = 0
guard.guard_animation = "GUARD1"
guard.description = "Shock through enemies"
 
function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = guard.name
    props.damage = guard.damage
    props.time_freeze = false
    props.element = Element.None
    props.description = guard.description

    package:declare_package_id("rune.onb."..props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(guard.codes)
end

card_create_action = guard.card_create_action




