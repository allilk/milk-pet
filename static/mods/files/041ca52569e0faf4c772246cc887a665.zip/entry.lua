function package_init(package) 
    package:declare_package_id("com.alrysc.player.ShanghaiFighter")
    package:set_special_description("Shanghai in Fighter Style!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."shanghai_preview.png"))
    package:set_overworld_animation_path(_modpath.."ShanghaiOW.animation")
    package:set_overworld_texture_path(_modpath.."ShanghaiOW.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Shanghai")
    player:set_health(1000)
    player:set_element(Element.Wood)
    player:set_height(50.0)
    player:set_animation(_modpath.."Shanghai.animation")
    player:set_texture(Engine.load_texture(_modpath.."FighterLeaf.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -20)

    local rapid_buster = include("RapidBuster/entry.lua")

    

    local function get_charge_time(player)
        local level = player:get_charge_level()
        if level == 5 then return 120
        elseif level == 4 then return 130
        elseif level == 3 then return 140
        elseif level == 2 then return 150
        else return 160 end
    end

    player.is_charged = false
    player.special_used = false
    player.current_charge_time = 0
    player.player_anim = player:get_animation()
    player.desired_charge_start = math.floor(get_charge_time(player) / 4)
    player.desired_charge_finish = get_charge_time(player)
    player.sound_first = true
    player.sound_second = true

    local function reset_charge_variables(player)
        player.current_charge_time = 0
        player.is_charged = false
        player.sound_first = true
        player.sound_second = true
        player.special_used = false
        if player.charge and not player:is_deleted() then    
            player.charge:hide()
        end
      end
      
    player.battle_start_func = function()
        player.charge = player:create_node()
        player.charge:hide()
        player.charge:set_layer(-3)
        player.charge:set_offset(4, -4)
        player.charge:set_texture(Engine.load_texture(_modpath.."custom_charge.png"), true)
        player.charge_animation = Engine.Animation.new(_folderpath.."custom_charge.animation")

        player.charge_animation:set_state("CHARGING")
        player.charge_animation:refresh(player.charge)
        player.charge_animation:set_playback(Playback.Loop)
    
        player.charge_animate_component = Battle.Component.new(player, Lifetimes.Battlestep)
        
        player.charge_animate_component.update_func = function(self, dt)
            if self and player.charge and not player:is_deleted() then player.charge_animation:update(dt, player.charge) end
        end
        player:register_component(player.charge_animate_component)
        end
        player.battle_end_func = function(self)
        if player.charge then player.charge = nil end
        if player.charge_animate_component then player.charge_animate_component:eject() end
    end

    player.is_rapid_buster = false
    player.rapid_queue_time = 5
    player.update_func = function(self, dt)
        if player.is_rapid_buster then 
            player.rapid_queue_time = player.rapid_queue_time - 1
        end
        if player.player_anim:get_state() ~= "PLAYER_IDLE" and not player:is_moving() or player.special_used then
            reset_charge_variables(player)
        end
        if not player:input_has(Input.Held.Use) and (player:input_has(Input.Released.Shoot) or not player:input_has(Input.Held.Shoot)) then
            if player.charge then
                player.current_charge_time = player.current_charge_time + 1
                if player.current_charge_time >= player.desired_charge_finish and player.sound_second then
                    player.sound_second = false
                    Engine.play_audio(player.sounds.chargemax, AudioPriority.High)
                    player.is_charged = true
                    player.charge:show()
                    player.charge_animation:set_state("CHARGED")
                    player.charge_animation:set_playback(Playback.Loop)
                elseif player.current_charge_time >= player.desired_charge_start and player.sound_first then
                    player.sound_first = false
                    Engine.play_audio(player.sounds.charge, AudioPriority.High)
                    player.charge:show()
                    player.charge_animation:set_state("CHARGING")
                    player.charge_animation:set_playback(Playback.Loop)
                end
            end
            
            if player.rapid_queue_time < 1 or not player.is_rapid_buster then 
                player.is_rapid_buster = false
                player.rapid_queue_time = 5
            end
        end
        if not player:input_has(Input.Held.Use) then
            if player.is_charged and player:input_has(Input.Pressed.Shoot) and (player:is_moving() or player.player_anim:get_state() == "PLAYER_IDLE") then
                player.current_charge_time = 0
                local action = player.charged_attack_func(player)
                player:card_action_event(action, ActionOrder.Immediate)
                reset_charge_variables(player)
                player.rapid_queue_time = 5
                player.is_rapid_buster = true

            elseif not player.is_charged and not player.is_rapid_buster and player:input_has(Input.Held.Shoot) and not player:is_moving() and player.player_anim:get_state() == "PLAYER_IDLE" then
                reset_charge_variables(player)
                player.is_rapid_buster = true

                local action = rapid_buster.card_create_action(player)
                player:card_action_event(action, ActionOrder.Immediate)
            end
        end
    end

    player.normal_attack_func = function()

    end

    player.charged_attack_func = fighter_charged_attack
    player.charge_attack = 0
    player.special_attack_func = function(player)
        local action = Battle.CardAction.new(player, "PLAYER_IDLE")

        action.execute_func = function()
            player.special_used = true
            if player.charge_attack == 0 then 
                player.charged_attack_func = create_charged_attack
                player.charge_attack = 1
            else
                player.charged_attack_func = fighter_charged_attack
                player.charge_attack = 0
            end

            action:end_action()

        end

        return action
    end

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        punch = Engine.load_audio(_modpath.."lance.ogg"),
        knife = Engine.load_audio(_modpath.."knife.ogg"),
        vulcan = Engine.load_audio(_modpath.."vulcan.ogg"),
        charge = Engine.load_audio(_modpath.."charge.ogg"),
        chargemax = Engine.load_audio(_modpath.."chargemax.ogg")
    }


    --local fighter = player:create_form()
    --fighter:set_mugshot_texture_path(_modpath.."FighterWindow.png")
    --fighter.on_activate_func = function(self, player)
      --  player:set_texture(Engine.load_texture(_modpath.."FighterLeaf.png"), true)
        --player:set_element(Element.Wood)
        --player.normal_attack_func = fighter_normal_attack

      --  create_window(player)
   -- end

    --fighter.on_deactivate_func = function(self, player)
      --  player:set_texture(Engine.load_texture(_modpath.."Normal.png"), true)
        --player:set_element(Element.None)
        --player.normal_attack_func = normal_attack


    --end

    --fighter.charged_attack_func = fighter_charged_attack

end


function charged_attack(player)
    return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end

function fighter_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level() * 2)
end

function fighter_charged_attack(player)
    local action = Battle.CardAction.new(player, "PLAYER_PUNCH")
    local field = player:get_field()
    local spell_list = {}

    local function copy_spell(spell, props, lifetime)
        local newSpell = Battle.Spell.new(spell:get_team())
        newSpell:set_hit_props(props)
        newSpell.lifetime = lifetime
        newSpell.update_func = function(self)
            self.lifetime = self.lifetime-1
            self:get_current_tile():highlight(Highlight.Solid)


            if self.lifetime == 0 then 
                self:delete()
            end
            self:get_current_tile():attack_entities(self)

        end

        newSpell.attack_func = spell.attack_func
        newSpell.collision_func = spell.collision_func

        
        return newSpell
    end
    -- 12f active
    local function create_punch(user)
        local spell = Battle.Spell.new(user:get_team())
        spell.lifetime = 12
        spell.has_hit = false
	    spell:set_facing(user:get_facing())

        spell:set_hit_props(
            HitProps.new(
                user:get_attack_level() * 30, 
                Hit.Impact | Hit.Flinch | Hit.Drag | Hit.Breaking, 
                Element.Wood, 
                user:get_context(),
                Drag.new(spell:get_facing(), 1)
            )
        )

        spell.update_func = function(self)
            spell:highlight_tile(Highlight.Solid)

            if not self.has_hit then 
                self:get_current_tile():attack_entities(self)
            end

            if self.lifetime == 0 then 
                self:delete()
            end
            self.lifetime = self.lifetime - 1

        end


        spell.collision_func = function()
            spell_list[1].has_hit = true
            spell_list[2].has_hit = true

        end

        spell.attack_func = function()
            Engine.play_audio(user.sounds.hit, AudioPriority.Low)


        end

        return spell
    end


    action.execute_func = function()
        player:get_animation():on_frame(2, function()
            Engine.play_audio(player.sounds.punch, AudioPriority.Low)

        end)
        
        player:get_animation():on_frame(3, function()
            local tile = player:get_current_tile()
            local tile1 = tile:get_tile(player:get_facing(), 1)
            local tile2 = tile:get_tile(player:get_facing(), 2)

            spell_list[1] = create_punch(player)
            spell_list[2] = create_punch(player)
            
            if tile1 then 
                field:spawn(spell_list[1], tile1)
            end
            if tile2 then 
                field:spawn(spell_list[2], tile2)
            end

        
        end)

    end


    action.action_end_func = function()
        for i=1, #spell_list, 1
        do
            local check = spell_list[i]
            if check and not check:is_deleted() then 
                check:delete()
            end
        end

    end

    return action
end


-- Not used
function create_charged_attack(player)
    local action = Battle.CardAction.new(player, "PLAYER_HADOUKEN")

    action.execute_func = function()
        player:get_animation():on_frame(3, function()
            player:get_field():spawn(create_shot(player), player:get_current_tile():get_tile(player:get_facing(), 1))
            Engine.play_audio(player.sounds.knife, AudioPriority.Low)

        end)

    end
    return action
  --  return Battle.Buster.new(player, true, 50)
end


-- Not used
function create_special_attack(player)
    return nil
end


function create_shot(user)
    local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
    local offsetX = 0
    if user:get_facing() == Direction.Left then 
        offsetX = offsetX * -1
    end
   -- spell:set_offset(offsetX, -51)
    spell:set_texture(Engine.load_texture(_modpath.."FighterLeaf.png"), true)
    spell:highlight_tile(Highlight.Solid)
    spell:set_animation(_modpath.."Shanghai.animation")
    spell:get_animation():set_state("HADOUKEN")

	spell.slide_started = false

    local direction = spell:get_facing()
    spell:set_hit_props(
        HitProps.new(
            user:get_attack_level() * 20, 
            Hit.Impact | Hit.Flinch, 
            Element.Wood, 
            nil,
            Drag.None
        )
    )
    
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
		if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
         --   local ref = self
            self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, 
                function()
                    self.slide_started = true 
                end
            )
        end
    end

    spell.collision_func = function(self, other) 
      --  Engine.play_audio(METABEE_SHOT_HIT, AudioPriority.High)
        --self:erase()
    end

    spell.attack_func = function()
        Engine.play_audio(user.sounds.hit, AudioPriority.Low)
    end
    
	spell.can_move_to_func = function(tile)
        return true
    end


    return spell
end


