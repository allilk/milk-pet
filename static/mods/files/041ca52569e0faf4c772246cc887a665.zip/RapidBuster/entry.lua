local card = {}

card.card_create_action = function(player)
    local rapid_buster_cooldown = 3
    local rapid_buster_cooldown_max = 7
    local doneFiring = false
    local count = 2
    local buster
    local charge = player:get_charge_level()
    

    local flare_texture = Engine.load_texture(_modpath.."shot.png")
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    action:set_lockout(make_sequence_lockout())
    action.action_end_func = function(self)       
        player.is_rapid_buster = false
    end
    action.animation_end_func = function(self)
        local p_anim = player:get_animation()
        p_anim:set_state("PLAYER_SHOOTING")
        p_anim:set_playback(Playback.Loop)
        p_anim:refresh(player:sprite())
        buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(player:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(player:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster:sprite())
        buster_anim:set_playback(Playback.Loop)
        buster_anim:on_frame(2, function()
            local first_flare = buster:add_attachment("endpoint")
            first_flare:sprite():set_texture(flare_texture)
            local flare_anim = first_flare:get_animation()
            flare_anim:load(_modpath.."shell.animation")
            flare_anim:set_state("busterflare")
            flare_anim:refresh(first_flare:sprite())
            flare_anim:set_playback(Playback.Loop)
            first_flare:sprite():set_layer(-3)

        end)
    end
    action.execute_func = function(self, user)
        local step = Battle.Step.new()
        buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster:sprite())
        buster_anim:on_frame(2, function()
            local first_flare = buster:add_attachment("endpoint")
            first_flare:sprite():set_texture(flare_texture)
            local flare_anim = first_flare:get_animation()
            flare_anim:load(_modpath.."shell.animation")
            flare_anim:set_state("busterflare")
            flare_anim:refresh(first_flare:sprite())
            flare_anim:set_playback(Playback.Loop)
            first_flare:sprite():set_layer(-3)

        end)
        buster_anim:set_playback(Playback.Loop)
        local tile = player:get_tile(player:get_facing(), 1)


        local point = player:get_animation():point("buster")
        local origin = player:get_animation():point("origin")
        -- spell:set_offset(0.0, 0-(origin.y - point.y))
        --  spell:set_elevation(((origin.y - point.y + buster_endpoint.y/2)*2))
        -- That's definitely just a Y pos

        local buster_endpoint = buster_anim:point("endpoint")

        

        local offset = {
            y = -((origin.y - point.y + buster_endpoint.y/2)*2+5*2),
            x = 20*2 -- Should use origin and buster endpoint to formulate this
        }   

        local height = ((origin.y - point.y + buster_endpoint.y/2)*2+5*2)




        step.update_func = function(self, dt)
            if doneFiring then 
               -- print("We are done firing", (count-1))
                count = count - 1
                if count == 0 then 
                    --print("Should be done now")
                    player:get_animation():set_state("PLAYER_IDLE")
                    self:complete_step()
                    buster:sprite():hide()

                end
                
                rapid_buster_cooldown = 999
            end

            if player:input_has(Input.Released.Shoot) then
                --print("Releasing")
                
                player.is_rapid_buster = false
            end
            if rapid_buster_cooldown <= 0 then
                if doneFiring then
                    
                else
                    rapid_buster_cooldown = rapid_buster_cooldown_max
                    local spell = buster_spam_action(player, player:get_attack_level()*2, height, math.floor(player:get_attack_level()/2), charge)
                    if not player.is_rapid_buster then 
                        --print("doneFiring set true")
                        doneFiring = true
                    else
                       -- print("Not done firing")
                    end
                    local facing_offset = 1
                    local face = player:get_facing()
                    if face == Direction.Left then 
                        facing_offset = facing_offset * -1
                    end
                    player:get_field():spawn(spell, player:get_tile(face, 1))
                    create_bullet_shell(nil, player, offset, offset.x*facing_offset, offset.y, height, face, 20 + math.random(0, 20), 2, 0, player:get_current_tile())

                end
            else
                rapid_buster_cooldown = rapid_buster_cooldown - 1
            end
        end
        self:add_step(step)
    end
    return action
end

function buster_spam_action(player, damage, height, type, charge)
    local animation_x = 0
    local animation_y = 0
    local isType2 = false
    local speed
    if charge == 1 then 
        speed = 10
    elseif charge == 2 then speed = 8
    elseif charge == 3 then speed = 6
    elseif charge == 4 then speed = 4
    elseif charge == 5 then speed = 3
    end
    -- 3, 6, 9, 12, 15, for 9, --6, 5, 3, 3
    local randomY = math.random(-3, 3) * (charge*2)  / 20
    local offsetY = 0


    if type >=2 then
        animation_x = math.random(5)
        isType2 = true
        type = 2
    end 

    local spell = Battle.Spell.new(player:get_team())
    spell:set_texture(Engine.load_texture(_modpath.."shot.png"), false)
    spell:set_animation(_modpath.."shell.animation")
    local spell_anim = spell:get_animation()

    spell_anim:set_state("level"..type.." "..animation_x..animation_y)
    spell_anim:refresh(spell:sprite())

    spell:set_elevation(height)

    spell.slide_started = false
    spell:set_facing(player:get_facing())
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            nil,
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        local self_anim = self:get_animation()
        self_anim:set_state("level"..type.." "..animation_x..animation_y)
        offsetY = offsetY+randomY
      --  self:sprite():set_offset(0, offsetY)
        self:set_elevation(height+offsetY)
     --   print("Offset is ", self:sprite():get_offset().y)
        self_anim:refresh(self:sprite())


        self:get_current_tile():attack_entities(self)
        if not self:is_sliding() then
            --Delete the attack if it hits an edge tile.
            if self:get_current_tile():is_edge() and self.slide_started then self:delete() end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
        end

        if isType2 then 
            animation_x = animation_x+1
            if animation_x > 5 then 
                animation_x = 0
                
            end
            if animation_y < 3 then 
                animation_y = animation_y+1
            end
        end
    end
    --Delete the buster shot on collision with something it can hurt.
    spell.collision_func = function(self, other) self:delete() end
    spell.attack_func = function(self, other) 
        Engine.play_audio(player.sounds.hit, AudioPriority.Low)

    end

    spell.delete_func = function(self) self:erase() end
    --Can move anywhere.
    spell.can_move_to_func = function(tile) return true end
    --Play the buster pea shot sound effect. Low priority so as not to be too annoying, but also so it can override itself.
    Engine.play_audio(player.sounds.vulcan, AudioPriority.Low)
    return spell
end


function create_bullet_shell(sound, user, start_pos, pX, pY, pZ, facing, time, count, spin, tile)

    local plusY = 0.0
    local speedY = 3*2 -- 2 is the scale

    local offset_facing = 1

    if facing == Direction.Left then 
        offset_facing = offset_facing * -2
    end

    local end_pos = {
        x = (start_pos.x - (8 + 8*2 * count * offset_facing)),
        y = start_pos.y + pZ
    }

   -- print("New shell. Start position is ", start_pos.x, start_pos.y)
    --print("and end is ", end_pos.x, end_pos.y, " and time ", time)


    local moveX = (start_pos.x - end_pos.x) / time
    local moveY = (start_pos.y - end_pos.y) / time
    local plusing = speedY / (time / 2) 


    local real_offset = {
        x = start_pos.x,
        y = start_pos.y
    }


    local function update(pX, pY, time)

        local new_offset = {}
       -- print("moveX is ", moveX, "calculated using ", offset.x, " - (", start_pos.x, " - ", end_pos.x, ") / ", time)
    
        new_offset[1] = pX - moveX
      --  print("Changed x by ", moveX, "Also count is ", count)
        new_offset[2] = pY - moveY
        plusY = plusY + speedY
        speedY = speedY - plusing
    
        return new_offset
    end
    

    local spell = Battle.Spell.new(user:get_team())
    spell_anim = spell:get_animation()
    spell.time = time
     -- spell:set_offset(0.0, 0-(origin.y - point.y))
    if facing == Direction.Left then 
       -- start_pos.x = -start_pos.x
    end
    spell:set_offset(start_pos.x, start_pos.y)
 --   print("Spell initial offset is ", spell:get_offset().x, spell:get_offset().y)

    spell:sprite():set_layer(-3)


    spell:set_texture(Engine.load_texture(_modpath.."shell.png"), true)
    spell:set_animation(_modpath.."shell.animation")
    spell_anim:set_state("shell"..spin)
    spell_anim:refresh(spell:sprite())


    spell.update_func = function(self)
        self:get_animation():set_state("shell"..spin)
        self:get_animation():refresh(self:sprite())



        spin = spin+1
        if spin > 9 then 
            spin = 0 
        end

        self.time = self.time - 1
   --     print("Time is ", self.time)
        if self.time == 0 then 
            if count > 0 then 
       --         print("Well, a new one should have been made. Count is ", count, " so this is sending in ", count-1)
                create_bullet_shell(sound, user, self:get_offset(), pX, pY, 0, facing, math.floor(time/2), count-1, spin, self:get_current_tile())
            end
     --       print("Should definitely be dead.")
            self:delete()
        end

        --print("Spell offset is currently", pX, pY)
        local new_offset = update(pX, pY, self.time)
        pX = new_offset[1]
        pY = new_offset[2]
        self:set_offset(pX, (pY - plusY))
        --print("Updated to", pX, pY)


        

    end


    user:get_field():spawn(spell, tile)

end


return card
