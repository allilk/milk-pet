local DAMAGE = 130
local TEXTURE = Engine.load_texture(_folderpath .. "Moonblade.png")
local AUDIO = Engine.load_audio(_folderpath .. "sfx.ogg")

local chip = { name = "MoonBld" }

local frame_data = make_frame_data({
	{ 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})

chip.card_create_action = function(actor)
	local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local tile = user:get_current_tile()
		local slash = nil

		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
		end)

		if slash == nil then
			self:add_anim_action(3, function()
				slash = create_slash("0", user)
				actor:get_field():spawn(slash, tile)
			end)
		end
	end
	return action
end

function spawn_slash_hitbox(user, user_tile, direction)
	user_tile:get_tile(direction, 1):highlight(Highlight.Solid)
	local hitbox_r = Battle.SharedHitbox.new(user, 1)
	hitbox_r:set_hit_props(user:copy_hit_props())
	user:get_field():spawn(hitbox_r, user_tile:get_tile(direction, 1))
end

function create_slash(animation_state, user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_texture(TEXTURE, true)
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			DAMAGE,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	anim:load(_folderpath .. "Moonblade.animation")
	anim:set_state(animation_state)
	spell:get_animation():on_complete(function()
		spell:erase()
	end)
	local frame = 0
	local facing = user:get_facing()
	local facing_away = user:get_facing_away()
	local clockwise_path = {
		facing,
		Direction.join(facing, Direction.Down),
		Direction.Down,
		Direction.join(facing_away, Direction.Down),
		facing_away,
		Direction.join(facing_away, Direction.Up),
		Direction.Up,
		Direction.join(facing, Direction.Up)
	}
	spell.update_func = function(self, dt)
		local tile = self:get_tile()
		frame = frame + 1
		if (frame < 9) then
			spawn_slash_hitbox(spell, tile, clockwise_path[frame])
		else
			spell:erase()
		end
	end
	spell.collision_func = function(self, other)
	end
	spell.attack_func = function(self, other)
	end
	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.High)

	return spell
end

return chip