local chip = { name = "FireBrn3" }

local hit_fx = Engine.load_texture(_modpath .. "Effects/FireFX.png")

local function create_flame_spell(user)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(Engine.load_texture(_modpath .. "Effects/Fireburn.png"))
    local animation = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            150,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire,
            user:get_context(),
            Drag.None
        )
    )
    spell:highlight_tile(Highlight.Solid)
    animation:load(_modpath .. "Effects/Fireburn.animation")
    animation:set_state("0")
    animation:set_playback(Playback.Loop)
    local sprite = spell:sprite()
    sprite:set_layer(-2)
    animation:refresh(sprite)
    spell:set_facing(user:get_facing())
    spell.has_spawned = false
    local tile = nil
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if tile:is_walkable() then
            if tile:get_state() == TileState.Cracked then
                tile:set_state(TileState.Broken)
            else
                tile:set_state(TileState.Cracked)
            end
        end
    end

    spell.collision_func = function(self, other)
        local fx = Battle.Spell.new(self:get_team())
        fx:set_texture(hit_fx)
        local anim = fx:get_animation()
        local fx_sprite = fx:sprite()
        anim:load(_modpath .. "Effects/FireFX.animation")
        anim:set_state("FIRE")
        sprite:set_layer(-3)
        anim:refresh(fx_sprite)
        anim:on_complete(function()
            fx:erase()
        end)
        self:get_field():spawn(fx, tile)
    end

    spell.update_func = function(self, dt)
        tile:attack_entities(self)
    end
    return spell
end

chip.card_create_action = function(user)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local field = user:get_field()
    local frame1 = { 1, 0.016 }
    local frame2 = { 1, 0.05 }
    local frame3 = { 2, 0.033 }
    local tile_array = {}
    local AUDIO = Engine.load_audio(_modpath .. "Sounds/FireBurn.ogg")
    local frames = make_frame_data(
        {
            frame1,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2,
            frame2, frame3, frame2, frame3, frame2, frame3, frame2, frame2, frame3, frame2, frame2, frame3, frame2
        }
    )
    action:override_animation_frames(frames)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local self_tile = user:get_tile()
        local y = self_tile:y()
        local x = self_tile:x()
        local increment = 1
        if user:get_facing() == Direction.Left then increment = -1 end
        for i = 1, 3, 1 do
            local prospective_tile = field:tile_at(x + (i * increment), y)
            if prospective_tile and not prospective_tile:is_edge() then
                table.insert(tile_array, prospective_tile)
            end
        end
        local point = user:get_animation():point("BUSTER")
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
        buster_sprite:set_layer(-2)

        self.flame1 = create_flame_spell(user)
        self.flame2 = create_flame_spell(user)
        self.flame3 = create_flame_spell(user)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster_sprite)

        self:add_anim_action(1, function()
            buster_sprite:set_texture(Engine.load_texture(_modpath.."Effects/Firebuster.png", true))
            buster_sprite:set_layer(-2)

            buster_anim:load(_modpath.."Effects/Firebuster.animation", true)
            buster_anim:set_state("0")
            buster_anim:refresh(buster_sprite)
        end)
        self:add_anim_action(5, function()
            Engine.play_audio(AUDIO, AudioPriority.High)
            if #tile_array > 0 then
                field:spawn(self.flame1, tile_array[1])
            end
        end)

        self:add_anim_action(9, function()
            if #tile_array > 1 then
                field:spawn(self.flame2, tile_array[2])
            end
        end)

        self:add_anim_action(13, function()
            if #tile_array > 2 then
                field:spawn(self.flame3, tile_array[3])
            end
        end)

        self:add_anim_action(32, function()
            if self.flame1.has_spawned then
                self.flame1:get_animation():set_state("1")
                self.flame1:get_animation():refresh(self.flame1:sprite())
                self.flame1:get_animation():on_complete(function()
                    self.flame1:erase()
                end)
            end
        end)

        self:add_anim_action(36, function()
            if self.flame2.has_spawned then
                self.flame2:get_animation():set_state("1")
                self.flame2:get_animation():refresh(self.flame2:sprite())
                self.flame2:get_animation():on_complete(function()
                    self.flame2:erase()
                end)
            end
        end)

        self:add_anim_action(40, function()
            if self.flame3.has_spawned then
                self.flame3:get_animation():set_state("1")
                self.flame3:get_animation():refresh(self.flame3:sprite())
                self.flame3:get_animation():on_complete(function()
                    self.flame3:erase()
                end)
            end
        end)
    end
    action.action_end_func = function(self)
        if not self.flame1:is_deleted() then self.flame1:erase() end
        if not self.flame2:is_deleted() then self.flame2:erase() end
        if not self.flame3:is_deleted() then self.flame3:erase() end
    end
    return action
end

return chip
