local chip = {name="DarkSwrd"}

local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_darksword.png")
local BLADE_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_blades.png")
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")

chip.card_create_action = function(actor)
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		self:add_anim_action(2,
			function()
				local hilt = self:add_attachment("HILT")
				local hilt_sprite = hilt:sprite()
				hilt_sprite:set_texture(actor:get_texture())
				hilt_sprite:set_layer(-2)
				hilt_sprite:enable_parent_shader(true)
				
				local hilt_anim = hilt:get_animation()
				hilt_anim:copy_from(actor:get_animation())
				hilt_anim:set_state("HILT")

				local blade = hilt:add_attachment("ENDPOINT")
				local blade_sprite = blade:sprite()
				blade_sprite:set_texture(BLADE_TEXTURE)
				blade_sprite:set_layer(-1)

				local blade_anim = blade:get_animation()
				blade_anim:load(_folderpath.."spell_sword_blades.animation")
				blade_anim:set_state("DEFAULT")
			end
		)
		local field = user:get_field()
		self:add_anim_action(3, function()
			local sword = create_slash(user)
			local tile = user:get_tile(user:get_facing(), 1)
			local fx = Battle.Spell.new(user:get_team())
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(SLASH_TEXTURE, true)
			anim:load(_folderpath.."spell_darksword.animation")
			anim:set_state("DEFAULT")
			anim:on_complete(function()
				fx:erase()
				if not sword:is_deleted() then sword:delete() end
			end)
			field:spawn(sword, tile)
			field:spawn(fx, tile)
		end)
	end
    return action
end

function create_slash(user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			400,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = user:get_field()
	spell.timer = 2
	spell.update_func = function(self, dt)
		if not self:is_deleted() and self.timer <= 0 then self:delete() return end
		self.timer = self.timer - 1
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(spell:get_facing(), 1)
		local tile_up = tile:get_tile(Direction.Up, 1)
		local tile_down = tile:get_tile(Direction.Down, 1)
		local tile_up_next = tile:get_tile(Direction.join(self:get_facing(), Direction.Up), 1)
		local tile_down_next = tile:get_tile(Direction.join(self:get_facing(), Direction.Down), 1)
		
		if tile then
			if tile_up and not tile_up:is_edge() then
				tile_up:highlight(Highlight.Flash)
			end
			if tile_down and not tile_down:is_edge() then
				tile_down:highlight(Highlight.Flash)
			end
		end
		
		if tile_next then
			if tile_up_next and not tile_up_next:is_edge() then
				tile_up_next:highlight(Highlight.Flash)
			end
			if tile_down_next and not tile_down_next:is_edge() then
				tile_down_next:highlight(Highlight.Flash)
			end
			if tile_next and not tile_next:is_edge() then
				tile_next:highlight(Highlight.Flash)
			end
		end
		if attack_once then
			if tile_next then
				local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile_next)
			end
			if tile_up then
				local hitbox_u = Battle.SharedHitbox.new(self, 0.2)
				hitbox_u:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_u, tile_up)
			end
			if tile_down then
				local hitbox_d = Battle.SharedHitbox.new(self, 0.2)
				hitbox_d:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_d, tile_down)
			end
			if tile_up_next then
				local hitbox_ur = Battle.SharedHitbox.new(self, 0.2)
				hitbox_ur:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_ur, tile_up_next)
			end
			if tile_down_next then
				local hitbox_dl = Battle.SharedHitbox.new(self, 0.2)
				hitbox_dl:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_dl, tile_down_next)
			end
			tile:attack_entities(self)
			attack_once = false
		end
	end
	spell.collision_func = function(self, other)
		if not self:is_deleted() then self:delete() end
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

return chip