local Cannon = include("Chips/Cannon/entry.lua")
local MCannon = include("Chips/MCannon/entry.lua")
local MoonBld = include("Chips/MoonBld/entry.lua")
local Tornado = include("Chips/Tornado/entry.lua")
local AirHocky = include("Chips/AirHocky/entry.lua")
local WideSwrd = include("Chips/WideSwrd/entry.lua")
local LongSwrd = include("Chips/LongSwrd/entry.lua")
local DarkSwrd = include("Chips/DrkSword/entry.lua")
local SuprVulc = include("Chips/SuperVulc/vulcan.lua")
local MiniBomb = include("Chips/MiniBomb/bomb.lua")
local EnergBom = include("Chips/EnergBom/bomb.lua")
local MegEnBom = include("Chips/MegEnBom/bomb.lua")
local FireSwrd = include("Chips/FireSwrd/entry.lua")
local AquaSwrd = include("Chips/AquaSwrd/entry.lua")
local BambSwrd = include("Chips/BambSwrd/entry.lua")
local ElecSwrd = include("Chips/ElecSwrd/entry.lua")
local FireBrn2 = include("Chips/FireBurn2/entry.lua")
local FireBrn3 = include("Chips/FireBurn3/entry.lua")
local GunDelHel = include("Chips/GunDelHell/entry.lua")
local TankCannon1 = include("Chips/TankCannon/entry.lua")
local TankCannon2 = include("Chips/TankCannon2/entry.lua")
local TankCannon3 = include("Chips/TankCannon3/entry.lua")
local TrainArrow2 = include("Chips/TrainArrow2/entry.lua")
local TrainArrow3 = include("Chips/TrainArrow3/entry.lua")
local DollThunder2 = include("Chips/DollThunder2/entry.lua")
local DollThunder3 = include("Chips/DollThunder3/entry.lua")

local function spawn_mob_move(dark_rock)
    local fx = Battle.Artifact.new()
    fx:set_texture(Engine.load_texture(_modpath .. "mob_move.png", true))
    local anim = fx:get_animation()
    anim:load(_modpath .. "mob_move.animation")
    anim:set_state("DEFAULT")
    anim:refresh(fx:sprite())
    anim:on_complete(function()
        fx:erase()
    end)
    local field = dark_rock:get_field()
    field:spawn(fx, dark_rock:get_tile())
end

local function move_at_random(self)
    local moved = false
    local field = self:get_field()
    local target_tile = nil
    local tile_array = {}
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local prospective_tile = field:tile_at(x, y)
            if self.can_move_to_func(prospective_tile) then
                table.insert(tile_array, prospective_tile)
            end
        end
    end
    if #tile_array == 0 then return false end
    target_tile = tile_array[math.random(1, #tile_array)]
    if target_tile then
        moved = self:teleport(target_tile, ActionOrder.Immediate, function()
            spawn_mob_move(self)
            self._teleports = self._teleports + 1
            if self._teleports >= self._goal_teleports then
                self._teleports = 0
                self._goal_teleports = math.random(1, 3)
                self._should_attack = true
                self._should_move = false
            end
        end)
        if moved then
            self._movement_wait = 10
            self._current_attacks = 0
        end
    end
    return moved
end

local function buster_spam_action(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    local damage = 10
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end

            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true
                end
            )
        end
    end
    spell.collision_func = function(self, other)
        self:delete()
    end
    spell.attack_func = function(self, other)
    end

    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function package_init(self)
    --meta
    self:set_name("Dark Rock")
    self:set_health(1000)
    self:set_texture(Engine.load_texture(_modpath .. "navi_megaman_atlas.og.png"))

    local anim = self:get_animation()
    anim:load(_modpath .. "megaman.animation")
    anim:set_state("PLAYER_IDLE")
    local DarkDefense = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
    DarkDefense.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Blind
        return statuses
    end
    self._movement_wait = 10
    self._should_move = true
    self._should_attack = false
    local attack_list = {
        { Cannon, MiniBomb, WideSwrd },
        { Cannon, WideSwrd, EnergBom },
        { Cannon, LongSwrd, MegEnBom },
        { FireSwrd, FireBrn2, TankCannon1 },
        { MCannon, AquaSwrd, TrainArrow2 },
        { ElecSwrd, TankCannon2, DollThunder2 },
        { GunDelHel, BambSwrd }, --[[ RlngLog2,--]]
        { Tornado, MoonBld, TankCannon3 },
        { AirHocky, DarkSwrd, TankCannon3 },
        { SuprVulc, DarkSwrd, FireBrn3, TrainArrow3, DollThunder3 } --[[ RlngLog3,--]]
    }
    local attack_list_index = 10
    local pick_attack_once = true
    local chosen_attack = nil
    local roll = -1
    local roll_once = true
    local frame1 = { 1, 0.05 }
    local frame2 = { 2, 0.05 }
    local frame3 = { 3, 0.05 }
    local frame4 = { 1, 0.05 }
    local frame5 = { 2, 0.05 }
    local frame6 = { 3, 0.05 }
    local frame7 = { 1, 0.05 }
    local frame8 = { 2, 0.05 }
    local frame9 = { 3, 0.05 }
    local frame10 = { 4, 0.1 }
    local frame_sequence = make_frame_data({ frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9,
        frame10 })
    local health = 1000
    self._teleports = 0
    self._goal_teleports = 3
    local current_attacks = 0
    self:register_status_callback(Hit.Drag, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:register_status_callback(Hit.Stun, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:set_float_shoe(true)
    local entity_query = function(ent)
        if ent:get_health() <= 0 then return false end
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        --No tile, no move
        if not tile then return false end
        --Not walkable, no move
        if not tile:is_walkable() then return false end
        --If it's not his team, no move
        if not self:is_team(tile:get_team()) then return false end
        --Check that the tile isn't occupied already. Allow move if it's not.
        return #tile:find_entities(entity_query) == 0
    end
    local idle_counter = 0
    self.update_func = function(self, dt)
        if self:get_health() ~= health then
            attack_list_index = math.max(1, math.floor(self:get_health() / 100))
        end
        if self._should_attack and anim:get_state() == "PLAYER_IDLE" then
            idle_counter = idle_counter + 1
            if idle_counter >= 30 then
                if current_attacks >= 3 then
                    self._should_attack = false
                    self._should_move = true
                end
                roll = -1
                roll_once = true
                pick_attack_once = true
                idle_counter = 0
            end
            if roll_once then
                roll = math.random(1, 20)
                roll_once = false
            end
            if roll > 5 then
                if pick_attack_once then
                    pick_attack_once = false
                    chosen_attack = attack_list[attack_list_index][math.random(1, #attack_list[attack_list_index])]
                    current_attacks = current_attacks + 1
                    local action = chosen_attack.card_create_action(self)
                    self:card_action_event(action, ActionOrder.Involuntary)
                    local action2 = Battle.CardAction.new(self, "PLAYER_IDLE")
                    action2.execute_func = function(act2)
                        pick_attack_once = true
                        act2:end_action()
                    end
                    self:card_action_event(action2, ActionOrder.Voluntary)
                    if math.random(1, 20) > 10 then
                        self._should_attack = false
                        self._should_move = true
                    end
                    roll = -1
                    roll_once = true
                end
            else
                if pick_attack_once then
                    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
                    action:override_animation_frames(frame_sequence)
                    action:set_lockout(make_animation_lockout())
                    action.execute_func = function(act, user)
                        local buster = act:add_attachment("BUSTER")
                        local sprite = buster:sprite()
                        sprite:set_texture(self:get_texture())
                        sprite:enable_parent_shader(true)
                        sprite:set_layer(-1)

                        local buster_anim = buster:get_animation()
                        buster_anim:copy_from(self:get_animation())
                        buster_anim:set_state("BUSTER")
                        buster_anim:refresh(sprite)
                        act:add_anim_action(1, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath .. "pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath .. "pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(4, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath .. "pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath .. "pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(7, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath .. "pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath .. "pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                    end
                    action.action_end_func = function(self)
                        self._should_attack = false
                        self._should_move = true
                        roll = -1
                        current_attacks = current_attacks + 1
                    end
                    self:card_action_event(action, ActionOrder.Involuntary)
                    pick_attack_once = false
                end
            end
        elseif self._should_move then
            if self._movement_wait <= 0 then
                if not self:is_teleporting() then
                    local did_move = move_at_random(self)
                    if not did_move then
                        self._should_attack = true
                        self._should_move = false
                    end
                end
            else
                self._movement_wait = self._movement_wait - 1
            end
        end
    end
end
