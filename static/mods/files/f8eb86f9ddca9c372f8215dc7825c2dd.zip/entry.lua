function package_init(package)
    package:declare_package_id("com.Rework.Y.D095")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'R' })

    local props = package:get_card_props()
    props.shortname = "DrkCloak"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "DEATH TO THOSE WHO HARM YOU"
    props.card_class = CardClass.Dark
    props.limit = 1
    props.long_description = "A Dark Chip. Harms those who harm you."
    props.can_boost = false
end

function card_create_action(player, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(player, "PLAYER_IDLE")
    action:override_animation_frames(make_frame_data({ { 1, 0.016 } }))
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local bug = Battle.Component.new(player, Lifetimes.Battlestep)
        bug.cooldown = 0
        bug.cooldown_max = 30
        bug.initial_cooldown = 180
        bug.owner = player
        bug.update_func = function(self, dt)
            if self.owner:get_health() <= 1 then return end
            if self.initial_cooldown <= 0 then
                self.cooldown = self.cooldown - 1
                if self.cooldown <= 0 then
                    self.owner:set_health(self.owner:get_health() - 1)
                    self.cooldown = self.cooldown_max
                end
            else
                self.initial_cooldown = self.initial_cooldown - 1
            end
        end
        local cloak = Battle.Artifact.new()
        local end_cloak = Battle.Component.new(player, Lifetimes.Battlestep)
        end_cloak.artifact = cloak
        end_cloak.cooldown = 180
        end_cloak.update_func = function(self, dt)
            self.cooldown = self.cooldown - 1
            if self.cooldown <= 0 then
                self:get_owner():remove_defense_rule(self.defense_rule)
                self.artifact:erase()
                self:eject()
            end
        end
        end_cloak.defense_rule = Battle.DefenseRule.new(9979, DefenseOrder.CollisionOnly)
        end_cloak.defense_rule.can_block_func = function(judge, attacker, defender)
            local spell = Battle.Spell.new(defender:get_team())
            spell:set_hit_props(attacker:copy_hit_props())
            spell:set_facing(attacker:get_facing_away())
            spell:highlight_tile(Highlight.Solid)
            spell.slide_started = false
            spell:set_float_shoe(true)
            spell:set_air_shoe(true)
            spell.can_move_to_func = function(tile) return true end
            spell.update_func = function(self, dt)
                --If deleted, do nothing
                if self:is_deleted() then return end
                local own_tile = self:get_tile()
                own_tile:attack_entities(self)
                if not self:is_sliding() then
                    --If we're on an edge tile, delete.
                    if self:get_current_tile():is_edge() then self:delete() end
                    local dest = self:get_tile(spell:get_facing(), 1)
                    local ref = self
                    self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, function()
                        ref.slide_started = true
                    end)
                end
            end
            --On collision, erase.
            spell.collision_func = function(self, dt) self:erase() end
            defender:get_field():spawn(spell, defender:get_tile())
            judge:block_damage()
            judge:block_impact()
        end
        cloak.color = Color.new(0, 0, 0, 255)
        cloak.mode = ColorMode.Multiply
        cloak.owner = player
        cloak.update_func = function(self, dt)
            local owner = self.owner
            owner:set_color(self.color)
            owner:sprite():set_color_mode(self.mode)
        end
        player:get_field():spawn(cloak, player:get_tile())
        player:add_defense_rule(end_cloak.defense_rule)
        player:register_component(end_cloak)
        player:register_component(bug)
    end

    return action
end
