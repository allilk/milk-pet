function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXEPoN-ElecShock-2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'B', 'C', 'D'})

    local props = package:get_card_props()
    props.shortname = "ElecShk2"
    props.damage = 90
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Electric cracks panels!"
    props.long_description = "Radial discharge attack! Cracks the panel!"
	props.limit = 3
end

local frame_data = make_frame_data({
	{1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.416}
})

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()

        local elec_2 = nil
        local elec_3 = nil
        local elec_4 = nil

        if user:get_facing() == Direction.Right then
            elec_2 = Direction.UpRight
            elec_3 = Direction.Right
            elec_4 = Direction.DownRight
        elseif user:get_facing() == Direction.Left then
            elec_2 = Direction.UpLeft
            elec_3 = Direction.Left
            elec_4 = Direction.DownLeft
        end

        local field = user:get_field()
        local tile = user:get_tile(user:get_facing(), 1)
        local tile2 = tile:get_tile(elec_2, 1)
        local tile3 = tile:get_tile(elec_3, 1)
        local tile4 = tile:get_tile(elec_4, 1)

        self.elec1 = create_attack(user, props)
        self.elec2 = create_attack(user, props)
        self.elec3 = create_attack(user, props)
        self.elec4 = create_attack(user, props)

        self:add_anim_action(2, function()
			user:toggle_counter(true)
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)
				
		self:add_anim_action(3, function()
			if not tile:is_edge() and tile:get_state() ~= TileState.Broken and tile:get_state() ~= TileState.Empty then
                field:spawn(self.elec1, tile)
            end
		end) 

		self:add_anim_action(4, function()
			user:toggle_counter(false)
            if self.elec1.has_spawned then
                self.elec1:get_animation():on_frame(7, function()
                    if not tile3:is_edge() and tile3:get_state() ~= TileState.Broken and tile3:get_state() ~= TileState.Empty then
                        field:spawn(self.elec3, tile3)
                        if not tile2:is_edge() and tile2:get_state() ~= TileState.Broken and tile2:get_state() ~= TileState.Empty then
                            field:spawn(self.elec2, tile2)
                        end
                        if not tile4:is_edge() and tile4:get_state() ~= TileState.Broken and tile4:get_state() ~= TileState.Empty then
                            field:spawn(self.elec4, tile4)
                        end
                    end
                end)
            end
		end)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function create_attack(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_texture(Engine.load_texture(_modpath.."attack.png"), true)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
            )
        )
    spell:highlight_tile(Highlight.Solid)
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("ATTACK")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-1)
    
    spell.on_spawn_func = function(self)
        tile = self:get_tile()
        self.has_spawned = true
        if tile:is_walkable() then
            tile:set_state(TileState.Cracked)
        end
    end

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    Engine.play_audio(Engine.load_audio(_modpath.."sfx.ogg"), AudioPriority.High)
    return spell
end