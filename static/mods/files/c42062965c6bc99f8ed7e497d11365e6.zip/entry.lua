local bomberman = include("bomberman/bomberman.lua")

local DAMAGE = 140

bomberman.codes = {"B"}
bomberman.shortname = "BombrMnV2"
bomberman.damage = DAMAGE
bomberman.time_freeze = true
bomberman.element = Element.Fire
bomberman.description = "Cros area explosion 3pnl ahed"
bomberman.long_description = "Bomb 3 squares in front! Burst of explosion in the enemy area!"
bomberman.can_boost = true
bomberman.card_class = CardClass.Mega
bomberman.limit = 1

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE1-156-BomberManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(bomberman.codes)

    local props = package:get_card_props()
    props.shortname = bomberman.shortname
    props.damage = bomberman.damage
    props.time_freeze = bomberman.time_freeze
    props.element = bomberman.element
    props.description = bomberman.description
    props.long_description = bomberman.long_description
    props.can_boost = bomberman.can_boost
	props.card_class = bomberman.card_class
	props.limit = bomberman.limit
end

card_create_action = bomberman.card_create_action