function create_soldier_shot(user, props, facing)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(facing)
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Stun,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_tile():attack_entities(self)
        local dest = self:get_tile(self:get_facing(), 1)
        if not self:is_sliding() then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Involuntary, function()
                ref.slide_started = true 
            end)
        end
    end
    spell.collision_func = function(self, other)
        Engine.play_audio(Engine.load_audio(_modpath.."hit.ogg", true), AudioPriority.Low)

        local next_tile = self:get_tile(self:get_facing(), 1)
        if next_tile then
            next_tile:attack_entities(self)
        end
        if not self:is_deleted() then self:delete() end
    end

    -- I don't think this one runs maybe, but probably doesn't matter
    spell.on_attack_func = function(self, other)
        local next_tile = self:get_tile(self:get_facing(), 1)
        if next_tile then
            next_tile:attack_entities(self)
        end
        if not self:is_deleted() then self:delete() end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(Engine.load_audio(_modpath.."gun.ogg", true), AudioPriority.Low)
    return spell
end

function package_init(package) 
    package:declare_package_id("com.Alrysc.Dawn.card.requested.ColForce")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'Q'})
    
    local props = package:get_card_props()
    props.shortname = "ColForce"
    props.damage = 30
    props.time_freeze = false
    props.element = Element.None
    props.description = "Smn Col. army in open pnls"
    props.card_class = CardClass.Giga
    props.limit = 1
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local do_once = true
        local facing = Direction.Right
        local start_x = 5
        local increment = -1
        if user:get_team() == Team.Blue then
            facing = Direction.Left
            start_x = 1
            increment = 1
        end
        local tile_array = {}
        local texture = Engine.load_texture(_modpath.."CommanderAddon.png")
        local anim_path = _modpath.."CommanderAddon.animation"
        local field = user:get_field()
        local character_query = function(c)
            return true
        end
        local occupied_query = function(ent)
            return true
        end

        local fail_count = 0


        local function create_soldier(tile)
            local soldier = Battle.Spell.new(user:get_team())
            soldier:set_facing(facing)
            soldier:set_texture(texture)
            local anim = soldier:get_animation()
            anim:load(anim_path)
            anim:set_state("COMMANDERARMY")
            anim:refresh(soldier:sprite())
            anim:on_frame(7, function()
                local spell = create_soldier_shot(user, props, facing)
                field:spawn(spell, soldier:get_tile(soldier:get_facing(), 1))
            end)
            anim:on_frame(11, function()
                local spell = create_soldier_shot(user, props, facing)
                field:spawn(spell, soldier:get_tile(soldier:get_facing(), 1))
            end)
            anim:on_frame(15, function()
                local spell = create_soldier_shot(user, props, facing)
                field:spawn(spell, soldier:get_tile(soldier:get_facing(), 1))
            end)
            anim:on_complete(function()
                soldier:erase()
            end)
            field:spawn(soldier, tile)
            not_done = false


        end

        local function create_soldier_wave(list)
            local delay = 9
            local spawn = 1
            local spawned_something = false


            local soldier_handler = Battle.Component.new(user, Lifetimes.Local)

            soldier_handler.update_func = function()
                if delay % 9 == 0 then 
                    while(not spawned_something)
                    do
                        if list[spawn] then 
                            create_soldier(list[spawn])
                            spawn = spawn + 1
                            spawned_something = true

                        else
                            spawn = spawn + 1
                        end

                        if spawn == 4 then 
                            spawned_something = true
                            soldier_handler:eject()
                        end
                    end
                end

                spawned_something = false

                delay = delay + 1
                
            end

            user:register_component(soldier_handler)

        end

        local colforce_handler = Battle.Component.new(user, Lifetimes.Local)

        
        local delay = -5
        local function tile_checker()
            local done = false

            while(true)
            do
                -- Collect column
                for i=1, 3, 1
                do
                    tile_array[i] = field:tile_at(start_x, i)
                end

                -- Check which ones can't have a spawn
                    -- Probably redundant
                for i=1, 3, 1
                do
                    if tile_array[i]:is_edge() then 
                        done = true
                        break
                    end
                    if not (tile_array[i]:is_walkable() and user:get_team() == tile_array[i]:get_team() and #tile_array[i]:find_obstacles(occupied_query) == 0) then 
                        tile_array[i] = nil 
                        fail_count = fail_count + 1
                    end
                end

                if done then 
                    tile_array = {}

                    colforce_handler:eject()
                    break
                end

                -- If we could spawn on some, start the wave
                    -- Else, check next column
                if fail_count < 3 and not done then 
                    start_x = start_x + increment

                    break
                else
                    fail_count = 0
                    start_x = start_x + increment
                    
                end
            end
            

        end

        tile_checker()

        colforce_handler.update_func = function()

            if delay % 50 == 0 then
                if do_once then 
                    do_once = false
                else
                    tile_checker()
                end

                create_soldier_wave(tile_array)    

            end

            delay = delay+1 
        end

        user:register_component(colforce_handler)
        action:end_action()

        
    end -- End execute

    return action
end