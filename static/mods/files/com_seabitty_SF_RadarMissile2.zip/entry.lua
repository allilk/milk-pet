nonce = function() end

local TEXTURE = Engine.load_texture(_modpath.."missilecrash.png")
local AUDIO = Engine.load_audio(_modpath.."missile.ogg")
local O_TEXTURE = Engine.load_texture(_modpath.."O.png")
local O_ANIMPATH = _modpath.."O.animation"

function package_init(package) 
    package:declare_package_id("com.seabitty.radarmissile2")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C','F','U'})

    local props = package:get_card_props()
    props.shortname = "RdrMisl2"
    props.damage = 130
    props.time_freeze = true
    props.element = Element.None
    props.description = " atk if emy HP tens dgt is even"
    props.long_description = "Missile attack. Targets enemies with even tens HP digit."
	props.can_boost = true
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "IDLE")
    local frame1 = {2, 0.75}
    local long_frame = make_frame_data({frame1})
    action:override_animation_frames(long_frame)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("Searching...")
        local function is_even_tens(n)
            return math.floor(n / 10) % 2 == 0
        end
        
        local field = user:get_field()
        local targets = field:find_characters(function(found)
            if found ~= nil and user:get_team() ~= found:get_team() then
                local health = found:get_health()
                print("Health:", health)
                if health ~= nil and math.floor((health % 100) / 10) % 2 == 0 then
                    print("Target hit")
                    return true
                end
            end
            return false
        end)
        local tile = nil
        local spell = nil
        for i = 1, #targets, 1 do
            tile = targets[i]:get_tile()
            spell = create_missile(user, props)
            field:spawn(spell, tile)
        end
    end
    return action
end

function create_missile(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(TEXTURE, true)
	anim:load(_modpath.."missilecrash.animation")
	anim:set_state("0")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:erase()
	end)
	local do_once = true

	spell.update_func = function(self, dt)
		if do_once then
			self:get_tile():attack_entities(self)
			do_once = false
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end