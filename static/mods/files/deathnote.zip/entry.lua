function package_init(block)
    block:declare_package_id("com.example.block.deathnote")
    block:set_name("Deathnote")
    block:set_description("Take a Chip and Eat it.")
    block:set_color(Blocks.Red)
    block:set_shape({
        1, 1, 1, 1, 1,
        1, 1, 1, 1, 1,
        1, 1, 1, 1, 1,
        1, 1, 1, 1, 1,
        1, 1, 1, 1, 1
    })
    block:set_mutator(modify)
end

function modify(player)
	local music_player = Battle.Component.new(player, Lifetimes.Local)
	local cooldown = 1/60
	music_player.update_func = function(self, dt)
		if cooldown <= 0 then
			Engine.stream_music(_modpath.."music.wav")
			self:eject()
		else
			cooldown = cooldown - dt
		end
	end
	player:register_component(music_player)
end