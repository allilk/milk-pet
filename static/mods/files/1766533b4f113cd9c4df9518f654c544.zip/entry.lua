local DAMAGE = 300
local TEXTURE = Engine.load_texture(_modpath .. "black wave.png")
local AUDIO = Engine.load_audio(_modpath .. "sfx.ogg")

function package_init(package)
	package:declare_package_id("com.Dawn.PhantasyStar.BlackWave")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'Z' })

	local props = package:get_card_props()
	props.shortname = "BlkWave"
	props.damage = DAMAGE
	props.time_freeze = false
	props.element = Element.None
	props.description = "The Power of Dark Force!"
	props.card_class = CardClass.Giga
	props.limit = 1
	props.long_description = "Summon a Black Wave 3 tiles ahead!"
end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local tile = user:get_tile(user:get_facing(), 3)

		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
		end)

		self:add_anim_action(3, function()
			local attack = create_attack("BLACK_WAVE", user, props)
			user:get_field():spawn(attack, tile)
		end)
	end
	return action
end

function create_attack(animation_state, user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_texture(TEXTURE, true)
	spell:sprite():set_layer(-5)
	spell:highlight_tile(Highlight.Flash)
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Pierce,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	anim:load(_modpath .. "black wave.animation")
	anim:set_state(animation_state)
	spell:get_animation():on_complete(function()
		spell:erase()
	end)

	local attack_delay = 15
    spell.update_func = function(self, dt)
        if attack_delay <= 0 then
            self:get_tile():attack_entities(self)
        else
            attack_delay = attack_delay - 1
        end
	end
	spell.collision_func = function(self, other)
	end
	spell.attack_func = function(self, other)
		local bug = Battle.Component.new(other, Lifetimes.Local)
		bug.cooldown = 0
		bug.cooldown_max_table = {40, 35, 30, 25, 20, 15, 10}
		bug.cooldown_index = 1
		bug.acceleration_cooldown = 300
		bug.cooldown_max = bug.cooldown_max_table[bug.cooldown_index]
		bug.owner = other
		bug.owner_is_player = Battle.Player.from(other) ~= nil
		bug.update_func = function(self, dt)
			if self.owner:is_deleted() then return end
			if bug.owner_is_player then
				if self.owner:get_health() <= math.floor(self.owner:get_max_health()*0.25) then
					Engine.stream_music(_modpath.."song.mid")
					self.cooldown_index = 1
					self.acceleration_cooldown = -1
				end
			end
			self.acceleration_cooldown = self.acceleration_cooldown - 1
			if self.acceleration_cooldown == 0 then
				self.cooldown_index = self.cooldown_index + 1
				self.acceleration_cooldown = 300
				if self.cooldown_index > #self.cooldown_max_table then
					self.cooldown_index = #self.cooldown_max_table
					self.acceleration_cooldown = -1
				end
			end
			self.cooldown = self.cooldown - 1
			if self.cooldown <= 0 then
				self.owner:set_health(self.owner:get_health() - 1)
				self.cooldown = self.cooldown_max_table[self.cooldown_index]
			end
		end
		other:register_component(bug)
	end
	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.High)

	return spell
end
