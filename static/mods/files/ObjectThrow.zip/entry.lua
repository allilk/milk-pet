nonce = function() end

local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.claris.card.ObjectThrowV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'O', 'B', 'J'})

    local props = package:get_card_props()
    props.shortname = "ObjThrow"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "Grab obj. behind & throw!"
	props.can_boost = true
	props.limit = 1
	props.long_description = "Grab what's behind you and toss it 2 tiles in front!"
	props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		local direction = user:get_facing_away()
		local tile = user:get_tile(direction, 1)
		local target = tile:find_obstacles(function(found)
			if found ~= nil then
				return true
			end
		end)
		if target[1] ~= nil then
			local jump_component = Battle.Component.new(target[1], Lifetimes.Battlestep)
			jump_component._thrown = false
			jump_component._shake_countdown = 30
			jump_component._shake_complete = false
			jump_component.target = target[1]
			jump_component.user = user
			jump_component.update_func = function(self, dt) 
				if self._thrown then 
					self._shake_countdown = self._shake_countdown - 1
					if self._shake_countdown <= 0 and not self._shake_complete then
						self.user:shake_camera(5, 1)
						self._shake_complete = true
						self:eject()
					end
					return
				end
				self.target:jump(self.target:get_tile(self.user:get_facing(), 3), 60.0, frames(30), frames(10), ActionOrder.Involuntary, function() jump_component._thrown = true end)
			end
			target[1]:register_component(jump_component)
		end
	end
	return action
end