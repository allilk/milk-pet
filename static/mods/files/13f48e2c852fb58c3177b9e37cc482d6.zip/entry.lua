local DAMAGE = 0

local MAGNECOIL_TEXTURE = Engine.load_texture(_modpath.."magnecoil.png")
local MAGNECOIL_ANIMPATH = _modpath.."magnecoil.animation"
local MAGNECOIL_AUDIO = Engine.load_audio(_modpath.."magnecoil.ogg")
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster.png")
local BUSTER_ANIMPATH = _modpath.."buster.animation"

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-185-MagneCoil")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"*"})

    local props = package:get_card_props()
    props.shortname = "MagCoil"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "Draw in enmy with mag force"
    props.long_description = "3 horizontal squares of the magnetic force draws in upper and lower enemies"
    props.can_boost = false
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    local frame1 = {1, 0.017}
	local frame2 = {1, 0.050}
	local frame3 = {1, 0.033}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame2, frame3, frame2, frame1})
    action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-3)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")

        local field = user:get_field()
        local team = user:get_team()
        local facing = user:get_facing()

		self:add_anim_action(2, function()
			create_magnecoil(field, team, facing, user, props, actor:get_tile(facing, 1))
		end)
    end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
	end
    return action
end

function create_magnecoil(field, team, facing, user, props, tile)
    local fx = Battle.Artifact.new()
    fx:set_facing(facing)
    fx:set_texture(MAGNECOIL_TEXTURE, true)
    if facing == Direction.Right then
        print("MagneCoil range: from ("..tile:x()..";"..tile:y()..") to ("..tile:get_tile(facing, 2):x()..";"..tile:y()..")")
        fx:set_offset(37, -29)
    else
        print("MagneCoil range: from ("..tile:get_tile(facing, 2):x()..";"..tile:y()..") to ("..tile:x()..";"..tile:y()..")")
        fx:set_offset(-37, -29)
    end
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-9999)
    local fx_anim = fx:get_animation()
    fx_anim:load(MAGNECOIL_ANIMPATH)
    fx_anim:set_state("0")
    fx_anim:refresh(fx_sprite)
    local frames = {2, 6, 9, 13}
    for i, j in ipairs(frames) do
        fx_anim:on_frame(j, function()
            create_attack(user, props, team, field, tile:get_tile(Direction.Up, 1), Direction.Down)
            create_attack(user, props, team, field, tile:get_tile(facing, 1):get_tile(Direction.Up, 1), Direction.Down)
            create_attack(user, props, team, field, tile:get_tile(facing, 2):get_tile(Direction.Up, 1), Direction.Down)
            create_attack(user, props, team, field, tile:get_tile(Direction.Down, 1), Direction.Up)
            create_attack(user, props, team, field, tile:get_tile(facing, 1):get_tile(Direction.Down, 1), Direction.Up)
            create_attack(user, props, team, field, tile:get_tile(facing, 2):get_tile(Direction.Down, 1), Direction.Up)
        end)
    end
    fx_anim:on_complete(function() fx:erase() end)
    Engine.play_audio(MAGNECOIL_AUDIO, AudioPriority.High)
    field:spawn(fx, tile)
    return fx
end

function create_attack(user, props, team, field, tile, direction)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            0,
            Hit.Drag,
            Element.None,
            user:get_id(),
            Drag.new(direction, 1)
        )
    )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

	spell.collision_func = function(self, other)
	end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		self:delete()
	end

    spell.delete_func = function(self)
		self:erase()
	end

    spell.attack_func = function(self, other)
        --Engine.play_audio(Engine.load_audio(_modpath.."hitsound"..number..".ogg"), AudioPriority.High)
    end

    field:spawn(spell, tile)

    --print("Attack tile: ("..tile:x()..";"..tile:y()..")")

	return spell
end