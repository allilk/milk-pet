function package_init(package) 
    package:declare_package_id("com.claris.card.Sword02")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'H', 'L', 'S', '*'})

    local props = package:get_card_props()
    props.shortname = "WideSwrd"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Cuts enmy in front! Range: 3"
	props.limit = 5
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())
	local SLASH_TEXTURE = Engine.load_texture(_modpath.."spell_sword_slashes.png")
	local BLADE_TEXTURE = Engine.load_texture(_modpath.."spell_sword_blades.png")
    action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HILT")

			local blade = hilt:add_attachment("ENDPOINT")
			local blade_sprite = blade:sprite()
			blade_sprite:set_texture(BLADE_TEXTURE)
			blade_sprite:set_layer(-1)

			local blade_anim = blade:get_animation()
			blade_anim:load(_modpath.."spell_sword_blades.animation")
			blade_anim:set_state("DEFAULT")
		end)
		
		local field = user:get_field()
		self:add_anim_action(3, function()
			local sword = create_slash(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			local fx = Battle.Artifact.new()
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(SLASH_TEXTURE, true)
			anim:load(_modpath.."spell_sword_slashes.animation")
			anim:set_state("WIDE")
			anim:on_complete(function()
				fx:erase()
				if not sword:is_deleted() then sword:delete() end
			end)
			field:spawn(sword, tile)
			field:spawn(fx, tile)
		end)
	end
    return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = user:get_field()
    spell.update_func = function(self, dt) 
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(Direction.Up, 1)
		local tile_next_two = tile:get_tile(Direction.Down, 1)
		if tile_next and not tile_next:is_edge() then
			tile_next:highlight(Highlight.Flash)
		end
		if tile_next_two and not tile_next_two:is_edge() then
			tile_next_two:highlight(Highlight.Flash)
		end
		if attack_once then
			if tile_next and not tile_next:is_edge() then
				local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile_next)
			end
			if tile_next_two and not tile_next_two:is_edge() then
				local hitbox_l = Battle.SharedHitbox.new(self, 0.2)
				hitbox_l:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_l, tile_next_two)
			end
			attack_once = false
		end
		tile:attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end