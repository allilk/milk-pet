nonce = function() end

local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
local TEXTURE = Engine.load_texture(_modpath.."present.png")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."spell_explosion.png")
 
local FRAME1 = {1, 0.1}
local FRAME2 = {2, 0.05}
local FRAME3 = {3, 0.05}
local FRAMES = make_frame_data({FRAME1, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME3, FRAME2, FRAME1, FRAME3, FRAME2, FRAME3, FRAME2})

--??? If you're reading this. You're really not funny. We all have gotten to the point where we're likely to just ignore you. We really don't want too, 
--but it isn't fun dealing with heavily modified chips that are solely made to make *you* win more times than not
--If it is discovered that you modify this chip or any others then I will be keeping them private going forwards

function package_init(package)
    package:declare_package_id("rune.legacy.darkprism")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'R','O','Y','G','B','P'})
    local props = package:get_card_props()
    props.shortname = "DarkPrism"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Summon
    props.secondary_element = Element.None
    props.description = "Dark Rainbow Burst"
    props.card_class = CardClass.Dark
	props.can_boost = false
	props.limit = 1
   
end






function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")		
		local present = Battle.Obstacle.new(Team.Other)
		present:set_texture(TEXTURE, true)
		present:get_animation():load(_modpath.."present.animation")
		present:get_animation():set_state("SPAWN")
		present:get_animation():on_complete(function()
			present:get_animation():set_state("DEFAULT")
			present:get_animation():set_playback(Playback.Loop)
		end)
		present:set_health(200)
		present.can_move_to_func = function(tile)
			if not tile then
				return false
			end
            anim:refresh(spell:sprite())
			if tile:get_state() == TileState.Broken or tile:get_state() == TileState.Empty or tile:is_edge() then
				return false
			end
            anim:refresh(spell:sprite())
			return true
		end
		present.update_func = function(self, dt)
			local tile = present:get_current_tile()
			if not tile then
                anim:refresh(spell:sprite())
				self:erase()
			end
			if tile:get_state() == TileState.Broken or tile:get_state() == TileState.Empty or tile:is_edge() then
				self:erase()
                anim:refresh(spell:sprite())
			end
			if self:get_health() <= 0 then
				self:delete()
                anim:refresh(spell:sprite())
			end
		end
		present.delete_func = function(self)
			Engine.play_audio(AUDIO, AudioPriority.Low)
			local field = user:get_field()
			local tile = nil
			for i = 0, 6, 1 do
				for j = 0, 6, 1 do
					tile = field:tile_at(i, j)
					if tile and not tile:is_edge() then
						local explosion = create_boom(user)
						field:spawn(explosion, tile)
					end
				end
			end
		end
		user:get_field():spawn(present, user:get_tile(user:get_facing(), 1))
	end
    return action
end

function create_boom(user)
	local spell = Battle.Spell.new(Team.Other)
    spell.hits = 3
	spell:set_texture(EXPLOSION_TEXTURE, true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            200, 
            Hit.Pierce | Hit.Stun, 
            Element.Wind,
            user:get_context(),
            Drag.None

        )
    )
	local do_once = true
	spell.update_func = function(self, dt) 
		if do_once then
			local anim = spell:get_animation()
			anim:load(_modpath.."spell_explosion.animation")
			local spare_props = spell:copy_hit_props()
			local cur_tile = spell:get_current_tile()
			if cur_tile and cur_tile:get_state() == TileState.Grass then
				spare_props.element = Element.Wood
				anim:set_state("DEFAULT")
				spell:set_hit_props(spare_props)
			elseif cur_tile and cur_tile:get_state() == TileState.Lava then
				spare_props.element = Element.Fire
				anim:set_state("DEFAULT")
				spell:set_hit_props(spare_props)
				cur_tile:set_state(TileState.Normal)
			else	
				anim:set_state("DEFAULT")
			end
			anim:refresh(spell:sprite())
			anim:on_complete(function()
				if spell.hits > 1 then
					anim:set_playback(Playback.Loop)
					spell.hits = spell.hits - 1
					local hitbox = Battle.Hitbox.new(spell:get_team())
					hitbox:set_hit_props(spell:copy_hit_props())
					spell:get_field():spawn(hitbox, spell:get_current_tile())
				else
                    anim:refresh(spell:sprite())
                    spell:erase()
				end
			end)
			do_once = false
		end
		self:get_current_tile():attack_entities(self)
    end
	spell.collision_func = function(self, other)
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
        anim:refresh(spell:sprite())
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO, AudioPriority.Highest)
	return spell
end