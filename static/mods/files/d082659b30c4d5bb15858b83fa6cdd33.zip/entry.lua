local bustertexture = Engine.load_texture(_modpath.."bustertexture.png")
local atktexture = Engine.load_texture(_modpath.."TornadoS.png")
local impacttexture = Engine.load_texture(_modpath.."hiteffectS.png")
local shootaudio = Engine.load_audio(_modpath.."sword.ogg")
local hitaudio = Engine.load_audio(_modpath.."damageenemy.ogg")
local impactanim = _modpath .. "hiteffectS.animation"

function package_init(package) -- Basic stuff
    package:declare_package_id("hoov.card.coldair2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon2.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview2.png"))
    package:set_codes({"B","I","Q","U"})

    local props = package:get_card_props()
    props.shortname = "ColdAir2"
    props.damage = 20
    props.time_freeze = false
    props.element = Element.Aqua
    props.secondary_element = Element.Wind --Useless right now, but I'll need to set it in 2.5
    props.description = "Cold wind pushes obj forward"
    props.limit = 4

    -- assign the global resources
    
end


function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(bustertexture, true)
        buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "buster.animation")
		buster_anim:set_state("V2")
        --local direction = user:get_facing()
        local tile = user:get_current_tile()
        local tileA = user:get_current_tile():get_tile(Direction.Up, 1)
        local tileB = user:get_current_tile():get_tile(Direction.Down, 1)
        --comment/uncomment accordingly based on version
        local shot1 = create_shot(user, props)
        local shot2 = create_shot(user, props)
        local shot3 = create_shot(user, props)
        user:get_animation():on_frame(1, function()
            --user:toggle_counter(true)
            user:get_field():spawn(shot1, tile)
            if tileA ~= nil and not tileA:is_edge() then
                user:get_field():spawn(shot2, tileA)
            end
            if tileB ~= nil and not tileB:is_edge() then
                user:get_field():spawn(shot3, tileB)
            end
            
            Engine.play_audio(shootaudio, AudioPriority.Low)
        end, false)


    end
    return action
end


function create_shot(user, props)
    local direction = user:get_facing()
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Drag,
            props.element,
            user:get_context(),
            Drag.new(direction, 1)
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(atktexture)
    sprite:set_layer(-1)
    local anim = spell:get_animation()
    anim:load(_modpath.."TornadoS.animation")
    anim:set_state("AQUA1")
    anim:refresh(spell:sprite())
    anim:on_complete(function()

        anim:set_playback(Playback.Loop)
    end)
    local collisionswitch = true
    local erasetime = 1
    --local canhit = true
    spell.update_func = function(self, dt)
        
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(direction, 1)
        
        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            print("erased")
            spell:erase()
            return
        end
        --- Makes the spell slide to the next tile over a certain number of frames.
        if collisionswitch == true then
            spell:slide(tile, frames(5), frames(0), ActionOrder.Voluntary, nil)
        else
            --multihit code here
            erasetime = erasetime + 1
            if erasetime % 8 == 0 then
                local tile = self:get_current_tile()
                local attack = create_attack(user, props)
                spell:get_field():spawn(attack, tile)
                --local hitbox = Battle.Hitbox.new(spell:get_team())
                --hitbox:set_hit_props(spell:copy_hit_props())
                --spell:get_field():spawn(hitbox, spell:get_current_tile())

            end
            if erasetime % 22 == 0 then
                
                spell:erase()
            end
        end
        --tilecount = tilecount + 1
        --- Attacks the entities this spell collides with.
        --if canhit then
            self:get_current_tile():attack_entities(self)
        --end
        spell:highlight_tile(Highlight.Solid)
    end
    spell.collision_func = function(self, other)
        collisionswitch = false
        canhit = false
	end
    spell.delete_func = function(self)
		self:erase()
    end

	spell.can_move_to_func = function(tile)
		return true
	end
	spell.attack_func = function(self, other)
		--Engine.play_audio(hitaudio, AudioPriority.Lowest)
        print("hit!")
        local tile = self:get_current_tile()
        create_effect(self, props, tile)
		--hit effect gen here

	end



    return spell
end

function create_attack(user, props)
    local direction = user:get_facing()
    local spell = Battle.Spell.new(user:get_team())
    local attack_once = true
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Drag,
            props.element,
            user:get_context(),
            Drag.new(direction, 1)
        )
    )
    local tile = user:get_current_tile()
    spell.update_func = function(self, dt)
        if attack_once then
         self:get_current_tile():attack_entities(self)
         attack_once = false
        end
    end
    spell.attack_func = function(self, other)
        print("attackhit")
        local tile = self:get_current_tile()
        --Engine.play_audio(hitaudio, AudioPriority.Lowest)
        create_effect(self, props, tile)
    end


    return spell
end

function create_effect(self, props, tile)
    print("createfx")
    local fx = Battle.Artifact.new()
    fx:set_texture(impacttexture, true)
    fx:get_animation():load(impactanim)
    fx:get_animation():set_state("ICE")
    fx:get_animation():refresh(fx:sprite())
    fx:get_animation():on_complete(function()
        fx:erase()
    end)
    fx:set_elevation(40)
    fx:set_height(-16.0)
    self:get_field():spawn(fx, tile)


    Engine.play_audio(hitaudio, AudioPriority.Highest)


end