local DAMAGE = 150

local TEXTURE_AIRMAN = Engine.load_texture(_modpath.."airman.png")
local TEXTURE_TORNADO = Engine.load_texture(_modpath.."tornado.png")
local ANIMPATH_AIRMAN = _modpath.."airman.animation"
local ANIMPATH_TORNADO = _modpath.."tornado.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_TORNADO = Engine.load_audio(_modpath.."tornado.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.airmands")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A"})

    local props = package:get_card_props()
    props.shortname = "AirManDS"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Wind
    props.description = "Shoots 3 twisters!"
    props.long_description = "Shoots air twisters in a line"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_hole_query = function(hole)
        return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
    end
    local field = actor:get_field()
    local dark_hole_list = field:find_obstacles(dark_hole_query)
    local boost = 10 * (math.min(10, #dark_hole_list))
    props.damage = props.damage + boost
    action:set_metadata(props)
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset = nil

        if direction == Direction.Right then
            X_offset = X + 1
        else
            X_offset = X - 1
        end

		local step1 = Battle.Step.new()

        self.airman = nil
        self.tile  = user:get_current_tile()
        
        local field = user:get_field()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.airman = Battle.Artifact.new()
                ref.airman:set_facing(user:get_facing())
		    	ref.airman:set_texture(TEXTURE_AIRMAN, true)
		    	ref.airman:sprite():set_layer(-1)

                airman_anim = ref.airman:get_animation()
                airman_anim:load(ANIMPATH_AIRMAN)
                airman_anim:set_state("SPAWN")
		    	airman_anim:refresh(ref.airman:sprite())
                airman_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
		    	end)
		    	airman_anim:on_complete(function()
		    		airman_anim:set_state("ATTACK")
		    		airman_anim:refresh(ref.airman:sprite())
		    	end)
                field:spawn(ref.airman, ref.tile)
            end
            local anim = ref.airman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local tornado_01 = create_tornado(user, props, 12)
                    local tornado_02 = create_tornado(user, props, 14)
                    local tornado_03 = create_tornado(user, props, 16)
                    anim:on_frame(4, function()
                        Engine.play_audio(AUDIO_TORNADO, AudioPriority.Highest)
                        field:spawn(tornado_01, X_offset, 1)
                        field:spawn(tornado_02, X_offset, 2)
                        field:spawn(tornado_03, X_offset, 3)
                    end)
                    anim:on_frame(6, function()
                        tornado_01.start()
                        tornado_02.start()
                        tornado_03.start()    
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
                        anim:refresh(ref.airman:sprite())
                        anim:on_complete(function()
                            ref.airman:erase()
                            step1:complete_step()
                        end)
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_tornado(user, props, speed)
    local spell = Battle.Spell.new(user:get_team())
    local direction = user:get_facing()
    spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_texture(TEXTURE_TORNADO)
    local anim = spell:get_animation()
    anim:load(ANIMPATH_TORNADO)
    anim:set_state("1")
    anim:set_playback(Playback.Loop)
    anim:refresh(sprite)

    spell.update_func = function(self, dt)
        if(spell.started)then
            local tile = spell:get_tile(direction, 1)
            if(tile == nil) then
                spell:erase()
                return
            end
            spell:slide(tile, frames(speed), frames(0), ActionOrder.Voluntary, nil)
            
            self:get_current_tile():attack_entities(self)
        end
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
		spell:erase()
	end
    spell.can_move_to_func = function(tile)
        return true
    end
    spell.start = function()
        spell.started = true
    end
    return spell
end

