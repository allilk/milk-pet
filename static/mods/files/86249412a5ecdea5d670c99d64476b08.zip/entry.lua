
function package_init(package)
    package:declare_package_id("supersmashbros_NormalNavi_made_by_Pyroja_and_Jamesking")
    package:set_special_description("The basic commercial Navi.")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."NormalNavi_ow.animation")
    package:set_overworld_texture_path(_modpath.."NormalNavi_ow.png")
    package:set_icon_texture(Engine.load_texture(_modpath.."NormalNavi_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("NormalNavi")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(48.0)

    local base_texture = Engine.load_texture(_modpath.."NormalNavi.png")
    local base_animation_path = _modpath.."NormalNavi.animation"
    local base_charge_color = Color.new(255, 0, 255, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -16)

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end

end
