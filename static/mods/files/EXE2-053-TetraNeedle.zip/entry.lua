local doubleneedle = include("doubleneedle/doubleneedle.lua")

local DAMAGE = 50

doubleneedle.shots_count = 4
doubleneedle.needle_type = "2"

doubleneedle.codes = {"C","H","I","P","U"}
doubleneedle.shortname = "TetraNdl"
doubleneedle.damage = DAMAGE
doubleneedle.time_freeze = false
doubleneedle.element = Element.None
doubleneedle.description = "4 volleys of needles!"
doubleneedle.long_description = "Launch 4 needles in a row!"
doubleneedle.can_boost = true
doubleneedle.card_class = CardClass.Standard
doubleneedle.limit = 5

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-053-TetraNeedle")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(doubleneedle.codes)

    local props = package:get_card_props()
    props.shortname = doubleneedle.shortname
    props.damage = doubleneedle.damage
    props.time_freeze = doubleneedle.time_freeze
    props.element = doubleneedle.element
    props.description = doubleneedle.description
    props.long_description = doubleneedle.long_description
    props.can_boost = doubleneedle.can_boost
	props.card_class = doubleneedle.card_class
	props.limit = doubleneedle.limit
end

card_create_action = doubleneedle.card_create_action