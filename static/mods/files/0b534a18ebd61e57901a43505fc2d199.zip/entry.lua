local DAMAGE = 50

local VOICE_FLASHLIGHT_1 = Engine.load_audio(_modpath.."furasshuraito1.ogg")
local VOICE_FLASHLIGHT_2 = Engine.load_audio(_modpath.."furasshuraito2.ogg")

local TEXTURE_FLASHMAN = Engine.load_texture(_modpath.."flashman.png")
local ANIMPATH_FLASHMAN = _modpath.."flashman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")

local TEXTURE_FLASHLIGHT = Engine.load_texture(_modpath.."flashlight.png")
local ANIMPATH_FLASHLIGHT = _modpath.."flashlight.animation"
local AUDIO_FLASHLIGHT = Engine.load_audio(_modpath.."flashlight.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
	package:declare_package_id("com.Dawn.k1rbyat1na.card.EXE3-234-FlashMan")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F"})

	local props = package:get_card_props()
	props.shortname = "FlashMan"
	props.damage = DAMAGE
	props.time_freeze = true
	props.can_boost = true
	props.element = Element.Elec
	props.description = "Flash atk paralyzes enemies!"
	props.long_description = "Flash attack illuminates all! Paralyzes enemies"
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		local actor = self:get_actor()
		actor:hide()

		local NOT_HOLE = nil

		local VOICEACTING = false
        local input_time = 50
        local voiceline_number = 0

		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local self_tile = user:get_current_tile()

		local friendly_query = function(ent)
			if user:is_team(ent:get_team()) then
				return true
			end
		end
		local dark_query = function(o)
			return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
		end

		local step1 = Battle.Step.new()

		self.flashman = nil

		local ref = self

		local do_once = true
		local do_once_part_two = true
		step1.update_func = function(self, dt)
			if input_time > 0 then
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
            end
			if not user:get_current_tile():is_hole() then
                NOT_HOLE = true
            else
                NOT_HOLE = false
            end
			if do_once then
				do_once = false
				ref.flashman = Battle.Artifact.new()
				ref.flashman:set_facing(direction)
				local boss_sprite = ref.flashman:sprite()
				boss_sprite:set_layer(-5)
				boss_sprite:set_texture(TEXTURE_FLASHMAN, true)
				local boss_anim = ref.flashman:get_animation()
				boss_anim:load(ANIMPATH_FLASHMAN)
				if NOT_HOLE then
					boss_anim:set_state("SPAWN")
					boss_anim:refresh(boss_sprite)
				else
					boss_anim:set_state("HOLE")
					boss_anim:refresh(boss_sprite)
				end
				boss_anim:on_frame(2, function()
					voiceline_number = math.random(1,2)
					Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
				end)
				boss_anim:on_frame(13, function()
					if VOICEACTING then
						if voiceline_number == 1 then
							print("FlashMan: FlashLight!")
							Engine.play_audio(VOICE_FLASHLIGHT_1, AudioPriority.High)
						end
					end
				end)
				boss_anim:on_complete(function()
					if NOT_HOLE then
						boss_anim:set_state("ATTACK")
						boss_anim:refresh(boss_sprite)
					else
						ref.flashman:erase()
                        step1:complete_step()
					end
				end)
				field:spawn(ref.flashman, self_tile)
			end
			local anim = ref.flashman:get_animation()
			if anim:get_state() == "ATTACK" then
				if do_once_part_two then
					do_once_part_two = false
					anim:on_frame(3, function()
                        if VOICEACTING then
                            if voiceline_number == 2 then
                                print("FlashMan: FlashLight!")
                                Engine.play_audio(VOICE_FLASHLIGHT_2, AudioPriority.High)
                            end
                        end
                    end)
					anim:on_frame(7, function()
						if not VOICEACTING then
							print("FlashMan: FlashLight!")
						end
						Engine.play_audio(AUDIO_FLASHLIGHT, AudioPriority.High)
						for i = 1, 6, 1 do
							for j = 1, 3, 1 do
								local tile = field:tile_at(i,j)
								if tile == self_tile then
									print("user tile found, skipping")
								elseif #tile:find_characters(friendly_query) > 0 or #tile:find_entities(dark_query) > 0 then
									print("friendly/obstacle tile found, skipping")
								else
									create_attack(user, props, team, direction, field, tile)
								end
							end
						end
						local flashlight = Battle.Artifact.new()
        				flashlight:set_facing(Direction.Right)
						local flashlight_sprite = flashlight:sprite()
        				local flashlight_anim = flashlight:get_animation()
						flashlight_sprite:set_layer(1)
						flashlight_sprite:set_texture(TEXTURE_FLASHLIGHT, true)
						flashlight_anim:load(ANIMPATH_FLASHLIGHT)
						flashlight_anim:set_state("DEFAULT")
						flashlight_anim:refresh(flashlight_sprite)
        				flashlight_anim:on_complete(function()
        				    flashlight:erase()
        				end)
        				field:spawn(flashlight, 1, 1)
					end)
					anim:on_complete(function()
						anim:set_state("END")
                        anim:refresh(ref.flashman:sprite())
                        anim:on_complete(function()
                            ref.flashman:erase()
                            step1:complete_step()
                        end)
					end)
				end
			end
		end
		self:add_step(step1)
	end
	action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_attack(user, props, team, direction, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_facing(direction)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Stun | Hit.Pierce | Hit.Retangible, 
            props.element,
            user:get_id(),
            Drag.None
        )
    )

	local animation = spell:get_animation()
    animation:load(_modpath.."attack.animation")
    animation:set_state("1")
    animation:on_complete(function()
        spell:erase()
    end)
	
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
    end

	spell.can_move_to_func = function(self, other)
		return true
	end

	spell.battle_end_func = function(self)
		spell:erase()
	end

	spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "ELEC", math.random(-5,5), math.random(-5,5), field, self:get_current_tile())
    end

	field:spawn(spell, tile)

	return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end