local HIT_SFX = nil
local FIRE_PROJECTILE_SFX = nil
local FIRE_KICK = nil
local APPEAR_SFX = nil
local BREAK_SFX = nil
local SPIN_SFX = nil
local COMMAND_SUCCESS = nil

local HIT_SFX = nil

function package_init(package) 
    package:declare_package_id("com.alrysc.card.YukiV1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'Y','M','*'})

    local props = package:get_card_props()
    props.shortname = "Yuki"
    props.damage = 40
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Fire combo attack!"
    props.card_class = CardClass.Mega
    props.limit = 2
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local fixed = 10
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function highlight_tiles(self, list, time)
        local spell = Battle.Spell.new(self:get_team())
    
    
        local ref = self
        spell.update_func = function(self)
            for i=1, #list
            do 
                local t = list[i]
                if t and not t:is_edge() then 
                    t:highlight(Highlight.Solid)
                end
    
            end
    
    
            time = time - 1
            if time == 0 then 
                self:delete()
            end
    
            if self.flinching then 
                if spell and not spell:is_deleted() then 
                    spell:delete()
        
                end
            end
        end
    
    
        self:get_field():spawn(spell, self:get_current_tile())
        return spell
    end

    local function punch_attack(self, num, from_spin)
        from_spin = from_spin or false
        local spell = Battle.Spell.new(self:get_team())
        local effect = graphic_init("spell", 0, 0, "Yuki.png", "Yuki.animation", -4, "HIT_EFFECT"..num, self, self:get_facing(), true)
        local field = self:get_field()
        local tile = self:get_tile(self:get_facing(), 1)
        local hit_props = nil
        local team = self:get_team()
    
        if from_spin then 
            spell:highlight_tile(Highlight.Solid)
        end
    
        local damage = props.damage
    
        if from_spin or (num < 3 and not from_spin) then 
            hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Flash  | Hit.Shake | Hit.Drag,
                Element.Fire, 
                self:get_id(), 
                Drag.new(self:get_facing(), self:get_field():width())
            )
        else
            hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Flash  | Hit.Shake | Hit.Drag,
                Element.Fire, 
                self:get_id(), 
                Drag.new(self:get_facing(), self:get_field():width())
            )
        end
        spell:set_hit_props(hit_props)
    
        local lifetime = 12
        spell.update_func = function(self)
            self:get_tile():attack_entities(self)
    
            lifetime = lifetime - 1
            if lifetime == 0 then 
                self:delete()
            end
        end
    
    
    
        local function check_behind(other, is_behind)
            local spell = Battle.Spell.new(team)
            local tile = other:get_tile(other:get_facing_away(), 1)
    
            local hit_props = HitProps.new(
                50,
                Hit.Impact | Hit.Breaking,
                Element.None, 
                nil, 
                Drag.None
            )
    
            spell:set_hit_props(hit_props)
    
            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self:delete()
            end
    
            
    
            spell.collision_func = function()
                if not is_behind then 
                    check_behind(other, true)
                end
            end
    
            if is_behind then 
                tile = other:get_tile()
            end
    
            field:spawn(spell, tile)
        end
    
    
        spell.attack_func = function(self, other)
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
            if num < 3 or from_spin then return end
            local slide_check = Battle.Component.new(other, Lifetimes.Local)
    
    
            local not_sliding = 0
            slide_check.update_func = function()
                if not other:is_sliding() then 
                    if not_sliding == 1 then
                        other:get_tile(Direction.Up, 1):set_state(TileState.Cracked)
                        other:get_tile(Direction.Down, 1):set_state(TileState.Cracked)
                        other:get_tile():set_state(TileState.Cracked)
                        check_behind(other, false)
    
                        local shake_artifact = Battle.Artifact.new()
                        local time = 0
                        shake_artifact.update_func = function(self)
                                
                            self:shake_camera(150, 0.016)
                            if time == 24 then 
                                self:delete()
                            end
                        
                            time = time+1
                        end
    
                        field:spawn(shake_artifact, tile)
    
                        Engine.play_audio(BREAK_SFX, AudioPriority.Low)
    
                        slide_check:eject()
                    end
                    not_sliding = not_sliding+1
                else
                    not_sliding = 0
                end
    
            end
    
    
            other:register_component(slide_check)
        end
    
        field:spawn(spell, tile)
        field:spawn(effect, tile)
    
        return spell
    end

    local function move_slide(self, direction, time)
        Engine.play_audio(SPIN_SFX, AudioPriority.Low)
        time = time or nil
        self.slide_component = Battle.Component.new(self, Lifetimes.Local)
        local startPosition = 0
        local target = -50
        if direction == Direction.Down then 
            target = target * -1
        end
        local moveTime = 18
        if time then 
            moveTime = time
        end
        local elapsedMoveTime = 0
        local delta = 0
    
        local interp = 0
        local tileOffset = 0 
        local t = self:get_tile(direction, 1);
        self.slide_dest = t
        t:reserve_entity_by_id(self:get_id())
    
        local moved = false;
        local already_moved = false;
        self.slide_component.update_func = function()
            if delta >= 0.5 and not moved then 
                target = 0
            end
            
            delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
            interp =  target * delta + (startPosition * (1 - delta))
            
            tileOffset = interp - startPosition
            if delta >= 0.5 then
                tileOffset = -1*target + startPosition + tileOffset
            end
    
            if not already_moved then 
                t:reserve_entity_by_id(self:get_id())
            end
    
            -- Offsets are reflected a frame later than they're set
                -- So this moves us a frame later than we set an offset 
                -- for the new panel
            if moved and not already_moved then 
                already_moved = true
                start_tile = self:get_current_tile()
                start_tile:get_tile(direction, 1):add_entity(self)
                start_tile:remove_entity_by_id(self:get_id())
                self.slide_dest = nil
            end
    
            if delta >=0.5 and not moved then             
                moved = true
    
            end
    
            self:set_offset(0, tileOffset)
    
    
            if elapsedMoveTime == moveTime then 
                self.slide_component:eject()
                self.slide_component = nil
                self:set_offset(0, 0)
    
    
            end
    
            elapsedMoveTime = elapsedMoveTime + 1
    
        end
    
    
        self:register_component(self.slide_component)
    
      
    end

    
    local function move_slide_horizontal(self, direction, moveTime)
        Engine.play_audio(SPIN_SFX, AudioPriority.Low)
        self.slide_component = Battle.Component.new(self, Lifetimes.Local)
        local startPosition = 0
        local target = -80
        if direction == Direction.Right then 
            target = target * -1
        end
        local elapsedMoveTime = 0
        local delta = 0
    
        local interp = 0
        local tileOffset = 0 
        local t = self:get_tile(direction, 1);
        self.slide_dest = t
        t:reserve_entity_by_id(self:get_id())
    
        local moved = false;
        local already_moved = false;
        self.slide_component.update_func = function()
            if delta >= 0.5 and not moved then 
                target = 0
            end
            
            delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
            interp =  target * delta + (startPosition * (1 - delta))
            
            tileOffset = interp - startPosition
            if delta >= 0.5 then
                tileOffset = -1*target + startPosition + tileOffset
            end
    
            if not already_moved then 
                t:reserve_entity_by_id(self:get_id())
            end
    
            -- Offsets are reflected a frame later than they're set
                -- So this moves us a frame later than we set an offset 
                -- for the new panel
            if moved and not already_moved then 
                already_moved = true
                start_tile = self:get_current_tile()
                start_tile:get_tile(direction, 1):add_entity(self)
                start_tile:remove_entity_by_id(self:get_id())
                self.slide_dest = nil
            end
    
            if delta >=0.5 and not moved then             
                moved = true
    
            end
    
            self:set_offset(tileOffset, 0)
    
    
            if elapsedMoveTime == moveTime then 
                self.slide_component:eject()
                self.slide_component = nil
                self:set_offset(0, 0)
    
    
            end
    
            elapsedMoveTime = elapsedMoveTime + 1
    
        end
    
    
        self:register_component(self.slide_component)
    
      
    end

    local function create_fire_shot(self)
        local field = self:get_field()
        local spell = graphic_init("spell", 0, 0, "Yuki.png", "Yuki.animation", -4, "FIRE1", self, self:get_facing())
        spell:get_animation():on_complete(function()
            spell:get_animation():set_state("FIRE1_LOOP")
            spell:get_animation():refresh(spell:sprite())
            spell:get_animation():set_playback(Playback.Loop)
            spell.start_moving = true
        end)
        local facing = self:get_facing()
    
        local damage = fixed

        local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Shake | Hit.Drag,
                Element.Fire, 
                self:get_id(), 
                Drag.new(self:get_facing(), self:get_field():width())
            )
    
        spell:set_hit_props(hit_props)
    
        local speed = 6
        if self.apollo_active then 
            speed = 4
        end
        spell.update_func = function(self, dt)
            if not self.start_moving then 
                return 
            end
            self:get_tile():attack_entities(self)
            spell:get_current_tile():highlight(Highlight.Solid)
    
            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() and self.slide_started then 
                    self:delete()
    
                end 
                
                local dest = self:get_tile(facing, 1)
                local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end
            
        end
    
        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
            
        end
    
    
        spell.collision_func = function()
            local hit_effect = graphic_init("artifact", 0, 0, "Yuki.png", "Yuki.animation", -4, "FIRE1_HIT", self, spell:get_facing(), true)
            field:spawn(hit_effect, spell:get_current_tile())
            spell:delete()
        end
    
        spell.can_move_to_func = function()
            return true
        end
    
       -- Engine.play_audio(SHOOT_SFX, AudioPriority.Low)
        local tile = self:get_tile(facing, 1)
    
        if tile then 
            field:spawn(spell, tile)
        end
    end
    

    local function create_fire_wave(self, dir)
        local field = self:get_field()
        local state = "FIRE_WAVE"
        local last = 4
        local dir2 = Direction.Down
        if dir == Direction.Left or dir == Direction.Right then 
            state = "FIRE_SPIKE"
            last = 3
            dir2 = self:get_facing()
        end
        local spell = graphic_init("spell", 0, 0, "Yuki.png", "Yuki.animation", -4, state, self, self:get_facing())
        spell:get_animation():on_frame(last, function()
            spell.start_moving = true
        end)
        local facing = self:get_facing()
    
        local damage = fixed
   
        local hit_props = HitProps.new(
                damage,
                Hit.Impact | Hit.Flinch | Hit.Shake | Hit.Drag,
                Element.Fire, 
                self:get_id(), 
                Drag.None
            )
    
        spell:set_hit_props(hit_props)
    
        spell.update_func = function(self, dt)
            if not self.start_moving then 
                return 
            end
            self:get_tile():attack_entities(self)
            local t2 = spell:get_tile(dir2, 1)
            
            if t2 and not t2:is_edge() then
                t2:attack_entities(self)
                t2:highlight(Highlight.Solid)
            end
    
            spell:get_current_tile():highlight(Highlight.Solid)
    
    
            if self:is_sliding() == false then
                if not self:get_tile(facing, 1) and self.slide_started then 
                    self:delete()
    
                end 
                
                local dest = self:get_tile(facing, 1)
                local ref = self
                self:slide(dest, frames(9), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )
            end
            
        end
    
    
    
        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)
        end
    
    
        spell.collision_func = function()
           -- spell:delete()
        end
    
        spell.can_move_to_func = function()
            return true
        end
    
        local tile = self:get_tile(facing, 1)
        if dir == Direction.Up then 
            tile = tile:get_tile(Direction.Up, 1)
        end
    
        if dir == Direction.Left or dir == Direction.Right then 
            tile = self:get_current_tile()
        end
    
        if tile then 
            field:spawn(spell, tile)
        end
    end


    local function check_obstacles(tile, self)
        local ob = tile:find_obstacles(function(o)
            return o:get_health() > 0 
        end)
    
        return #ob > 0 
    end
    
    
    local function check_characters(tile, self)
        local characters = tile:find_characters(function(c)
            return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
        end)
    
        return #characters > 0
    
    end

    local yuki
    local can_move = function(tile)
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
  

        return not check_obstacles(tile, yuki) and not check_characters(tile, yuki)
    end

    local anim


    local actor
    local a_press = false
    local pressed_up = false
    local pressed_down = false
    local pressed_left = false
    local pressed_right = false

    local accepted_command = false


    local command = Battle.Step.new()
    local command_first = true
    command.update_func = function()
        if command_first then 
            if not pressed_right then 
                local dir
                if pressed_up then 
                    dir = Direction.Up
                elseif pressed_down then 
                    dir = Direction.Down
                elseif pressed_left then 
                    dir = user:get_facing_away()
                end

                anim:set_state("SPIN_KICK")
                anim:refresh(yuki:sprite())

                anim:on_frame(3, function()
                    create_fire_wave(yuki, dir)
                end)
                anim:on_frame(5, function()
                    local time = 18
                    
                    if dir == Direction.Left or dir == Direction.Right then 
                        move_slide_horizontal(yuki, dir, time)
                    else
                        move_slide(yuki, dir, time)
                    end
              
                end)

            else
                anim:set_state("PUNCH1")
                anim:refresh(yuki:sprite())

                anim:on_frame(1, function()
                    Engine.play_audio(FIRE_PROJECTILE_SFX, AudioPriority.Low)
                    create_fire_shot(yuki)
                end)
            end

            anim:on_complete(function()
                command:complete_step()
            
            end)
            
            command_first = false
        end


    end

    local last_step = Battle.Step.new()
    local last_step_first = true
    last_step.update_func = function()
        if last_step_first then 
            anim:set_state("FINISH")
            anim:on_complete(function()
                yuki:delete()
                user:reveal()
                last_step:complete_step()
            end)

            last_step_first = false
        end
    end

    local combo = Battle.Step.new()
    combo_first = true

    combo.update_func = function()
        if combo_first then 

            local filter = function(c)
                return c:get_team() ~= user:get_team()
            end

            local list = user:get_field():find_nearest_characters(user, filter)

            local target = nil
            for i=1, #list
            do
                if yuki.can_move_to_func(list[1]:get_tile(yuki:get_facing_away(), 1)) then 
                    target = list[1]:get_tile(yuki:get_facing_away(), 1)
                    break
                end

            end

            if not target then
                combo:complete_step()
            else
                anim:set_state("MOVE")

                anim:on_frame(2, function()
                    yuki.can_move_to_func = function()
                        return true
                    end
                    yuki:teleport(target, ActionOrder.Voluntary, function()
                    end)
                end)

                anim:on_complete(function()
                    anim:set_state("PUNCH_COMBO")

                    local spells = {}
                    anim:on_frame(1, function()
                        table.insert(spells, highlight_tiles(yuki, {yuki:get_tile(yuki:get_facing(), 1)}, 66))

                    end)
                    anim:on_frame(2, function()
                        table.insert(spells, punch_attack(yuki, 1))
                    end)

                    anim:on_frame(5, function()
                        table.insert(spells, punch_attack(yuki, 2))
                    end)

                    anim:on_frame(9, function()
                        Engine.play_audio(FIRE_KICK, AudioPriority.Low)
                        table.insert(spells, punch_attack(yuki, 3))
                    end)


                    anim:on_complete(function()
                        combo:complete_step()
                    
                    end)
                
                end)
            end


            action:add_step(last_step)
            combo_first = false
        end

    end

    local tile = nil
    step.update_func = function()
        if step_first then 
            actor:hide()
            tile = user:get_current_tile()
            field:spawn(yuki, tile)

            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)

            anim:on_complete(function()
                if accepted_command then 
                    action:add_step(command)
                end

                action:add_step(combo)
                step:complete_step()
            end)

            step_first = false
        else
            a_press = a_press or user:input_has(Input.Pressed.Use)
            if not accepted_command and a_press then 
                if user:input_has(Input.Pressed.Up) then 
                    if yuki.can_move_to_func(tile:get_tile(Direction.Up, 1)) then 
                        pressed_up = true
                    end
                elseif user:input_has(Input.Pressed.Down) then 
                    if yuki.can_move_to_func(tile:get_tile(Direction.Down, 1)) then 
                        pressed_down = true
                    end
                elseif user:input_has(Input.Pressed.Left) then 
                    if yuki.can_move_to_func(tile:get_tile(user:get_facing_away(), 1)) then 
                        pressed_left = true
                    end
                elseif user:input_has(Input.Pressed.Right) then 
                    pressed_right = true
                end

                accepted_command = pressed_up or pressed_down or pressed_left or pressed_right

                if accepted_command then 
                    Engine.play_audio(COMMAND_SUCCESS, AudioPriority.Low)
                end
            end
        end
    end

    

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        FIRE_PROJECTILE_SFX = Engine.load_audio(_folderpath.."FireProjectile.ogg")
        FIRE_KICK = Engine.load_audio(_folderpath.."FireKick.ogg")
        BREAK_SFX = Engine.load_audio(_folderpath.."break.ogg")
        SPIN_SFX = Engine.load_audio(_folderpath.."Spin.ogg")
        APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
        COMMAND_SUCCESS = Engine.load_audio(_folderpath.."CommandSuccess.ogg")

        HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")

        
        yuki = graphic_init("artifact", 0, 0, "Yuki.png", "Yuki.animation", -3, "APPEAR", user, facing)
        yuki:set_team(user:get_team())
        yuki.can_move_to_func = can_move
        yuki:set_float_shoe(true)
        
        anim = yuki:get_animation()


    end

    return action
end