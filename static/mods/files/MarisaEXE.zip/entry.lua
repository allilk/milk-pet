function package_init(package) 
    package:declare_package_id("com.alrysc.player.MarisaEXE")
    package:set_special_description("Mari Morichika's navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."marisa_preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Marisa")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(55.0)
    player:set_animation(_modpath.."marisa.animation")
    player:set_texture(Engine.load_texture(_modpath.."marisa.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -20)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        beam = Engine.load_audio(_modpath .. "beam.ogg"),
        explosion = Engine.load_audio(_modpath .. "explosion.ogg"),
        throw = Engine.load_audio(_modpath .. "toss_item.ogg")
    }

    local attachment_texture = Engine.load_texture(_modpath .. "bomb.png")
    local attachment_animation_path = _modpath .. "bomb.animation"
    local explosion_texture = Engine.load_texture(_modpath .. "explosion.png")
    local explosion_sfx = Engine.load_audio(_modpath .. "explosion.ogg")
    local explosion_animation_path = _modpath .. "explosion.animation"


    
    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
 

    end

    player.normal_attack_func = base_normal_attack


    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function narrow_spark(user)
        local action = Battle.CardAction.new(user, "NARROW_SPARK")
        local field = user:get_field()

        local ending = false
    
        local spell_list = {}
    
        local function extra_laser(user, tile, facing, elevation, hit_props)
            if not tile or tile:is_edge() then 
                return 
            end
            local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER", user, facing)
            spell:highlight_tile(Highlight.Solid)
            spell:set_elevation(elevation)
            spell:set_hit_props(hit_props)
    
    
            local anim = spell:get_animation()
            anim:on_frame(2, function()
                extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)
    
            end)
            local fade = false
            spell.update_func = function(self)
                if not fade then 
                    if ending == true then 
                        anim:set_state("LASER_END")
                        anim:refresh(self:sprite())
    
                        fade = true
                    end
    
                end
    
                self:get_tile():attack_entities(self)
    
            end
    
            spell.attack_func = function()
                Engine.play_audio(user.sounds.hit, AudioPriority.Low)
            end
    
            spell_list[#spell_list+1] = spell
            field:spawn(spell, tile)
        end
    
        local function shoot_laser(user, starting_tile, facing, elevation)
            local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER_START", user, facing, true)
            spell:highlight_tile(Highlight.Solid)
            spell:set_elevation(elevation)
    
            local hit_props = HitProps.new(20 + user:get_attack_level()*30,
                                       Hit.Impact | Hit.Flinch | Hit.Flash,
                                       Element.Elec, user:get_context(), Drag.None)
    
            local anim = spell:get_animation()
            spell:set_hit_props(hit_props)
    
            anim:on_frame(7, function()
                extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)
            end)
    
            anim:on_frame(8, function()
                ending = true
            
            end)
    
            anim:on_frame(13, function()
                spell:highlight_tile(Highlight.None)
    
            end)
    
            anim:on_frame(14, function()
                spell:highlight_tile(Highlight.None)
                stop = true
                spell:delete()
    
                for i=1, #spell_list
                do
                    local spell = spell_list[i]
                    if spell and not spell:is_deleted() then 
                        spell:delete()
                    end
                end
            end)
    
    
            local stop = false
    
            spell.update_func = function(self)
                if not stop then 
                    self:get_tile():attack_entities(self)
                end
    
            end
    
            spell.attack_func = function()
                Engine.play_audio(user.sounds.hit, AudioPriority.Low)
            end
    
            field:spawn(spell, starting_tile)
        end
    
    
        action.execute_func = function()    
            local facing = user:get_facing()
                
            local anim = user:get_animation()
       
            anim:on_frame(6, function()
                shoot_laser(user, user:get_current_tile():get_tile(user:get_facing(), 1), user:get_facing(), 20)
                Engine.play_audio(user.sounds.beam, AudioPriority.Low)
            end)
        end
    
        return action
    end


    local function throw_bomb(user, bomb_type)
        local action = Battle.CardAction.new(user, "THROW_BOMB")
        action:set_lockout(make_animation_lockout())
    
        local hit_props
        local first_explosion = true
        local second_explosion = true
        
        local function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback)
            local starting_height = -110
            local start_tile = tosser:get_current_tile()
            local field = tosser:get_field()
            local spell = Battle.Spell.new(tosser:get_team())
            spell:set_facing(tosser:get_facing())
            local spell_animation = spell:get_animation()
            spell_animation:load(animation_path)
            spell_animation:set_state("DEFAULT")
            if tosser:get_height() > 1 then
                starting_height = -(tosser:get_height() + 40)
            end
        
        
            spell.jump_started = false
            spell.starting_y_offset = starting_height
            spell.starting_x_offset = 10
            if tosser:get_facing() == Direction.Left then
                spell.starting_x_offset = -10
            end
        
            spell.y_offset = spell.starting_y_offset
            spell.x_offset = spell.starting_x_offset
            local sprite = spell:sprite()
            sprite:set_texture(texture)
            spell:set_offset(spell.x_offset, spell.y_offset)
        
            spell.update_func = function(self)
                if not spell.jump_started then
                    self:jump(target_tile, toss_height, frames(frames_in_air),
                              frames(frames_in_air), ActionOrder.Voluntary)
                    self.jump_started = true
                end
                if self.y_offset < 0 then
                    self.y_offset = self.y_offset +
                                        math.abs(self.starting_y_offset / frames_in_air)
                    self.x_offset = self.x_offset -
                                        math.abs(self.starting_x_offset / frames_in_air)
                    self:set_offset(self.x_offset, self.y_offset)
                else
                    arrival_callback()
                    self:delete()
                    self:hide()
                end
            end
            spell.can_move_to_func = function(tile) return true end
            field:spawn(spell, start_tile)
        end

        local function hit_explosion(user, target_tile, props, texture, anim_path, target_tiles)
            local field = user:get_field()
            local spell = Battle.Spell.new(user:get_team())
        
        
            spell:set_hit_props(props)
            spell.has_attacked = false
            local lifetime = 3
            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
        
                lifetime = lifetime - 1
                if lifetime == 0 then 
                    self:delete()
                end
            end
        
            spell.attack_func = function()
                Engine.play_audio(user.sounds.hit, AudioPriority.Low)
        
            end
        
            local artifact = Battle.Artifact.new()
            local anim = artifact:get_animation()
            artifact:set_texture(texture)
            anim:load(anim_path)
            anim:set_state("DEFAULT")
            anim:refresh(artifact:sprite())
        
          
            anim:on_complete(function()
                artifact:delete()
            end)
        
        
            for i=2, #target_tiles
            do
                local target = target_tiles[i]
                if target and not target:is_edge() then 
                    local sharebox = Battle.SharedHitbox.new(spell, 0.05)
                    sharebox:set_hit_props(spell:copy_hit_props())
                    field:spawn(sharebox, target)
        
                    local new_artifact = Battle.Artifact.new()
                    local new_anim = new_artifact:get_animation()
                    new_artifact:set_texture(texture)
                    new_anim:copy_from(anim)
                    new_anim:set_state("DEFAULT")
                    new_anim:refresh(new_artifact:sprite())
                            
                    new_anim:on_complete(function()
                        new_artifact:delete()
                    end)
        
                    field:spawn(new_artifact, target)
                end
            end
        
            field:spawn(spell, target_tile)
            field:spawn(artifact, target_tile)
        
        end
    
        local function second_toss(starting_tile, direction, toss_height, texture, animation_path, frames_in_air, facing)
            local target_tile = starting_tile:get_tile(direction, 1)
            if not target_tile or target_tile:is_edge() then 
                return
            end
            local starting_height = 0
            local field = user:get_field()
            local spell = Battle.Spell.new(user:get_team())
            local spell_animation = spell:get_animation()
            spell_animation:load(animation_path)
            spell_animation:set_state("DEFAULT")
            spell:sprite():set_layer(-3)
            spell:set_facing(facing)
    
            local tiles = {}
            if bomb_type == 2 then 
                tiles = {
                    target_tile
                }
            else
                tiles = {
                    target_tile,
                    target_tile:get_tile(Direction.Right, 1),
                    target_tile:get_tile(Direction.Down, 1),
                    target_tile:get_tile(Direction.Left, 1),
                    target_tile:get_tile(Direction.Up, 1)
                }
            end
    
            local function arrival_callback() 
                if not target_tile:is_walkable() then return end
                if second_explosion then 
                    Engine.play_audio(user.sounds.explosion, AudioPriority.Low)
                    second_explosion = false
                end

                hit_explosion(user, target_tile, hit_props, explosion_texture, explosion_animation_path, tiles)
            end
        
            spell.jump_started = false
            spell.starting_y_offset = starting_height
        
            spell.y_offset = -10
        
            local sprite = spell:sprite()
            sprite:set_texture(texture)
            spell:set_offset(0, 0)
        
            local time = frames_in_air
            spell.update_func = function(self)
                if not spell.jump_started then
                    self:jump(target_tile, toss_height, frames(frames_in_air),
                              frames(frames_in_air), ActionOrder.Voluntary)
                    self.jump_started = true
                end
                if self.jump_started then 
                    if time == 0 then 
                        arrival_callback()
                        self:delete()
                        self:hide()
                    end
                        
                    time = time - 1
                   
                end
            end
            spell.can_move_to_func = function(tile) return true end
            field:spawn(spell, starting_tile)
        end
    
    
        action.execute_func = function(self)
            hit_props = HitProps.new(user:get_attack_level()*10,
                                       Hit.Impact | Hit.Flinch,
                                       Element.None, user:get_context(), Drag.None)
            local attachment = self:add_attachment("HAND")
            local attachment_sprite = attachment:sprite()
            attachment_sprite:set_texture(attachment_texture)
            attachment_sprite:set_layer(-2)
    
            local attachment_animation = attachment:get_animation()
            attachment_animation:load(attachment_animation_path)
            attachment_animation:set_state("DEFAULT")
    
            self:add_anim_action(3, function()
                attachment_sprite:hide()
                -- self.remove_attachment(attachment)
                local tiles_ahead = 3
                local frames_in_air = 40
                local toss_height = 140
                local facing = user:get_facing()
                local target_tile = user:get_tile(facing, tiles_ahead)
                local first_landing = true
                user.bomb_count = user.bomb_count-1
    
                if not target_tile then return end
                local tiles = {
                    target_tile,
                    target_tile:get_tile(Direction.Right, 1),
                    target_tile:get_tile(Direction.Down, 1),
                    target_tile:get_tile(Direction.Left, 1),
                    target_tile:get_tile(Direction.Up, 1)
                }
                action.on_landing = function()
                    if not target_tile:is_walkable() or target_tile:is_edge() then return end
                    if first_explosion then 
                        Engine.play_audio(user.sounds.explosion, AudioPriority.Low)
                        first_explosion = false
                    end
                    
                    hit_explosion(user, target_tile, hit_props, explosion_texture, explosion_animation_path, tiles)

                    if first_landing and bomb_type > 1 then 
                        local height = 60
                        second_toss(target_tile, Direction.Up, height, attachment_texture, attachment_animation_path, 20, facing)
                        second_toss(target_tile, Direction.Right, height, attachment_texture, attachment_animation_path, 20, facing)
                        second_toss(target_tile, Direction.Left, height, attachment_texture, attachment_animation_path, 20, facing)
                        second_toss(target_tile, Direction.Down, height, attachment_texture, attachment_animation_path, 20, facing)
    
                        first_landing = false
                    end
                end
                toss_spell(user, toss_height, attachment_texture,
                attachment_animation_path, target_tile, frames_in_air,
                action.on_landing)
    
            end)
    
            self:add_anim_action(4, function()
                Engine.play_audio(user.sounds.throw, AudioPriority.Low)
            end)
        end
    
        return action
    end
    
    

    player.bomb_count = 2
    player.bomb_indicator = Battle.Artifact.new()

    player.charged_attack_func = narrow_spark
    player.special_attack_func = function()
        if player.bomb_count > 0 then 
            player:card_action_event(throw_bomb(player, 2), ActionOrder.Voluntary)
        end
        
    end 

    local first = true
    local turn1 = true
    local turn1_ = true

    player.battle_start_func = function()
        turn1 = false
        
    end

    player.battle_end_func = function()
        player.bomb_indicator:sprite():hide()
    end
    player.update_func = function(self)
        if first then 
            self.bomb_indicator:sprite():set_layer(-5)
            self.bomb_indicator:set_texture(Engine.load_texture(_modpath.."bomb_indicator.png"), true)
            local offsetX = 10
            if self:get_facing() == Direction.Left then 
                offsetX = offsetX * -1
            end
            self.bomb_indicator:set_offset(offsetX, -66)
            self.bomb_indicator:get_animation():load(_modpath.."bomb_indicator.animation")
            self.bomb_indicator:get_animation():set_state(""..self.bomb_count)
            self.bomb_indicator:get_animation():refresh(self.bomb_indicator:sprite())
            if self:get_facing() == Direction.Left then 
                self:get_field():spawn(self.bomb_indicator, self:get_field():tile_at(6, 0))
            else self:get_field():spawn(self.bomb_indicator, self:get_field():tile_at(1, 0))
            end

            local turn_checker2 = Battle.Component.new(player, Lifetimes.Scene)

            local turn_checker1 = Battle.Artifact.new()
            turn_checker1.time = 0
            local time2 = 0
            turn_checker1.updated = false
        
            turn_checker1.update_func = function()
                if not turn_checker1.updated then 
                    turn_checker1.time = turn_checker1.time + 1
                    turn_checker1.updated = true
                end

            end
        
            turn_checker2.update_func = function()
                if turn_checker1.updated and time2 ~= turn_checker1.time then 
                    turn_checker1.time = 0
                    time2 = 0
                    if not turn1_ then 
                        self.bomb_count = math.min(self.bomb_count+1, 3)
                        self.bomb_indicator:get_animation():set_state(""..self.bomb_count)
                    elseif not turn1 then
                        turn1_ = false
                    end

                end
                time2 = time2+1
                turn_checker1.updated = false

            end
        
          
            self:register_component(turn_checker2)
            self:get_field():spawn(turn_checker1, 0, 0)

            first = false


            first = false
        end
        self.bomb_indicator:get_animation():set_state(""..self.bomb_count)


    end

end