function package_init(block)
    block:declare_package_id("com.stockCustomization.Tango")
    block:set_name("Tangisnt")
    block:as_program()
    block:set_description("Fight on! Heals low HP!")
    block:set_color(Blocks.Green)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 1, 1, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Battlestep)
    component.owner = player
    component.hp = player:get_health()
    component.mhp = player:get_max_health()
    component.defense = include("barrier/entry.lua")
    component.do_once = true
    component.update_func = function(self, dt)
        if not self.do_once then
            self:eject()
            return
        end
        if not self.owner then
            self.owner = self:get_owner()
        end
        local hp = self.owner:get_health()
        if self.hp ~= hp then self.hp = hp end
        if self.hp <= math.floor(self.mhp*0.25) and self.owner:get_animation():get_state() == "PLAYER_IDLE" and not self.owner:is_sliding() and self.do_once then
            self.do_once = false
            local props = Battle.CardProperties:new()
            props.time_freeze = true
            props.shortname = "Tango"
            props.skip_time_freeze_intro = true
            local action = self.defense.card_create_action(self.owner, props)
            self.owner:card_action_event(action, ActionOrder.Involuntary)
        end
    end
    player:register_component(component)
end