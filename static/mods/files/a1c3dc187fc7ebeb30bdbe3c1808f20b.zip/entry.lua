nonce = function() end

local TEXTURE = Engine.load_texture(_modpath.."void.png")
local AUDIO = Engine.load_audio(_modpath.."void.ogg")

function package_init(package) 
    package:declare_package_id("com.seabitty.blackhole3")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'I','N','Q'})

    local props = package:get_card_props()
    props.shortname = "BlkHole3"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Del enmy 160HP or less."
    props.long_description = "Deletes Enemies with less than 160 HP remaining."
	props.can_boost = true
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "IDLE")
    local frame1 = {2, 0.75}
    local long_frame = make_frame_data({frame1})
    action:override_animation_frames(long_frame)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("Searching...")
        local field = user:get_field()
        local targets = field:find_characters(function(found)
            if found ~= nil and user:get_team() ~= found:get_team() and found:get_health() <= 160 then
                return true
            end
        end)
        for i = 1, #targets, 1 do
            tile = targets[i]:get_tile()
			spell = create_hole(user, props)
			field:spawn(spell, tile)
			takeout = targets[i]:delete()
        end
    end
    return action
end


function create_hole(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.None,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(TEXTURE, true)
	anim:load(_modpath.."void.animation")
	anim:set_state("0")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:erase()
	end)
	local do_once = true

	spell.update_func = function(self, dt)
		if do_once then
			self:get_tile():attack_entities(self)
			do_once = false
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end


	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end