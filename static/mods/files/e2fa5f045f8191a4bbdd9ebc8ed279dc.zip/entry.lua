function package_init(block)
    block:declare_package_id("com.BN5.BusterPack")
    block:set_name("BustPack")
    block:as_program()
    block:set_description("Buster Attack/Charge +3. Rapid TBD.")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 0, 1, 0,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_attack_level(math.min(player:get_attack_level() + 3, 5))
    player:set_charge_level(math.min(player:get_charge_level() + 3, 5))
    --player:set_rapid_level(math.min(player:get_rapid_level() + 3, 5))
end