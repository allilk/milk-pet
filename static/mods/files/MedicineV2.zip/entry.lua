local HIT 
local POOF
local THROW
local EXPLODE
local CREATE


function package_init(package) 
    package:declare_package_id("com.alrysc.card.MedicineV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'M','P'})

    local props = package:get_card_props()
    props.shortname = "MedicinV2"
    props.damage = 90
    props.time_freeze = true
    props.element = Element.None
    props.description = "Toss Psn 3sq ahead!"
    props.card_class = CardClass.Mega
    props.limit = 2
    props.meta_classes = {"Element.Poison"}
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true
    

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    

    local medicine
    local ball
    local target_tiles = {}

    local function create_gas(tile, user)
       local gas = graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, user:get_facing(), true)

       field:spawn(gas, tile)
    end

    local function spawn_n_gas(n)
        local artifact = Battle.Artifact.new()
        local max = #target_tiles
        local counter = 0
        artifact.update_func = function()
            if counter % 2 == 0 then 
                create_gas(target_tiles[math.random(1, max)], user)
                n = n-1
            end

            counter = counter + 1
            if n == 0 then 
                artifact:delete()
            end
        end

        field:spawn(artifact, user:get_current_tile())
    end

    local function absorb_poison()
        local filter = function(tile)
            return tile:get_team() == user:get_team() and tile:get_state() == TileState.Poison
        end

        local poison_tiles = field:find_tiles(filter)

        for i=1, #poison_tiles
        do
            poison_tiles[i]:set_state(TileState.Normal)
        end

        props.damage = props.damage + 10*#poison_tiles
    end
    
    local function create_attack()
        local spell = Battle.Spell.new(user:get_team())
        spell:set_name("Element.Poison")

        spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake,
                props.element,
                user:get_context(),
                Drag.None
            )
        )

        local first = true
        local counter = 0
        spell.update_func = function(self)
            if counter == 0 then 
                for i=1, #target_tiles
                do
                    target_tiles[i]:attack_entities(self)
                end
                Engine.play_audio(EXPLODE, AudioPriority.Low)

                local shake_artifact = Battle.Artifact.new()
                local time = 0
                shake_artifact.update_func = function(self)
                        
                    self:shake_camera(200, 0.016)
                    if time == 61 then 
                        self:delete()
                    end
                
                    time = time+1
                end

                field:spawn(shake_artifact, user:get_current_tile())


            elseif counter == 1 then 
                for i=1, #target_tiles
                do
                    target_tiles[i]:set_state(TileState.Poison)

                end
            elseif counter == 2 then 
                self:delete()
                spawn_n_gas(18)

            end

            counter = counter+1
        end

        spell.collision_func = function()

        end

        spell.attack_func = function(self, other)
            Engine.play_audio(HIT, AudioPriority.Low)

            -- Use find spells and get rid of health later
            local list = field:find_entities(function(e) return e:get_name() == "POISON_CONTROLLER"..other:get_id() end)        
            if list[1] then 
                list[1]:set_name("RESET")
                return
            end
      
            local artifact = Battle.Spell.new(other:get_team())
            artifact:set_name("POISON_CONTROLLER"..other:get_id())
            artifact:set_health(1)
           -- artifact:toggle_hitbox(true)
            local time_remaining = 299

            local colored = false
            local poison_component = Battle.Component.new(other, Lifetimes.Local)
            local mode = other:sprite():get_color_mode()

            poison_component.update_func = function()
                if artifact:get_name() == "RESET" then
                    time_remaining = 299
                    artifact:set_name("POISON_CONTROLLER"..other:get_id())
                end
                if time_remaining % 8 == 0 then 
                    other:set_health(other:get_health()-1)
                end

                if time_remaining == 0 then 
                    artifact:delete()
                    poison_component:eject()
                    other:sprite():set_color_mode(mode)

                end
                time_remaining = time_remaining - 1

                if time_remaining % 3 == 1 then 
                    other:sprite():set_color_mode(ColorMode.Multiply)

                end
                if time_remaining % 3 == 0 then 
                    local color = Color.new(30, 20, 170, 255)
                    other:set_color(color)
                    other:sprite():set_color_mode(mode)
           
                    colored = true
                end
                
            end

            other:register_component(poison_component)
            field:spawn(artifact, field:tile_at(1, 1))
        end

        field:spawn(spell, target_tiles[1])
    end


    local actor
    step.update_func = function()
        if step_first then 
            create_gas(user:get_current_tile(), user)
            actor:hide()
            field:spawn(medicine, user:get_current_tile())
            Engine.play_audio(POOF, AudioPriority.Low)

            step_first = false
        end

    end

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        HIT = Engine.load_audio(_modpath.."hit.ogg")
        POOF = Engine.load_audio(_modpath.."bomb.ogg")
        THROW = Engine.load_audio(_modpath.."sword.ogg")
        EXPLODE = Engine.load_audio(_modpath.."bombmiddle.ogg")
        CREATE = Engine.load_audio(_modpath.."eriasteal1.ogg")

        target = user:get_current_tile():get_tile(user:get_facing(), 3)
        if target and not target:is_edge() then 
            target_tiles[1] = target
            local dirs = {Direction.Right, Direction.UpRight, Direction.Up, Direction.UpLeft, Direction.Left, Direction.Down, Direction.DownRight, Direction.DownLeft}

            for i=1, #dirs
            do
                target_tiles[i+1] = target:get_tile(dirs[i], 1) 
            end
        end
        medicine = graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -3, "DEFAULT", user, facing)
        ball = graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -3, "BALL", user, facing)
        
        ball:get_animation():set_playback(Playback.Loop)
        ball:set_elevation(144)

        
        local anim = medicine:get_animation()
        anim:on_complete(function()
            medicine:delete()
            step:complete_step()
            user:reveal()
        end)
        anim:on_frame(4, function()
            Engine.play_audio(CREATE, AudioPriority.Low)
            absorb_poison()
            field:spawn(ball, user:get_current_tile())
        end)

        anim:on_frame(6, function()
            Engine.play_audio(THROW, AudioPriority.Low)
            local attack_next_frame = false
            local timer = 21
            local highlight_time = 10
            local current_elev = ball:get_elevation()
            local target_x = 110*2 -- three tiles
            if ball:get_facing() == Direction.Left then 
                target_x = target_x * -1
            end

            local curr_x = 0
            local d_x = target_x / timer
            local d_elev = (current_elev+10)/timer
            ball.update_func = function(self)
                if attack_next_frame then 
                    self:delete()
                    return
                end
                if highlight_time > 0 then 
                    for i=1, #target_tiles
                    do
                        target_tiles[i]:highlight(Highlight.Solid)
                    end
                    highlight_time = highlight_time - 1

                end
                current_elev = current_elev - d_elev
                self:set_elevation(current_elev)
                curr_x = curr_x + d_x
                self:set_offset(curr_x, 0)
                if timer == 0 then
                    attack_next_frame = true
                    ball:hide()
                    for i=1, #target_tiles
                    do
                        target_tiles[i]:highlight(Highlight.Solid)

                    end


                    if target_tiles[1] then 
                        create_attack()
                    end

                end
                timer = timer - 1

            end
        end)
    end

    return action
end