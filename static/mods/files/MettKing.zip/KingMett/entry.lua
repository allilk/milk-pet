local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name="KingMett",
        hp=500,
        damage=200,
        palette=_folderpath.."battle_v1.palette.png",
        height=20,
        cascade_frame = 5,
        shockwave_animation="shockwave_fast.animation",
        heal_animation="spell_heal.animation",
        move_delay = 38,
        can_guard = true 
    }
    if character:get_rank() == Rank.V1 then
        character_info.shockwave_animation="shockwave.animation"
        character_info.can_guard = true
    end
    if character:get_rank() == Rank.V2 then
        character_info.damage = 300
        character_info.cascade_frame = 5
        character_info.palette=_folderpath.."battle_v2.palette.png"
        character_info.hp = 800
        character_info.move_delay = 32
    elseif character:get_rank() == Rank.V3 then
        character_info.damage = 500
        character_info.palette=_folderpath.."battle_v3.palette.png"
        character_info.hp = 1200
        character_info.cascade_frame = 4
        character_info.move_delay = 26
    elseif character:get_rank() == Rank.SP then
        --I'm making up the frame values for SP and higher because I cant easily record them
        character_info.damage = 700
        character_info.palette=_folderpath.."battle_vsp.palette.png"
        character_info.hp = 1600
        character_info.cascade_frame = 3
        character_info.move_delay = 24
    elseif character:get_rank() == Rank.Rare1 then
        character_info.damage = 500
        character_info.palette=_folderpath.."battle_vrare1.palette.png"
        character_info.hp = 1200
        character_info.cascade_frame = 3
        character_info.move_delay = 22
    elseif character:get_rank() == Rank.Rare2 then
        character_info.damage = 800
        character_info.palette=_folderpath.."battle_vrare2.palette.png"
        character_info.hp = 1800
        character_info.cascade_frame = 3
        character_info.move_delay = 20
    end
    shared_package_init(character,character_info)
end
