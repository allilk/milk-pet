nonce = function() end

local TEXTURE = Engine.load_texture(_modpath .. "dragon.png")
local TEXTURE_ANIM = _modpath .. "dragon.animation"
local LAUNCH_AUDIO = Engine.load_audio(_modpath .. "burn.ogg")
local HITSOUND = Engine.load_audio(_modpath .. "hitsound.ogg")
local PARTICLE_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local DUST_TEXTURE = Engine.load_texture(_modpath .. "poof.png")

local palette = Engine.load_texture(_modpath .. "ElecDragon.png")
local EFFECT_ANIM_STATE = "ELEC"
local DRAGON_TILE_STATE = TileState.Cracked

function package_init(package)
	package:declare_package_id("com.loui.card.ElecDragon")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'A', 'L', 'V' })

	local props = package:get_card_props()
	props.shortname = "ElecDrgn"
	props.damage = 150
	props.time_freeze = false
	props.element = Element.Elec
	props.description = "Drgn hits 2 columns"
	props.long_description = "Elec dragon summoned near closest enemy. Hits 2 rows!"
	props.limit = 2
end

local frame_data = make_frame_data({
	{ 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})


local offset_data = { { 0, 0 }, { 0, 8 }, --step1
	{ 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, --step2
	{ 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, { 0, 8 }, --step3
	{ 8, 8 }, { 8, 8 }, { 8, 6 }, { 8, 0 }, { 8, 6 }, { 8, 0 }, { 8, 0 }, --step4
	{ 0, 0 }, { 8, -2 }, { 0, 0 }, { 8, -6 }, { 8, 0 }, { 0, -8 }, { 0, -8 }, --step5
	{ 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, --step6
	{ 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, { 0, -8 }, --step7
	{ 0, -8 }, { 0, -8 } } --step 8

function do_offsets(spell, user)
	local offsets = offset_data[spell.current_index]
	local offsetX = offsets[1]
	local current_offsets = spell:get_offset()
	local multiplier = 1
	if (user:get_facing() == Direction.Left) then
		--perspective flip
		multiplier = -1
	end
	spell:set_offset(current_offsets.x + (multiplier * offsets[1]), current_offsets.y + offsets[2])
end

function card_create_action(user, props)
	local action = Battle.CardAction.new(user, "PLAYER_SWORD")

	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local actor = self:get_actor()

		self:add_anim_action(2, function()
			user:toggle_counter(true)
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)
		end)

		self:add_anim_action(3, function()
			local field = user:get_field()
			local start_x = find_start_x(user)
			local tile = field:tile_at(start_x, 0)
			local dragon = create_dragon(user, props, tile)

			user:get_field():spawn(dragon, tile)
		end)

		self:add_anim_action(4, function()
			user:toggle_counter(false)
		end)


	end
	return action
end

function find_start_x(user)
	if (user:get_facing() == Direction.Right) then
		local x = 6;
		user:get_field():find_characters(function(char)
			local charX = char:get_tile():x()
			if (user:get_team() ~= char:get_team() and charX < x) then
				x = char:get_tile():x()
			end
		end)
		return x
	elseif (user:get_facing() == Direction.Left) then
		local x = 0;
		user:get_field():find_characters(function(char)
			local charX = char:get_tile():x()
			if (user:get_team() ~= char:get_team() and charX > x) then
				x = char:get_tile():x()
			end
		end)
		return x
	end
end

function create_dragon(user, props, start_tile)
	local spell = Battle.Spell.new(user:get_team())
	local anim = spell:get_animation()
	anim:load(TEXTURE_ANIM)
	anim:set_state("DOWN")
	local sprite = spell:sprite()
	sprite:set_texture(TEXTURE)
	sprite:set_layer(-999999)
	anim:refresh(sprite)
	anim:set_playback(Playback.Loop)

	spell:highlight_tile(Highlight.Flash)
	spell:set_palette(palette)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)

	spell.current_index = 1
	spell.targeted_tile = start_tile
	spell.update_func = function(self, dt)

		spell.targeted_tile:attack_entities(spell)
		if (spell.current_index == 3) then
			spell.targeted_tile = start_tile:get_tile(Direction.Down, 1)
			create_dragon_tail(user, start_tile)
		elseif (spell.current_index == 5) then
			create_dragon_tail(user, start_tile)
		elseif (spell.current_index == 9) then
			create_dragon_tail(user, start_tile)
		if (spell.targeted_tile:is_walkable()) then
			spell.targeted_tile:set_state(DRAGON_TILE_STATE)
		end
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Down, 1)
		elseif (spell.current_index == 12) then
			create_dragon_tail(user, start_tile)
		elseif (spell.current_index == 15) then
			create_dragon_tail(user, start_tile)
		if (spell.targeted_tile:is_walkable()) then
			spell.targeted_tile:set_state(DRAGON_TILE_STATE)
		end
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Down, 1)
		elseif (spell.current_index == 16) then
			anim:set_state("DOWN_RIGHT")
		elseif (spell.current_index == 18) then
			anim:set_state("RIGHT")
		elseif (spell.current_index == 19) then
			if (spell.targeted_tile:is_walkable()) then 
				spell.targeted_tile:set_state(DRAGON_TILE_STATE)
			end
			spell.targeted_tile = spell.targeted_tile:get_tile(user:get_facing(), 1)
		elseif (spell.current_index == 20) then
			anim:set_state("UP_RIGHT")
		elseif (spell.current_index == 22) then
			anim:set_state("UP")
		elseif (spell.current_index == 26) then
			if (spell.targeted_tile:is_walkable()) then
				spell.targeted_tile:set_state(DRAGON_TILE_STATE)
			end
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		elseif (spell.current_index == 32) then
			if (spell.targeted_tile:is_walkable()) then
				spell.targeted_tile:set_state(DRAGON_TILE_STATE)
			end
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		elseif (spell.current_index == 38) then
			if (spell.targeted_tile:is_walkable()) then
				spell.targeted_tile:set_state(DRAGON_TILE_STATE)
			end
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		end
		do_offsets(spell, user)
		spell.current_index = spell.current_index + 1
		if (not spell.targeted_tile:is_edge()) then
			spell.targeted_tile:highlight(Highlight.Solid)
		end


		if (spell.current_index > #offset_data) then
			spell:erase()
		end
	end

	spell.collision_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(PARTICLE_TEXTURE, true)
		fx:get_animation():load(_modpath .. "effect.animation")
		fx:get_animation():set_state(EFFECT_ANIM_STATE)
		fx:get_animation():refresh(fx:sprite())
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		spell:get_field():spawn(fx, spell.targeted_tile)
	end

	spell.attack_func = function(self, other)
		Engine.play_audio(HITSOUND, AudioPriority.Highest)
	end


	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(LAUNCH_AUDIO, AudioPriority.High)

	return spell
end

function create_dragon_tail(user, start_tile)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_palette(palette)
	local anim = spell:get_animation()
	anim:load(TEXTURE_ANIM)
	anim:set_state("TAIL")
	local sprite = spell:sprite()
	sprite:set_texture(TEXTURE)
	spawn_dust(user:get_field(), start_tile)
	anim:refresh(sprite)
	anim:set_playback(Playback.Loop)
	spell.current_index = 1
	spell.update_func = function(self, dt)

		--tile:attack_entities(self)
		if (spell.current_index == 3) then
			spell.targeted_tile = start_tile:get_tile(Direction.Down, 1)
		elseif (spell.current_index == 9) then
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Down, 1)
		elseif (spell.current_index == 15) then
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Down, 1)
		elseif (spell.current_index == 19) then
			spell.targeted_tile = spell.targeted_tile:get_tile(user:get_facing(), 1)
		elseif (spell.current_index == 26) then
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		elseif (spell.current_index == 32) then
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		elseif (spell.current_index == 38) then
			spell.targeted_tile = spell.targeted_tile:get_tile(Direction.Up, 1)
		end

		do_offsets(spell, user)
		spell.current_index = spell.current_index + 1
		if (spell.current_index > #offset_data) then
			spawn_dust(user:get_field(), spell.targeted_tile)
			spell:erase()
		end

	end
	spell.can_move_to_func = function(tile)
		return true
	end
	Engine.play_audio(LAUNCH_AUDIO, AudioPriority.Low)

	user:get_field():spawn(spell, start_tile)
	return spell
end

function spawn_dust(field, tile)
	local fx = Battle.Artifact.new()
	fx:set_texture(DUST_TEXTURE, true)
	fx:get_animation():load(_modpath .. "poof.animation")
	fx:get_animation():set_state("1")
	fx:get_animation():refresh(fx:sprite())
	fx:get_animation():on_complete(function()
		fx:erase()
	end)
	field:spawn(fx, tile)
end
