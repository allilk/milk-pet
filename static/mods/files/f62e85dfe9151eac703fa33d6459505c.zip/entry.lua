function package_init(package)
    package:declare_package_id("com.discord.ShrekXL.player.GustMan")
    package:set_special_description("ShrekXL's personal cyber-monk.")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
    package:set_overworld_animation_path(_folderpath.."overworld.animation")
    package:set_overworld_texture_path(_folderpath.."overworld.png")
    package:set_mugshot_texture_path(_folderpath.."mug.png")
    package:set_mugshot_animation_path(_folderpath.."mug.animation")
end

function player_init(player)
    player:set_name("GustMan")
    player:set_health(1000)
    player:set_element(Element.Wind)
    player:set_height(38.0)

    local base_texture = Engine.load_texture(_folderpath.."battle.png")
    local base_animation_path = _folderpath.."battle.animation"
    local base_charge_color = Color.new(57, 198, 243, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        print("charged attack")
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
	
	
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_modpath.."AirShot.png"), true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."airshot.animation")
		buster_anim:set_state("DEFAULT")
		local props = HitProps.new(
            player:get_attack_level() * 5 + 15, 
            Hit.Impact | Hit.Drag | Hit.Flinch, 
            Element.Wind,
            user:get_context(),
            Drag.new(player:get_facing(), 1)
        )
		local cannonshot = create_attack(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		player:get_field():spawn(cannonshot, tile)
	end
    return action
end
	
function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Drag | Hit.Flinch, 
            Element.Wind,
            user:get_context(),
            Drag.new(direction, 1)
        )
    )
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(Engine.load_audio(_modpath.."sfx.ogg"), AudioPriority.High)
	return spell
end
    end 