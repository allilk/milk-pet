local DAMAGE = 400

local TEXTURE_BLUEMOON = Engine.load_texture(_modpath.."bluemoon.png")
local ANIMPATH_BLUEMOON = _modpath.."bluemoon.animation"
local AUDIO_SPAWN2 = Engine.load_audio(_modpath.."spawn2.ogg")
local AUDIO_CHARGE = Engine.load_audio(_modpath.."charge.ogg")
local AUDIO_BLUEMOONRAY = Engine.load_audio(_modpath.."bluemoonray.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-283-BlueMoonRay")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"B"})

    local props = package:get_card_props()
    props.shortname = "BlueMoon"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "BlueMoon drains 3 ahead!"
    props.long_description = "Blue Moon emits a power-stealing light 3 squares ahead!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local field = user:get_field()
        local team = user:get_team()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

		local step1 = Battle.Step.new()

        self.bluemoon = nil
        self.tile     = user:get_current_tile()
		
        local field = user:get_field()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.bluemoon = Battle.Artifact.new()
                ref.bluemoon:set_facing(direction)
                ref.bluemoon:sprite():set_layer(-3)
		    	ref.bluemoon:set_texture(TEXTURE_BLUEMOON, true)

                blue_anim = ref.bluemoon:get_animation()
                blue_anim:load(ANIMPATH_BLUEMOON)
                blue_anim:set_state("SPAWN")
		    	blue_anim:refresh(ref.bluemoon:sprite())
                blue_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN2, AudioPriority.High)
                end)
                blue_anim:on_frame(8, function()
                    Engine.play_audio(AUDIO_CHARGE, AudioPriority.High)
                end)
		    	blue_anim:on_complete(function()
		    		blue_anim:set_state("ATTACK")
		    		blue_anim:refresh(ref.bluemoon:sprite())
		    	end)
                field:spawn(ref.bluemoon, ref.tile)
            end
            local anim = ref.bluemoon:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local hitbox = create_attack(user, team, direction, props)
                    anim:on_frame(1, function()
                        Engine.play_audio(AUDIO_BLUEMOONRAY, AudioPriority.High)
                        field:spawn(hitbox, user:get_tile(direction, 3))
			        end)
                    anim:on_complete(function()
                        ref.bluemoon:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
	action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_attack(actor, team, direction, props)
    local spell = Battle.Spell.new(team)
    spell:get_facing(direction)
    spell:sprite():set_layer(-1)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Flash | Hit.Impact | Hit.Pierce | Hit.Retangible | Hit.Breaking,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
		local uninstll = Battle.Component.new(other, Lifetimes.Battlestep)
		local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
		local super_armor2 = Battle.DefenseRule.new(2, DefenseOrder.CollisionOnly)
		local super_armor3 = Battle.DefenseRule.new(1, DefenseOrder.CollisionOnly)
		local antifreeze = Battle.DefenseRule.new(913, DefenseOrder.CollisionOnly)
        local sunglasses = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
        local undershirt = Battle.DefenseRule.new(61044,DefenseOrder.CollisionOnly)
        uninstll.update_func = function(self, dt)
            local owner = self:get_owner()
            owner:set_air_shoe(false)
            owner:set_float_shoe(false)
            owner:add_defense_rule(super_armor)
            owner:remove_defense_rule(super_armor)
			owner:add_defense_rule(super_armor2)
            owner:remove_defense_rule(super_armor2)
			owner:add_defense_rule(super_armor3)
            owner:remove_defense_rule(super_armor3)
            owner:add_defense_rule(sunglasses)
            owner:remove_defense_rule(sunglasses)
            owner:add_defense_rule(undershirt)
            owner:remove_defense_rule(undershirt)
            owner:add_defense_rule(antifreeze)
            owner:remove_defense_rule(antifreeze)
            self:eject()
        end
        other:register_component(uninstll)
        self:delete()
    end
    
    spell.delete_func = function(self)
		self:erase()
    end

    return spell
end