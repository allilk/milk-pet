local function find_opponent(player)
    local opponent

    player:get_field():find_characters(function(c)
        if c:get_team() == player:get_team() then
            -- already on the same team
            return false
        end

        local possible_p = Battle.Player.from(c)

        if possible_p then
            -- is a player on the opposite team!
            -- found the opponent!
            opponent = possible_p
        end

        return false
    end)

    return opponent
end

local function recruit(player)
    local opponent = find_opponent(player)

    if not opponent then
        -- no opponent
        return
    end
    local fx = Battle.Artifact.new()
    local field = player:get_field()
    field:spawn(fx, field:tile_at(1, 0))
    local entity_id = fx:get_id()
    for x = 0, 6, 1 do
        for y = 0, 3, 1 do
            field:tile_at(x, y):reserve_entity_by_id(entity_id)
        end
    end
    field:tile_at(1, 1):set_state(TileState.Hidden)
    field:tile_at(2, 1):set_state(TileState.Hidden)
    field:tile_at(3, 1):set_state(TileState.Hidden)
    field:tile_at(4, 1):set_state(TileState.Hidden)
    field:tile_at(5, 1):set_state(TileState.Hidden)
    field:tile_at(6, 1):set_state(TileState.Hidden)
    field:tile_at(1, 3):set_state(TileState.Hidden)
    field:tile_at(2, 3):set_state(TileState.Hidden)
    field:tile_at(3, 3):set_state(TileState.Hidden)
    field:tile_at(4, 3):set_state(TileState.Hidden)
    field:tile_at(5, 3):set_state(TileState.Hidden)
    field:tile_at(6, 3):set_state(TileState.Hidden)
end

local function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    local i = 0

    component.update_func = function ()
        i = i + 1

        -- allow time for setup
        if i == 1 then return end

        recruit(player)
        Engine.stream_music(_modpath.."music.mid")
        component:eject()
    end

    player:register_component(component)
end


function package_init(block)
    block:declare_package_id("com.Dawn.cus.FireEmblem")
    block:set_name("Grand Prix")
    block:as_program()
    block:set_description("BCC Returns! Fight On!")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end