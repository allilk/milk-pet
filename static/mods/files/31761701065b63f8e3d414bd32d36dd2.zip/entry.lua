local add_Holy_Element_component = include('Holy_Element_component/Holy_Element_component.lua')

function package_init(block)
    block:declare_package_id("Rubedo.HolyElement")
    block:set_name("HolyElement")
    block:set_description("BecomePure")
    block:set_color(Blocks.White)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end



function modify(player)
    player:sprite():set_color_mode(ColorMode.Additive)
    player:set_color(Color.new(50, 50, 50, 255))
    add_Holy_Element_component.add_component(player)
end

