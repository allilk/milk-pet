Holy_element = {}

Holy_element.add_component = function(character)
    local c = Battle.Component.new(character, Lifetimes.Battlestep)
    c.cooldown = 0
    c.heal_cooldown_table = {20, 25, 35, 45, 55, 60, 65, 75, 70, 75, 90}
    c.health = character:get_health()
    c.max_health = character:get_max_health()
    c.calculate_cooldown = function(self, p)
        if p:get_health() ~= self.health then
            self.cooldown = self.heal_cooldown_table[math.max(1, math.floor(self.max_health / self.health))]
        end
    end
    c.update_func = function(self, dt)
        local player = self:get_owner()
        player:sprite():set_color_mode(ColorMode.Additive)
        player:set_color(Color.new(50, 50, 50, 255))    
        if self:get_owner():get_health() <= 0 then
            self:eject()
            return
        end
        if player:is_moving() then return end
        self.cooldown = self.cooldown - 1
        if self.cooldown <= 0 then
            local current_tile = player:get_tile()
            if current_tile:get_state() == TileState.Holy then
                player:set_health(player:get_health() + 3)
            end
            if current_tile:get_state() == TileState.Poison then
                player:set_health(player:get_health() - 3)
            end
            self:calculate_cooldown(player)
            self.health = player:get_health()
        end
    end

    -- add to character
    character:register_component(c)
end

return Holy_element