nonce = function() end

local CHARGE_CANNON_TEXTURE = Engine.load_texture(_modpath.."chargecannon.png") 
local CHARGE_CANNON_ANIMATION_PATH = _modpath.."chargecannon.animation" 
local CHARGE_CANNON_HIT_TEXTURE = Engine.load_texture(_modpath.."explosion.png") 
local CHARGE_CANNON_HIT_ANIMATION_PATH = _modpath.."explosion.animation" 
local CHARGE_CANNON_SHOT_TEXTURE = Engine.load_texture(_modpath.."bullet.png") 
local CHARGE_CANNON_SHOT_ANIMATION_PATH = _modpath.."bullet.animation" 
local CHARGE_CANNON_WHIR = Engine.load_audio(_modpath.."machineRunning.ogg") 
local CHARGE_CANNON_CHARGE = Engine.load_audio(_modpath.."charge.ogg") -- Charge sound, normalized to -5
local CHARGE_CANNON_FIRE = Engine.load_audio(_modpath.."bombbig.ogg") 
local CHARGE_CANNON_HIT_SOUND = Engine.load_audio(_modpath.."damageenemy.ogg") 
local CHARGE_CANNON_IMPACT_SOUND = Engine.load_audio(_modpath.."bombmiddle.ogg") -- Another hit sound, normalized to -12
local CHARGE_CANNON_SUCCESS = Engine.load_audio(_modpath.."CommandSuccess.ogg") 


function package_init(package) 
  package:declare_package_id("com.alrysc.card.chrgcan3")
  package:set_icon_texture(Engine.load_texture(_modpath.."icon3.png"))
  package:set_preview_texture(Engine.load_texture(_modpath.."preview3.png"))
  package:set_codes({'D', 'T', 'U', 'V'})

  local props = package:get_card_props()
  props.shortname = "ChrgCan3"
  props.damage = 300
  props.time_freeze = false
  props.element = Element.Break
  props.description = "Long chrg high dmg shot!"
  props.limit = 1

end

function card_create_action(user, props)
  local ChargeHold = 0
  local specialActivate = false
  local isHeld = user.input_has(user, Input.Held.Shoot)
    -- Right now, player is required to hold through time freeze intro
    -- I can change this by having this also be set in the action execute, but it will often force the player to buster after freeze ends
      -- This isn't behavior I can fix, but it might be a good idea to come back if there's an update to fix that buffer


  -- For graphic positions
  local offsetX = 40 
  local offsetY = -54
 
  local FLASH = {0, 0.0667}
  local READY = {0, 0.0833}
  local CYCLE = {3, 1.4333} 
  local PRESHAKE1 = {3, 0.0167}
  local PRESHAKE2 = {3, 0.0167} 
  local PREFIRE = {3, 0.05}
  local FIRE = {3, 0.3} 
  local END = {3, 0.1} 
  
  local FRAMES = make_frame_data({FLASH, READY, CYCLE, PRESHAKE1, PRESHAKE2, PREFIRE, FIRE, END})


  local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
  action:set_lockout(make_animation_lockout())
  action:override_animation_frames(FRAMES)

  local function spawn_shaking()
    local artifact = Battle.Artifact.new()
    local time = 0
    
    artifact.update_func = function()
      
      artifact:shake_camera(450, 0.016)
      if time == 29 then 
        artifact:delete() 
      end

      time = time+1
    end

    user:get_field():spawn(artifact, user:get_current_tile())

  end

  local function spawn_attack(user, tile)
    local field = user:get_field()
    local team = user:get_team()
    local direction = user:get_facing()

    local spell = Battle.Spell.new(team)
    spell:set_facing(user:get_facing())


    spell:set_hit_props(
      HitProps.new(
        props.damage,
        Hit.Flinch | Hit.Breaking | Hit.Impact | Hit.Flash,
        props.element,
        user:get_context(),
        Drag.None
      )
    )
  
    local bullet = Battle.Artifact.new()
    bullet:sprite():set_layer(-2)
    bullet:set_texture(CHARGE_CANNON_SHOT_TEXTURE, true)
    bullet:set_offset(0, offsetY)
    bullet:get_animation():load(CHARGE_CANNON_SHOT_ANIMATION_PATH)
    bullet:get_animation():set_state("SHOOTING")

    bullet:get_animation():on_complete(function ()
      bullet:get_animation():set_state("SHOOTING") -- Loops it
    end)

    bullet.can_move_to_func = function() return true end



    local function spawn_trail(tile, offset)
      local trail = Battle.Artifact.new()
      trail:sprite():set_layer(-1)
      trail:set_texture(CHARGE_CANNON_SHOT_TEXTURE, true)
      if direction == Direction.Right then 
        trail:set_offset(offset, offsetY)
      else
        trail:set_offset(-offset, offsetY)
      end

      trail:get_animation():load(CHARGE_CANNON_SHOT_ANIMATION_PATH)
      trail:get_animation():set_state("TRAIL")

      trail:get_animation():on_complete(function ()
        trail:delete()
      end)

      field:spawn(trail, tile)
    end

    field:spawn(bullet, tile)

    local initialSpawn = true
    local counter = 1
    local doubleCounter = 0 
    local halfPanel = false
    local offset = 0

    local checkHighlight = false

    spell.update_func = function(self, dt)  
      if spell:get_current_tile():is_edge() then 
        spell:delete()
        bullet:delete()
      end

      if initialSpawn then 
        if counter == 8 then 
          bullet:set_offset(offsetX, offsetY)
          halfPanel = true
          counter = 0
          initialSpawn = false
          spawn_trail(tile, offset)

        end
      else 
        if doubleCounter == 5 then 
          spawn_trail(tile, offset)
          doubleCounter = -1
        end
        doubleCounter = doubleCounter+1
        if counter == 2 then 
          if halfPanel then 
            tile = tile:get_tile(user:get_facing(), 1)
            bullet:set_offset(0, offsetY)
            halfPanel = false
            bullet:teleport(tile, ActionOrder.Immediate)
            spell:teleport(tile, ActionOrder.Immediate)
            checkHighlight = true
            spell:get_current_tile():get_tile(direction, 1):attack_entities(self)

            counter = 0

            offset = 0
          else
            bullet:set_offset(offsetX, offsetY)
            halfPanel = true
            counter = 0

            offset = offsetX
          end
        end
        
        end

        if not checkHighlight then
          spell:highlight_tile(Highlight.Solid)
          spell:get_tile():highlight(Highlight.Solid)

        else

          if spell then
            spell:highlight_tile(Highlight.None)
          
            spell:get_tile():highlight(Highlight.Solid)
       
            checkHighlight = false
          end

      end
      

      counter = counter+1

      spell:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other) 
      Engine.play_audio(CHARGE_CANNON_HIT_SOUND, AudioPriority.Low)
      Engine.play_audio(CHARGE_CANNON_IMPACT_SOUND, AudioPriority.High)
      spell:delete()
      bullet:delete()

      local explosion = Battle.Artifact.new()
      explosion:sprite():set_layer(-2)
      explosion:set_texture(CHARGE_CANNON_HIT_TEXTURE, true)
      explosion:set_offset(0, -30)
      explosion:get_animation():load(CHARGE_CANNON_HIT_ANIMATION_PATH)
      explosion:get_animation():set_state("EXPLOSION")

      explosion:get_animation():on_complete(function()
        explosion:delete()
      end)

      field:spawn(explosion, spell:get_current_tile())
    end


    spell.delete_func = function(self)
      self:erase()
    end

    spell.can_move_to_func = function(tile)
      return true
    end

    spell.collision_func = function(self, other)
  
    end

    
    field:spawn(spell, tile)

    return spell
  end

  
  action.update_func = function()
    if isHeld then
      isHeld = user.input_has(user, Input.Held.Shoot)
      ChargeHold = ChargeHold+1
    end
    if ChargeHold == 30 then
      props.damage = math.floor(props.damage/2)
      Engine.play_audio(CHARGE_CANNON_SUCCESS, AudioPriority.High)
      specialActivate = true
    end
  end

  action.execute_func = function(self)

    local actor = self:get_actor()

    local cannon = action:add_attachment("BUSTER")
    cannon:sprite():set_texture(CHARGE_CANNON_TEXTURE, true)
    cannon:sprite():set_layer(-1)
    
    local cannon_anim = cannon:get_animation()
    cannon_anim:load(CHARGE_CANNON_ANIMATION_PATH)
    cannon_anim:set_state("APPEAR")


    cannon_anim:on_complete(function() 
      cannon_anim:set_state("CHARGE")
      
      cannon_anim:on_complete(function()
        cannon_anim:set_state("FIRE")

      end)
    
    end)
    

    local tile = user:get_tile(user:get_facing(), 1)
    actor:get_animation():on_frame(3, function() 
      if actor:get_facing() == Direction.Right then 
        actor:set_offset(-2, 0)
      else
        actor:set_offset(2, 0)
      end
 
      Engine.play_audio(CHARGE_CANNON_WHIR, AudioPriority.High)
      Engine.play_audio(CHARGE_CANNON_CHARGE, AudioPriority.Low)
    
    end)
    
    actor:get_animation():on_frame(6, function()
      spawn_shaking()
    end)

    actor:get_animation():on_frame(7, function()
      spawn_attack(user, tile)
      if specialActivate then 
        if not tile:get_tile(Direction.Up, 1):is_edge() then 
          spawn_attack(user, tile:get_tile(Direction.Up, 1))
        end

        if not tile:get_tile(Direction.Down, 1):is_edge() then
          spawn_attack(user, tile:get_tile(Direction.Down, 1))
        end
        
      end

      Engine.play_audio(CHARGE_CANNON_FIRE, AudioPriority.High)
    end)

  end

  action.action_end_func = function()
    user:set_offset(0, 0)
    -- Possibility that this could be troublesome in time stop, but probably fine
      -- If it is, introduce actor as above
  end
  
  return action
end