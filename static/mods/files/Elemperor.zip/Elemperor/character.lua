-- Includes

---@type BattleHelper
local battle_helpers = include("battle_helpers.lua")
local elem_change = Engine.load_audio(_folderpath .. "elem_change.ogg")
local burn = Engine.load_audio(_folderpath .. "burn.ogg")


-- Animations and Textures
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local flame = Engine.load_texture(_folderpath .. "flame/flame_greyscaled.png")
local flame_anim = _folderpath .. "flame/flame.animation"

local grass_tint = Color.new(28, 147, 32, 255)
local poison_tint = Color.new(102, 19, 128, 255)
local ice_tint = Color.new(96, 255, 247, 255)
local fire_tint = Color.new(174, 0, 0, 255)
--possible states for character
local states = { DEFAULT = 1, ATTACK = 2 }

local enemy_count = -1
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.damage = (character_info.damage)
    -- Elemperor Specific
    self:set_element(character_info.element)
    self.frames_before_attack = character_info.frames_before_attack
    self.tint = nil

    --Other Setup
    self:set_explosion_behavior(4, 1, false)
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false
    --This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.move_counter = 0
    self:set_float_shoe(true)
    self.current_tilestate = TileState.Empty

    -- Elemperor Element Aura.
    self.aura = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.aura:set_texture(Engine.load_texture(_folderpath .. "aura/aura.png")) --Just set their texture...
    self.aura_anim = Engine.Animation.new(_folderpath .. "aura/aura.animation") --And they have no get_animation, so we create one...
    self.aura:set_layer(1) --Set their layer, they're already a sprite...
    self.aura_anim:set_state("NONE")
    self.aura_anim:refresh(self.aura)

    self.aura_activated = false


    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.aura_anim:update(dt, ref.aura)
    end
    self:register_component(self.animate_component)

    -- actions for states

    -- Code that runs in the default state
    ---@param frame number
    self.action_default = function(frame)

        if (frame == 1) then
            self.animation:set_state("IDLE")
            self.aura_anim:set_state("IDLE")
            self.aura_anim:set_playback(Playback.Loop)
        end
        if (frame == self.frames_before_attack) then
            self.set_state(states.ATTACK)
        end
    end

    --- Code that runs in the attack state.
    ---@param frame number
    self.action_attack = function(frame)
        if (frame == 1) then
            local target_x = battle_helpers.find_target(self):get_tile():x()
            self.target_tile = self:get_field():tile_at(target_x, self:get_tile():y())
        elseif (frame == 8) then
            self:toggle_counter(true)
        elseif (frame == 22) then
            self:toggle_counter(false)
        else if (frame == 30) then
                self.flame_attack()
            end
        end
        if (frame < 30) then
            self.target_tile:highlight(Highlight.Flash)
        end
    end

    self.flame_attack = function()
        self.animation:set_state("ATTACK")
        self.aura_anim:set_state("ATTACK")
        self.animation:on_frame(3, function()
            create_flame(self, self.target_tile, self.damage)
        end)
        self.animation:on_complete(function()
            self.set_state(states.DEFAULT)
        end)
    end

    self.battle_start_func = function(self)
        enemy_count = -1
    end

    self.on_spawn_func = function(self)
        enemy_count = enemy_count + 1
        self.start_delay = enemy_count * 90
    end


    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_default, [2] = self.action_attack }
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            if self.frame_counter > self.start_delay then
                self.started = true
                self.set_state(states.DEFAULT)
            end
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end

        self.apply_aura()
        if self.tint then
            self.aura:set_color_mode(ColorMode.Additive)
            self.aura:set_color(self.tint)
        end
        if (self.aura_activated and self.frame_counter % 5 == 0) then
            self:set_health(self:get_health() + 1)
        end
    end


    self.apply_aura = function()

        if (self:get_current_tile():get_state() ~= self.current_tilestate) then
            self.aura_anim:set_state("NONE")
            self.aura_activated = false
        end
        if (not self.aura_activated) then
            local tileState = self:get_current_tile():get_state()
            if (tileState == TileState.Grass) then
                self.tint = grass_tint;
            elseif (tileState == TileState.Ice) then
                self.tint = ice_tint;
            elseif (tileState == TileState.Poison) then
                self.tint = poison_tint;
            elseif (tileState == TileState.Lava) then
                self.tint = fire_tint;
            else
                self.tint = nil
            end
            if (self.tint ~= nil) then
                self.current_tilestate = self:get_current_tile():get_state()
                Engine.play_audio(elem_change, AudioPriority.High)
                self.aura_anim:set_state("IDLE")
                self.aura_anim:set_playback(Playback.Loop)
                self.aura_activated = true
            end
            --self.aura:set_palette(Engine.load_texture(fire_aura))
        end

    end
end

---@param user Entity The user summoning a flame
---@param tile Tile The tile to summon the flame on
---@param damage number The amount of damage the flame will do
function create_flame(user, tile, damage)
    -- Creates a new spell that belongs to the user's team.
    ---@type BnSpell
    local spell = Battle.Spell.new(user:get_team())
    -- Setup sprite of the spell
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            Element.None,
            user:get_context(),
            Drag.new()
        )
    )

    spell.update_func = function()
        if (user.tint) then
            spell:sprite():set_color_mode(ColorMode.Multiply)
            spell:sprite():set_color(user.tint)
        end
        spell:get_current_tile():attack_entities(spell)
    end

    setup_sprite(spell, flame, flame_anim)
    local anim = spell:get_animation()
    anim:set_state("DEFAULT")
    anim:on_complete(function()
        if (user.aura_activated) then
            spell:get_current_tile():set_state(user.current_tilestate)
        end
        spell:erase()
    end)
    spell:set_facing(user:get_facing())

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    Engine.play_audio(burn, AudioPriority.High)
    return spell
end

function setup_sprite(spell, texture, animpath)
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    sprite:set_layer(-3)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(animpath)
    anim:refresh(sprite)
end

return package_init
