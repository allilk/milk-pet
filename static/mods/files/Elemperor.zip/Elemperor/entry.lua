local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "Elemperor",
        hp = 100,
        damage = 30,
        palette = _folderpath .. "V1.png",
        height = 44,
        element = Element.None,
        frames_before_attack = 88
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 140
        character_info.damage = 60
        character_info.palette = _folderpath .. "V2.png"
    end
    if character:get_rank() == Rank.Rare1 then
        character_info.hp = 220
        character_info.damage = 90
        character_info.palette = _folderpath .. "Rare1.png"
    end
    if character:get_rank() == Rank.V3 then
        character_info.hp = 180
        character_info.damage = 120
        character_info.palette = _folderpath .. "V3.png"
    end
    if character:get_rank() == Rank.Rare2 then
        character_info.hp = 260
        character_info.damage = 160
        character_info.palette = _folderpath .. "Rare2.png"
    end
    if character:get_rank() == Rank.SP then
        character_info.hp = 300
        character_info.damage = 200
        character_info.palette = _folderpath .. "SP.png"
    end
    if character:get_rank() == Rank.NM then
        character_info.hp = 500
        character_info.damage = 300
        character_info.palette = _folderpath .. "NM.png"
    end
    shared_package_init(character, character_info)
end
