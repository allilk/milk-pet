local DAMAGE = 130

local SPAWNER_ANIMPATH = _modpath.."spawner.animation"
local NULLIME_TEXTURE = Engine.load_texture(_modpath.."nullime.png")
local NULLIME_ANIMPATH = _modpath.."nullime.animation"
local AUDIO_FALL = Engine.load_audio(_modpath.."metallspawn.ogg")
local AUDIO_LAND = Engine.load_audio(_modpath.."land.ogg")

local WARP_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local WARP_ANIMPATH = _modpath.."mob_move.animation"

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = true

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE3-122-StealJelly2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"E","F","G","P","S"})

    local props = package:get_card_props()
    props.shortname = "GrabJel2"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Aqua
    props.description = "Jelly atk stels lft panels!"
    props.long_description = "Jelly attack repaints panels on the left edge of enemy area!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()

		local tile = nil
		if team == Team.Red then
			if direction == Direction.Right then
				tile = field:tile_at(1, 2)
			else
				tile = field:tile_at(6, 2)
			end
		else
			if direction == Direction.Left then
				tile = field:tile_at(6, 2)
			else
				tile = field:tile_at(1, 2)
			end
		end
		local tile_array = {}
		local count = 1
		local max = 6
		local tile_front = nil
		local tile_up = nil
		local tile_down = nil
		local check_front = false
		local check_up = false
		local check_down = false
		
		for i = count, max, 1 do
        
			tile_front = tile:get_tile(direction, i)
			tile_up = tile_front:get_tile(Direction.Up, 1)
			tile_down = tile_front:get_tile(Direction.Down, 1)
        
			check_front = tile_front and user:get_team() ~= tile_front:get_team() and not tile_front:is_edge() and tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(direction), 1):get_team())
			check_up = tile_up and user:get_team() ~= tile_up:get_team() and not tile_up:is_edge() and tile_up:get_team() ~= Team.Other and user:is_team(tile_up:get_tile(Direction.reverse(direction), 1):get_team())
			check_down = tile_down and user:get_team() ~= tile_down:get_team() and not tile_down:is_edge() and tile_down:get_team() ~= Team.Other and user:is_team(tile_down:get_tile(Direction.reverse(direction), 1):get_team())
			
			if check_front or check_up or check_down then
				if SHOW_DEBUG_TEXT then
					print("The 1st target tile is: ("..tile_up:x()..";"..tile_up:y()..")")
					print("The 2nd target tile is: ("..tile_front:x()..";"..tile_front:y()..")")
					print("The 3rd target tile is: ("..tile_down:x()..";"..tile_down:y()..")")
				end
				table.insert(tile_array, tile_up)
				table.insert(tile_array, tile_front)
				table.insert(tile_array, tile_down)
				break
			end
		end

		local step1  = Battle.Step.new()

        self.spawner = nil
        self.tile    = user:get_current_tile()
		self.pattern = math.random(1,6)
		self.y1 	 = nil
		self.y2 	 = nil
		self.y3 	 = nil
		
		--[[
			1 - (1, 2, 3)
			2 - (2, 3, 1)
			3 - (3, 1, 2)
			4 - (3, 2, 1)
			5 - (2, 1, 3)
			6 - (1, 3, 2)
		]]

		local jelly3_deleted = false
		local latency_before_end = 150

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
			--[[if jelly3_deleted == false then
				print("JELLY NOT DELETED")
			else
				print("JELLY IS DELETED")
			end]]

			if latency_before_end > 0 then
				latency_before_end = latency_before_end - 1
			else
				ref.spawner:erase()
            	step1:complete_step()
			end

            if do_once then
                do_once = false

				if ref.pattern == 1 then
					ref.y1 = 1
					ref.y2 = 2
					ref.y3 = 3
				elseif ref.pattern == 2 then
					ref.y1 = 2
					ref.y2 = 3
					ref.y3 = 1
				elseif ref.pattern == 3 then
					ref.y1 = 3
					ref.y2 = 1
					ref.y3 = 2
				elseif ref.pattern == 4 then
					ref.y1 = 3
					ref.y2 = 2
					ref.y3 = 1
				elseif ref.pattern == 5 then
					ref.y1 = 2
					ref.y2 = 1
					ref.y3 = 3
				else
					ref.y1 = 1
					ref.y2 = 3
					ref.y3 = 2
				end

				local jelly3
    			jelly3 = function()
					local jelly = Battle.Artifact.new()
					jelly:set_offset(0.0, -350.0)
					jelly:set_facing(direction)
					local anim = jelly:get_animation()
					anim:load(NULLIME_ANIMPATH)
					anim:set_state("0")
					anim:set_playback(Playback.Loop)
					anim:refresh(jelly:sprite())
					jelly:sprite():set_layer(-9)
					jelly:sprite():set_texture(NULLIME_TEXTURE, true)
					local doOnce = false
					jelly.update_func = function(self, dt)
						if self:get_offset().y >= -6 then
							if not self:get_current_tile():is_hole() and self:get_current_tile():get_team() ~= user:get_team() then
								if not doOnce then
									self:set_offset(0.0, 0.0)
									self:get_animation():set_state("1")
									self:get_animation():set_playback(Playback.Once)
									self:get_current_tile():set_team(user:get_team(), false)
									self:get_animation():on_frame(2, function()
										Engine.play_audio(AUDIO_LAND, AudioPriority.Highest)
									end)
									
									local hitbox = Battle.Spell.new(user:get_team())
									local props = HitProps.new(
										props.damage, 
										Hit.Impact | Hit.Flinch | Hit.Flash,
										props.element,
										user:get_id(),
										Drag.None
									)
									hitbox:set_hit_props(props)
									hitbox.update_func = function(self, dt)
										self:get_current_tile():attack_entities(self)
									end
									hitbox.attack_func = function(self)
										Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
										create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-15,15), math.random(-15,15), field, self:get_current_tile())
									end
									hitbox.collision_func = function()
										jelly:delete()
									end
									self:get_animation():on_frame(7, function()
										hitbox:erase()
									end)
									field:spawn(hitbox, self:get_current_tile())
									doOnce = true
								end
								self:get_animation():on_complete(function()
									create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, -10, field, self:get_current_tile())
									self:delete()
								end)
							else
								if not doOnce then
									self:set_offset(0.0, 0.0)
									self:get_animation():set_state("1")
									self:get_animation():set_playback(Playback.Once)
									
									local hitbox = Battle.Spell.new(user:get_team())
									local props = HitProps.new(
										props.damage, 
										Hit.Impact | Hit.Flinch | Hit.Flash,
										props.element,
										user:get_id(),
										Drag.None
									)
									hitbox:set_hit_props(props)
									hitbox.update_func = function(self, dt)
										self:get_current_tile():attack_entities(self)
									end
									hitbox.attack_func = function(self)
										Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
										create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-15,15), math.random(-15,15), field, self:get_current_tile())
									end
									hitbox.collision_func = function()
										jelly:delete()
									end
									self:get_animation():on_frame(2, function()
										hitbox:delete()
										create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, -10, field, self:get_current_tile())
										self:delete()
									end)
									field:spawn(hitbox, self:get_current_tile())
									doOnce = true
								end
							end
						else
							self:set_offset(0.0, self:get_offset().y + 16.0)
						end
					end
					jelly.delete_func = function(self)
						if SHOW_DEBUG_TEXT then
							print("JELLY DELETED")
						end
						jelly3_deleted = true
						self:erase()
					end
					Engine.play_audio(AUDIO_FALL, AudioPriority.Highest)
					field:spawn(jelly, tile_array[ref.y3])
					return jelly
				end
				
                ref.spawner = Battle.Artifact.new()
                ref.spawner:set_facing(direction)
                spawner_anim = ref.spawner:get_animation()
                spawner_anim:load(SPAWNER_ANIMPATH)
                spawner_anim:set_state("0")
                spawner_anim:on_frame(2, function()
					if SHOW_DEBUG_TEXT then
						print("Nullime at tile ("..tile_array[ref.y1]:x()..";"..tile_array[ref.y1]:y()..")")
					end
					spawn_jelly(user, props, direction, field, tile_array[ref.y1])
				end)
				spawner_anim:on_frame(3, function()
					if SHOW_DEBUG_TEXT then
						print("Nullime at tile ("..tile_array[ref.y2]:x()..";"..tile_array[ref.y2]:y()..")")
					end
					spawn_jelly(user, props, direction, field, tile_array[ref.y2])
				end)
				spawner_anim:on_frame(4, function()
					if SHOW_DEBUG_TEXT then
						print("Nullime at tile ("..tile_array[ref.y3]:x()..";"..tile_array[ref.y3]:y()..")")
					end
					jelly3()
				end)
		    	spawner_anim:on_complete(function()
		    		spawner_anim:set_state("1")
		    	end)
                field:spawn(ref.spawner, ref.tile)
            end
			--[[local anim = ref.spawner:get_animation()
			if jelly3_deleted then
				if SHOW_DEBUG_TEXT then
					print("ALL DELETED")
				end
				anim:set_state("2")
			end
			if anim:get_state() == "2" then
				if do_once_part_two then
					do_once_part_two = false
					if SHOW_DEBUG_TEXT then
						print("STATE 2")
					end
					anim:on_complete(function()
						if SHOW_DEBUG_TEXT then
							print("ANIM END")
						end
						ref.spawner:erase()
            		    step1:complete_step()
					end)
				end
			end]]
        end
        self:add_step(step1)
	end
    return action
end

function spawn_jelly(user, props, direction, field, thetile)
	local jelly = Battle.Artifact.new()
	jelly:set_offset(0.0, -350.0)
	jelly:set_facing(direction)
	local anim = jelly:get_animation()
	anim:load(NULLIME_ANIMPATH)
	anim:set_state("0")
	anim:set_playback(Playback.Loop)
	anim:refresh(jelly:sprite())
	jelly:sprite():set_layer(-9)
	jelly:sprite():set_texture(NULLIME_TEXTURE, true)
	local doOnce = false
	jelly.update_func = function(self, dt)
		if self:get_offset().y >= -6 then
			if not self:get_current_tile():is_hole() and self:get_current_tile():get_team() ~= user:get_team() then
				if not doOnce then
					self:set_offset(0.0, 0.0)
					self:get_animation():set_state("1")
					self:get_animation():set_playback(Playback.Once)
					self:get_current_tile():set_team(user:get_team(), false)
					self:get_animation():on_frame(2, function()
						Engine.play_audio(AUDIO_LAND, AudioPriority.Highest)
					end)
					local hitbox = Battle.Spell.new(user:get_team())
					local props = HitProps.new(
						props.damage, 
						Hit.Impact | Hit.Flinch | Hit.Flash,
						props.element,
						user:get_id(),
						Drag.None
					)
					hitbox:set_hit_props(props)
					hitbox.update_func = function(self, dt)
						self:get_current_tile():attack_entities(self)
					end
					hitbox.attack_func = function(self)
						Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
						create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-15,15), math.random(-15,15), field, self:get_current_tile())
					end
					hitbox.collision_func = function()
						jelly:delete()
					end
					self:get_animation():on_frame(7, function()
						hitbox:erase()
					end)
					field:spawn(hitbox, self:get_current_tile())
					doOnce = true
				end
				self:get_animation():on_complete(function()
					create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, -10, field, self:get_current_tile())
					self:delete()
				end)
			else
				if not doOnce then
					self:set_offset(0.0, 0.0)
					self:get_animation():set_state("1")
					self:get_animation():set_playback(Playback.Once)
					
					local hitbox = Battle.Spell.new(user:get_team())
					local props = HitProps.new(
						props.damage, 
						Hit.Impact | Hit.Flinch | Hit.Flash,
						props.element,
						user:get_id(),
						Drag.None
					)
					hitbox:set_hit_props(props)
					hitbox.update_func = function(self, dt)
						self:get_current_tile():attack_entities(self)
					end
					hitbox.attack_func = function(self)
						Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
						create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "AQUA", math.random(-15,15), math.random(-15,15), field, self:get_current_tile())
					end
					hitbox.collision_func = function()
						jelly:delete()
					end
					self:get_animation():on_frame(2, function()
						hitbox:delete()
						create_effect(WARP_TEXTURE, WARP_ANIMPATH, "0", 0, -10, field, self:get_current_tile())
						self:delete()
					end)
					field:spawn(hitbox, self:get_current_tile())
					doOnce = true
				end
			end
		else
			self:set_offset(0.0, self:get_offset().y + 16.0)
		end
	end
	jelly.delete_func = function(self)
		if SHOW_DEBUG_TEXT then
			print("JELLY DELETED")
		end
		self:erase()
	end
	Engine.play_audio(AUDIO_FALL, AudioPriority.Highest)
	field:spawn(jelly, thetile)
	return jelly
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end