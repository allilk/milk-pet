function package_init(block)
    block:declare_package_id("com.alrysc.block.TimeFreezeParry")
    block:set_name("TFParry")
    block:set_description("Press Back during dim to block!")
    block:set_color(Blocks.White)
    block:as_program()
    block:set_shape({
        0, 0, 1, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local active_window = 6
    local current_window = 0
    local active = false
    local blocked = false
    local cooling = false
    local cooldown_max = 40
    local cooldown = 0

    local component_counter = 0
    local artifact_counter = 0

    local component_first = true


    local parry_component = Battle.Component.new(player, Lifetimes.Battlestep)
    local parry_defense = Battle.DefenseRule.new(8621, DefenseOrder.CollisionOnly)
    
    local function spawn_parry_artifact(player)
        local artifact = Battle.Artifact.new()
        artifact:set_texture(Engine.load_texture(_modpath.."block.png"), false)
        artifact:get_animation():load(_folderpath.."block.animation")
        artifact:sprite():set_layer(-4)
        artifact:set_facing(player:get_facing())

        artifact:get_animation():set_state("10")
        artifact:get_animation():refresh(artifact:sprite())           
        artifact:set_offset(0, 0)

        artifact:get_animation():on_complete(function()
            artifact:delete()
        
        end)

        player:get_field():spawn(artifact, player:get_current_tile())

    end

    parry_defense.can_block_func = function(judge, attacker, defender)
        if active then
            local hit_props = attacker:copy_hit_props()
            hit_props.damage = math.floor(hit_props.damage/2)
            attacker:set_hit_props(hit_props)

            blocked = true
            spawn_parry_artifact(player)
            Engine.play_audio(Engine.load_audio(_modpath.."block.ogg"), AudioPriority.Low)
        end


    end

    parry_component.update_func = function()
        if component_counter ~= artifact_counter then 
            artifact_counter = component_counter
            active = false
            blocked = false
            cooling = false
            current_window = 0
            cooldown = 0

        end

        component_counter = component_counter+1

    end


    local function spawn_artifact(player)
        local artifact = Battle.Artifact.new()
        artifact.update_func = function()
            artifact_counter = artifact_counter+1

            if blocked then 
                active = false
                blocked = false
                cooling = false
                current_window = 0
                cooldown = 0

            end


            if active then 
                current_window = current_window + 1
                if current_window == active_window then 
                    active = false
                    current_window = 0

                end

            end

            if cooling then 
                cooldown = cooldown-1
                if cooldown == 0 then 
                    cooling = false
                end
            end

            if player:input_has(Input.Pressed.Left) and artifact_counter ~= component_counter then 
                if not cooling then 
                    active = true
                    cooling = true
                    cooldown = cooldown_max
                end
            end


        end

        player:get_field():spawn(artifact, 0, 0)
    end

    spawn_artifact(player)

    player:register_component(parry_component)
    player:add_defense_rule(parry_defense)

end