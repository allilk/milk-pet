function package_init(package)
    package:declare_package_id("com.discord.Konstinople.player.AquaMan")
    package:set_special_description("Slosh slosh")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_modpath .. "face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_overworld_animation_path(_modpath .. "overworld.animation")
    package:set_overworld_texture_path(_modpath .. "overworld.png")
    package:set_mugshot_texture_path(_modpath .. "mug.png")
    package:set_mugshot_animation_path(_modpath .. "mug.animation")
    package:set_emotions_texture_path(_modpath .. "emotions.png")
end

function player_init(player)
    player:set_name("AquaMan")
    player:set_health(1000)
    player:set_element(Element.Aqua)
    player:set_height(40.0)
    player:set_charge_position(2, -13)
    player:set_animation(_modpath .. "battle.animation")
    player:set_texture(Engine.load_texture(_modpath .. "battle.png"))
    player:set_fully_charged_color(Color.new(255, 55, 198, 255))

    player.shoot_sfx = Engine.load_audio(_modpath .. "bubbler_shoot.ogg")
    player.bubble_sfx = Engine.load_audio(_modpath .. "57- Bubbles!.wav")
    player.impacts_texture = Engine.load_texture(_folderpath .. "impacts.png")
    player.impacts_animation_path = _folderpath .. "impacts.animation"

    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player, sfx)
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")

    local buster = action:add_attachment("BUSTER")
    local buster_sprite = buster:sprite()
    buster_sprite:set_texture(player:get_texture())
    buster_sprite:set_layer(-2)
    buster_sprite:enable_parent_shader(true)

    local buster_anim = buster:get_animation()
    buster_anim:copy_from(player:get_animation())
    buster_anim:set_state("BUSTER")

    action:add_anim_action(2, function()
        local artifact = buster:add_attachment("ENDPOINT")
        local artifact_sprite = artifact:sprite()
        artifact_sprite:set_texture(player:get_texture())
        artifact_sprite:set_layer(-1)

        local artifact_anim = artifact:get_animation()
        artifact_anim:copy_from(player:get_animation())
        artifact_anim:set_state("AQUA_SHOT_ARTIFACT")

        local context = player:get_context()
        create_aqua_shot(player, context)
    end)

    return action
end

function create_aqua_shot(player, context)
    local spell = Battle.Spell.new(player:get_team())
    spell:set_facing(player:get_facing())
    spell:set_texture(player:get_texture())
    local spell_anim = spell:get_animation()
    spell_anim:copy_from(player:get_animation())
    spell_anim:set_state("AQUA_SHOT")
    spell_anim:refresh(spell:sprite())

    local TOTAL_FRAMES = 15
    local frame_count = 0

    local start_offset_x = -96
    local start_offset_y = -24

    if player:get_facing() == Direction.Left then
        start_offset_x = start_offset_x * -1
    end

    spell:set_offset(start_offset_x, start_offset_y)

    spell.update_func = function()
        if frame_count >= TOTAL_FRAMES then
            if spell:get_tile():is_walkable() then
                create_splash(player, context, spell:get_tile(), true)
                create_splash(player, context, spell:get_tile(spell:get_facing(), 1))
            end

            spell:erase()
            return
        end

        spell:set_offset(
        start_offset_x + frame_count * -start_offset_x / TOTAL_FRAMES,
            start_offset_y + frame_count * -start_offset_y / TOTAL_FRAMES
        )

        frame_count = frame_count + 1
    end

    Engine.play_audio(player.shoot_sfx, AudioPriority.High)
    player:get_field():spawn(spell, player:get_tile(player:get_facing(), 2))
end

function create_splash(player, context, tile, break_panel)
    if not tile:is_walkable() then
        return
    end

    local spell = Battle.Spell.new(player:get_team())
    spell:set_facing(player:get_facing())
    spell:set_texture(player:get_texture())
    local spell_anim = spell:get_animation()
    spell_anim:copy_from(player:get_animation())
    spell_anim:set_state("SPLASH")
    spell_anim:refresh(spell:sprite())
    spell:sprite():set_layer(-5)

    spell:set_hit_props(
        HitProps.new(
            player:get_attack_level() * 10,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Aqua,
            context,
            Drag.None
        )
    )

    spell.update_func = function()
        spell:get_tile():attack_entities(spell)
    end

    spell_anim:on_complete(function()
        if tile:is_walkable() and break_panel then
            if tile:get_state() == TileState.Cracked then
                tile:set_state(TileState.Broken)
            else
                tile:set_state(TileState.Cracked)
            end
        end

        spell:erase()
    end)

    local impacts_texture = player.impacts_texture
    local impacts_animation_path = player.impacts_animation_path

    spell.collision_func = function(self, other)
        local artifact = Battle.Artifact.new()
        artifact:never_flip(true)
        artifact:set_texture(impacts_texture)
        artifact:set_animation(impacts_animation_path)

        local anim = artifact:get_animation()
        anim:set_state("1")
        anim:on_complete(function()
            artifact:erase()
        end)

        other:get_field():spawn(artifact, other:get_tile())
    end

    Engine.play_audio(player.bubble_sfx, AudioPriority.High)
    player:get_field():spawn(spell, tile)
end
