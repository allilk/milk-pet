function package_init(block)
    block:declare_package_id("com.Dawn.DiscordRoles.Buggy")
    block:set_name("BugRole")
    block:as_program()
    block:set_description("Why so buggy?")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 0, 1, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local step_tile_list = {TileState.Cracked, TileState.Lava, TileState.Poison, TileState.Ice}
    local status_list = {Hit.Blind, Hit.Freeze, Hit.Stun, Hit.Root}
    local chosen_bug = math.random(1, 100) --Roll between 1 and 100 to decide a bug.
    if chosen_bug <= 40 then
        local component = Battle.Component.new(player, Lifetimes.Battlestep)
        component.tile_type = step_tile_list[math.random(1, #step_tile_list)]
        component.tile = player:get_tile()
        component.update_func = function(self, dt)
            if not self.owner then
                self.owner = self:get_owner()
            end
            if self.owner:is_moving() and not self.owner:is_sliding() and self.owner:get_tile() ~= self.tile then
                if self.tile_type == TileState.Cracked and tile:get_state() == self.tile_type then
                    self.tile:set_state(TileState.Broken)
                else
                    self.tile:set_state(self.tile_type)
                end
            end
            self.tile = self.owner:get_tile()
        end
        player:register_component(component)
    elseif chosen_bug <= 20 then
        local hitbox = Battle.Hitbox.new(Team.Other)
        hitbox:set_hit_props(
            HitProps.new(
                0,
                Hit.None | status_list[math.random(1, #status_list)],
                Element.None,
                nil,
                Drag.None
            )
        )
        player:get_field():spawn(hitbox, player:get_tile())
    elseif chosen_bug <= 10 then
        local rare_component = Battle.Component.new(player, Lifetimes.Battlestep)
        rare_component.update_func = function(self, dt)
            if not self.owner then
                self.owner = Battle.Player.from(self:get_owner())
            end
            if self.owner then
                if self.owner:get_attack_level() > 1 then player:set_attack_level(1) end
                if self.owner:get_charge_level() > 1 then player:set_charge_level(1) end
            else
                self:eject()
            end
        end
        player:register_component(rare_component)
    end
end