--- Setup Textures, Animations and Sounds
--- modpath refers to the root folder of the chip.
GOLEMHIT_TEXTURE = Engine.load_texture(_modpath .. "golem_hit.png")
GOLEMHIT_ANIMATION = _modpath .. "golem_hit.animation"
GOLEMHIT_SFX = Engine.load_audio(_modpath .. "golem.ogg")
GOLEM_IMPACT_TEXTURE = Engine.load_texture(_modpath .. "shockwave.png")
GOLEM_IMPACT_ANIM = _modpath .. "shockwave.animation"
HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
HIT_ANIM_PATH = _modpath .. "effect.animation"
HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")

--Damage property.
DAMAGE = 190

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    -- DisplayName of the chip
    props.shortname = "GolmHit2"
    -- Damage displayed on the chip
    props.damage = DAMAGE
    -- Whether or not this chip uses time freeze.
    props.time_freeze = false
    -- Element displayed on this chip.
    props.element = Element.Break
    -- Description of this chip in the folder
    props.description = "Hit 3pnl area arnd clst enmy"
    -- Description of this chip when special button is presssed
    props.long_description = "Golem hits closest enemy column!"
    props.limit = 4
    -- Package ID. Usually uses some form of the author's name + chip name
    package:declare_package_id("com.louise.card." .. props.shortname)
    -- Sets small icon icon
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    -- Sets large preview graphic
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    -- List of codes this chip will be available as.
    package:set_codes({ "D", "P", "U" })
end

function card_create_action(user, props)
    -- Creates a new cardAction that will play the play_sword animation
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    -- Prevents the user from using other cards during this animation
    action:set_lockout(make_async_lockout(0.34))

    --Function that happens when the card actually executes.
    action.execute_func = function(self, user)
        self:add_anim_action(1, function()
            local direction = user:get_facing()
            Engine.play_audio(GOLEMHIT_SFX, AudioPriority.High)
            local tile = get_target(user)
            create_golem_hand(user, tile, DAMAGE)
        end)
    end
    return action
end

function get_target(user)
    local tile = user:get_tile()
    while tile:get_team() == user:get_team() do
        tile = tile:get_tile(user:get_facing(), 1)
    end
    return tile
end

function setup_sprite(spell, texture, animpath)
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    sprite:set_layer(-3)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(animpath)
    anim:refresh(sprite)
end

---@param user Entity The user summoning a golemHit
---@param tile Tile The tile to summon the golemHit on
---@param damage number The amount of damage the golemHit will do
---@param speed number The number of frames it takes the golemHit to travel 1 tile.
---@param direction any The direction the
function create_golem_hand(user, tile, damage)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Spell.new(user:get_team())
    -- Setup sprite of the spell
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Drag | Hit.Breaking,
            Element.Break,
            user:get_context(),
            Drag.new()
        )
    )

    setup_sprite(spell, GOLEMHIT_TEXTURE, GOLEMHIT_ANIMATION)
    local anim = spell:get_animation()
    anim:set_state("1")

    anim:on_frame(7, function()
        if (tile:is_walkable()) then
            spell:shake_camera(8, 0.5)
            create_golem_impact(damage, user, spell:get_tile():get_tile(Direction.Up, 1), true)
            create_golem_impact(damage, user, spell:get_tile():get_tile(Direction.Down, 1), true)
            create_golem_impact(damage, user, spell:get_tile(), true)
        else
            tile:attack_entities(spell)
        end
    end)
    anim:on_complete(function()
        spell:erase()
    end)
    spell:set_facing(user:get_facing())

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end

    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function create_golem_impact(damage, user, tile, doDamage)
    local spell = Battle.Spell.new(user:get_team())
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flash | Hit.Flinch | Hit.Drag | Hit.Breaking,
            Element.Break,
            user:get_context(),
            Drag.new()
        )
    )

    setup_sprite(spell, GOLEM_IMPACT_TEXTURE, GOLEM_IMPACT_ANIM)
    local anim = spell:get_animation()
    anim:set_state("1")
    anim:on_complete(function()
        spell:erase()
    end)
    local do_once = doDamage
    user:get_field():spawn(spell, tile)
    spell.update_func = function()
        if (do_once) then
            ---@type Tile

            tile:attack_entities(spell)
            --if (tile:get_state() == TileState.Cracked) then
            --    tile:set_state(TileState.Broken)
            --else
            --    tile:set_state(TileState.Cracked)
            --end
            do_once = false
        end
    end
end

--- create hit effect.
---@param field any #A field to spawn the effect on
---@param tile Tile tile to spawn effect on
---@param hit_texture any Texture hit effect. (Engine.load_texture)
---@param hit_anim_path any The animation file path
---@param hit_anim_state any The hit animation to play
---@param sfx any Audio # Audio object to play
---@return any returns the hit fx
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    -- Create artifact, artifacts do not have hitboxes and are used mostly for special effects
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    -- This will randomize the position of the effect a bit.
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end
