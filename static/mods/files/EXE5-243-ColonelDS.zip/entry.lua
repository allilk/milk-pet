local DAMAGE = 200

local TEXTURE_COLONEL = Engine.load_texture(_modpath.."colonel.png")
local TEXTURE_SCREENDIVIDE = Engine.load_texture(_modpath.."screendivide.png")
local ANIMPATH_COLONEL = _modpath.."colonel.animation"
local ANIMPATH_SCREENDIVIDE = _modpath.."screendivide.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SCREENDIVIDE = Engine.load_audio(_modpath.."screendivide.ogg")

local TEXTURE_FLASH = Engine.load_texture(_modpath.."flash.png")
local ANIMPATH_FLASH = _modpath.."flash.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = false

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-243-ColonelDS")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"C"})

    local props = package:get_card_props()
    props.shortname = "ColonelDS"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Slice enemy in same row"
    props.long_description = "Slash enemies in the same front row diagonally down to right"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    local dark_hole_query = function(hole)
        return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
    end
    local field = actor:get_field()
    local dark_hole_list = field:find_obstacles(dark_hole_query)
    local boost = 10 * (math.min(10, #dark_hole_list))
    props.damage = props.damage + boost
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local tile = nil
		if team == Team.Red then
			if direction == Direction.Right then
				tile = field:tile_at(1, Y)
			else
				tile = field:tile_at(6, Y)
			end
		else
			if direction == Direction.Left then
				tile = field:tile_at(6, Y)
			else
				tile = field:tile_at(1, Y)
			end
		end

		local tile_array = {}
		local count = 1
		local max = 6
		local tile_front = nil
		local check_front = false
        local targeted = false

        local check = function(ent)
            if not user:is_team(ent:get_team()) then
				return true
			end
        end
        local checkOBS = function(ent)
            return true
        end
		
		for i = count, max, 1 do

			tile_front = tile:get_tile(direction, i)
			
			check_front = tile_front and #tile_front:find_characters(check) > 0 and #tile_front:find_obstacles(checkOBS) <= 0

            if check_front then
                targeted = true
                table.insert(tile_array, tile_front)
				break
			end
		end

        local SD_X1 = nil
        local SD_Y1 = Y + 1
        local SD_X2 = nil
        local SD_Y2 = Y - 1

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
                local navi_sprite = ref.navi:sprite()
                navi_sprite:set_layer(-3)
		    	navi_sprite:set_texture(TEXTURE_COLONEL, true)
                local navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_COLONEL)
                navi_anim:set_state("SPAWN")
		    	navi_anim:refresh(navi_sprite)
                navi_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	navi_anim:on_complete(function()
                    if ref.tile:get_tile(direction, 3) == nil or ref.tile:get_tile(direction, 3):is_edge() then
                        if tile_array[1] == nil then
                            navi_anim:set_state("END")
		    		        navi_anim:refresh(navi_sprite)
                        else
                            navi_anim:set_state("ATTACK")
		    		        navi_anim:refresh(navi_sprite)
                        end
                    else
                        navi_anim:set_state("ATTACK")
		    		    navi_anim:refresh(navi_sprite)
                    end
		    	end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local sword = create_slash(team, direction, user, props)
                    local sharebox1 = Battle.SharedHitbox.new(sword, 0.05)
                    sharebox1:set_hit_props(sword:copy_hit_props())
                    local sharebox2 = Battle.SharedHitbox.new(sword, 0.05)
                    sharebox2:set_hit_props(sword:copy_hit_props())
                    local fx = Battle.Artifact.new()
                    fx:set_facing(sword:get_facing())
                    local fx_sprite = fx:sprite()
                    fx_sprite:set_layer(-9)
                    fx_sprite:set_texture(TEXTURE_SCREENDIVIDE, true)
                    local fx_anim = fx:get_animation()
                    fx_anim:load(ANIMPATH_SCREENDIVIDE)
                    fx_anim:set_state("0")
                    fx_anim:refresh(fx_sprite)
                    fx_anim:on_complete(function()
                        fx:erase()
                    end)
                    anim:on_frame(2, function()
                        print("Colonel: ScreenDivide!")
                        Engine.play_audio(AUDIO_SCREENDIVIDE, AudioPriority.High)
                    end)
                    anim:on_frame(3, function()
                        create_flashlight(field)
                        if targeted then
                            if SHOW_DEBUG_TEXT then
                                print("target ON")
                            end
                            if direction == Direction.Right then
                                SD_X1 = tile_array[1]:x() - 1
                                SD_X2 = tile_array[1]:x() + 1
                            else
                                SD_X1 = tile_array[1]:x() + 1
                                SD_X2 = tile_array[1]:x() - 1
                            end
                            field:spawn(sword, tile_array[1])
                            field:spawn(sharebox1, SD_X1, SD_Y1)
                            field:spawn(sharebox2, SD_X2, SD_Y2)
                        else
                            if SHOW_DEBUG_TEXT then
                                print("target OFF")
                            end
                            if direction == Direction.Right then
                                SD_X1 = ref.tile:x() + 2
                                SD_X2 = ref.tile:x() + 4
                            else
                                SD_X1 = ref.tile:x() - 2
                                SD_X2 = ref.tile:x() - 4
                            end
                            field:spawn(sword, ref.tile:get_tile(direction, 3))
                            field:spawn(sharebox1, SD_X1, SD_Y1)
                            field:spawn(sharebox2, SD_X2, SD_Y2)
                        end
                    end)
                    anim:on_frame(4, function()
                        ref.navi:shake_camera(25, 0.5)
                        if targeted then
				            field:spawn(fx, tile_array[1])
                        else
                            field:spawn(fx, ref.tile:get_tile(direction, 3))
                        end
                    end)
                    anim:on_frame(7, function()
                        create_flashlight(field)
                    end)
                    anim:on_frame(9, function()
                        create_flashlight(field)
                    end)
                    anim:on_complete(function()
                        sword:erase()
                        anim:set_state("END")
		    		    anim:refresh(ref.navi:sprite())
                    end)
                end
            end
            if anim:get_state() == "END" then
                anim:on_complete(function()
                    ref.navi:erase()
                    step1:complete_step()
                end)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action    
end

function create_slash(team, direction, user, props)
	local spell = Battle.Spell.new(team)
	spell:set_facing(direction)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_id(),
			Drag.None
		)
	)
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
    end
    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

function create_flashlight(field)
    local flashlight = Battle.Artifact.new()
    flashlight:set_facing(Direction.Right)
    flashlight:sprite():set_layer(10)
    flashlight:set_texture(TEXTURE_FLASH, true)
    local flashlight_anim = flashlight:get_animation()
	flashlight_anim:load(ANIMPATH_FLASH)
	flashlight_anim:set_state("0")
	flashlight_anim:refresh(flashlight:sprite())
    flashlight_anim:on_complete(function()
        flashlight:erase()
    end)
    field:spawn(flashlight, 3, 2)
    
    return flashlight
end