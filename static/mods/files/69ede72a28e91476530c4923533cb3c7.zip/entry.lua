nonce = function() end
local AUDIO1 = Engine.load_audio(_modpath.."PanelFinalChange.ogg")
local AUDIO2 = Engine.load_audio(_modpath.."PanalChange.wav")


function package_init(package) 
	package:declare_package_id("com.Thor.card.IceArea")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'*'})

	local props = package:get_card_props()
	props.shortname = "IceArea"
	--props.damage = DAMAGE
	props.time_freeze = true
	props.element = Element.Aqua
	props.description = "Changes your panls to ice"
	props.limit = 3
	props.card_class = CardClass.Standard
	--props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		local tile_count = 0
		
		local all_red_tiles = user:get_field():find_tiles(function(tile) 
			if tile:get_team() == user:get_team() then 
				tile_count = tile_count+1
			return true 
			else return false
			end
		end)


		local k = 0
		local cooldown = 0
		local step1 = Battle.Step.new()
		step1.update_func = function(self, dt)
			if cooldown <= 0 then
				k = k + 1
				cooldown = 0.05
				Engine.play_audio(AUDIO2, AudioPriority.Low)
				if user:get_tile():get_state() == TileState.Ice then
					for i=1, tile_count, 1
					do
						all_red_tiles[i]:set_state(TileState.Normal)
					end

				else
					for i=1, tile_count, 1
					do
						all_red_tiles[i]:set_state(TileState.Ice)

					end
					
				end
			else
				cooldown = cooldown - dt
			end
			
			if k == 14 then
				self:complete_step()
			end	
		end
		self:add_step(step1)		
		
		for i=1, tile_count, 1
		do
			all_red_tiles[i]:set_state(TileState.Ice)
		end

		Engine.play_audio(AUDIO1, AudioPriority.Low)
	end
	return action
end