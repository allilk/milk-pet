local wave = include("/wave/wave.lua")


function package_init(package)
    package:declare_package_id("seabit.waveman.player.soup")
    package:set_special_description("WaveMan.EXE, designed by seabit.")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_icon_texture(Engine.load_texture(_modpath.."blues_face.png"))
    package:set_overworld_animation_path(_modpath.."waybow.animation")
    package:set_overworld_texture_path(_modpath.."owsprite.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("WaveMan")
    player:set_health(1000)
    player:set_element(Element.Aqua)
    player:set_height(62.0)

    local base_texture = Engine.load_texture(_modpath.."inbattle.png")
    local base_animation_path = _modpath.."wayb.animation"
    local base_charge_color = Color.new(255, 0, 255, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -30)
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack

    player.update_func = function(self, dt) 
        -- nothing in particular
    end
end

function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
    print("charged attack")
    local props = Battle.CardProperties:new()
    props.damage = (player:get_attack_level()*50)
    local wave_action = wave.card_create_action(player,props)
    return wave_action
end

