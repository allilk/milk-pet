local DAMAGE = 50

local TEXTURE_GUTSMAN = Engine.load_texture(_modpath .. "battle.png")
local ANIMPATH_GUTSMAN = _modpath .. "battle.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath .. "navispawn.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")

local shockwave_sound = Engine.load_audio(_folderpath .. "shockwave.ogg")
local shockwave_sprite = Engine.load_texture(_folderpath .. "shockwave.png")
local shockwave_anim = "shockwave.animation"
local quake = Engine.load_audio(_folderpath .. "hammer.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.gutsmanv1")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "G", "*" })

    local props = package:get_card_props()
    props.shortname = "GutsMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Terrain damaging shockwave!"
    props.long_description = "Cracks and smashes panels!"
    props.can_boost = true
    props.card_class = CardClass.Mega
    props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        local actor = self:get_actor()
        actor:hide()
        local self_tile = user:get_tile()
        local self_Y = self_tile:y()
        local step1 = Battle.Step.new()
        local field = actor:get_field()

        self.navi = nil
        self.tile = user:get_current_tile()
        local ref = self
        local frames = 0
        local do_once = true
        local warp_index = 1
        local state = "default"
        step1.update_func = function(self, dt)
            if (do_once) then
                ---create the navi artifact..
                ---@type Entity
                ref.navi = Battle.Artifact.new()
                ref.navi:set_float_shoe(true)
                ref.navi:set_facing(user:get_facing())
                ref.navi:set_texture(TEXTURE_GUTSMAN, true)
                ref.navi:sprite():set_layer(-1)
                navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_GUTSMAN)
                navi_anim:set_state("JUMP_IN")
                navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                end)

                navi_anim:on_complete(function()
                    navi_anim:set_state("JUMP_OUT")
                    navi_anim:refresh(ref.navi:sprite())
                    state = "prep_attack"
                    frames = 0
                end)
                do_once = false
                field:spawn(ref.navi, ref.tile)
            end
            --states
            if (state == "prep_attack") then
                navi_anim:set_state("HAMMER")
                navi_anim:on_frame(7, function()
                    create_shockwaves(actor, props.damage)
                end)
                navi_anim:on_complete(function()
                    state = "end"
                end)
                state = "attacking"
            end
            if (state == "end") then
                ref.navi:erase()
                step1:complete_step()
            end
            frames = frames + 1
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        actor:reveal()
    end
    return action
end

function create_shockwaves(self, damage)
    local startx = self:get_tile():get_tile(self:get_facing(), 1):x()
    local start_tile = self:get_field():tile_at(startx, 1)
    spawn_shockwave(self, start_tile, self:get_facing(), damage,
        shockwave_sprite, shockwave_anim,
        shockwave_sound, 4)
    spawn_shockwave(self, start_tile:get_tile(Direction.Down, 1), self:get_facing(), damage,
        shockwave_sprite, shockwave_anim,
        shockwave_sound, 4)
    spawn_shockwave(self, start_tile:get_tile(Direction.Down, 2), self:get_facing(), damage,
        shockwave_sprite, shockwave_anim,
        shockwave_sound, 4)
    self:shake_camera(10, 0.5)
    Engine.play_audio(quake, AudioPriority.Highest)
end

---Used by quaker to shockwave
---@param owner Entity
function spawn_shockwave(owner, tile, direction, damage, wave_texture, wave_animation, wave_sfx, cascade_frame_index)
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local cascade_frame = cascade_frame_index
    local spawn_next
    local Tier = owner:get_rank()

    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(wave_sfx, AudioPriority.Low)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(damage, Hit.Flash | Hit.Flinch, Element.None, owner_id, Drag.new()))

        local sprite = spell:sprite()
        sprite:set_texture(wave_texture)
        sprite:set_layer(-1)

        local animation = spell:get_animation()
        animation:load(_folderpath .. wave_animation)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)

        animation:on_frame(cascade_frame, function()
            tile:set_state(TileState.Cracked)
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() end)

        spell.attack_func = function(self, other)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        end
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end
