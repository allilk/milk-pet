function package_init(block)
    block:declare_package_id("com.example.block.BABYBABYBABYBABY")
    block:set_name("Mass Destruction")
    block:set_description("BABYBABYBABYBABYBABY")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
	local music_player = Battle.Component.new(player, Lifetimes.Local)
	local cooldown = 1/60
	music_player.update_func = function(self, dt)
		if cooldown <= 0 then
			Engine.stream_music(_modpath.."music.mid")
			self:eject()
		else
			cooldown = cooldown - dt
		end
	end
	player:register_component(music_player)
end