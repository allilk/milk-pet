function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.Dab.blue")
    block:set_name("Dab")
    block:set_description("<o/")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

local FRAMES = make_frame_data({
  { 4, 9999999 }
})

local function create_dab_action(player)
    local action = Battle.CardAction.new(player, "PLAYER_SWORD")
    action:override_animation_frames(FRAMES)
    action:set_lockout(make_sequence_lockout())

    local hand = action:add_attachment("HILT")
    hand:sprite():set_texture(player:get_texture())
    hand:sprite():set_layer(-1)

    local player_anim = player:get_animation()
    local hand_anim = hand:get_animation()
    hand_anim:copy_from(player_anim)
    hand_anim:set_state("HAND")
    hand_anim:set_playback_speed(1000)

    local step = Battle.Step.new()
    step.update_func = function(self)
        if not player:input_has(Input.Held.Shoot) then
            self:complete_step()
        end
    end

    action:add_step(step)
    return action
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Local)

    local held_use_last_frame = false
    component.update_func = function()
        if held_use_last_frame and player:input_has(Input.Pressed.Shoot) then
            local action = create_dab_action(player)
            player:card_action_event(action, ActionOrder.Voluntary)
        end

        held_use_last_frame = player:input_has(Input.Held.Use)
    end

    player:register_component(component)
end
