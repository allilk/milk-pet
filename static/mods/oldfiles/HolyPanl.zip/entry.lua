nonce = function() end
 
local AUDIO1 = Engine.load_audio(_modpath.."PanelFinalChange.ogg")
local AUDIO2 = Engine.load_audio(_modpath.."PanalChange.wav")

function package_init(package)
    package:declare_package_id("rune.legacy.holypanl")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"A","B","S","*"})
 
    local props = package:get_card_props()
    props.shortname = "HolyPanl"
    props.damage = 0-0
    props.time_freeze = true
    props.element = Element.None
    props.secondary_element = Element.None
    props.description = "Creates a HolyPanl in front"
end


function card_create_action(player, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(player, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
     local f = player:get_field()
     local t = player:get_tile()
        local q = f:tile_at(t:x(), t:y())
        q:set_state(TileState.Holy)
        Engine.play_audio(AUDIO2, AudioPriority.Low)
	end
    Engine.play_audio(AUDIO1, AudioPriority.Low)
	return action
end