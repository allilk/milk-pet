local CHARACTER_ANIMATION = _folderpath .. "yoyo.anim"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "yoyo.greyscaled.png")
local YOYO_SFX = Engine.load_audio(_folderpath .. "yoyothrow.ogg")
local HIT_SFX = Engine.load_audio(_folderpath .. "yoyohit.ogg")
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"
local palette = Engine.load_texture(_folderpath .. "NM.png")
local debug = true
local fx_helper = include("fx.lua")
function debug_print(text)
    if debug then
        print("[yoyo] " .. text)
    end
end

function nonce() end


--variables that change for each version of the card
local details = {
    name = "DarkYoYo",
    codes = { "Y"},
    damage = 100,
    duration = 0.5,
    animation = "DEFAULT"
}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = details.name
    props.damage = details.damage
    props.time_freeze = false
    props.element = Element.None
	props.card_class = CardClass.Dark
    props.description = "3-SQ YO-YO"

    package:declare_package_id("com.loui.card." .. props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(details.codes)
end

function card_create_action(user, props)
    debug_print("in create_card_action()!")

    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    --special properties
    action.animation = details.animation

    action:set_lockout(make_async_lockout(details.duration))
    local ATTACK = { 1, details.duration }
    local POST_ATTACK = { 1, 0.017 }
    local FRAMES = make_frame_data({ ATTACK, POST_ATTACK })
    action:override_animation_frames(FRAMES)
    local yoyo = nil
    action.execute_func = function(self, user)
        local buster_attachment = self:add_attachment("BUSTER")
        local buster_sprite = buster_attachment:sprite()
        buster_sprite:set_texture(user:get_texture(), false)
        buster_sprite:set_layer(-2)
        local buster_animation = buster_attachment:get_animation()
        buster_animation:copy_from(user:get_animation())
        buster_animation:set_state("BUSTER")
        buster_animation:refresh(buster_sprite)

        self:add_anim_action(1, function()
            yoyo = spawn_yoyo(
                user,
                user:get_team(),
                user:get_field(),
                user:get_tile(user:get_facing(), 1),
                user:get_facing(), details.damage,
                CHARACTER_TEXTURE,
                YOYO_SFX,
                frames(7),
                3
            )
        end)
    end
    action.animation_end_func = function(self)

    end

    return action
end

function hit_func(self, entity)
    fx_helper.create_hit_effect(entity:get_field(), entity:get_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "8", HIT_SFX)
end

function spawn_hitbox(team, field, tile, hitbox_props)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(hitbox_props)
    spell.update_func = function()
        tile:attack_entities(spell)
        spell:erase()
    end
    spell.attack_func = hit_func
    field:spawn(spell, tile)
end

function spawn_yoyo(owner, team, field, tile, direction, damage, texture, sfx, speed, hits)
    local spawn_next
    spawn_next = function()
        local spell = Battle.Obstacle.new(team)
        spell:set_health(10)
        spell.max_move_count = 3
        spell.move_count = spell.max_move_count
        spell.waiting = false
        spell.returning = false
        spell.hits = 6
        local hit_frame = 3
        spell:set_facing(direction)
        spell:set_move_direction(direction)
        spell:highlight_tile(Highlight.None)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact | Hit.Flinch, Element.Sword, owner:get_context(), Drag.None))
        Engine.play_audio(sfx, AudioPriority.Highest)
        -- YOYO DEFENSE
        spell.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
        local defense_texture = Engine.load_texture(_folderpath .. "guard_hit.png")
        local defense_animation = _folderpath .. "guard_hit.animation"
        local defense_audio = Engine.load_audio(_folderpath .. "tink.ogg", true)
        spell.defense_rule.can_block_func = function(judge, attacker, defender)
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                --cant block breaking hits
                return
            end
            judge:block_impact()
            judge:block_damage()
            local artifact = Battle.Spell.new(spell:get_team())
            artifact:set_texture(defense_texture)
            local anim = artifact:get_animation()
            anim:load(defense_animation)
            anim:set_state("DEFAULT")
            anim:refresh(artifact:sprite())
            anim:on_complete(function()
                artifact:erase()
            end)
            spell:get_field():spawn(artifact, spell:get_tile())
            Engine.play_audio(defense_audio, AudioPriority.High)
        end
        spell:add_defense_rule(spell.defense_rule)

        --#end yoyo defense
        local sprite = spell:sprite()
        sprite:set_texture(texture)
        spell:set_palette(palette)
        local animation = spell:get_animation()
        animation:load(CHARACTER_ANIMATION)
        animation:set_state("DEFAULT")
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)

        spell.can_move_to_func = function(tile)
            return true
        end

        spell.attack_func = hit_func

        spell.delete_func = function(self)
            local fx = Battle.Explosion.new(1, 1.0)
            self:get_field():spawn(fx, self:get_current_tile())
            self:erase()
        end

        spell.update_func = function()
            if (spell:get_current_tile():get_team() == spell:get_team()) then
                spell:share_tile(true)
            else
                spell:share_tile(false)
            end
            if not spell.waiting then
                -- yoyo hits 3 times when on the target tile where it waits
                -- otherwise attack the tile it is on
                spell:get_current_tile():attack_entities(spell)
            end

            if not spell:is_sliding() then
                spell.move_count = spell.move_count - 1

                if spell.move_count == 0 then
                    if spell.returning then
                        spell:erase()
                    else
                        if not spell.waiting then
                            spell.waiting = true
                            animation:on_complete(
                                function()
                                    if (spell.hits == hit_frame) then
                                        spawn_hitbox(team, field, spell:get_current_tile(), spell:copy_hit_props())
                                    end
                                    spell.hits = spell.hits - 1
                                    if spell.hits == 0 then
                                        spawn_hitbox(team, field, spell:get_current_tile(), spell:copy_hit_props())
                                        spell.returning = true
                                        spell.waiting = false
                                        spell.move_count = spell.max_move_count
                                        spell:set_move_direction(spell:get_facing_away())
                                    end
                                end
                            )

                            return
                        end
                    end
                end

                if not spell.waiting then
                    spell:slide(
                        spell:get_tile(spell:get_move_direction(), 1),
                        speed,
                        frames(0),
                        ActionOrder.Immediate,
                        nonce
                    )
                end
            end
        end

        field:spawn(spell, tile)

        spell:slide(spell:get_tile(spell:get_move_direction(), 1), speed, frames(0), ActionOrder.Immediate, nonce)

        return spell
    end

    return spawn_next()
end
