local HIT_SFX = nil
local BUBBLE_SFX = nil
local WATER_SFX = nil
local APPEAR_SFX = nil


function package_init(package) 
    package:declare_package_id("com.alrysc.card.KogasaV3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'K','T'})

    local props = package:get_card_props()
    props.shortname = "KogasaV3"
    props.damage = 160
    props.time_freeze = true
    props.element = Element.Aqua
    props.description = "Raindrops make foe slip!"
    props.card_class = CardClass.Mega
    props.limit = 1
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local step_first = true

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function highlight_tiles(self, list, time)
        local spell = Battle.Spell.new(self:get_team())
    
    
        local ref = self
        spell.update_func = function(self)
            for i=1, #list
            do 
                local t = list[i]
                if t and not t:is_edge() then 
                    t:highlight(Highlight.Solid)
                end
    
            end
    
    
            time = time - 1
            if time == 0 then 
                self:delete()
            end
    
            if self.flinching then 
                if spell and not spell:is_deleted() then 
                    spell:delete()
        
                end
            end
        end
    
    
        self:get_field():spawn(spell, self:get_current_tile())
    end

    local function get_rain_tiles(self, drops)
        local field = self:get_field()
        local list = {}
        local iter = 1
        local max_tiles = drops
        local team = self:get_team()
        local closest_tile = nil
        local x = self:get_current_tile():x()
        local facing = self:get_facing()
    
        local function not_behind(tile)
            return facing == Direction.Left and x >= tile:x() or x <= tile:x()
        end
    
        
    
        local tile_filter = function(tile)
            return not tile:is_edge() and tile:get_team() ~= team and (not closest_tile or (closest_tile and closest_tile ~= tile)) and not_behind(tile)
    
        end
    
        local character_filter = function(character)
            return character:get_team() ~= team and tile_filter(character:get_current_tile())
        end
    
        local chars = field:find_nearest_characters(self, character_filter)
        if chars[1] then 
            closest_tile = chars[1]:get_current_tile()
            list[1] = closest_tile
            iter = 2
        end
    
        local p_tiles = field:find_tiles(tile_filter)
    
        -- If for some reason there are no tiles here, we'll probably infinite loop next
            -- So need to get out now
        if #p_tiles == 0 then 
            return list
        end
    
        while iter < max_tiles+1
        do    
            local r = math.random(#p_tiles)
            list[iter] = p_tiles[r]
            table.remove(p_tiles, r)
            if #p_tiles == 0 then 
                p_tiles = field:find_tiles(tile_filter)
            end
    
            iter = iter + 1
        end
    
        return list
    end

    local function attach_slip(other)
        local c = Battle.Player.from(other)
        if not c then 
            c = Battle.Character.from(other)
        end
    
        if not c then return end
        other = c
    
        local sliding_component = nil
        local dir
        local start_tile = other:get_current_tile()

        
        local list = other:get_field():find_entities(function(e) return e:get_name() == "SLIP_CONTROLLER"..other:get_id() end)        
        if list[1] then 
            list[1]:set_name("RESET")
            return
        end
    
        local artifact = Battle.Spell.new(other:get_team())
        artifact:set_name("SLIP_CONTROLLER"..other:get_id())
        artifact:set_health(1)
        -- artifact:toggle_hitbox(true)
        local time_remaining = 599
    
        local function find_dir(s, c)
            local dest
            local dir
            local x = s:x() - c:x()
    
            local y = s:y() - c:y()
    
            if y > 0 then 
                dir = Direction.Up
            elseif y < 0 then 
                dir = Direction.Down
    
            end
    
            if x > 0 then 
                dir = Direction.Left
            elseif x < 0 then 
                dir = Direction.Right
            end
    
            if not dir then return nil end
    
            dest = c:get_tile(dir, 1)
    
            return dir
        end
    
    
        local function create_slide(start_tile)
            local component = Battle.Component.new(other, Lifetimes.Battlestep)
    
            component.update_func = function()
                if not other:is_moving() then 
                   -- print("Going to slide")
                    local cur_tile = other:get_current_tile()
                    --print("Cur tile is ", start_tile:x(), start_tile:y())

                    dir = find_dir(start_tile, cur_tile)
    
                    local move = MoveEvent.new() 
                        move.delta_frames = frames(4)
                        move.delay_frames = frames(0)
                        move.endlag_frames = frames(0)
                        move.height = 0
                        move.dest_tile = cur_tile:get_tile(dir, 1)
                        move.on_begin_func = function() end
            
                    
            
                    -- local slide_succeded = other:slide(cur_tile:get_tile(dir, 1), frames(4), frames(0), ActionOrder.Immediate, nil)
                    local slide_succeded = other:raw_move_event(move, ActionOrder.Immediate)
                    if not slide_succeded then 
                       -- print("Couldn't slide right now")
                        sliding_component = nil
                        component:eject()
                    end
                end
            end
            
            sliding_component = component
            other:register_component(component)
    
            
        end
    
    
        local component = Battle.Component.new(other, Lifetimes.Battlestep)
        local colored = false
        local mode = other:sprite():get_color_mode()
        local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)
    
        component.update_func = function()
            if artifact:get_name() == "RESET" then
                time_remaining = 599
                artifact:set_name("SLIP_CONTROLLER"..other:get_id())
            end

    
           -- print(other:is_moving())
            if first_move and not sliding_component and start_tile ~= other:get_current_tile() then 
               -- start_tile = other:get_current_tile()
              --  print("Start tile is ", start_tile:x(), start_tile:y())
    
                create_slide(start_tile)
                first_move = false
            else
                first_move = true
                start_tile = other:get_current_tile()

            end


    
            if time_remaining == 0 or artifact:get_name() == "DELETE" then 
                artifact:delete()
                component:eject()
                other:sprite():set_color_mode(mode)
                other:remove_defense_rule(defense)
                return
            end
            time_remaining = time_remaining - 1
    
    
            if time_remaining % 3 == 1 then 
                other:sprite():set_color_mode(ColorMode.Multiply)
    
            end
            if time_remaining % 3 == 0 then 
                local color = Color.new(30, 170, 20, 255)
                other:set_color(color)
                other:sprite():set_color_mode(mode)
        
                colored = true
            end
    
    
        end
    
    
        defense.can_block_func = function(judge, attacker, defender)
        
    
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then
                if attacker_hit_props.element == Element.Elec then 
                    attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                    attacker:set_hit_props(attacker_hit_props)
    
                    local alert = graphic_init("artifact", 0, -32, "overlay_fx07_animations.png", "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                    local y = defender:get_height()+14
                    if y < 20 then 
                        y = 40
                    end
                    alert:set_elevation(y)
                    defender:get_field():spawn(alert, defender:get_current_tile())
                    if sliding_component then 
                        sliding_component:eject()
                        sliding_component = nil
                        defender:sprite():set_color_mode(mode)
    
    
                    end
    
                    artifact:set_name("DELETE")
    
    
                end
    
            end
    
    
        end
    
        other:add_defense_rule(defense)
    
        other:register_component(component)
        other:get_field():spawn(artifact, other:get_field():tile_at(1, 1))
    
    end

    local function throw_rain(self, dest)
        if not dest then return end
        local start = self:get_current_tile()
        local offset = -160
        local time = 42
    
        local d_y = offset/time
    
        local rain = graphic_init("spell", 0, offset, "kogasa.png", "kogasa.animation", -4, "RAIN", self, self:get_facing())
    
    
        local function rain_land()
            local splash = graphic_init("artifact", 0, offset, "kogasa.png", "kogasa.animation", -4, "SPLASH", self, self:get_facing(), true)
            local splash_box = Battle.Spell.new(self:get_team())
            
            local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Aqua, 
                self:get_id(), 
                Drag.None
            )
    
            splash_box:set_hit_props(hit_props)
    
            splash_box.update_func = function(self)
                Engine.play_audio(WATER_SFX, AudioPriority.Low)
                self:get_current_tile():attack_entities(self)
                self:delete()
    
            end
            
            local first = true
            splash.update_func = function(self)
                if first then 
                    self:get_field():spawn(splash_box, dest)
                    first = false
                end
                
    
            end
    
            splash_box.attack_func = function(self, other)
                Engine.play_audio(HIT_SFX, AudioPriority.Low)

                if other:get_element() == Element.Aqua then return end
                attach_slip(other)
            end
    
            self:get_field():spawn(splash, dest)
        end
    
        rain.update_func = function()
            --print(offset)
            rain:set_offset(0, offset)
            offset = offset - d_y
    
            if offset >= 0 then 
                rain:delete()
                rain_land()
            end
    
        end
    
        rain.can_move_to_func = function()
            return true
        end
    
        self:get_field():spawn(rain, start)
        Engine.play_audio(BUBBLE_SFX, AudioPriority.Low)
    
    
        rain:jump(dest, 150, frames(time), frames(0), ActionOrder.Immediate, function()
            --print("Started jump")
        end) 
    end
    

    local kogasa
    local target_tiles = {}



    local actor
    step.update_func = function()
        if step_first then 
            actor:hide()
            field:spawn(kogasa, user:get_current_tile())
            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)

            step_first = false
        end

    end

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")
        BUBBLE_SFX = Engine.load_audio(_modpath.."bubble.ogg")
        WATER_SFX = Engine.load_audio(_modpath.."water.ogg")
        APPEAR_SFX = Engine.load_audio(_modpath.."appear.ogg")
        
        kogasa = graphic_init("artifact", 0, 0, "kogasa.png", "kogasa.animation", -3, "DEFAULT", user, facing)
        kogasa:set_team(user:get_team())
        local list
        local drops = 3

        local anim = kogasa:get_animation()
        anim:on_complete(function()
            kogasa:delete()
            step:complete_step()
            user:reveal()
        end)
        

        anim:on_frame(9, function()
            list = get_rain_tiles(kogasa, drops)
            highlight_tiles(kogasa, list, 18)
        end)

        
        for i=1, drops
        do
            anim:on_frame(11+i, function()
                throw_rain(kogasa, list[i])
            
            end)
        end




    end

    return action
end