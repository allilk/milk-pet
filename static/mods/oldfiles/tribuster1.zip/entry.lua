nonce = function() end
--im surprised this even works 
local DAMAGE = 120
local SHOTS_COUNT = 3--prob pointless
local NEEDLE_TYPE = "1"--prob pointless
local TEXTURE_BUSTER = Engine.load_texture(_modpath.."buster.png")
local TEXTURE_NEEDLE = Engine.load_texture(_modpath.."needle.png")
local ANIMPATH_BUSTER = _modpath.."buster.animation"
local ANIMPATH_NEEDLE = _modpath.."needle.animation"
local TANKCAN_TEXTURE = Engine.load_texture(_modpath .. "tankcan.png")
local TANKCAN_ANIM = _modpath .. "tankcan.animation"
local BLAST_TEXTURE = Engine.load_texture(_modpath .. "blast.png")
local BLAST_ANIM = _modpath .. "blast.animation"
local BACKROW_BLAST = Engine.load_texture(_modpath .. "backrow_blast.png")
local BACKROW_BLAST_ANIM = _modpath .. "backrow_blast.animation"
local AUDIO = Engine.load_audio(_modpath .. "tankcan.ogg")
local SUCCESS_AUDIO = Engine.load_audio(_folderpath.."input.ogg", true)
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."spread_buster.png")
local BURST_TEXTURE = Engine.load_texture(_modpath.."spread_impact.png")
local AUDIO2 = Engine.load_audio(_modpath.."sfx.ogg")
local AUDIO_SHOOT = Engine.load_audio(_modpath.."shoot.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")


function package_init(package)
	package:declare_package_id("DJ.Multigun1")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ "B", "C", 'G' })

	local props = package:get_card_props()
	props.shortname = "MultiGun"
	props.damage = DAMAGE
	props.time_freeze = false
	props.element = Element.Break
	props.description = "Triple Changing Buster"
	props.long_description = "How do you want them Deleted?"
end

local frame1 = { 1, 0.646 }
local frame_data = make_frame_data({
	frame1
})

---@param actor Entity
---@param props any
---@return unknown



local recipes = {
	{
		name = "wide",
		pattern = {
			{ "up" },
			{ "up" },
			{ "up" }
		}
	},
	{
		name = "fighter",
		pattern = {
			{ "right" },
			{ "right" },
			{ "right" },
			{ "right" }

		}
	},
	{
		name = "sonic",
		pattern = {
			{ "left" },
			{ "left" },
			{ "left" },
			{ "left" }
		}
	},

}

local function deep_clone(t)
	if type(t) ~= "table" then
		return t
	end

	local o = {}
	for k, v in pairs(t) do
		o[k] = deep_clone(v)
	end
	return o
end

local function contains(t, value)
	for k, v in ipairs(t) do
		if v == value then
			return true
		end
	end
	return false
end

local function get_first_completed_recipe(matching)
	for _, recipe in ipairs(matching) do
		if recipe.current_step > #recipe.pattern then
			Engine.play_audio(SUCCESS_AUDIO, AudioPriority.High)
			return recipe.name
		end
	end

	return nil
end

function card_create_action(actor, props)
	local matching = deep_clone(recipes)

	for _, recipe in ipairs(matching) do
		recipe.current_step = 1
	end

	local action = Battle.CardAction.new(actor, "IDLE")
	action:set_lockout(make_sequence_lockout())

	local remaining_time = 50 -- 50 frame timer

	local step1 = Battle.Step.new()
	step1.update_func = function()
		remaining_time = remaining_time - 1

		if remaining_time < 0 or not actor:input_has(Input.Pressed.Use) and not actor:input_has(Input.Held.Use) or get_first_completed_recipe(matching) ~= nil then
			step1:complete_step()
			return
		end

		local drop_list = {}
		local inputs = {
			up = actor:input_has(Input.Pressed.Up),
			down = actor:input_has(Input.Pressed.Down),
			left = actor:input_has(Input.Pressed.Left),
			right = actor:input_has(Input.Pressed.Right),
			b = actor:input_has(Input.Pressed.Shoot)
		}

		local function inputs_fail(required_inputs)
			-- has an input that should not be held
			for name, held in pairs(inputs) do
				if held and not contains(required_inputs, name) then
					return true
				end
			end
			return false
		end

		local function inputs_match(required_inputs)
			for _, name in ipairs(required_inputs) do
				if not inputs[name] then
					return false
				end
			end
			print("input was matched")
			return true
		end

		for i, recipe in ipairs(matching) do
			local last_required_inputs = recipe.pattern[recipe.current_step - 1]
			local required_inputs = recipe.pattern[math.min(recipe.current_step, #recipe.pattern)]
			local fails_current_requirements = inputs_fail(required_inputs)

			if fails_current_requirements and (not last_required_inputs or inputs_fail(last_required_inputs)) then
				-- has an input that failed to match the current + previous requirements
				drop_list[#drop_list + 1] = i
			elseif not fails_current_requirements and recipe.current_step <= #recipe.pattern and inputs_match(required_inputs) then
				-- has all of the required inputs to continue
				recipe.current_step = recipe.current_step + 1
			end
		end

		for i, v in ipairs(drop_list) do
			table.remove(matching, v - i + 1)
		end
	end
	action:add_step(step1)


	local step2 = Battle.Step.new()
	step2.update_func = function()
		local attack_name = get_first_completed_recipe(matching)

		print(attack_name)

		if attack_name == "wide" then
			take_wide_action(actor, props)
		elseif attack_name == "sonic" then
			take_sonic_action(actor, props)
		elseif attack_name == "fighter" then
			take_fighter_action(actor, props)
		else
			take_default_action(actor, props)
		end
		step2:complete_step()
	end
	action:add_step(step2)

	return action
end
function take_default_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TANKCAN_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TANKCAN_ANIM)
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(8, function()
			offset = -12
			if (user:get_facing() == Direction.Left) then
				offset = 12
			end
			actor:set_offset(offset, 0)
		end)
		buster_anim:on_frame(9, function()
			local blast = create_attack(user, props)
			Engine.play_audio(AUDIO, AudioPriority.Highest)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if (tile ~= nil) then
				actor:get_field():spawn(blast, tile)
			else
				local back_row = 6
				if (user:get_facing() == Direction.Left) then
					back_row = 1
				end
				local back_row_center_tile = user:get_field():tile_at(back_row, user:get_tile():y())
				create_basic_effect(user:get_field(), back_row_center_tile, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")
				actor:shake_camera(10, 0.5)

				actor:get_field():spawn(blast, back_row_center_tile)
				local tile_up = back_row_center_tile:get_tile(Direction.Up, 1)
				local tile_down = back_row_center_tile:get_tile(Direction.Down, 1)
				back_row_center_tile:set_state(TileState.Cracked)
				if (not tile_up:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_up)
					tile_up:set_state(TileState.Cracked)
				end
				if (not tile_down:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_down)
					tile_down:set_state(TileState.Cracked)
				end
			end
		end)
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end

	actor:card_action_event(action, ActionOrder.Involuntary)

	return action
end


function take_long_action(actor, props) --useless doesnt need to be here but too lazy to remove lol doesnt seen to cause prob
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TANKCAN_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TANKCAN_ANIM)
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(8, function()
			offset = -12
			if (user:get_facing() == Direction.Left) then
				offset = 12
			end
			actor:set_offset(offset, 0)
		end)
		buster_anim:on_frame(9, function()
			local blast = create_attack(user, props)
			Engine.play_audio(AUDIO, AudioPriority.Highest)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if (tile ~= nil) then
				actor:get_field():spawn(blast, tile)
			else
				local back_row = 6
				if (user:get_facing() == Direction.Left) then
					back_row = 1
				end
				local back_row_center_tile = user:get_field():tile_at(back_row, user:get_tile():y())
				create_basic_effect(user:get_field(), back_row_center_tile, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")
				actor:shake_camera(10, 0.5)

				actor:get_field():spawn(blast, back_row_center_tile)
				local tile_up = back_row_center_tile:get_tile(Direction.Up, 1)
				local tile_down = back_row_center_tile:get_tile(Direction.Down, 1)
				back_row_center_tile:set_state(TileState.Cracked)
				if (not tile_up:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_up)
					tile_up:set_state(TileState.Cracked)
				end
				if (not tile_down:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_down)
					tile_down:set_state(TileState.Cracked)
				end
			end
		end)
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end

	actor:card_action_event(action, ActionOrder.Involuntary)

	return action
end

function take_wide_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")

	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."spread_buster.animation")
		buster_anim:set_state("DEFAULT")

		local cannonshot = create_wide_attack(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
		buster_anim:on_frame(9, function()
			local blast = create_sonic_attack(user, props)
			Engine.play_audio(AUDIO2, AudioPriority.Highest)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if (tile ~= nil) then
				actor:get_field():spawn(blast, tile)
			else
				local back_row = 6
				if (user:get_facing() == Direction.Left) then
					back_row = 1
				end
				local back_row_center_tile = user:get_field():tile_at(back_row, user:get_tile():y())
				create_basic_effect(user:get_field(), back_row_center_tile, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")
				actor:shake_camera(10, 0.5)

				actor:get_field():spawn(blast, back_row_center_tile)
				local tile_up = back_row_center_tile:get_tile(Direction.Up, 1)
				local tile_down = back_row_center_tile:get_tile(Direction.Down, 1)
				back_row_center_tile:set_state(TileState.Cracked)
				if (not tile_up:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_up)
					tile_up:set_state(TileState.Cracked)
				end
				if (not tile_down:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_down)
					tile_down:set_state(TileState.Cracked)
				end
			end
		end)
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end



	actor:card_action_event(action, ActionOrder.Involuntary)

    return action
end


function take_sonic_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TANKCAN_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TANKCAN_ANIM)
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(8, function()
			offset = -12
			if (user:get_facing() == Direction.Left) then
				offset = 12
			end
			actor:set_offset(offset, 0)
		end)
		buster_anim:on_frame(9, function()
			local blast = create_sonic_attack(user, props)
			Engine.play_audio(AUDIO, AudioPriority.Highest)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if (tile ~= nil) then
				actor:get_field():spawn(blast, tile)
			else
				local back_row = 6
				if (user:get_facing() == Direction.Left) then
					back_row = 1
				end
				local back_row_center_tile = user:get_field():tile_at(back_row, user:get_tile():y())
				create_basic_effect(user:get_field(), back_row_center_tile, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")
				actor:shake_camera(10, 0.5)

				actor:get_field():spawn(blast, back_row_center_tile)
				local tile_up = back_row_center_tile:get_tile(Direction.Up, 1)
				local tile_down = back_row_center_tile:get_tile(Direction.Down, 1)
				back_row_center_tile:set_state(TileState.Cracked)
				if (not tile_up:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_up)
					tile_up:set_state(TileState.Cracked)
				end
				if (not tile_down:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_down)
					tile_down:set_state(TileState.Cracked)
				end
			end
		end)
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end

	actor:card_action_event(action, ActionOrder.Involuntary)



	return action



end


function take_fighter_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
	action.hits = SHOTS_COUNT

    --YOU ARE SUPPOSED TO SHOOT 3 TIMES WHY ARENT YOU SHOOTING 3 TIMES


    local frame1 = {1, 0.033}
    local frame2 = {1, 0.305}
    action.frames = {frame1,frame1,frame1,frame2}

    action.before_exec = function(action)
        local frame3 = {1, 0.017}
        local frame4 = {1, 0.033}
        local frame5 = {1, 0.22}
        local frame6 = {1, 0.067}
        for i = 1, action.hits do
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame5)
        end
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame4)
        table.insert(action.frames,frame4)
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    

    action.execute_func = function(self, user)--has to stay as it is
		
        local field = user:get_field()
        local direction = user:get_facing()

        local attacking = false

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TEXTURE_BUSTER, true)
		buster:sprite():set_layer(-2)

		local buster_anim = buster:get_animation()
		local action = create_needle_attack(user, props, field, user:get_tile(direction, 1))--fix
		buster_anim:load(ANIMPATH_BUSTER)
		buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        self:add_anim_action(2, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(5, function()
            buster_anim:set_state("1")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Loop)
        end)

        

        self:add_anim_action(6, function()
            user:toggle_counter(false)
        end)

       

	end
    action.action_end_func = function ()
        user:toggle_counter(false)
    end



	user:card_action_event(action, ActionOrder.Involuntary)




local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
	action.hits = SHOTS_COUNT

    --YOU ARE SUPPOSED TO SHOOT 3 TIMES WHY ARENT YOU SHOOTING 3 TIMES


    local frame1 = {1, 0.033}
    local frame2 = {1, 0.305}
    action.frames = {frame1,frame1,frame1,frame2}

    action.before_exec = function(action)
        local frame3 = {1, 0.017}
        local frame4 = {1, 0.033}
        local frame5 = {1, 0.22}
        local frame6 = {1, 0.067}
        for i = 1, action.hits do
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame5)
        end
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame4)
        table.insert(action.frames,frame4)
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    

    action.execute_func = function(self, user)--has to stay as it is
		
        local field = user:get_field()
        local direction = user:get_facing()

        local attacking = false

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TEXTURE_BUSTER, true)
		buster:sprite():set_layer(-2)

		local buster_anim = buster:get_animation()
		local action = create_needle_attack(user, props, field, user:get_tile(direction, 1))--fix
		buster_anim:load(ANIMPATH_BUSTER)
		buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        self:add_anim_action(2, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(5, function()
            buster_anim:set_state("1")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Loop)
        end)

        

        

        self:add_anim_action(6, function()
            user:toggle_counter(false)
        end)

       

	end
    action.action_end_func = function ()
        user:toggle_counter(false)
    end



	user:card_action_event(action, ActionOrder.Involuntary)



local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	action:set_lockout(make_animation_lockout())
	action.hits = SHOTS_COUNT

    --YOU ARE SUPPOSED TO SHOOT 3 TIMES WHY ARENT YOU SHOOTING 3 TIMES


    local frame1 = {1, 0.033}
    local frame2 = {1, 0.305}
    action.frames = {frame1,frame1,frame1,frame2}

    action.before_exec = function(action)
        local frame3 = {1, 0.017}
        local frame4 = {1, 0.033}
        local frame5 = {1, 0.22}
        local frame6 = {1, 0.067}
        for i = 1, action.hits do
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame3)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame4)
            table.insert(action.frames,frame5)
        end
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame6)
        table.insert(action.frames,frame4)
        table.insert(action.frames,frame4)
        local FRAME_DATA = make_frame_data(action.frames)
        action:override_animation_frames(FRAME_DATA)
    end

    

    action.execute_func = function(self, user)--has to stay as it is
		
        local field = user:get_field()
        local direction = user:get_facing()

        local attacking = false

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TEXTURE_BUSTER, true)
		buster:sprite():set_layer(-2)

		local buster_anim = buster:get_animation()
		local action = create_needle_attack(user, props, field, user:get_tile(direction, 1))--fix
		buster_anim:load(ANIMPATH_BUSTER)
		buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        self:add_anim_action(2, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(5, function()
            buster_anim:set_state("1")
            buster_anim:refresh(buster:sprite())
            buster_anim:set_playback(Playback.Loop)
        end)

        

        self:add_anim_action(6, function()
            user:toggle_counter(false)
        end)

       

	end
    action.action_end_func = function ()
        user:toggle_counter(false)
    end



	user:card_action_event(action, ActionOrder.Involuntary)





    return action

end


--get first enemy in line of sight
function get_first_enemy(user, tile)

	if (tile:is_edge()) then
		return nil
	else
		if (#tile:find_entities(filter) >= 1) then
			return tile
		else
			return get_first_enemy(user, tile:get_tile(user:get_facing(), 1))
		end
	end

end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
	local fx = Battle.Artifact.new()
	fx:set_texture(hit_texture, true)
	local fx_sprite = fx:sprite()
	fx_sprite:set_layer(-3)
	local fx_anim = fx:get_animation()
	fx_anim:load(hit_anim_path)
	fx_anim:set_state(hit_anim_state)
	fx_anim:refresh(fx_sprite)
	fx_anim:on_complete(function()
		fx:erase()
	end)
	field:spawn(fx, tile)



	return fx
end

--filter function to only consider characters or obstacles
function filter(ent)
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Drag | Hit.Flash | Hit.Flinch,
			props.element,
			user:get_context(),
			Drag.new(direction, 6)
		)
	)
	spell.do_once = true
	spell.update_func = function(self, dt)
		if (spell.do_once) then
			spell:get_current_tile():attack_entities(self)
			local sprite = spell:sprite()
			sprite:set_texture(BLAST_TEXTURE)
			local animation = spell:get_animation()
			animation:load(BLAST_ANIM)
			animation:set_state("DEFAULT")
			animation:refresh(sprite)
			animation:on_complete(function()
				self:delete()
			end)
			spell.do_once = false
		end
	end
	spell.collision_func = function(self, other)
	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	spell.attack_func = function()

		hasHit = true
	end

	return spell

end


function create_sonic_attack(user, props)
		local spell = Battle.Spell.new(user:get_team())
		spell.slide_started = false
		local direction = user:get_facing()
		spell:set_hit_props(
			HitProps.new(
				props.damage,
				Hit.Impact | Hit.Drag| Hit.Blind,
				props.element,
				user:get_context(),
				Drag.new(direction, 6)
			)
		)
		spell.do_once = true
		spell.update_func = function(self, dt)
			if (spell.do_once) then
				spell:get_current_tile():attack_entities(self)
				local sprite = spell:sprite()
				sprite:set_texture(BLAST_TEXTURE)
				local animation = spell:get_animation()
				animation:load(BLAST_ANIM)
				animation:set_state("DEFAULT")
				animation:refresh(sprite)
				animation:on_complete(function()
					self:delete()
				end)
				spell.do_once = false
			end
		end
		spell.collision_func = function(self, other)
		end

		spell.delete_func = function(self)
			self:erase()
		end

		spell.can_move_to_func = function(tile)
			return true
		end
		spell.attack_func = function()

			hasHit = true
		end



		return spell
end


function create_wide_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary,
                function()
                    ref.slide_started = true
                end
            )
        end
    end
	spell.collision_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(BURST_TEXTURE, true)
		fx:get_animation():load(_modpath.."spread_impact.animation")
		fx:get_animation():set_state("DEFAULT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
		local tile = self:get_current_tile()
		if tile and not tile:is_edge() then
			spell:get_field():spawn(fx, tile)
		end
	end
    spell.attack_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(BURST_TEXTURE, true)
		fx:get_animation():load(_modpath.."spread_impact.animation")
		fx:get_animation():set_state("DEFAULT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
		local tile = self:get_current_tile():get_tile(direction, 1)
		if tile and not tile:is_edge() then
			spell:get_field():spawn(fx, tile)
			tile:attack_entities(self)
		end

		local fx2 = Battle.Artifact.new()
		fx2:set_texture(BURST_TEXTURE, true)
		fx2:get_animation():load(_modpath.."spread_impact.animation")
		fx2:get_animation():set_state("DEFAULT")
		fx2:get_animation():on_complete(function()
			fx2:erase()
		end)
		fx2:set_height(-16.0)

		local tile2 = self:get_current_tile():get_tile(direction, 1)
		if tile2 and not tile2:is_edge() then
			spell:get_field():spawn(fx2, tile2)
			tile2:attack_entities(self)
		end
		self:erase()
    end

    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO2, AudioPriority.High)
	return spell
end






function create_needle_attack(user, props, field, tile)
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(user:get_team())
        local direction = user:get_facing()
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_height(78.0)
        spell:set_hit_props(
            HitProps.new(
                props.damage,
                Hit.Impact,
                props.element,
                user:get_context(),
                Drag.None
            )
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_NEEDLE)
        sprite:set_layer(2)

        local anim = spell:get_animation()
        anim:load(ANIMPATH_NEEDLE)
        anim:set_state(NEEDLE_TYPE)
        anim:refresh(sprite)
        anim:on_complete(function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
            spell:erase()
        end, true)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end

        spell.collision_func = function(self, other)
            spell:erase()
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end