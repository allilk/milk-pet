local DAMAGE = 200

local BLASTMAN_TEXTURE = Engine.load_texture(_modpath.."blastman.png")
local BLASTMAN_ANIMPATH = _modpath.."blastman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_BLASTFIRE = Engine.load_audio(_modpath.."blastfire.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local SHOW_DEBUG_TEXT = false

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-260-BlastManSP")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"B"})

    local props = package:get_card_props()
    props.shortname = "BlastMnSP"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Head fwd & launch blst attk"
    props.long_description = "Hot wind attack forward in 3 vertical rows!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local tile = nil
        local offsetX = nil
        local offsetY2 = user:get_tile():y()
        local offsetY1 = offsetY2 - 1
        local offsetY3 = offsetY2 + 1
		if team == Team.Red then
			if direction == Direction.Right then
				offsetX = 0
			else
				offsetX = 7
			end
		else
			if direction == Direction.Left then
				offsetX = 7
			else
				offsetX = 0
			end
		end

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
                local navi_sprite = ref.navi:sprite()
                navi_sprite:set_texture(BLASTMAN_TEXTURE, true)
		    	navi_sprite:set_layer(-3)
                local navi_anim = ref.navi:get_animation()
                navi_anim:load(BLASTMAN_ANIMPATH)
                navi_anim:set_state("SPAWN")
		    	navi_anim:refresh(navi_sprite)
                navi_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	navi_anim:on_complete(function()
		    		navi_anim:set_state("ATTACK")
		    		navi_anim:refresh(navi_sprite)
		    	end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    anim:on_frame(5, function()
                        print("BlastMan: BlastFire!")
                        --Engine.play_audio(AUDIO_BLASTFIRE, AudioPriority.High)
                        if offsetY1 ~= 0 then
                            create_blastfire(user, props, team, direction, field, offsetX, offsetY1)
                        end
                            create_blastfire(user, props, team, direction, field, offsetX, offsetY2)
                        if offsetY3 ~= 4 then
                            create_blastfire(user, props, team, direction, field, offsetX, offsetY3)
                        end
                    end)
                    anim:on_complete(function()
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action    
end

function create_blastfire(owner, props, team, direction, field, x, y)
    local spell = Battle.Spell.new(team)
    spell:set_facing(direction)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(
        props.damage, 
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        props.element, 
        owner:get_id(), 
        Drag.new())
    )
    spell.slide_started = false

    local tile = field:tile_at(x, y)

    Engine.play_audio(AUDIO_BLASTFIRE, AudioPriority.High)

    local sprite = spell:sprite()
    sprite:set_texture(BLASTMAN_TEXTURE)
    sprite:set_layer(-4)

    local anim = spell:get_animation()
    anim:load(BLASTMAN_ANIMPATH)
    anim:set_state("BLASTFIRE")
    anim:set_playback(Playback.Loop)
    anim:refresh(sprite)

    local check = function(ent)
        if not owner:is_team(ent:get_team()) then
			return true
		end
    end

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then
                if direction == Direction.Right and self:get_current_tile():x() == 7 then
                    self:delete()
                elseif direction == Direction.Left and self:get_current_tile():x() == 0 then
                    self:delete()
                end
            end

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end

        if self:get_current_tile():get_state() == TileState.Grass and #self:get_current_tile():find_characters(check) <= 0 and #self:get_current_tile():find_obstacles(check) then
            self:get_current_tile():set_state(TileState.Normal)
        end
    end

    spell.collision_func = function(self, other)
		self:erase()
	end

    spell.attack_func = function(self)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-20,20), math.random(-20,20), field, self:get_current_tile())
    end

    spell.delete_func = function(self)
        if SHOW_DEBUG_TEXT then
            print("BLASTFIRE DELETED")
        end
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-9)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end