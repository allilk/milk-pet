local HIT_SFX = nil
local BOMB_SFX = nil
local LASER_SFX = nil
local LASER_EXPLOSION_SFX = nil
local WHIR_SFX = nil
local texture = nil
local shadow_texture = nil
local APPEAR_SFX = nil

function package_init(package) 
    package:declare_package_id("com.alrysc.card.VolcanoManV1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'V','M','*'})

    local props = package:get_card_props()
    props.shortname = "VlcnoMn"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Powerful flame lasr ahd!"
    props.card_class = CardClass.Mega
    props.limit = 3
end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())
    local rock_damage = 30
    local step = Battle.Step.new()
    local step_first = true

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(texture, false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local function spawn_flame(self, team, tile, from_bomb)
        local field = self:get_field()
        local flame = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -4, "FIRE", self, self:get_facing(), true)
        local tiles
        local spell = Battle.Spell.new(team)
        if from_bomb then 
            tiles = {
                tile:get_tile(Direction.Up, 1),
                tile:get_tile(Direction.Left, 1),
                tile:get_tile(Direction.Down, 1),
                tile:get_tile(Direction.Right, 1)
            }
        end
    
        local hit_props = HitProps.new(
            rock_damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire, 
            self:get_id(), 
            Drag.None
        )
    
        spell:set_hit_props(hit_props)
    
        local lifetime = 12
    
        
        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            lifetime = lifetime - 1
            if lifetime == 0 then 
                self:delete()
            end
        end

        spell.attack_func = function()
            Engine.play_audio(HIT_SFX, AudioPriority.Low)

        end
    
       
    
        if from_bomb then
            flame:get_animation():on_frame(3, function()
                for i=1, #tiles
                do
                    local t = tiles[i]
                    if t and not t:is_edge() then 
                        spawn_flame(self, team, t, false)
                    end
                end
            end)
            
        
        end
    
        field:spawn(flame, tile)
        field:spawn(spell, tile)
        Engine.play_audio(BOMB_SFX, AudioPriority.Low)
    end
   
    
    local function laser_attack(self)
        local list = {}
        local field = self:get_field()
        local facing = self:get_facing()
        local tile = self:get_tile(facing, 1)
    
        table.insert(list, tile)
    
        local check_tile = tile
        for i=2, field:width()
        do
            check_tile = check_tile:get_tile(facing, 1)
            if check_tile and not check_tile:is_edge() then 
                table.insert(list, check_tile)
            else
                break
            end
        end
        
        local function spawn_spell(tile, lifetime)
            local spell = Battle.Spell.new(self:get_team())
            spell.lifetime = lifetime
            local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                Element.Fire, 
                self:get_id(), 
                Drag.None
            )
    
            spell:set_hit_props(hit_props)
    
            spell.update_func = function(self)
                self:get_current_tile():attack_entities(self)
                self.lifetime = self.lifetime - 1
                if self.lifetime == 0 then 
                    self:delete()
                end
            end
            spell.attack_func = function()
                Engine.play_audio(HIT_SFX, AudioPriority.Low)
            end

    
            field:spawn(spell, tile)
        end
    
    
        local function back_laser_attack(tile, lifetime)
            local artifact = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -4, "EXPLOSION", self, self:get_facing(), true)
            local tile1 = tile:get_tile(Direction.Up, 1)
            local tile2 = tile:get_tile(Direction.Down, 1)
    
    
            field:spawn(artifact, tile)
            spawn_spell(tile1, 20)
            spawn_spell(tile2, 20)
    
            Engine.play_audio(LASER_EXPLOSION_SFX, AudioPriority.Low)
    
        end
    
    
        for i=1, #list 
        do
            spawn_spell(list[i], 45)
        end
    
        back_laser_attack(list[#list], 20)
    
        local shake_artifact = Battle.Artifact.new()
        local time = 0
        shake_artifact.update_func = function(self)
                
            self:shake_camera(200, 0.016)
            if time == 61 then 
                self:delete()
            end
        
            time = time+1
        end
    
        field:spawn(shake_artifact, tile)
    
    end
    
    local function rock_fall(self)
        local field = self:get_field()
        local team = self:get_team()
    
        local list = field:find_tiles(function(t)
            return not t:is_edge() and t:get_team() ~= team
        
        end)
    
        if #list == 0 then return end
    
    
        local function spawn_rock(tile)
            local spell = graphic_init("spell", 0, 0, texture, "VolcanoMan.animation", -4, "FALLING_ROCK", self, self:get_facing())
           -- spell:get_animation():set_playback(Playback.Loop)
            local shadow = graphic_init("spell", 0, 0, shadow_texture, "VolcanoMan.animation", 5, "SHADOW", self, self:get_facing())
    
            local y = 300
            spell:set_elevation(y)
            local max_time = 35
            local time = 0
            local d_y = y/max_time
    
            local ref = self
            spell.update_func = function(self)
                self:set_elevation(y - time*d_y)
                time = time+1
    
                if time > max_time then               
                    spawn_flame(ref, self:get_team(), self:get_current_tile(), false)
                    self:delete()
                    shadow:delete()
    
                end
    
                if time < max_time - 25 then 
                    self:get_current_tile():highlight(Highlight.Flash)
                end
            end
    
            field:spawn(spell, tile)
            field:spawn(shadow, tile)
    
        end
    
        local max_rocks = 5
        
        for i=1, max_rocks
        do
            if #list == 0 then break end
            local r = math.random(1, #list)
            spawn_rock(list[r])
            table.remove(list, r)
        end
    
    end
    
    

    local volcanoman

    local actor
    step.update_func = function()
        if step_first then 
            actor:hide()
            field:spawn(volcanoman, user:get_current_tile())
            Engine.play_audio(APPEAR_SFX, AudioPriority.Low)

            step_first = false
        end

    end

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)
        local facing = user:get_facing()

        HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")
        APPEAR_SFX = Engine.load_audio(_modpath.."appear.ogg")
        BOMB_SFX = Engine.load_audio(_folderpath.."explosion.ogg")
        LASER_SFX = Engine.load_audio(_folderpath.."bombbig.ogg")
        LASER_EXPLOSION_SFX = Engine.load_audio(_folderpath.."bombmiddle.ogg")
        WHIR_SFX = Engine.load_audio(_folderpath.."machineRunning.ogg")
        texture = Engine.load_texture(_modpath.."VolcanoMan.png")
        shadow_texture = Engine.load_texture(_modpath.."shadow.png")
        
        volcanoman = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -3, "DEFAULT", user, facing)
        volcanoman:set_team(user:get_team())

        local anim = volcanoman:get_animation()
        anim:on_complete(function()
            volcanoman:delete()
            step:complete_step()
            user:reveal()
        end)
        
        anim:on_frame(6, function()
            Engine.play_audio(WHIR_SFX, AudioPriority.Low)
        end)

        anim:on_frame(29, function()
            local laser_graphic = graphic_init("artifact", 0, 0, texture, "VolcanoMan.animation", -3, "LASER_GRAPHIC", volcanoman, volcanoman:get_facing(), true)

            volcanoman:get_field():spawn(laser_graphic, volcanoman:get_current_tile())
        end)

        anim:on_frame(28, function()
            Engine.play_audio(LASER_SFX, AudioPriority.Low)
        end)

        anim:on_frame(30, function()
            laser_attack(volcanoman)
        end)
        
        anim:on_frame(38, function()
            rock_fall(volcanoman)
        end)




    end

    return action
end