function package_init(package)
    package:declare_package_id("Noir.exe")
    package:set_special_description("Color mod of the NormalNavi by Chris.")
    package:set_speed(1)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."BlueNavi_ow.animation")
    package:set_overworld_texture_path(_modpath.."BlueNavi_ow.png")
    package:set_icon_texture(Engine.load_texture(_modpath.."BlueNavi_face.png"))
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Noir")
    player:set_health(1500)
    player:set_element(Element.None)
    player:set_height(48.0)

    local base_texture = Engine.load_texture(_modpath.."BlueNavi.png")
    local base_animation_path = _modpath.."BlueNavi.animation"
    local base_charge_color = Color.new(0, 0, 0, 0)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(4, -16)
	
    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function(player)
        return Battle.Buster.new(player, true, player:get_attack_level() * 10)
    end
	
	local heatShot = include("Chips/com_Dawn_card_FireBurn3/entry.lua")
	local heatForm = player:create_form()
	heatForm:set_mugshot_texture_path(_modpath.."Heat_entry.png")
    local heat_charge_color = Color.new(255, 127, 0, 0)
	
	heatForm.on_activate_func = function(self,player)
		player:set_element(Element.Fire)
		player:set_texture(Engine.load_texture(_modpath.."forms/Heat/BlueNavi.png"))
		player:set_fully_charged_color(heat_charge_color)
	end
	
	heatForm.on_deactivate_func = function(self,player)
		player:set_element(Element.None)
		player:set_texture(base_texture, true)
		player:set_fully_charged_color(base_charge_color)
	end
	
	heatForm.charged_attack_func = function(player)
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 10
		props.element = Element.Fire
		return heatShot.card_create_action(player, props)
    end
	
    local antifreeze = Battle.DefenseRule.new(913, DefenseOrder.CollisionOnly)
	antifreeze.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Freeze
		return statuses
	end	
	
	local iceWave = include("Chips/IceWave_PVP/entry.lua")
	local iceForm = player:create_form()
	iceForm:set_mugshot_texture_path(_modpath.."Ice_entry.png")
    local ice_charge_color = Color.new(0, 255, 255, 0)
	
	iceForm.on_activate_func = function(self,player)
		player:set_element(Element.Aqua)
		player:set_texture(Engine.load_texture(_modpath.."forms/Ice/BlueNavi.png"))
		player:set_fully_charged_color(ice_charge_color)
		player:add_defense_rule(antifreeze)
	end
	
	iceForm.on_deactivate_func = function(self,player)
		player:set_element(Element.None)
		player:set_texture(base_texture, true)
		player:set_fully_charged_color(base_charge_color)
		player:remove_defense_rule(antifreeze)
	end
	
	iceForm.charged_attack_func = function(player)
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 10
		props.element = Element.Aqua
		return iceWave.card_create_action(player, props)
    end
	
	local dolthdr3 = include("Chips/Dolthdr3_rune_legacy_PVP/entry.lua")
	local elecForm = player:create_form()
	elecForm:set_mugshot_texture_path(_modpath.."Elec_entry.png")
    local elec_charge_color = Color.new(255, 255, 0, 0)
	
    local antistun = Battle.DefenseRule.new(913, DefenseOrder.CollisionOnly)
	antistun.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Stun
		return statuses
	end	
	
	elecForm.on_activate_func = function(self,player)
		player:add_defense_rule(antistun)
		player:set_element(Element.Elec)
		player:set_texture(Engine.load_texture(_modpath.."forms/Elec/BlueNavi.png"))
		player:set_fully_charged_color(elec_charge_color)
	end
	
	elecForm.on_deactivate_func = function(self,player)
		player:remove_defense_rule(antistun)
		player:set_element(Element.None)
		player:set_texture(base_texture, true)
		player:set_fully_charged_color(base_charge_color)
	end
	
	elecForm.charged_attack_func = function(player)
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 10
		props.element = Element.Elec
		return dolthdr3.card_create_action(player, props)
    end
	
	local woodTower = include("Chips/com_alrysc_card_WoodTower/entry.lua")
	local woodForm = player:create_form()
	woodForm:set_mugshot_texture_path(_modpath.."Wood_entry.png")
    local wood_charge_color = Color.new(0, 255, 0, 0)
	
	woodForm.on_activate_func = function(self,player)
		player:set_element(Element.Wood)
		player:set_texture(Engine.load_texture(_modpath.."forms/Wood/BlueNavi.png"))
		player:set_fully_charged_color(wood_charge_color)
	end
	
	woodForm.on_deactivate_func = function(self,player)
		player:set_element(Element.None)
		player:set_texture(base_texture, true)
		player:set_fully_charged_color(base_charge_color)
	end
	
	woodForm.charged_attack_func = function(player)
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 10
		props.element = Element.Wood
		return woodTower.card_create_action(player, props)
    end
	
	local windRack = include("Chips/com_louise_AirToss/entry.lua")
	local windForm = player:create_form()
	windForm:set_mugshot_texture_path(_modpath.."Wind_entry.png")
    local wind_charge_color = Color.new(191, 191, 191, 0)
	
	windForm.on_activate_func = function(self,player)
		player:set_air_shoe(true)
		player:set_element(Element.Wind)
		player:set_texture(Engine.load_texture(_modpath.."forms/Wind/BlueNavi.png"))
		player:set_fully_charged_color(wind_charge_color)
	end
	
	windForm.on_deactivate_func = function(self,player)
		player:set_air_shoe(false)
		player:set_element(Element.None)
		player:set_texture(base_texture)
		player:set_fully_charged_color(base_charge_color)
	end
	
	windForm.charged_attack_func = function(player)
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 10
		props.element = Element.Wind
		return windRack.card_create_action(player, props)
    end
end
