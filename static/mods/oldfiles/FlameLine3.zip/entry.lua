nonce = function() end 

BUSTER_TEXTURE = nil
ATK_TEXTURE = nil
AUDIO = nil

local frame1 = {1, 0.2}
local frame2 = {2, 0.1}
local frame3 = {3, 0.1}
local frame4 = {4, 0.1}
local frame5 = {5, 0.1}
local frame6 = {6, 0.1}
local frame7 = {7, 0.1}
local frame8 = {8, 0.1}
local FRAMES = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8})

function package_init(package) -- Basic stuff
    package:declare_package_id("hoov.card.flameline3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"J","K","L"})

    local props = package:get_card_props()
    props.shortname = "FlmLine3"
    props.damage = 170
    props.time_freeze = false
    props.element = Element.Fire
    props.secondary_element = Element.None
    props.description = "Firebeam 2sq ahead 3sq long!"
    props.limit = 4

    -- assign the global resources
    BUSTER_TEXTURE = Engine.load_texture(_modpath.."buster.png")
    ATK_TEXTURE = Engine.load_texture(_modpath.."attack.png")
    AUDIO = Engine.load_audio(_modpath.."firetower.ogg")
end

function card_create_action(actor, props) --Card Action & Attack Creation
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:override_animation_frames(FRAMES)
    action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."buster.animation")
		buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster:sprite())

        local tile = user:get_tile(user:get_facing(), 2)
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)
        local field = user:get_field()

        if not tile:is_edge()  and tile:get_state() ~= TileState.Broken and tile:get_state() ~= TileState.Empty then
            local spell = create_attack(user, props)
			field:spawn(spell, tile)
        end

        if not tile2:is_edge() and tile2:get_state() ~= TileState.Broken and tile2:get_state() ~= TileState.Empty then
            local spell = create_attack(user, props)
			field:spawn(spell, tile2)
        end

        if not tile3:is_edge() and tile3:get_state() ~= TileState.Broken and tile3:get_state() ~= TileState.Empty then
            local spell = create_attack(user, props)
			field:spawn(spell, tile3)
        end
        action.action_end_func = function(self)
            self:get_actor():reveal()
        end
    
    end
    return action
end


function create_attack(user, props) --Attack Properties
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_texture(ATK_TEXTURE, true)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
            )
        )
    local anim = spell:get_animation()
    anim:load(_modpath.."attack.animation")
    anim:set_state("ATTACK")
    anim:refresh(spell:sprite())
    anim:on_complete(function()
        spell:erase()
    end)
    spell:sprite():set_layer(-1)
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end
    spell.collision_func = function(self, other)
    end
    spell.can_move_to_func = function(self, other)
        return true
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    Engine.play_audio(AUDIO, AudioPriority.Low)
    return spell
end