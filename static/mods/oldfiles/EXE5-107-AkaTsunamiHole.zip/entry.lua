local DAMAGE = 190

local TSUNAMI_TEXTURE = Engine.load_texture(_modpath.."tsunami.png")
local TSUNAMI_ANIMPATH = _modpath.."tsunami.animation"
local TSUNAMI_AUDIO1 = Engine.load_audio(_modpath.."tsunami1.ogg")
local TSUNAMI_AUDIO2 = Engine.load_audio(_modpath.."tsunami2.ogg")
local TSUNAMI_AUDIO3 = Engine.load_audio(_modpath.."tsunami3.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE5-107-AkaTsunamiHole")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A","F","H","*"})

    local props = package:get_card_props()
    props.shortname = "RedTsnmH"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "RedTsunam out of MagmaPanl"
    props.long_description = "Red Tsunami generated from magma panel"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.017},{1,0.017}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()
        self:add_anim_action(1,function()
            target_finder(user, props, team, direction, field, self_X, self_Y)
        end)
    end
    return action
end

function target_finder(owner, props, team, direction, field, owner_X, owner_Y)
    local finder1 = Battle.Spell.new(team)
    finder1:set_facing(direction)
    local anim1 = finder1:get_animation()
    anim1:load(_modpath.."attack.animation")
    anim1:set_state("0")

    local targeted = false
    local targeted_1 = false
    local targeted_2 = false
    local targeted_3 = false

    local tile1 = field:tile_at(owner_X, 1)
    local tile2 = field:tile_at(owner_X, 2)
    local tile3 = field:tile_at(owner_X, 3)
    local tile1_front = nil
    local tile2_front = nil
    local tile3_front = nil
	local check1_front = false
	local check2_front = false
	local check3_front = false
    local tile_array1 = {}
    local tile_array2 = {}
    local tile_array3 = {}

    local team_check = function(ent)
        if not owner:is_team(ent:get_team()) then
            return true
        end
    end

    for i = 1, 5, 1 do
        if i <= 5 then
             
            tile1_front = tile1:get_tile(direction, i)
             
            check1_front = tile1_front and tile1_front ~= nil and not tile1_front:is_edge() and tile1_front:get_state() == TileState.Lava
             
            if check1_front then
                print("Y1 TARGETED")
                targeted = true
                targeted_1 = true
                table.insert(tile_array1, tile1_front)
                break
            end
        end
    end
    for i = 1, 5, 1 do
        if i <= 5 then
             
            tile2_front = tile2:get_tile(direction, i)
             
            check2_front = tile2_front and tile2_front ~= nil and not tile2_front:is_edge() and tile2_front:get_state() == TileState.Lava
             
            if check2_front then
                print("Y2 TARGETED")
                targeted = true
                targeted_2 = true
                table.insert(tile_array2, tile2_front)
                break
            end
        end
    end
    for i = 1, 5, 1 do
        if i <= 5 then
             
            tile3_front = tile3:get_tile(direction, i)
             
            check3_front = tile3_front and tile3_front ~= nil and not tile3_front:is_edge() and tile3_front:get_state() == TileState.Lava
             
            if check3_front then
                print("Y3 TARGETED")
                targeted = true
                targeted_3 = true
                table.insert(tile_array3, tile3_front)
                break
            end
        end
    end

    anim1:on_frame(2, function()
        if targeted_1 then
            if tile_array1[1]:get_state() == TileState.Lava then
                tile_array1[1]:set_state(TileState.Normal)
                create_tsunami_1(field:tile_at(tile_array1[1]:x(),1), team, owner, props, direction, field, TSUNAMI_AUDIO1, true)
            end
        end
        if targeted_2 then
            if tile_array2[1]:get_state() == TileState.Lava then
                tile_array2[1]:set_state(TileState.Normal)
                create_tsunami_1(field:tile_at(tile_array2[1]:x(),2), team, owner, props, direction, field, TSUNAMI_AUDIO1, true)
            end
        end
        if targeted_3 then
            if tile_array3[1]:get_state() == TileState.Lava then
                tile_array3[1]:set_state(TileState.Normal)
                create_tsunami_1(field:tile_at(tile_array3[1]:x(),3), team, owner, props, direction, field, TSUNAMI_AUDIO1, true)
            end
        end
    end)
    anim1:on_complete(function()
        finder1:erase()
    end)

    finder1.update_func = function(self, dt)
    end
    finder1.battle_end_func = function(self)
		self:erase()
	end
    finder1.delete_func = function(self)
		self:erase()
    end
    finder1.can_move_to_func = function(tile)
		return true
	end

    field:spawn(finder1, owner_X, 2)

    return finder1
end

function create_tsunami_1(tile, team, owner, props, direction, field, audio, msg)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_2(tile, team, owner, props, direction, field, TSUNAMI_AUDIO2)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other) 
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        if msg then
            print("Tsunami spawned at tile ("..tile:x()..";"..tile:y()..")")
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_tsunami_2(tile, team, owner, props, direction, field, audio)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_3(tile, team, owner, props, direction, field, TSUNAMI_AUDIO3)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other) 
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_tsunami_3(tile, team, owner, props, direction, field, audio)
    local spawn_next
    spawn_next = function()
        if tile:is_hole() or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                owner:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(TSUNAMI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(TSUNAMI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_frame(7, function()
            tile = tile:get_tile(direction, 1)
            create_tsunami_1(tile, team, owner, props, direction, field, TSUNAMI_AUDIO1, false)
        end, true)
        anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, other)  
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-7,7), math.random(-7,7), field, spell:get_current_tile())
        end
    
	    spell.collision_func = function(self, other)
            spell:erase()
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        Engine.play_audio(audio, AudioPriority.High)

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end