function package_init(block)
    block:declare_package_id("com.alrysc.block.dollfriend")
    block:set_name("DollFrnd")
    block:set_description("Bring friend to battle!")
    block:set_color(Blocks.Yellow)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local function create_doll(user)
        local offset = -20
        local doll = graphic_init("artifact", offset, 0, "doll.png", "doll.animation", -1, "DEFAULT", user, user:get_facing())
        local component = Battle.Component.new(user, Lifetimes.Scene)
        component.update_func = function()
            if not user:is_deleted() then 
                if doll:get_current_tile() ~= user:get_current_tile() then 
                    local old_t = doll:get_current_tile()
                    local t = user:get_current_tile()
                    old_t:remove_entity_by_id(doll:get_id())
                    t:add_entity(doll)
                end
            else
                doll:delete()
            end
        end

        user:register_component(component)

        doll.can_move_to_func = function()
            return true
        end

        doll:set_float_shoe(true)

        user:get_field():spawn(doll, user:get_current_tile())
    end

    create_doll(player)

end