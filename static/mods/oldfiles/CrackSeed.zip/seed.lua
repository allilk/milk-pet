local debug = false

local seed = {
    -- default values, can be overwritten by the entry file that calls this card action
    panel_type = 1,
    skip_tiles = {},
    card_props = {
        damage = 10,
        can_boost = false,
        element = Element.None,
    },
    attachment_texture = nil,
}

function seed.set_seed_palette(parameter)
    local arg = parameter
    if not arg then
        arg = 0
        seed.panel_type = arg
        print([[ERROR: The panel_type_to_create variable wasn't assigned properly! 
        It needs to be an integer value that points to a real position in the table. 
        Edit entry.lua to fix this.]])
    end
    if type(arg) == "table" then
        arg = "table"
    else
        if arg < 3 then
            arg = 1
        elseif arg == 7 or (arg > 8 and arg ~= 13) then
            arg = 2
        end
        arg = tostring(arg)
    end
    seed.attachment_texture = Engine.load_texture(_modpath .. "seed_pal/" .. arg ..".png")
end

local attachment_anim_path = _modpath .. "attachment.animation"
local panel_change_texture = Engine.load_texture(_modpath .. "panel_change.png")
local panel_change_sfx = Engine.load_audio(_modpath .. "panel_change.ogg")
local panel_change_anim_path = _modpath .. "panel_change.animation"
local throw_sfx = Engine.load_audio(_modpath .. "toss_item.ogg")


function seed.card_create_action(actor, props)

    local action = Battle.CardAction.new(actor, "PLAYER_THROW")
    action:set_lockout(make_animation_lockout())
    local f_t = 0.016 -- this is the length of one frame in seconds
    local override_frames = {
        {1, 5*f_t}, {2, 4*f_t}, {3, 3*f_t}, {4, 5*f_t}, {5, 4*f_t}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        props.element, 
        actor:get_context(), 
        Drag.None
    )

    action.execute_func = function(self, user)

        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(seed.attachment_texture)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(attachment_anim_path)
        attachment_animation:set_state("DEFAULT")

        self:add_anim_action(3, function()
            attachment_sprite:hide()
            -- self.remove_attachment(attachment)
            local tiles_ahead = 3
            local frames_in_air = 40
            local toss_height = 70
            local facing = user:get_facing()
            local target_tile = user:get_tile(facing, tiles_ahead)
            if not target_tile then return end
            action.on_landing = function()
                if target_tile:is_walkable() then
                    -- play panel change sound once
                    Engine.play_audio(panel_change_sfx, AudioPriority.Highest)
                    hit_explosion(user, target_tile, hit_props, panel_change_texture, panel_change_anim_path)
                end
            end
            toss_spell(user, toss_height, seed.attachment_texture, attachment_anim_path, target_tile, frames_in_air, action.on_landing)
        end)

        Engine.play_audio(throw_sfx, AudioPriority.Highest)
    end
    return action
end

function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("DEFAULT")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height() + 40)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset, spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air),
                      frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset +
                                math.abs(self.starting_y_offset / frames_in_air)
            self.x_offset = self.x_offset -
                                math.abs(self.starting_x_offset / frames_in_air)
            self:set_offset(self.x_offset, self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile) return true end
    field:spawn(spell, start_tile)
end

function panel_sprite(user, tile, texture, anim_path)
    local dummy = Battle.Spell.new(user:get_team())
    local field = user:get_field()
    local dummy_animation = dummy:get_animation()
    dummy_animation:load(anim_path)
    dummy_animation:set_state("DEFAULT")
    local sprite = dummy:sprite()
    sprite:set_texture(texture)
    dummy_animation:refresh(sprite)
    dummy_animation:on_complete(function() dummy:erase() end)
    field:spawn(dummy, tile)
end


function hit_explosion(user, target_tile, props, texture, anim_path)
    local field = user:get_field()
    local spell = Battle.Spell.new(user:get_team())

    spell:set_hit_props(props)
    spell.waited = nil
    spell.collided = nil
    spell.spread = nil

    field:spawn(spell, target_tile)

    local x_target = {
        [1] = Direction.None,
        [2] = Direction.Left,
        [3] = Direction.Right,
    }
    local y_target = {
        [1] = Direction.None,
        [2] = Direction.Up,
        [3] = Direction.Down,
    }

    spell.collision_func = function(self)
        spell.collided = true
    end

    local random_choice = { 0,1,2,4,5,6,8,9,10,11,12,13,14}
    spell.update_func = function(self)
        if spell.waited then
            if not spell.spread then
                spell.spread = true
                local routine = 1   -- set every tile to a single provided TileState
                if type(seed.panel_type) == "table" then
                    routine = 3     -- use a table to support a unique TileState for each tile
                elseif seed.panel_type > 15 then
                    routine = 2     -- choose a random TileState for each tile 
                end
                local function should_skip(table, val)
                    for _, kk in pairs(table) do
                        if kk == val then return true end
                    end
                    return false
                end
                local ii = 0
                for xx = 1, #x_target do
                    for yy = 1, #y_target do
                        ii = ii + 1
                        local target = Direction.join(x_target[xx], y_target[yy])
                        local tile = target_tile:get_tile(target, 1)
                        if not should_skip(seed.skip_tiles, ii) then
                            if not(tile:is_edge() or tile:get_state() == TileState.Empty) then
                                if routine == 1 then
                                    tile:set_state(seed.panel_type)
                                elseif routine == 2 then
                                    tile:set_state(random_choice[math.random(1,12)])
                                elseif routine == 3 then
                                    tile:set_state(seed.panel_type[ii])
                                end
                                panel_sprite(user, tile, texture, anim_path)
                                if spell.collided then return end
                            end
                        end
                    end
                    if spell.collided then return end
                end
            else
                spell:delete()
            end
        else
            spell:get_current_tile():attack_entities(self)
            spell.waited = true
        end
    end
end

return seed
