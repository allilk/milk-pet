local TEXTURE = Engine.load_texture(_modpath .. "boomer.png")
local ANIMATION_PATH = _modpath .. "boomer.animation"
local START_AUDIO = Engine.load_audio(_modpath .. "boomer.ogg")

function package_init(package)
    package:declare_package_id("DJ.Finang2")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "L", "S", "U" })
    local props = package:get_card_props()
    props.shortname = "Fin Ang2"
    props.damage = 90
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Fin ang encircles field"
    props.long_description = "Fin boomerang flinged at enemy!"
    props.limit = 3
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:set_lockout(make_async_lockout(0.67))
    -- action:override_animation_frames(FRAMES)

    action.execute_func = function()
        local buster = action:add_attachment("Buster")
        buster:sprite():set_texture(actor:get_texture(), true)
        buster:sprite():set_layer(-1)
        buster:sprite():enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(actor:get_animation())
        buster_anim:set_state("BUSTER")
        create_spell(actor, props, false)
    end

    return action

end

function create_spell(actor, props, is_duplicate)
    local field = actor:get_field()
    --Reduce redundant team calls
    local team = actor:get_team()
    local spell = Battle.Spell.new(team)

    spell:set_texture(TEXTURE, true)
    spell:set_offset(0, -15)
    local anim = spell:get_animation()
    anim:load(ANIMATION_PATH)
    anim:set_state("DEFAULT")
    anim:set_playback(Playback.Loop)
    anim:refresh(spell:sprite())

    Engine.play_audio(START_AUDIO, AudioPriority.High)

    spell.can_move_to_func = function(tile)
        return true
    end

    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch,
            props.element,
            actor:get_context(),
            Drag.None
        )
    )
    --Spawns at 1,3 if team red, below the user
    --Otherwise below the user on team blue.
    --If it's a copy spell, spawn above the user.
    local start_tile = nil
    if team == Team.Red then
        if is_duplicate then
            field:spawn(spell, 1, 1)
            start_tile = field:tile_at(1, 1)
        else
            start_tile = field:tile_at(1, 3)
            field:spawn(spell, 1, 3)
        end
    else
        if is_duplicate then
            field:spawn(spell, 6, 1)
            start_tile = field:tile_at(6, 1)
        else
            start_tile = field:tile_at(6, 3)
            field:spawn(spell, 6, 3)
        end
    end

    spell.original_y = nil
    if is_duplicate then
        spell.original_y = 1
    else
        spell.original_y = 3
    end

    spell.delay = 24
    spell.direction = actor:get_facing()
    spell.next_tile = start_tile:get_tile(spell.direction, 1)
    spell.userfacing = spell.direction
    spell.update_func = function(self, dt)
        local tile = self:get_tile()
        if not spell:is_sliding() then
            if (spell.next_tile:is_edge()) then
                ---need to change direction.
                if (spell.direction == Direction.Left or spell.direction == Direction.Right) then
                    local end_of_field = (spell.userfacing == Direction.Left and spell.next_tile:x() == 7) or
                        (spell.userfacing == Direction.Right and spell.next_tile:x() == 0)
                    if (end_of_field) then
                        spell:erase()
                    end
                    --next direction is up or down
                    spell.direction = get_free_direction(spell:get_current_tile(), Direction.Up, Direction.Down)
                else if (spell.direction == Direction.Up or spell.direction == Direction.Down) then
                        --next direction is left or right
                        spell.direction = get_free_direction(spell:get_current_tile(), Direction.Left, Direction.Right)
                    end
                end
            end
        end
        spell:slide(spell.next_tile, frames(4), frames(0), ActionOrder.Voluntary, nil)
        spell.next_tile = tile:get_tile(spell.direction, 1)
        tile:attack_entities(self)
        if not is_duplicate then
            self.delay = self.delay - 1
            if self.delay == 0 then
                create_spell(actor, props, true)
            end
        end
    end
end

function get_free_direction(tile, direction1, direction2)
    local check_tile = tile:get_tile(direction1, 1)
    if (check_tile and not check_tile:is_edge()) then
        return direction1
    else
        return direction2
    end
end

