local function find_best_target(self)
    local target = nil
    local field = self:get_field()
    local query = function(c)
        return c:get_team() ~= self:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 99999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp and possible_target:get_health() > 0 then
                target = possible_target
            end
        end
    end
    return target
end

function package_init(package) 
    package:declare_package_id("com.claris.jojoreference.TokiwoTomare")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'D','I','O'})

    local props = package:get_card_props()
    props.shortname = "Za World"
    props.damage = 30
    props.time_freeze = true
    props.element = Element.None
    props.description = "ZA WORLD! TOKI WO TOMARE!"
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
		Engine.play_audio(Engine.load_audio(_folderpath.."ZAWARUDO.ogg", true), AudioPriority.Low)
        local road_tile = user:get_tile(user:get_facing(), 3)
		local dir = user:get_facing()
		local field = user:get_field()
		local tile_array = {}
		local start = 1
		local increment = 1
		local goal = 6
		for x = start, goal, increment do
			table.insert(tile_array, {})
			for y = 1, 3, 1 do
				local tile = field:tile_at(x, y)
				if tile and user:is_team(tile:get_team()) and not tile:is_edge() then
					table.insert(tile_array[x], tile)
				end
			end
		end
		local ref = self
		self.do_once = true
		local step1 = Battle.Step.new()
		local cooldown = 40*#tile_array
		self.index = 1
		step1.update_func = function(self, dt)
			if ref.do_once then
				ref.do_once = false
				if ref.index < #tile_array then
					for j = 1, #tile_array[ref.index], 1 do
						local spawn_tile = tile_array[ref.index][j]
						local knife = spawn_knife(user, props)
						field:spawn(knife, spawn_tile)
					end
				end
			end
			cooldown = cooldown - 1
			if cooldown <= 0 then
				self:complete_step()
			elseif cooldown % 40 == 0 then
				ref.do_once = true
				ref.index = ref.index + 1
			elseif ref.index > #tile_array or #tile_array[ref.index] == 0 then
				ref.index = ref.index + 1
				cooldown = cooldown - 40
			end
		end
		local step2 = Battle.Step.new()
		ref.do_twice = true
		self.can_complete_2 = false
		step2.update_func = function(self, dt)
			if ref.do_twice then
				ref.do_twice = false
				local road_roller = create_road_roller(user, props, ref)
				local target = find_best_target(user)
				if target ~= nil then road_tile = target:get_tile() end
				if road_tile and not road_tile:is_edge() then
					field:spawn(road_roller, road_tile)
				else
					ref.can_complete_2 = true
				end
			end
			if ref.can_complete_2 then
				self:complete_step()
			end
		end
		self:add_step(step1)
		self:add_step(step2)
	end
    return action
end

function create_road_roller(user, props, step)
	local spell = Battle.Spell.new(user:get_team())
	local hit_props = HitProps.new(
		props.damage * 5, 
		Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
		props.element,
		user:get_context(),
		Drag.None
	)
	spell:set_shadow(Shadow.Small)
	spell:show_shadow(true)
	spell:set_hit_props(hit_props)
	spell:set_texture(Engine.load_texture(_folderpath.."Roadroller.png"), true)
	local direction = user:get_facing()
	spell:set_facing(direction)
	spell:sprite():set_layer(-2)
	spell.cooldown = 16
    local x = 224
    spell.increment_x = 14
    spell.increment_y = 14
	local y = 224
	if user:get_facing() == Direction.Right then x = x * - 1 end
    spell:set_offset(spell:get_offset().x+x, spell:get_offset().y-y)
	local anim = spell:get_animation()
	anim:load(_folderpath.."Roadroller.animation")
	anim:set_state("DEFAULT")
	anim:refresh(spell:sprite())
	spell.attack_once = true
	spell.shake_cooldown = 100000
	spell.update_func = function(self, dt)
		local offset = self:get_offset()
		if offset.y >= 0 then
			if self.attack_once then
				self.attack_once = false
				local tile = self:get_tile()
				if tile and tile:is_walkable() then
					Engine.play_audio(AudioType.Explode, AudioPriority.High)
					tile:attack_entities(self)
					self:shake_camera(10, 0.5)
					self.shake_cooldown = 30
				else
					self.shake_cooldown = 10
				end
			else
				if self.shake_cooldown <= 0 then
					step.can_complete_2 = true
					self:erase()
				else
					self.shake_cooldown = self.shake_cooldown - 1
				end
			end
        else
			if self:get_facing() == Direction.Right then
				self:set_offset(offset.x+self.increment_x, offset.y+self.increment_y)
			else
            	self:set_offset(offset.x-self.increment_x, offset.y+self.increment_y)
			end
            self.cooldown = self.cooldown - 1
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	return spell
end

function spawn_knife(user, props)
	local target = user:get_field():find_nearest_characters(user, function(s)
		return s:get_team() ~= user:get_team() and not s:is_deleted() and s:get_health() > 0
	end)
	if #target > 0 then target = target[1] else target = nil end
	local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg", true)
	local spell = Battle.Spell.new(user:get_team())
	local direction = user:get_facing()
	spell:set_facing(direction)
	spell:sprite():set_layer(-2)
	spell:set_texture(Engine.load_texture(_folderpath.."knife.png"), true)
	local anim = spell:get_animation()
	anim:load(_folderpath.."knife.animation")
    anim:set_state("SPIN")
	anim:refresh(spell:sprite())
	spell:get_animation():on_complete(function()
		anim:set_state("POINT")
		anim:refresh(spell:sprite())
	end)
	spell:set_offset(0.0, -24.0)
    spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
	spell.frame = 0
	spell.delete_on_slide = false
	spell.dest = nil
	spell.update_func = function(self, dt) 
		local tile = self:get_tile()
		if anim:get_state() == "POINT" or anim:get_state() == "SPIN" and self.frame % 2 == 0 then
			self.frame = self.frame + 1
        	tile:attack_entities(self)
		end
		
		if anim:get_state() == "POINT" and not self:is_sliding() then
			if tile == self.dest and self.delete_on_slide then self:erase() end
			if tile:is_edge() and self.slide_started then self:delete() end
			self.dest = self:get_tile(direction, 1)
			if user:input_has(Input.Held.Shoot) and target and not target:is_deleted() then self.dest = target:get_tile(); self.delete_on_slide = true end
			local ref = self
			self:slide(self.dest, frames(4), frames(0), ActionOrder.Voluntary, function()
				if not ref.slide_started then Engine.play_audio(AUDIO, AudioPriority.High) end
				ref.slide_started = true
			end)
		end
    end
	
	spell.collision_func = function(self, other)
		if spell:get_animation():get_state() == "POINT" then self:erase() end
	end
	spell.can_move_to_func = function(self, other)
		return true
	end
	return spell
end