
local HIT 
local BLOCK
local SHOOT
local APPEAR

function package_init(package) 
    package:declare_package_id("com.alrysc.card.MarisaV1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'M','K','*'})

    local props = package:get_card_props()
    props.shortname = "Marisa"
    props.damage = 100
    props.time_freeze = true
    props.element = Element.Elec
    props.description = "Narrow Spark ahead!"
    props.limit = 4
    props.card_class = CardClass.Mega

end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local field = user:get_field()
    action:set_lockout(make_sequence_lockout())

    local actor
    local step = Battle.Step.new()
    local step_first = true
    

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local ending = false

    local spell_list = {}

    local function extra_laser(user, tile, facing, elevation, hit_props)
        if not tile or tile:is_edge() then 
            return 
        end
        local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER", user, facing)
        spell:highlight_tile(Highlight.Solid)
        spell:set_elevation(elevation)
        spell:set_hit_props(hit_props)


        local anim = spell:get_animation()
        anim:on_frame(2, function()
            extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)

        end)
        local fade = false
        spell.update_func = function(self)
            if not fade then 
                if ending == true then 
                    anim:set_state("LASER_END")
                    anim:refresh(self:sprite())

                    fade = true
                end

            end

            self:get_tile():attack_entities(self)

        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        spell_list[#spell_list+1] = spell
        field:spawn(spell, tile)
    end

    local function shoot_laser(user, starting_tile, facing, elevation)
        local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER_START", user, facing, true)
        spell:highlight_tile(Highlight.Solid)
        spell:set_elevation(elevation)

        local hit_props = HitProps.new(props.damage,
                                   Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake,
                                   props.element, user:get_context(), Drag.None)

        local anim = spell:get_animation()
        spell:set_hit_props(hit_props)

        anim:on_frame(7, function()
            extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)
        end)

        anim:on_frame(8, function()
            ending = true
        
        end)

        anim:on_frame(13, function()
            spell:highlight_tile(Highlight.None)

        end)

        anim:on_frame(14, function()
            spell:highlight_tile(Highlight.None)
            stop = true
            spell:delete()

            for i=1, #spell_list
            do
                local spell = spell_list[i]
                if spell and not spell:is_deleted() then 
                    spell:delete()
                end
            end
        end)


        local stop = false

        spell.update_func = function(self)
            if not stop then 
                self:get_tile():attack_entities(self)
            end

        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        field:spawn(spell, starting_tile)
    end


    local marisa
    local count = 0
    step.update_func = function()
        if count == 9 then 
            actor:hide()
            field:spawn(marisa, user:get_current_tile())
            Engine.play_audio(APPEAR, AudioPriority.Low)

            step_first = false
        end

        count = count + 1
    end

    action.execute_func = function()
        actor = action:get_actor()
        action:add_step(step)

        HIT = Engine.load_audio(_modpath .. "hit.ogg")
        BLOCK = Engine.load_audio(_modpath .. "tink.ogg")
        SHOOT = Engine.load_audio(_modpath .. "beam.ogg")
        APPEAR = Engine.load_audio(_modpath .. "appear.ogg")

        
        local facing = user:get_facing()
        marisa = graphic_init("artifact", 0, 0, "marisa.png", "marisa.animation", -3, "DEFAULT", user, facing)

        
        local anim = marisa:get_animation()
        anim:on_complete(function()
            marisa:delete()
            step:complete_step()
            actor:reveal()
        end)
        anim:on_frame(12, function()
            shoot_laser(user, user:get_current_tile():get_tile(user:get_facing(), 1), user:get_facing(), 20)
            Engine.play_audio(SHOOT, AudioPriority.Low)
        end)
    end

    return action
end