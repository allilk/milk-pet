function package_init(block)
    block:declare_package_id("com.example.block.Halo")
    block:set_name("Halo")
    block:set_description("Sainthood")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 1, 1, 1, 0,
        0, 1, 0, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local f = player:get_field()
    local t = player:get_tile()
    
    local q = f:tile_at(t:x(), t:y())
    q:set_state(TileState.Holy)
end