function package_init(block)
    block:declare_package_id("com.Dawn.BowserArmor.ToughGuy")
    block:set_name("ToughGuy")
    block:as_program()
    block:set_description("IT'S BOWSER TIME!")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        1, 0, 1, 0, 1,
        1, 1, 1, 1, 1,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    local super_armor = Battle.DefenseRule.new(313, DefenseOrder.CollisionOnly)
	super_armor.filter_statuses_func = function(statuses)
		if player:get_health() >= math.floor(player:get_max_health() * 0.25) then
			statuses.flags = statuses.flags & ~Hit.Freeze
			statuses.flags = statuses.flags & ~Hit.Flash
			statuses.flags = statuses.flags & ~Hit.Flinch
			statuses.flags = statuses.flags & ~Hit.Stun
		end	
		return statuses
	end
	player:add_defense_rule(super_armor)
end