local DAMAGE = 120

local BOMBERMAN_TEXTURE = Engine.load_texture(_folderpath.."bomberman.png")
local BOMBERMAN_ANIMPATH = _folderpath.."bomberman.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe1-spawn.ogg")
local AUDIO_BAKUDANSHOOT = Engine.load_audio(_folderpath.."bakudanshoot.ogg")

local bomberman = {
    codes = {"B"},
    shortname = "BombrMan",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.Fire,
    description = "Cros area explosion 3pnl ahed",
    long_description = "Bomb 3 squares in front! Burst of explosion in the enemy area!",
    can_boost = true,
    card_class = CardClass.Mega,
    limit = 1
}

bomberman.card_create_action = function(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local actor = self:get_actor()
		actor:hide()

        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local bomb_tile = user:get_tile(facing, 3)

		local step1 = Battle.Step.new()

        self.bomberman = nil
        self.tile      = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        local do_once_part_three = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false

                ref.bomberman = Battle.Artifact.new()
                ref.bomberman:set_facing(facing)
                local bomber_sprite = ref.bomberman:sprite()
		    	bomber_sprite:set_texture(BOMBERMAN_TEXTURE, true)
		    	bomber_sprite:set_layer(-3)
                local bomber_anim = ref.bomberman:get_animation()
                bomber_anim:load(BOMBERMAN_ANIMPATH)
                bomber_anim:set_state("SPAWN")
		    	bomber_anim:refresh(bomber_sprite)
                bomber_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	bomber_anim:on_complete(function()
                    bomber_anim:set_state("ATTACK")
		    	    bomber_anim:refresh(bomber_sprite)
		    	end)
                field:spawn(ref.bomberman, ref.tile)
            end
            local anim = ref.bomberman:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false

                    anim:on_frame(1, function()
                        print("BomberMan: Bakudan Shoot!")
                        Engine.play_audio(AUDIO_BAKUDANSHOOT, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                        if bomb_tile:get_state() == TileState.Broken or bomb_tile:is_hole() then
                            anim:set_state("END")
                        else
                            anim:set_state("BOMB")
                        end
		    	        anim:refresh(ref.bomberman:sprite())
                    end)
                end
            end
            if anim:get_state() == "BOMB" then
                if do_once_part_three then
                    do_once_part_three = false

                    local bakudanshoot = create_attack_1(user, props, bomb_tile, team, 1)

                    anim:on_frame(34, function()
                        field:spawn(bakudanshoot, bomb_tile)
                    end)
                    anim:on_complete(function()
                        anim:set_state("END")
                        anim:refresh(ref.bomberman:sprite())
                    end)
                end
            end
            if anim:get_state() == "END" then
                anim:on_complete(function()
                    ref.bomberman:erase()
                    step1:complete_step()
                end)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_attack_1(actor, props, tile, team, soundnumber)
    local spell = Battle.Spell.new(team)
    local field = actor:get_field()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            actor:get_id(), 
            Drag.None
        )
    )
    local boom_sprite = spell:sprite()
    boom_sprite:set_texture(BOOM_TEXTURE)
    boom_sprite:set_layer(-4)

    local boom_anim = spell:get_animation()
    boom_anim:load(BOOM_ANIMPATH)
    boom_anim:set_state("0")
    boom_anim:refresh(boom_sprite)
    boom_anim:on_frame(1, function()
        Engine.play_audio(Engine.load_audio(_folderpath.."boom"..soundnumber..".ogg"), AudioPriority.High)
    end, true)
    boom_anim:on_frame(4, function()
        if tile:get_team() ~= team then
            local tile_up = tile:get_tile(Direction.Up, 1)
            local tile_down = tile:get_tile(Direction.Down, 1)
            local tile_left = tile:get_tile(Direction.Left, 1)
            local tile_right = tile:get_tile(Direction.Right, 1)
            soundnumber = soundnumber + 1
            create_attack_up(actor, props, tile_up, team, soundnumber)
            create_attack_down(actor, props, tile_down, team, soundnumber)
            create_attack_left(actor, props, tile_left, team, soundnumber)
            create_attack_right(actor, props, tile_right, team, soundnumber)
        end
    end, true)
    boom_anim:on_complete(function() spell:erase() end)
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            if Battle.Player.from(actor) ~= nil then
                Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
            end
        else
            Engine.play_audio(Engine.load_audio(_folderpath.."hitsound_obs"..soundnumber..".ogg"), AudioPriority.High)
        end
    end
    
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.can_move_to_func = function(tile)
        return true
    end
    
    return spell
end

function create_attack_up(actor, props, tile, team, soundnumber)
    local spawn_next
    spawn_next = function()
        if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() or tile:get_team() == team then return end

        local spell = Battle.Spell.new(team)
        local field = actor:get_field()
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                actor:get_id(), 
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(BOOM_TEXTURE)
        boom_sprite:set_layer(-4)

        local boom_anim = spell:get_animation()
        boom_anim:load(BOOM_ANIMPATH)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_frame(1, function()
            Engine.play_audio(Engine.load_audio(_folderpath.."boom"..soundnumber..".ogg"), AudioPriority.High)
        end, true)
        boom_anim:on_frame(4, function()
            tile = tile:get_tile(Direction.Up, 1)
            soundnumber = soundnumber + 1
            spawn_next()
        end, true)
        boom_anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(actor) ~= nil then
                    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
                end
            else
                Engine.play_audio(Engine.load_audio(_folderpath.."hitsound_obs"..soundnumber..".ogg"), AudioPriority.High)
            end
        end
    
	    spell.collision_func = function(self, other)
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_attack_down(actor, props, tile, team, soundnumber)
    local spawn_next
    spawn_next = function()
        if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() or tile:get_team() == team then return end

        local spell = Battle.Spell.new(team)
        local field = actor:get_field()
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                actor:get_id(), 
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(BOOM_TEXTURE)
        boom_sprite:set_layer(-4)

        local boom_anim = spell:get_animation()
        boom_anim:load(BOOM_ANIMPATH)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_frame(1, function()
            Engine.play_audio(Engine.load_audio(_folderpath.."boom"..soundnumber..".ogg"), AudioPriority.High)
        end, true)
        boom_anim:on_frame(4, function()
            tile = tile:get_tile(Direction.Down, 1)
            soundnumber = soundnumber + 1
            spawn_next()
        end, true)
        boom_anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(actor) ~= nil then
                    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
                end
            else
                Engine.play_audio(Engine.load_audio(_folderpath.."hitsound_obs"..soundnumber..".ogg"), AudioPriority.High)
            end
        end
    
	    spell.collision_func = function(self, other)
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_attack_left(actor, props, tile, team, soundnumber)
    local spawn_next
    spawn_next = function()
        if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() or tile:get_team() == team then return end

        local spell = Battle.Spell.new(team)
        local field = actor:get_field()
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                actor:get_id(), 
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(BOOM_TEXTURE)
        boom_sprite:set_layer(-4)

        local boom_anim = spell:get_animation()
        boom_anim:load(BOOM_ANIMPATH)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_frame(1, function()
            Engine.play_audio(Engine.load_audio(_folderpath.."boom"..soundnumber..".ogg"), AudioPriority.High)
        end, true)
        boom_anim:on_frame(4, function()
            tile = tile:get_tile(Direction.Left, 1)
            soundnumber = soundnumber + 1
            spawn_next()
        end, true)
        boom_anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(actor) ~= nil then
                    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
                end
            else
                Engine.play_audio(Engine.load_audio(_folderpath.."hitsound_obs"..soundnumber..".ogg"), AudioPriority.High)
            end
        end
    
	    spell.collision_func = function(self, other)
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

function create_attack_right(actor, props, tile, team, soundnumber)
    local spawn_next
    spawn_next = function()
        if tile:get_state() == TileState.Broken or tile:is_hole() or tile:is_edge() or tile:get_team() == team then return end

        local spell = Battle.Spell.new(team)
        local field = actor:get_field()
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flash | Hit.Flinch, 
                props.element, 
                actor:get_id(), 
                Drag.None
            )
        )
        local boom_sprite = spell:sprite()
        boom_sprite:set_texture(BOOM_TEXTURE)
        boom_sprite:set_layer(-4)

        local boom_anim = spell:get_animation()
        boom_anim:load(BOOM_ANIMPATH)
        boom_anim:set_state("0")
        boom_anim:refresh(boom_sprite)
        boom_anim:on_frame(1, function()
            Engine.play_audio(Engine.load_audio(_folderpath.."boom"..soundnumber..".ogg"), AudioPriority.High)
        end, true)
        boom_anim:on_frame(4, function()
            tile = tile:get_tile(Direction.Right, 1)
            soundnumber = soundnumber + 1
            spawn_next()
        end, true)
        boom_anim:on_complete(function() spell:erase() end)
    
        spell.update_func = function(self, dt)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                if Battle.Player.from(actor) ~= nil then
                    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
                end
            else
                Engine.play_audio(Engine.load_audio(_folderpath.."hitsound_obs"..soundnumber..".ogg"), AudioPriority.High)
            end
        end
    
	    spell.collision_func = function(self, other)
	    end
    
        spell.delete_func = function(self)
            spell:erase()
        end

        spell.battle_end_func = function(self)
	    	spell:erase()
	    end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end
    
    spawn_next()
end

return bomberman