nonce = function() end

local TEXTURE = Engine.load_texture(_modpath.."poof.png")
local AUDIO = Engine.load_audio(_modpath.."break.ogg")
local ATTACK_FINISHED = true

function package_init(package) 
    package:declare_package_id("com.claris.card.PanelCrush")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'P'})

    local props = package:get_card_props()
    props.shortname = "PanlCrsh"
    props.damage = 50
    props.time_freeze = false
    props.element = Element.None
    props.description = "Break and throw the field!"
	props.card_class = CardClass.Giga
	props.limit = 1
	props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	local field = actor:get_field()
	local tile_array = {}
	local cooldown = 0
	for i = 0, 6, 1 do
		for j = 0, 6, 1 do
			local tile = field:tile_at(i, j)
			if tile and actor:is_team(tile:get_team()) and not tile:is_edge() and tile:get_state() ~= TileState.Broken then
				table.insert(tile_array, tile)
			end
		end
	end
	action:set_lockout(make_async_lockout((12*#tile_array)/60))
	action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		action.update_func = function(self, dt)
			for k = 0, #tile_array, 1 do
				if cooldown <= 0 then
					if #tile_array > 0 then
						local index = math.random(1, #tile_array)
						local tile2 = tile_array[index]
						if tile2:get_state() ~= TileState.Broken then
							local query = function(ent)
								if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
									return true
								end
							end
							if #tile2:find_entities(query) > 0 and tile2:get_state() ~= TileState.Cracked then
								tile2:set_state(TileState.Cracked)
								Engine.play_audio(AUDIO, AudioPriority.Low)
							elseif #tile2:find_entities(query) == 0 and tile2:get_state() ~= TileState.Broken then
								local attack = create_attack(user, props, tile2)
								user:get_field():spawn(attack, tile2)
								tile2:set_state(TileState.Broken)
								Engine.play_audio(AUDIO, AudioPriority.Low)
							end
							table.remove(tile_array, index)
						else
							table.remove(tile_array, index)
							k = k - 1
						end
						cooldown = 0.75						
					end
				else
					cooldown = cooldown - dt
				end
			end
		end
	end
	return action
end

function create_attack(user, props, tile)
	local spell = Battle.Spell.new(user:get_team())
	spell.can_move_to_func = function(self, tile)
		if tile then
			return true
		end
		return false
	end
	local direction = user:get_facing()
	spell:set_facing(direction)
	local target = user:get_field():find_nearest_characters(user, function(found)
		if not user:is_team(found:get_team()) and found:get_health() > 0 and not found:is_deleted() then
			return true
		end
	end)
	if tile then
		local dust_fx = Battle.Artifact.new()
		dust_fx:set_texture(Engine.load_texture(_modpath.."dust.png"), true)
		dust_fx:set_facing(user:get_facing())
		local dust_anim = dust_fx:get_animation()
		dust_anim:load(_modpath.."dust.animation")
		dust_anim:set_state("DEFAULT")
		dust_anim:refresh(dust_fx:sprite())
		dust_anim:on_complete(function()
			dust_fx:erase()
		end)
		user:get_field():spawn(dust_fx, tile)
		if tile:is_reserved({}) and tile:is_walkable() then
			tile:set_state(TileState.Cracked)
			spell:erase()
		elseif not tile:is_reserved({}) and tile:is_walkable() then
			tile:set_state(TileState.Broken)
			spell:set_texture(Engine.load_texture(_modpath.."spell_panel_shot.png"), true)
			spell.slide_started = false
			spell:set_hit_props(
				HitProps.new(
					props.damage, 
					Hit.Impact,
					props.element,
					user:get_context(),
					Drag.None
				)
			)
			spell:get_animation():load(_modpath.."spell_panel_shot.animation")
			if tile:get_team() == Team.Blue then
				spell:get_animation():set_state("BLUE_TEAM")
			else
				spell:get_animation():set_state("RED_TEAM")
			end
			spell:set_offset(0, 24)
			spell:get_animation():refresh(spell:sprite())
			spell:get_animation():on_complete(function()
				spell:get_animation():set_playback(Playback.Loop)
			end)
			local do_once = true
			spell.update_func = function(self, dt) 
				self:get_current_tile():attack_entities(self)
				if self:get_offset().y <= 0 then
					if self:is_sliding() == false then 
						if self:get_current_tile():is_edge() and self.slide_started then
							ATTACK_FINISHED = true
							self:delete()
						end
						
						local dest = spell:get_tile(direction, 1)
						if target[1] ~= nil and not target[1]:is_deleted() and do_once then
							dest = target[1]:get_tile()
							do_once = false
						end
						if self:get_tile() == dest then
							self:erase()
						end
						local ref = self
						self:slide(dest, frames(12), frames(0), ActionOrder.Voluntary, function()
							ref.slide_started = true
						end)
					end
				else
					self:set_offset(self:get_offset().x, self:get_offset().y - 4)
				end
			end
			spell.collision_func = function(self, other)
				self:delete()
			end
		end
	end
	spell.collision_func = function(self, other)
		ATTACK_FINISHED = true
		self:delete()
	end
	spell.attack_func = function(self, other)
	end
	spell.delete_func = function(self)
		self:erase()
    end
	spell.can_move_to_func = function(self, tile)
        return true
    end
	return spell
end