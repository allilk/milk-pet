nonce = function() end

local TEXTURE = Engine.load_texture(_modpath.."Lightning Cross.png")

function package_init(package) 
    package:declare_package_id("com.claris.card.Lightning1")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'L','*'})

    local props = package:get_card_props()
    props.shortname = "Lightning"
    props.damage = 160
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Dmgs object & area"
	props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_HIT")
	local frame1 = {2, 0.75}
	local long_frame = make_frame_data({frame1})
	action:override_animation_frames(long_frame)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		print("Executing action 1")
		local field = user:get_field()
		local targets = field:find_obstacles(function(found)
			if found ~= nil and user:get_team() ~= found:get_team() then
				return true
			end
		end)
		local tile = nil
		local spell = nil
		for i = 1, #targets, 1 do
			tile = targets[i]:get_tile()
			spell = create_bolt(user, props)
			field:spawn(spell, tile)
		end
	end
	return action
end

function create_bolt(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(TEXTURE, true)
	anim:load(_modpath.."Lightning Cross.animation")
	anim:set_state("DEFAULT")
	anim:refresh(spell:sprite())
	anim:on_complete(function()
		spell:erase()
	end)
	local do_once = true
	spell.update_func = function(self, dt)
		self:get_tile(Direction.Up, 1):highlight(Highlight.Solid)
		self:get_tile(Direction.Left, 1):highlight(Highlight.Solid)
		self:get_tile(Direction.Right, 1):highlight(Highlight.Solid)
		self:get_tile(Direction.Down, 1):highlight(Highlight.Solid)
		if do_once then
			self:get_tile(Direction.Up, 1):attack_entities(self)
			self:get_tile(Direction.Left, 1):attack_entities(self)
			self:get_tile(Direction.Right, 1):attack_entities(self)
			self:get_tile(Direction.Down, 1):attack_entities(self)
			self:get_tile():attack_entities(self)
			do_once = false
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	-- Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end