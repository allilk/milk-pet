local DAMAGE = 70

local VOICE_STRIKEBURNER_1 = Engine.load_audio(_modpath.."sutoraikubaanaa1.ogg")
local VOICE_STRIKEBURNER_2 = Engine.load_audio(_modpath.."sutoraikubaanaa2.ogg")

local TEXTURE_BURNERMAN = Engine.load_texture(_modpath.."burnerman.png")
local ANIMPATH_BURNERMAN = _modpath.."burnerman.animation"
local TEXTURE_HEATCHASER_U = Engine.load_texture(_modpath.."heatchaser_u.png")
local ANIMPATH_HEATCHASER_U = _modpath.."heatchaser_u.animation"
local TEXTURE_HEATCHASER_D = Engine.load_texture(_modpath.."heatchaser_d.png")
local ANIMPATH_HEATCHASER_D = _modpath.."heatchaser_d.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SPAWN2 = Engine.load_audio(_modpath.."spawn2.ogg")
local AUDIO_STRIKEBURNER = Engine.load_audio(_modpath.."strikeburner.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

local TEXTURE_BOOM = Engine.load_texture(_modpath.."boom.png")
local ANIMPATH_BOOM = _modpath.."boom.animation"
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-250-BurnerManDS")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"B"})

    local props = package:get_card_props()
    props.shortname = "BurnMnDS"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "3-direct burnr fry 2 ahead!"
    props.long_description = "Concentrated attack with burners from 3 sides, 2 squares forward"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    local dark_hole_query = function(hole)
        return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
    end
    local field = actor:get_field()
    local dark_hole_list = field:find_obstacles(dark_hole_query)
    local boost = 5 * (math.min(10, #dark_hole_list))
    props.damage = props.damage + boost
    action:set_metadata(props)
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 100
        local voiceline_number = 0

        local NOT_HOLE = nil

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local X_offset = nil
        local Y_offset_U = self_Y - 1
        local Y_offset_D = self_Y + 1

        if direction == Direction.Right then
            X_offset = self_X + 2
        else
            X_offset = self_X - 2
        end

		local step1 = Battle.Step.new()

        self.burnerman = nil
        self.tile   = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    VOICEACTING = true
                end
            end

            if not user:get_current_tile():is_hole() then
                NOT_HOLE = true
            else
                NOT_HOLE = false
            end

            if do_once then
                do_once = false
                ref.burnerman = Battle.Artifact.new()
                ref.burnerman:set_facing(direction)
                local burner_sprite = ref.burnerman:sprite()
                burner_sprite:set_layer(-4)
                burner_sprite:set_texture(TEXTURE_BURNERMAN, true)
                local burner_anim = ref.burnerman:get_animation()
                burner_anim:load(ANIMPATH_BURNERMAN)
                if NOT_HOLE then
                    burner_anim:set_state("PANEL")
		    	    burner_anim:refresh(burner_sprite)
                    burner_anim:on_frame(2, function()
                        voiceline_number = math.random(1,3)
                        Engine.play_audio(AUDIO_SPAWN, AudioPriority.Highest)
                    end)
                    burner_anim:on_frame(12, function()
                        if Y_offset_U ~= 0 then
                            print("HeatChaser1 spawned at tile ("..X_offset..";"..Y_offset_U..")")
                            Engine.play_audio(AUDIO_SPAWN2, AudioPriority.High)
                            create_heatchaser(user, props, TEXTURE_HEATCHASER_U, ANIMPATH_HEATCHASER_U, "HEATCHASER_U", team, direction, 23, Direction.Down, field, X_offset, Y_offset_U)
                        end
                        if Y_offset_D ~= 4 then
                            print("HeatChaser2 spawned at tile ("..X_offset..";"..Y_offset_D..")")
                            Engine.play_audio(AUDIO_SPAWN2, AudioPriority.High)
                            create_heatchaser(user, props, TEXTURE_HEATCHASER_D, ANIMPATH_HEATCHASER_D, "HEATCHASER_D", team, direction, 27, Direction.Up, field, X_offset, Y_offset_D)
                        end
                    end)
                    burner_anim:on_frame(23, function()
                        if VOICEACTING then
                            if voiceline_number == 1 then
                                print("BurnerMan: StrikeBurner!")
                                Engine.play_audio(VOICE_STRIKEBURNER_1, AudioPriority.High)
                            end
                        end
                    end)
                    burner_anim:on_frame(24, function()
                        if VOICEACTING then
                            if voiceline_number == 2 or voiceline_number == 3 then
                                print("BurnerMan: StrikeBurner!")
                                Engine.play_audio(VOICE_STRIKEBURNER_2, AudioPriority.High)
                            end
                        end
                    end)
                    burner_anim:on_frame(25, function()
                        if not VOICEACTING then
                            print("BurnerMan: StrikeBurner!")
                        end
                        Engine.play_audio(AUDIO_STRIKEBURNER, AudioPriority.Highest)
                        create_attack(user, props, user:get_tile(direction, 1), team, direction, field)
                        create_attack(user, props, user:get_tile(direction, 2), team, direction, field)
                        create_attack(user, props, user:get_tile(direction, 3), team, direction, field)
                    end)
                    --[[burner_anim:on_frame(94, function()
                        strikeburner:erase()
                    end)]]
                    burner_anim:on_complete(function()
                        ref.burnerman:erase()
                        step1:complete_step()
                    end)
                else
                    burner_anim:set_state("NOPANEL")
		    	    burner_anim:refresh(burner_sprite)
                    burner_anim:on_frame(2, function()
                        voiceline_number = math.random(1,3)
                        Engine.play_audio(AUDIO_SPAWN, AudioPriority.Highest)
                    end)
                    burner_anim:on_complete(function()
                        ref.burnerman:erase()
                        step1:complete_step()
                    end)
                end
                field:spawn(ref.burnerman, ref.tile)
            end
        end
        self:add_step(step1)
    end
	action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function create_heatchaser(owner, props, texture, animpath, animstate, team, direction, flameframe, flamedir, field, x, y)
    local spell = Battle.Spell.new(team)
    local spell_tile = field:tile_at(x, y)
    local spell_sprite = spell:sprite()
    spell_sprite:set_layer(-3)
    spell_sprite:set_texture(texture, true)
    local spell_anim = spell:get_animation()
    spell_anim:load(animpath)
    spell_anim:set_state(animstate)
    spell_anim:refresh(spell_sprite)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            owner:get_id(),
            Drag.None
        )
    )

    spell_anim:on_frame(flameframe, function()
        Engine.play_audio(AUDIO_STRIKEBURNER, AudioPriority.Highest)
        create_attack(owner, props, spell_tile:get_tile(flamedir, 1), team, direction, field)
        create_attack(owner, props, spell_tile:get_tile(flamedir, 2), team, direction, field)
    end)
    spell_anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.collision_func = function(self, other)
        Engine.play_audio(AUDIO_BOOM, AudioPriority.Highest)
        create_effect(TEXTURE_BOOM, ANIMPATH_BOOM, "0", math.random(-7,7), math.random(-7,7), field, self:get_current_tile())
		self:erase()
	end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		self:delete()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        --create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-10,10), math.random(-10,10), field, self:get_current_tile())
    end

    field:spawn(spell, spell_tile)

    return spell
end

function create_attack(owner, props, tile, team, direction, field)
    local spawn_attack
    spawn_attack = function()
        if tile == nil or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            props.element, 
            owner:get_id(), 
            Drag.new())
        )

        local animation = spell:get_animation()
        animation:load(_modpath.."attack.animation")
        animation:set_state("1")
        animation:on_complete(function()
            spell:erase()
        end)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.attack_func = function(self)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-7,7), math.random(-7,7), field, self:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)
    end

    spawn_attack()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end