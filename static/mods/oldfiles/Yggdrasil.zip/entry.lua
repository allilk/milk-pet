local sword = include("sword/sword.lua")
local chain = include("forms/ice_chain/chain.lua")
local woodball = include("forms/woodball/woodball.lua")
function package_init(package)
    package:declare_package_id("Yggdrasil.EXE")
    package:set_special_description("Cinna's WIP personal Navi")
    package:set_speed(10.0)
    package:set_attack(5)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_icon_texture(Engine.load_texture(_modpath.."forte_face.png"))
    package:set_overworld_animation_path(_modpath.."forte_OW.animation")
    package:set_overworld_texture_path(_modpath.."forte_OW.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
	
    player:set_name("Yggdrasil")
    player:set_health(1500)
    player:set_element(Element.Elec)
    player:set_height(55.0)
	
    local base_texture = Engine.load_texture(_modpath.."navi_forte_atlas.png")
    local base_animation_path = _modpath.."forte.animation"
    local base_charge_color = Color.new(255, 215, 0, 0)
	local special_cooldown = 120
	local can_use_special = true
    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(3,-35)
    --[[ Declared below instead
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
    player.special_attack_func = create_special_attack
    ]]
    player.update_func = function(self, dt) 
		if special_cooldown <= 0 then
			can_use_special = true
			special_cooldown = 120
        else
			special_cooldown = special_cooldown - 1
        end
    end
    
    player.charged_attack_func = function(self)
      print("charged attack")
      return Battle.Buster.new(self, true, self:get_attack_level()*10)
    end
    
    player.normal_attack_func = function(self)
      print("buster attack")
      return Battle.Buster.new(self, false, self:get_attack_level())
    end
  
    player.special_attack_func = function(self)
      print("execute special")
      local props = Battle.CardProperties:new()
      props.damage = 0 + (self:get_attack_level()*10)
      local sword_action = sword.card_create_action(self, props)
      return sword_action
    end
        
    local ice = player:create_form()
    ice:set_mugshot_texture_path(_modpath.."forms/Ice_entry.png")

    local original_attack_level, original_charge_level

    ice.on_activate_func = function(self, player)
        original_attack_level = player:get_attack_level()
        original_charge_level = player:get_charge_level()
        player:set_attack_level(5) -- max attack level
        player:set_charge_level(5) -- max charge level
        player:set_animation(_modpath.."forms/ice.animation")
        player:set_texture(Engine.load_texture(_modpath.."forms/ice.png"), true)
        player:set_fully_charged_color(Color.new(57, 198, 243, 255))
		player:set_element(Element.Aqua)
    end

    ice.on_deactivate_func = function(self, player)
        player:set_animation(base_animation_path)
        player:set_texture(base_texture, true)
        player:set_fully_charged_color(base_charge_color)
        player:set_attack_level(original_attack_level)
        player:set_charge_level(original_charge_level)
    end
	ice.special_attack_func = function(self)
		if can_use_special then
			print("execute special")
			can_use_special = false
			special_cooldown = 180
			local props = Battle.CardProperties:new()
			props.damage = 0 + (player:get_attack_level()*10)
			local chain_action = chain.card_create_action(player, props)
			return chain_action
		else
			local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
			action.execute_func = function(self, user)
				local buster = self:add_attachment("BUSTER")
				local buster_sprite = buster:sprite()
				buster_sprite:set_texture(user:get_texture())
				buster_sprite:set_layer(-2)
				buster_sprite:enable_parent_shader(true)
				
				local buster_anim = buster:get_animation()
				buster_anim:copy_from(user:get_animation())
				buster_anim:set_state("BUSTER")
			end
			return action
		end
    end
	local wood = player:create_form()
    wood:set_mugshot_texture_path(_modpath.."forms/Wood_entry.png")

    local original_attack_level, original_charge_level

    wood.on_activate_func = function(self, player)
        original_attack_level = player:get_attack_level()
        original_charge_level = player:get_charge_level()
        player:set_attack_level(5) -- max attack level
        player:set_charge_level(5) -- max charge level
        player:set_animation(_modpath.."forms/wood.animation")
        player:set_texture(Engine.load_texture(_modpath.."forms/wood.png"), true)
        player:set_fully_charged_color(Color.new(0, 255, 0, 0))
		player:set_element(Element.Wood)
    end

    wood.on_deactivate_func = function(self, player)
        player:set_animation(base_animation_path)
        player:set_texture(base_texture, true)
        player:set_fully_charged_color(base_charge_color)
        player:set_attack_level(original_attack_level)
        player:set_charge_level(original_charge_level)
    end

    wood.special_attack_func = function(self)
        if can_use_special then
            print("execute special")
            can_use_special = false
			special_cooldown = 120
            local props = Battle.CardProperties:new()
            props.damage = 30
            local woodball_action = woodball.card_create_action(player, props)
            return woodball_action
		else
			local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
			action.execute_func = function(self, user)
				local buster = self:add_attachment("BUSTER")
				local buster_sprite = buster:sprite()
				buster_sprite:set_texture(user:get_texture())
				buster_sprite:set_layer(-2)
				buster_sprite:enable_parent_shader(true)
				
				local buster_anim = buster:get_animation()
				buster_anim:copy_from(user:get_animation())
				buster_anim:set_state("BUSTER")
			end
			return action
		end
    end
end