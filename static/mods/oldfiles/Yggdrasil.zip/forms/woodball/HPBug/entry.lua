local HPBug = {
	bug_level = 0,
	hp_bug = nil
}
HPBug.inflict_health_bug = function(other)
	if HPBug.hp_bug ~= nil then
		HPBug.hp_bug:eject()
	end
	HPBug.hp_bug = Battle.Component.new(other, Lifetimes.Battlestep)
	local do_once = true
	HPBug.hp_bug.update_func = function(self, dt)
		if do_once then
			if HPBug.bug_level == 1 then
				self.cooldown = 40
				self.original_cooldown = 40
			elseif HPBug.bug_level == 2 then
				self.cooldown = 35
				self.original_cooldown = 35
			elseif HPBug.bug_level == 3 then
				self.cooldown = 30
				self.original_cooldown = 30
			elseif HPBug.bug_level == 4 then
				self.cooldown = 25
				self.original_cooldown = 25
			elseif HPBug.bug_level == 5 then
				self.cooldown = 20
				self.original_cooldown = 20
			elseif HPBug.bug_level == 6 then
				self.cooldown = 15
				self.original_cooldown = 15
			elseif HPBug.bug_level >= 7 then
				self.cooldown = 10
				self.original_cooldown = 10
			end				
			do_once = false
		end
		if self:get_owner():get_health() > 1 then
			self.cooldown = self.cooldown - 1
			if self.cooldown <= 0 then
				self:get_owner():set_health(self:get_owner():get_health() - 1)
				self.cooldown = self.original_cooldown
			end
		end
	end
	HPBug.bug_level = HPBug.bug_level + 1
	other:register_component(HPBug.hp_bug)
end
return HPBug