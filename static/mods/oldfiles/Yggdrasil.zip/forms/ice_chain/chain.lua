nonce = function() end
-- TODO: Maybe afix the chain to the chaingun so I only have one texture and they can be properly overlaid

local GUN_TEXTURE = Engine.load_texture(_modpath.."forms/ice_chain/chaingun.png")
local GUN_ANIMATION_PATH = _modpath.."forms/ice_chain/chaingun.animation"
local CHAIN_TEXTURE = Engine.load_texture(_modpath.."forms/ice_chain/chain.png")
local CHAIN_SHOOT = Engine.load_audio(_modpath.."forms/ice_chain/chain.ogg")
local CHAIN_HIT = Engine.load_audio(_modpath.."forms/ice_chain/damageenemy.ogg")
local CHAIN_ANIMATION_PATH = _modpath.."forms/ice_chain/chain.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath.."forms/ice_chain/hit.png")
local HIT_ANIMATION_PATH = _modpath.."forms/ice_chain/hit.animation"

function package_init(package) 
    package:declare_package_id("Ice_chain_special")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon3.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview3.png"))
	  package:set_codes({'K', 'N', 'O', 'T'})

    local props = package:get_card_props()
    props.shortname = "ElChain3"
    props.damage = 110
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Stun and pull foe w/ chain!"
    props.limit = 2

end

local chain = {

}

chain.card_create_action = function(actor, props)
  local DURATION = { 1, 0.481} -- I think that was like 30f; duration of the whole chip
  local FRAMES = make_frame_data({DURATION})
 
  -- These are used for checking various parts of the animation later
      -- So I don't delete things I don't want to delete and so I don't hit when I don't want to hit (when it's reeling)
  local hit = false
  local reeling = false
  local exists1 = false
  local exists2 = false
  local exists3 = false

  local current_length = 0
  local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
  action:set_lockout(make_animation_lockout())
  action:override_animation_frames(FRAMES)

  local chain_ref
  local spell1
  local spell2
  local spell3
  local alreadyDone = false

  local function deleteSpells()

  if exists1 then spell1:delete() exists1 = false end
  if exists2 then spell2:delete() exists2 = false end
  if exists3 then spell3:delete() exists3 = false end

  end

  local function spawn_attack(actor, tile, length)
    local field = actor:get_field()
    local team = actor:get_team()
    local direction = actor:get_facing()

    local firstTile = tile
    local distanceToTarget
    
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Solid)
    spell:set_facing(actor:get_facing())
    
    spell:set_hit_props(
    HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | Hit.Freeze | Hit.Drag,
        Element.Aqua,
        actor:get_context(),
        Drag.new(Direction.reverse(direction), length) 
    )
    )

    spell.update_func = function(self, dt)

    if not hit and not reeling then spell:get_current_tile():attack_entities(self) end

    end
    
    spell.collision_func = function(self, other)

    end
    
    spell.attack_func = function(self, other) 
        
    local artifact = Battle.Artifact.new()
    artifact:sprite():set_layer(-1)
    artifact:set_texture(HIT_TEXTURE, true)
    artifact:set_offset(0, -30)
    artifact:get_animation():load(HIT_ANIMATION_PATH)
    artifact:get_animation():set_state("HIT")
    artifact:get_animation():refresh(artifact:sprite())
    artifact:get_animation():on_complete(function()
    artifact:erase()
    end)

    local hitTile = spell:get_current_tile()
    field:spawn(artifact, hitTile:x(), hitTile:y())

    hit = true
    reeling = true
    Engine.play_audio(CHAIN_HIT, AudioPriority.Low)

    end

    spell.delete_func = function(self)
        self:erase()
    end

    spell.can_move_to_func = function(tile)
    return true
    end

    return spell
  
  end

action.animation_end_func = deleteSpells

action.execute_func = function()


  local chain = action:add_attachment("BUSTER")
  chain:sprite():set_texture(CHAIN_TEXTURE, true)
  chain:sprite():set_layer(-2) -- I actually should probably have this as -1

  local chain_anim = chain:get_animation()
  chain_anim:load(CHAIN_ANIMATION_PATH)
  chain_anim:set_state("SHOOTING")
  
  chain_ref = chain

  local chaingun = action:add_attachment("BUSTER")
  chaingun:sprite():set_texture(GUN_TEXTURE, true)
  chaingun:sprite():set_layer(-2)

  local chaingun_anim = chaingun:get_animation()
  chaingun_anim:load(GUN_ANIMATION_PATH)
  chaingun_anim:set_state("FIRE")
  
  Engine.play_audio(CHAIN_SHOOT, AudioPriority.High)


  local tile = actor:get_tile(actor:get_facing(), 1)
  local spawnTile = tile:get_tile(actor:get_facing(), current_length)    

  chain_anim:on_frame(2, function() 
    spell1 = spawn_attack(actor, tile, current_length)

    actor:get_field():spawn(spell1, spawnTile)
    current_length = current_length+1
    spawnTile = spawnTile:get_tile(actor:get_facing(), 1)
    exists1 = true

  end, false)
  
  
  chain_anim:on_frame(3, function() 
    if not hit then
    spell2 = spawn_attack(actor, tile, current_length)

    actor:get_field():spawn(spell2, spawnTile)
    current_length = current_length+1
    spawnTile = spawnTile:get_tile(actor:get_facing(), 1)
    exists2 = true
    end
  end, false)
  
  chain_anim:on_frame(4, function() 
    if not hit then
      spell3 = spawn_attack(actor, tile, current_length)
    
      actor:get_field():spawn(spell3, spawnTile)
      current_length = current_length+1
      spawnTile = spawnTile:get_tile(actor:get_facing(), 1)
      exists3 = true
    end
  end, false)

  
  chain_anim:on_frame(6, function() 
    if not reeling then
        reeling = true
    end

  end, false)

end

action.update_func = function()
  if hit then 
    if current_length == 1 and not alreadyDone then
      chain_ref:get_animation():set_state("REEL1")
      chain_ref:get_animation():on_complete(deleteSpells)

      alreadyDone = true

    elseif current_length == 2 and not alreadyDone then
      chain_ref:get_animation():set_state("REEL2")
      chain_ref:get_animation():on_complete(deleteSpells)

      alreadyDone = true

    elseif current_length == 3 and not alreadyDone then
      chain_ref:get_animation():set_state("REEL3")
      chain_ref:get_animation():on_complete(deleteSpells)

      alreadyDone = true

    end
  end
end

return action
end

return chain