local DAMAGE = 20
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE6_50.wav")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE6_131.wav")

local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."airshoot.png")
local BUSTER_ANIMPATH = _folderpath.."airshoot.animation"
local BUSTER_AUDIO = Engine.load_audio(_folderpath.."EXE6_282.wav")
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"

local airshoot = {
    codes = {"*"},
    shortname = "AirShoot",
    damage = DAMAGE,
    time_freeze = false,
    element = Element.Wind,
    description = "Knock enmy back 1 square",
    long_description = "Air cannon pushes a hitted target 1 square back",
    can_boost = true,
    card_class = CardClass.Standard,
    memory = 4,
    limit = 5
}

function package_init(package) 
    package:declare_package_id("com.claris.k1rbyat1na.card.EXE6-004-AirShoot")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes(airshoot.codes)

    local props = package:get_card_props()
    props.shortname = airshoot.shortname
    props.damage = airshoot.damage
    props.time_freeze = airshoot.time_freeze
    props.element = airshoot.element
    props.description = airshoot.description
    props.long_description = airshoot.long_description
    props.can_boost = airshoot.can_boost
    props.card_class = airshoot.card_class
	props.limit = airshoot.limit
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.017}
	local frame2 = {1, 0.050}
	local frame3 = {2, 0.017}
	local frame4 = {2, 0.017}
	local frame5 = {3, 0.017}
	local frame6 = {4, 0.017}
	local frame7 = {4, 0.084}
	local frame8 = {4, 0.135}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8})
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-3)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(BUSTER_ANIMPATH)
		buster_anim:set_state("0")
		
		self:add_anim_action(2, function()
            Engine.play_audio(BUSTER_AUDIO, AudioPriority.Highest)
			actor:toggle_counter(true)
        end)
		self:add_anim_action(3, function()
            if facing == Direction.Right then
                actor:set_offset(original_offset.x - 4.0*2, original_offset.y)
            else
                actor:set_offset(original_offset.x + 4.0*2, original_offset.y)
            end
		end)
		self:add_anim_action(4, function()
            if facing == Direction.Right then
                actor:set_offset(original_offset.x - 5.0*2, original_offset.y)
            else
                actor:set_offset(original_offset.x + 5.0*2, original_offset.y)
            end
		end)
		self:add_anim_action(5, function()
            if facing == Direction.Right then
                actor:set_offset(original_offset.x - 6.0*2, original_offset.y)
            else
                actor:set_offset(original_offset.x + 6.0*2, original_offset.y)
            end
            local tile = user:get_tile(facing, 1)
            create_attack(user, props, team, facing, field, tile)
		end)
		self:add_anim_action(8, function()
			actor:toggle_counter(false)
        end)
	end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_attack(user, props, team, facing, field, tile)
	local spell = Battle.Spell.new(team)
	spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Drag, 
            props.element,
            user:get_context(),
            Drag.new(facing, 1)
        )
    )
	spell.slide_started = false
    --[[local sprite = spell:sprite()
    sprite:set_texture(Engine.load_texture(_folderpath.."testdot.png"), true)
	sprite:set_layer(-3)
    local anim = spell:get_animation()
	anim:load(_folderpath.."testdot.animation")
	anim:set_state("0")]]
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(0), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, ent)
        local rndm1 = math.random(-7,7)
        local rndm2 = math.random(-30,-15)
		print("Air Shoot attacked tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
        create_effect(Direction.Right, BOOM_TEXTURE, BOOM_ANIMPATH, "0", rndm1 * 2, rndm2 * 2, -999999, field, ent:get_current_tile())
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Highest)
		end
	end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)
    print("Air Shoot attack spawned at tile ("..tile:x()..";"..tile:y()..")")
	return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end