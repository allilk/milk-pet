local DAMAGE = 600

local TEXTURE_GOSPEL = Engine.load_texture(_modpath.."gospel.png")
local TEXTURE_FLAMES = Engine.load_texture(_modpath.."flames.png")
local ANIMPATH_GOSPEL = _modpath.."gospel.animation"
local ANIMPATH_FLAMES = _modpath.."flames.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_BREATH = Engine.load_audio(_modpath.."breathofgospel.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-265-WoodGospel")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"X"})

    local props = package:get_card_props()
    props.shortname = "WoodGspl"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Wood
    props.description = "Gospel's breath of wood!"
    props.long_description = "Breath of Gospel! Breath of wood slices enemies in pieces!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local field = actor:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local x = self_tile:x()
        local y = self_tile:y()

		local step1 = Battle.Step.new()

        self.gospel = nil
        self.tile   = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.gospel = Battle.Artifact.new()
                ref.gospel:set_facing(direction)
		    	ref.gospel:set_texture(TEXTURE_GOSPEL, true)
		    	ref.gospel:sprite():set_layer(-1)

                local gospel_anim = ref.gospel:get_animation()
                gospel_anim:load(ANIMPATH_GOSPEL)
                gospel_anim:set_state("DEFAULT")
		    	gospel_anim:refresh(ref.gospel:sprite())

                local flamehit1 = create_flame(user, props)
                local flamehit2 = create_flame(user, props)
                local flamehit3 = create_flame(user, props)
                local flamehit4 = create_flame(user, props)
                local flamehit5 = create_flame(user, props)
                local flamehit6 = create_flame(user, props)
                local flamehit7 = create_flame(user, props)

                local flamefx1 = Battle.Artifact.new()
		        flamefx1:set_facing(direction)
		        local flameanim1 = flamefx1:get_animation()
		        flamefx1:set_texture(TEXTURE_FLAMES, true)
		        flameanim1:load(ANIMPATH_FLAMES)
		        flameanim1:set_state("1")
                flameanim1:refresh(flamefx1:sprite())
                flameanim1:on_complete(function()
                    flamehit1:erase()
                    flameanim1:set_state("2")
                    flameanim1:refresh(flamefx1:sprite())
                    flameanim1:on_complete(function()
                        flamefx1:erase()
                    end)
                end)

                local flamefx2 = Battle.Artifact.new()
		        flamefx2:set_facing(direction)
		        local flameanim2 = flamefx2:get_animation()
		        flamefx2:set_texture(TEXTURE_FLAMES, true)
		        flameanim2:load(ANIMPATH_FLAMES)
		        flameanim2:set_state("3")
                flameanim2:refresh(flamefx2:sprite())
                flameanim2:on_complete(function()
                    flamehit2:erase()
                    flamehit3:erase()
                    flamehit4:erase()
                    flameanim2:set_state("4")
                    flameanim2:refresh(flamefx2:sprite())
                    flameanim2:on_complete(function()
                        flamefx2:erase()
                    end)
                end)

                local flamefx3 = Battle.Artifact.new()
		        flamefx3:set_facing(direction)
		        local flameanim3 = flamefx3:get_animation()
		        flamefx3:set_texture(TEXTURE_FLAMES, true)
		        flameanim3:load(ANIMPATH_FLAMES)
		        flameanim3:set_state("3")
                flameanim3:refresh(flamefx3:sprite())
                flameanim3:on_complete(function()
                    flamehit5:erase()
                    flamehit6:erase()
                    flamehit7:erase()
                    flameanim3:set_state("4")
                    flameanim3:refresh(flamefx3:sprite())
                    flameanim3:on_complete(function()
                        flamefx3:erase()
                    end)
                end)

                gospel_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                end)
                gospel_anim:on_frame(34, function()
                    Engine.play_audio(AUDIO_BREATH, AudioPriority.High)
                    if direction == Direction.Right then
                        field:spawn(flamefx1, 3, 2)
                        field:spawn(flamehit1, 3, 2)
                    else
                        field:spawn(flamefx1, 4, 2)
                        field:spawn(flamehit1, 4, 2)
                    end
                end)
                gospel_anim:on_frame(36, function()
                    if direction == Direction.Right then
                        field:spawn(flamefx2, 4, 2)
                        field:spawn(flamehit2, 4, 1)
                        field:spawn(flamehit3, 4, 2)
                        field:spawn(flamehit4, 4, 3)
                    else
                        field:spawn(flamefx2, 3, 2)
                        field:spawn(flamehit2, 3, 2)
                        field:spawn(flamehit3, 3, 2)
                        field:spawn(flamehit4, 3, 2)
                    end
                end)
                gospel_anim:on_frame(37, function()
                    if direction == Direction.Right then
                        field:spawn(flamefx3, 5, 2)
                        field:spawn(flamehit5, 5, 1)
                        field:spawn(flamehit6, 5, 2)
                        field:spawn(flamehit7, 5, 3)
                    else
                        field:spawn(flamefx3, 2, 2)
                        field:spawn(flamehit5, 2, 1)
                        field:spawn(flamehit6, 2, 2)
                        field:spawn(flamehit7, 2, 3)
                    end
                end)
		    	gospel_anim:on_complete(function()
		    		ref.gospel:erase()
                    step1:complete_step()
		    	end)
                if direction == Direction.Right then
                    field:spawn(ref.gospel, 2, 2)
                else
                    field:spawn(ref.gospel, 5, 2)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function create_flame(actor, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

    return spell
end