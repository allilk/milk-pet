local CURSOR_ANIMATION = _folderpath .. "cursor.animation"
local CURSOR_TEXTURE = Engine.load_texture(_folderpath .. "cursor.png")
local CURSOR_SFX = Engine.load_audio(_folderpath .. "scan.ogg")
local IMPACT_TEXTURE = Engine.load_texture(_modpath .. "impact.png")
local IMPACT_ANIM = _modpath .. "impact.animation"
local CANNON_TEXTURE = Engine.load_texture(_folderpath .. "canon.png")
local CANNON_ANIM = _folderpath .. "canon.animation"
local CANON_SFX = Engine.load_audio(_folderpath .. "canon.ogg")

--variables that change for each version of the card

--local palette = Engine.load_texture(_folderpath .. "V1.png")
local details = {
    name = "MarkCan",
    codes = { "A", "C", "M", "N", "*" },
    damage = 120,
    duration = 0.5,
    animation = "DEFAULT"
}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = details.name
    props.damage = details.damage
    props.time_freeze = false
    props.element = Element.Cursor
    props.description = "Cursor locks on 3 rows"
    props.limit = 3

    package:declare_package_id("com.loui.card." .. props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(details.codes)
end

function card_create_action(user, props)

    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    --special properties
    action.animation = details.animation

    action:set_lockout(make_sequence_lockout())
    local ATTACK = { 1, details.duration }
    local POST_ATTACK = { 1, 0.017 }
    local FRAMES = make_frame_data({ ATTACK, POST_ATTACK })
    action:override_animation_frames(FRAMES)
    action.execute_func = function(self, user)

        local step = Battle.Step.new()
        action:add_step(step)
        local start_x = user:get_tile(user:get_facing(), 1):x()
        cursor = spawn_cursor(
            user,
            user:get_team(),
            user:get_field(),
            user:get_field():tile_at(start_x, 1),
            user:get_facing(), details.damage,
            CURSOR_TEXTURE,
            step
        )
    end
    action.animation_end_func = function(self)

    end

    return action
end

function spawn_hitbox(team, field, tile, hitbox_props)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(hitbox_props)
    spell.update_func = function()
        tile:attack_entities(spell)
        spell:erase()
    end
    field:spawn(spell, tile)
end

function spawn_cursor(owner, team, field, tile, direction, damage, texture, step)
    local spawn_next
    spawn_next = function()
        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.None)
        spell:set_hit_props(HitProps.new(0, Hit.Impact | Hit.Stun | Hit.Retangible, Element.None, owner:get_context(),
            Drag.None))

        spell.move_dir = Direction.Down
        local sprite = spell:sprite()
        sprite:set_layer(-9)
        sprite:set_texture(texture)
        local animation = spell:get_animation()
        animation:load(CURSOR_ANIMATION)
        animation:set_state("DEFAULT")
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)

        spell.target_found = false

        spell.can_move_to_func = function(tile)
            return true
        end

        spell.attack_func = function()
            Engine.play_audio(CURSOR_SFX, AudioPriority.Highest)
            spell.target_found = true
            spell:get_animation():set_state("FOUND")
            spell:get_animation():on_complete(function()
                spell:erase()
            end)
            step:complete_step()
            cannon(owner, spell:get_current_tile())
        end


        spell.speed = tile:height() * 15 / 60
        spell.counter = 1
        spell.row_count = 1

        spell.update_func = function()
            if (not spell.target_found) then
                local current_offset = spell:get_offset()
                if (spell.counter < 4) then
                elseif (spell.counter > 12 and spell.counter < 16) then
                elseif (spell.counter > 16) then
                    if (spell:get_tile():x() == 0 or spell:get_tile():x() == 7) then
                        spell:erase()
                        step:complete_step()
                        return
                    end
                    local next_tile = spell:get_tile(spell:get_facing(), 1)
                    spell.move_dir = Direction.reverse(spell.move_dir)
                    spell.speed = -spell.speed
                    spell:teleport(next_tile, ActionOrder.Immediate)
                    spell.counter = 1
                    spell.row_count = spell.row_count + 1
                    if (spell.row_count > 3) then
                        spell:erase()
                        step:complete_step()
                    end
                    return
                end
                spell:set_offset(0, current_offset.y + spell.speed)
                if (current_offset.y >= tile:height() * .9 or current_offset.y <= -tile:height() * .9) then
                    spell:teleport(spell:get_tile(spell.move_dir, 1), ActionOrder.Immediate)
                    spell:set_offset(0, 0)
                end
                spell.counter = spell.counter + 1
            end
            spell:get_current_tile():attack_entities(spell)
        end
        field:spawn(spell, tile)

        return spell
    end

    return spawn_next()
end

function cannon(user, tile)
    local props = {}
    --standard properties
    props.shortname = details.name
    props.damage = details.damage
    props.time_freeze = false
    props.element = Element.None
    props.tile = tile
    local canon_action = cannon_action(user, props)
    user:card_action_event(canon_action, ActionOrder.Immediate)
end

function cannon_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    local frame1 = { 1, 0.1 }
    local frame2 = { 2, 0.1 }
    local frame3 = { 3, 0.05 }
    local frame4 = { 4, 0.05 }
    local frame5 = { 5, 0.05 }
    local frame6 = { 6, 0.02 }
    local frame7 = { 7, 0.02 }
    local frame8 = { 8, 0.02 }
    local frame9 = { 9, 0.0165 }
    local frame_sequence = make_frame_data({ frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9 })
    local original_offset = actor:get_offset()
    action:override_animation_frames(frame_sequence)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(CANNON_TEXTURE, true)
        buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
        buster_anim:load(CANNON_ANIM)
        buster_anim:set_state("DEFAULT")

        self:add_anim_action(1, function()
            actor:toggle_counter(true)
        end)

        self:add_anim_action(3, function()
            local recoil_component = Battle.Component.new(actor, Lifetimes.Battlestep)
            recoil_component.update_func = function(self, dt)
                local goal_offset_x = original_offset.x - 12
                if self:get_owner():get_offset().x <= goal_offset_x then
                    self:eject()
                else
                    self:get_owner():set_offset(self:get_owner():get_offset().x - 4, self:get_owner():get_offset().y)
                end
            end
            actor:register_component(recoil_component)
        end)

        self:add_anim_action(6, function()
            actor:toggle_counter(false)
            local cannonshot = create_attack(user, props)
            actor:get_field():spawn(cannonshot, props.tile)
        end)

        self:add_anim_action(9, function()
            actor:set_offset(original_offset.x, original_offset.y)
        end)
    end
    action.action_end_func = function(self)
        actor:toggle_counter(false)
        actor:set_offset(original_offset.x, original_offset.y)
    end
    return action
end

function create_attack(user, props)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Cursor,
            user:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        self:get_current_tile():highlight(Highlight.Solid)
        self:delete()
    end
    spell.collision_func = function(self, other)
        create_effect(IMPACT_TEXTURE, IMPACT_ANIM, "0", 0, 0, spell:get_field(), spell:get_current_tile())
        self:delete()
    end
    spell.attack_func = function(self, other)
    end

    spell.delete_func = function(self)
        self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    Engine.play_audio(CANON_SFX, AudioPriority.Low)
    return spell
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(effect_animpath)
    hitfx_anim:set_state(effect_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end
