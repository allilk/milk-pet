function package_init(package) 
    package:declare_package_id("com.alrysc.card.Tadpole3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'N','O', 'P', 'S'})

    local props = package:get_card_props()
    props.shortname = "Tadpole3"
    props.damage = 170
    props.time_freeze = false
    props.element = Element.Aqua
    props.description = "Turn to closest enemy!"
    props.limit = 3

end



local HIT = nil
local BOUND = nil

-- 9f shake, normal hit sound, no spawn sound, spawn on frame 3, wait 3f before moving, 8-9f between each tile after that 
function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        
        {1, 0.05}, {2, 0.033}, {3, 0.033}, {4, 0.15}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local function create_tadpole(user)
        local spell = graphic_init("spell", 0, 0, "tadpole.png", "tadpole.animation", -4, "FORWARD", user, user:get_facing())
        local shadow = graphic_init("spell", 0, 0, "tadpole.png", "tadpole.animation", -4, "SHADOW", user, user:get_facing())

        spell:get_animation():set_playback(Playback.Loop)
        spell:highlight_tile(Highlight.Solid)
        local speed = 8
        spell.startup = 2
        spell:set_elevation(70)
        spell.turned = false
        spell.dir = spell:get_facing()

        local function check_column(spell)
            local cur_tile = spell:get_current_tile()
            local team = spell:get_team()
            local new_dir = spell:get_facing()

            for i = (cur_tile:y()-1), 0, -1
            do
                local t = cur_tile:get_tile(Direction.Up, i)
                if t and not t:is_edge() then
                    local chars = t:find_characters(function(c)
                        return c:get_team() ~= team
                    end)

                    if #chars > 0 then
                        new_dir = Direction.Up
                        spell:get_animation():set_state("UP")
                        spell:get_animation():refresh(spell:sprite())
                        spell:get_animation():set_playback(Playback.Loop)

                        return new_dir
                    end
                end

                
            end

            for i = (cur_tile:y()+1), field:height(), 1
            do
                local t = field:tile_at(cur_tile:x(), i)
                if t and not t:is_edge() then
                    local chars = t:find_characters(function(c)
                        return c:get_team() ~= team
                    end)

                    if #chars > 0 then
                        new_dir = Direction.Down
                        spell:get_animation():set_state("DOWN")
                        spell:get_animation():refresh(spell:sprite())
                        spell:get_animation():set_playback(Playback.Loop)

                        return new_dir
                    end
                end

                
            end


            return new_dir
        end
    
        local hit_props = HitProps.new(
                props.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                props.element, 
                user:get_context(), 
                Drag.None
            )

        spell:set_hit_props(hit_props)

        spell.update_func = function(self)
            self:get_tile():attack_entities(self)

            if self.startup > 0 then 
                self.startup = self.startup-1
                return
            end

            if self:is_sliding() == false then
                if self:get_current_tile():is_edge() then 
                    self:delete()
                    shadow:delete()
                    return
                end 
                
                if not self.turned then
                    self.dir = check_column(self)
                    if self.dir == Direction.Down or self.dir == Direction.Up then 
                        self.turned = true
                        speed = 6
                        
                    end
                end

                local dest = self:get_tile(self.dir, 1)
                local ref = self
                self:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                    function()
                        ref.slide_started = true 
                    end
                )

                shadow:slide(dest, frames(speed), frames(0), ActionOrder.Voluntary,
                    function()
                    end
                )

            end
        end

        spell.attack_func = function(self)
            local hit_effect = graphic_init("artifact", 0, 0, "hit_effects.png", "hit_effects.animation", -6, "HIT_AQUA", self, self:get_facing(), true)
            field:spawn(hit_effect, self:get_current_tile())

            local shake_artifact = Battle.Artifact.new()
            local time = 0
            shake_artifact.update_func = function(self)
                    
                self:shake_camera(150, 0.016)
                if time == 9 then 
                    self:delete()
                end
            
                time = time+1
            end

            field:spawn(shake_artifact, self:get_current_tile())
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        spell.collision_func = function(self)
            self:delete()
            shadow:delete()
        end

        spell.can_move_to_func = function()
            return true
        end

        shadow.can_move_to_func = function()
            return true
        end

        field:spawn(spell, user:get_current_tile())
    end


    action.execute_func = function(self)
        HIT = Engine.load_audio(_modpath.."hit.ogg")
        BOUND = Engine.load_audio(_modpath.."bound.ogg")

        action:add_anim_action(2, function()
            local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HAND")
			hilt_anim:refresh(hilt_sprite)

        
        
        end)

        action:add_anim_action(3, function()
            create_tadpole(user)
            Engine.play_audio(BOUND, AudioPriority.Low)

        end)

       
    end




    return action
end