local fishy_texture = Engine.load_texture(_modpath.."fishy.png")
local fishy_animation_path = _modpath.."fishy.animation"
local dash_sfx = Engine.load_audio(_modpath.."sfx.ogg")
local start_sfx = Engine.load_audio(_modpath.."start.ogg")

function package_init(package) 
    package:declare_package_id("com.louise.card.dashattck")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'C','D', 'G', 'J', 'Z', '*'})

    local props = package:get_card_props()
    props.shortname = "DashAtk"
    props.damage = 90
    props.time_freeze = false
    props.description = "Dash through enemies!"
	props.long_description = "Dash through enemies!"
	props.limit = 3
end

function card_create_action(actor, props)

    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local FRAMEDATA_ELEMENT = {2, 1 } --List with two entries: frame and duration (in seconds)
	local FRAMEDATA_ELEMENT2 = {3, 0.017 } --List with two entries: frame and duration (in seconds)
	local FRAMEDATA_ELEMENT3 = {3, 1}
	local FRAMES = make_frame_data({FRAMEDATA_ELEMENT, FRAMEDATA_ELEMENT2, FRAMEDATA_ELEMENT3}) --List with X entries, where you fill it with items in the above format. Here, we have two animation frames that each last for 0.3 seconds
	action:override_animation_frames(FRAMES)

    action.execute_func = function(self, actor)
		local fishy_anim=nil
		self:add_anim_action(1,
			function()
				local fishy = self:add_attachment("BUSTER")
				local fishy_sprite = fishy:sprite()
				fishy_sprite:set_texture(fishy_texture)
				fishy_sprite:set_layer(-1)
				Engine.play_audio(start_sfx, AudioPriority.High)
				fishy_anim = fishy:get_animation()
				fishy_anim:load(fishy_animation_path)
				fishy_anim:set_state("DEFAULT")
			end
		)
		self:add_anim_action(2,
			function()
				fishy_anim:set_state("COMPLETE")
				Engine.play_audio(dash_sfx, AudioPriority.Low)
				local highlightSpell = Battle.Spell.new(actor:get_team())
				highlightSpell:set_hit_props(
				HitProps.new(
				props.damage,
				Hit.Impact | Hit.Flinch | Hit.Flash,
				Element.None,
				actor:get_context(),
				Drag.None)
				)
				highlightSpell.offset = 0
				if(actor:get_facing()==Direction.Right) then
				highlightSpell.speed = 20
				else
				highlightSpell.speed = -20
				end
				local current_tile = actor:get_tile()
				actor:get_field():spawn(highlightSpell, current_tile)
				actor:toggle_hitbox(false)
				highlightSpell.update_func = function ()
					highlightSpell.offset=highlightSpell.offset+highlightSpell.speed
					actor:set_offset(highlightSpell.offset, 0)
					if(highlightSpell.offset%80 ==0) then
						if(not current_tile:is_edge()) then
						--Dash attacks break cracked panels
						if(current_tile:get_state()==TileState.Cracked) then
							current_tile:set_state(TileState.Broken)
						end
						current_tile=current_tile:get_tile(actor:get_facing(), 1)
						else
							actor:set_offset(0, 0)
							highlightSpell:erase()
							actor:toggle_hitbox(true)
							action:end_action()
						end
					end
					if(current_tile)then
					current_tile:attack_entities(highlightSpell)
					end
			end
				
			end
		)
	end
    return action
end

