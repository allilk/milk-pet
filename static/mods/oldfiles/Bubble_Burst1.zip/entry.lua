local bomb = include('bomb.lua')

bomb.name="BblBrst1"
bomb.damage=80
bomb.element=Element.Aqua
bomb.description = "Bbl Bmb explode on ice"
bomb.long_description ="Bubble Bomb explodes when on ice"
bomb.codes = {"B","F","*"}
bomb.limit = 4


function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = bomb.name
    props.damage = bomb.damage
    props.time_freeze = false
    props.element = bomb.element
    props.description = bomb.description
    props.long_description = bomb.long_description
    props.limit = bomb.limit

    package:declare_package_id("com.DJ.Bubble.Burst.1"..props.shortname)
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(bomb.codes)
end

card_create_action = bomb.card_create_action