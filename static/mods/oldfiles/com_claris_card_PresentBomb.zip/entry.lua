nonce = function() end

local AUDIO = Engine.load_audio(_modpath.."boom.ogg")
local TEXTURE = Engine.load_texture(_modpath.."present.png")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."spell_explosion.png")

function package_init(package) 
    package:declare_package_id("com.claris.card.PresentBomb")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'*'})

    local props = package:get_card_props()
    props.shortname = "Present"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Summon
    props.description = "To all a good night!"
	props.can_boost = false
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")		
		local present = Battle.Obstacle.new(Team.Other)
		present:set_texture(TEXTURE, true)
		present:get_animation():load(_modpath.."present.animation")
		present:get_animation():set_state("SPAWN")
		present:get_animation():refresh(present:sprite())
		present:get_animation():on_complete(function()
			present:get_animation():set_state("DEFAULT")
			present:get_animation():refresh(present:sprite())
			present:get_animation():set_playback(Playback.Loop)
		end)
		present:set_health(200)

		-- deletion process var
		local delete_self = nil
		local spawned_hitbox = false
		local countdown = 6000
		-- slide tracker
		local continue_slide = false
		local prev_tile = {}
		local cube_speed = 4

		-- define cube collision hitprops
		local props = HitProps.new(
            200, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            Element.None,
            user:get_context(),
            Drag.None
        )

		-- upon tangible collision
		present.collision_func = function(self)
			-- define the hitbox with its props every frame
			local hitbox = Battle.Hitbox.new(present:get_team())
			hitbox:set_hit_props(props)

			if not spawned_hitbox then
				present:get_field():spawn(hitbox, present:get_current_tile())
				spawned_hitbox = true
			end
			present.delete_func()
		end

		present.can_move_to_func = function(tile)
			if tile then
				if not tile:is_walkable() or tile:is_edge() then
					return false
				end
			end
			return true
		end
		present.update_func = function(self, dt)
			local tile = present:get_current_tile()
			tile:attack_entities(self)
			if not tile then
				self:erase()
			end
			if not tile:is_walkable() or tile:is_edge() then
				self:erase()
			end
			if self:is_sliding() then
				if self:can_move_to_func(tile:get_tile(self:get_facing(), 1)) then
					continue_slide = true
				elseif not self:can_move_to_func(tile:get_tile(self:get_facing(), 1)) or self:get_facing() == Direction.None then
					continue_slide = false
				end
			end
			if not self:is_sliding() and continue_slide then
				self:slide(self:get_tile(self:get_facing(), 1), frames(4), frames(0), ActionOrder.Immediate, function() end)
			end
			if self:get_health() <= 0 then
				self:delete()
			end
		end
		present.delete_func = function(self)
			Engine.play_audio(AUDIO, AudioPriority.Low)
			local field = user:get_field()
			local tile = nil
			for i = 0, 6, 1 do
				for j = 0, 6, 1 do
					tile = field:tile_at(i, j)
					if tile and not tile:is_edge() then
						local explosion = create_boom(user, props)
						field:spawn(explosion, tile)
					end
				end
			end
		end
		local query = function(ent)
			return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
		end
		if #user:get_tile(user:get_facing(), 1):find_entities(query) == 0 and user:get_tile(user:get_facing(), 1):is_walkable() and not user:get_tile(user:get_facing(), 1):is_edge() then
			user:get_field():spawn(present, user:get_tile(user:get_facing(), 1))
		end
	end
    return action
end

function create_boom(user, props)
	local spell = Battle.Spell.new(Team.Other)
	spell:set_texture(EXPLOSION_TEXTURE, true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(props)
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
    end
	
	local anim = spell:get_animation()
    anim:load(_modpath.."spell_explosion.animation")
    anim:set_state("Default")
	anim:on_complete(function()
		spell:erase()
	end)
	
	spell.collision_func = function(self, other)
	end
	spell.can_move_to_func = function(self, other)
		return true
	end
	return spell
end