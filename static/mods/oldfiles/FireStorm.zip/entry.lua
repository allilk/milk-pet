
local BUSTER_TEXTURE = Engine.load_texture(_modpath.."widebust.png")
local SHOT_TEXTURE = Engine.load_texture(_modpath.."wideshot.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.Dawn.FireStorm")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'F'})

    local props = package:get_card_props()
    props.shortname = "FireStrm"
    props.damage = 300
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Fireman's oldest attack!"
    props.long_description = "FireStorm down the row! High damage!"
    props.limit = 1
	props.card_class = CardClass.Standard
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local f = 1/60
	action:override_animation_frames(make_frame_data({{1,2*f}, {2,2*f}, {3,2*f}, {4,4*f}, {5,1*f}, {3,14*f}}))
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath.."widebust.animation")
		buster_anim:set_state("DEFAULT")

		action:add_anim_action(5, function()
			local shot = create_wideshot(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			actor:get_field():spawn(shot, tile)
		end)
	end
    return action
end


function create_wideshot(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			props.element,
			user:get_context(),
			Drag.None
		)
	)
	local attacking = false
	local anim = spell:get_animation()
	spell:set_texture(SHOT_TEXTURE, true)
	spell:set_offset(0.0, -10)
	anim:load(_modpath.."wideshot.animation")
	anim:set_state("STARTUP")
	anim:on_complete(function()
		anim:set_state("DEFAULT")
		anim:set_playback(Playback.Loop)
		attacking = true
	end)

	spell.update_func = function(self, dt)
		if not attacking then return end
		local tile = self:get_tile()
		tile:attack_entities(self)

		if self:is_sliding() == false then
			if tile:is_edge() then 
				self:delete()
			end 
			local dest = self:get_tile(spell:get_facing(), 1)
			local ref = self
			self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, function()
				if not tile:is_edge() then tile:set_state(TileState.Lava) end
			end)
		end
	end
    spell.collision_func = function(self, other) 
		self:delete()
    end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end