nonce = function() end

local DAMAGE = 90
local SLASH_TEXTURE = Engine.load_texture(_modpath.."spell_sword_slashes.png")
local BLADE_TEXTURE = Engine.load_texture(_modpath.."spell_sword_blades.png")
local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.ijuinpersonalterminalcompany.card.hawkcut2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'F','S','V'})

    local props = package:get_card_props()
    props.shortname = "HawkCut2"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Cut twice,wide and long"
    props.long_description = "Cut twice once wide once long"
    props.limit = 3
   

end

function card_create_action(user, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self)
		local actor = self:get_actor()

		local step1 = Battle.Step.new()
		local step1_first = true

		local step2 = Battle.Step.new()
		local step2_first = true






		

		step1.update_func = function()
			if step1_first then 
--				local actor = action:get_actor()

				action:add_anim_action(2, function()
					local hilt = action:add_attachment("HILT")
					local hilt_sprite = hilt:sprite()
					hilt_sprite:set_texture(actor:get_texture())
					hilt_sprite:set_layer(-2)
					hilt_sprite:enable_parent_shader(true)
					
					local hilt_anim = hilt:get_animation()
					hilt_anim:copy_from(actor:get_animation())
					hilt_anim:set_state("HILT")
		
					local blade = hilt:add_attachment("ENDPOINT")
					local blade_sprite = blade:sprite()
					blade_sprite:set_texture(BLADE_TEXTURE)
					blade_sprite:set_layer(-1)
		
					local blade_anim = blade:get_animation()
					blade_anim:load(_modpath.."spell_sword_blades.animation")
					blade_anim:set_state("DEFAULT")
					actor:get_animation():on_complete(function()
						step1:complete_step()
						hilt_sprite:hide()
					
					end)
				end)
				action:add_anim_action(3, function()
					local sword = create_slashwide(actor, props)
					local tile = actor:get_tile(actor:get_facing(), 1)
					local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
					sharebox1:set_hit_props(sword:copy_hit_props())
					local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
					sharebox2:set_hit_props(sword:copy_hit_props())
					actor:get_field():spawn(sharebox1, tile:get_tile(Direction.Up, 1))
					actor:get_field():spawn(sword, tile)
					actor:get_field():spawn(sharebox2, tile:get_tile(Direction.Down, 1))
					local fx = Battle.Artifact.new()
					fx:set_facing(sword:get_facing())
					local anim = fx:get_animation()
					fx:set_texture(SLASH_TEXTURE, true)
					anim:load(_modpath.."spell_sword_slashes.animation")
					anim:set_state("WIDE")
					anim:on_complete(function()
						fx:erase()
						sword:erase()
					end)

					local field = actor:get_field()
					field:spawn(fx, tile)
					field:spawn(sword, tile)
				end)

			

				step1_first = false
			end
		end

		step2.update_func = function()
			if step2_first then 
				actor:get_animation():set_state("PLAYER_SWORD")
				actor:get_animation():on_frame(2, function()
					local hilt = action:add_attachment("HILT")
					local hilt_sprite = hilt:sprite()
					hilt_sprite:set_texture(actor:get_texture())
					hilt_sprite:set_layer(-2)
					hilt_sprite:enable_parent_shader(true)
					
					local hilt_anim = hilt:get_animation()
					hilt_anim:copy_from(actor:get_animation())
					hilt_anim:set_state("HILT")
	
					local blade = hilt:add_attachment("ENDPOINT")
					local blade_sprite = blade:sprite()
					blade_sprite:set_texture(BLADE_TEXTURE)
					blade_sprite:set_layer(-1)
	
					local blade_anim = blade:get_animation()
					blade_anim:load(_modpath.."spell_sword_blades.animation")
					blade_anim:set_state("DEFAULT")

					actor:get_animation():on_complete(function()
						step2:complete_step()
						hilt_sprite:hide()
					end)

				end)
				actor:get_animation():on_frame(3, function()
					local sword = create_slash(actor, props)
					local tile = actor:get_tile(actor:get_facing(), 1)
					local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
					sharebox1:set_hit_props(sword:copy_hit_props())
					actor:get_field():spawn(sword, tile)
					actor:get_field():spawn(sharebox1, tile:get_tile(actor:get_facing(), 1))
					local fx = Battle.Artifact.new()
					fx:set_facing(sword:get_facing())
					local anim = fx:get_animation()
					fx:set_texture(SLASH_TEXTURE, true)
					anim:load(_modpath.."spell_sword_slashes.animation")
					anim:set_state("LONG")
					anim:on_complete(function()
						fx:erase()
						sword:erase()
					end)
					local field = actor:get_field()
					field:spawn(fx, tile)
					field:spawn(sword, tile)
				end)

				

				step2_first = false

			end



		end

		action:add_step(step1)
		action:add_step(step2)
	end

	return action

end


function create_slash(user, props)
  local spell = Battle.Spell.new(user:get_team())
  spell:set_facing(user:get_facing())
  spell:highlight_tile(Highlight.Flash)
  spell:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Impact | Hit.Flinch,
      Element.Sword,
      user:get_context(),
      Drag.None
    )
  )

  spell.update_func = function(self, dt) 
    if not self:get_tile():get_tile(user:get_facing(), 1):is_edge() then
      self:get_tile():get_tile(user:get_facing(), 1):highlight(Highlight.Flash)
    end
    self:get_tile():attack_entities(self)
  end

  spell.can_move_to_func = function(tile)
    return true
  end

  Engine.play_audio(AUDIO, AudioPriority.Low)

  return spell
end

function create_slashwide(user, props)
  local spell = Battle.Spell.new(user:get_team())
  spell:set_facing(user:get_facing())
  spell:highlight_tile(Highlight.Flash)
  spell:set_hit_props(
    HitProps.new(
      props.damage,
      Hit.Impact | Hit.Flinch,
      Element.Sword,
      user:get_context(),
      Drag.None
    )
  )
  spell.update_func = function(self, dt)
    if not self:get_tile():get_tile(Direction.Up, 1):is_edge() then
      self:get_tile():get_tile(Direction.Up, 1):highlight(Highlight.Flash)
    end
    if not self:get_tile():get_tile(Direction.Down, 1):is_edge() then
      self:get_tile():get_tile(Direction.Down, 1):highlight(Highlight.Flash)
    end
    self:get_tile():attack_entities(self)
  end

  spell.can_move_to_func = function(tile)
    return true
  end

  Engine.play_audio(AUDIO, AudioPriority.Low)

  return spell
end