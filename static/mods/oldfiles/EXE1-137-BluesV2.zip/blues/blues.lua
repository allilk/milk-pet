local DAMAGE = 140
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."hitsound_obs.ogg")

local BLUES_TEXTURE = Engine.load_texture(_folderpath.."blues.png")
local BLUES_ANIMPATH = _folderpath.."blues.animation"
local SWORD_SLASH_TEXTURE = Engine.load_texture(_folderpath.."sword_slash.png")
local SWORD_SLASH_ANIMPATH = _folderpath.."sword_slash.animation"
local SWORD_SLASH_AUDIO = Engine.load_audio(_folderpath.."sword_slash.ogg")
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."exe1-spawn.ogg")
local AUDIO_WARP = Engine.load_audio(_folderpath.."blues-warp.ogg")
local AUDIO_PLAYER = Engine.load_audio(_folderpath.."exe3-spawn.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local blues = {
    codes = {"B"},
    shortname = "Blues",
    damage = DAMAGE,
    time_freeze = true,
    element = Element.None,
    description = "SuprWdSwd cuts nrst enmy clmn",
    long_description = "Super Wide Sword cut to the nearest enemy column",
    can_boost = true,
    card_class = CardClass.Mega,
    limit = 1
}

blues.card_create_action = function(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local team = user:get_team()
        local field = user:get_field()
        local facing = user:get_facing()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local team_check = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end

        --[[local tile = nil
		if team == Team.Red then
			if facing == Direction.Right then
				tile = field:tile_at(1, self_Y)
			else
				tile = field:tile_at(6, self_Y)
			end
		else
			if facing == Direction.Left then
				tile = field:tile_at(6, self_Y)
			else
				tile = field:tile_at(1, self_Y)
			end
		end]]

        local tile_array = {}
		local tile_front_U2 = nil
		local tile_front_U1 = nil
		local tile_front_F1 = nil
		local tile_front_D1 = nil
		local tile_front_D2 = nil
        local enemy_front_U2 = false
        local enemy_front_U1 = false
        local enemy_front_F1 = false
        local enemy_front_D1 = false
        local enemy_front_D2 = false

        for i = 1, 6, 1 do
            ------
            tile_front_F1 = self_tile:get_tile(facing, i)
            tile_front_U1 = tile_front_F1:get_tile(Direction.Up,   1)
            tile_front_U2 = tile_front_F1:get_tile(Direction.Up,   2)
            tile_front_D1 = tile_front_F1:get_tile(Direction.Down, 1)
            tile_front_D2 = tile_front_F1:get_tile(Direction.Down, 2)
            ------
            enemy_front_U2 = tile_front_U2 and not tile_front_U2:is_edge() and tile_front_U2 ~= nil and #tile_front_U2:find_characters(team_check) > 0
            enemy_front_U1 = tile_front_U1 and not tile_front_U1:is_edge() and tile_front_U1 ~= nil and #tile_front_U1:find_characters(team_check) > 0
            enemy_front_F1 = tile_front_F1 and not tile_front_F1:is_edge() and tile_front_F1 ~= nil and #tile_front_F1:find_characters(team_check) > 0
            enemy_front_D1 = tile_front_D1 and not tile_front_D1:is_edge() and tile_front_D1 ~= nil and #tile_front_D1:find_characters(team_check) > 0
            enemy_front_D2 = tile_front_D2 and not tile_front_D2:is_edge() and tile_front_D2 ~= nil and #tile_front_D2:find_characters(team_check) > 0
            ------
            if i == 1 then
                if enemy_front_U1 or enemy_front_F1 or enemy_front_D1 then
                    print("Nearest enemy column X: "..tile_front_F1:x())
                    table.insert(tile_array, tile_front_F1:get_tile(Direction.reverse(facing), 1))
                    break
                end
            elseif i >= 2 then
                if enemy_front_U2 or enemy_front_U1 or enemy_front_F1 or enemy_front_D1 or enemy_front_D2 then
                    print("Nearest enemy column X: "..tile_front_F1:x())
                    table.insert(tile_array, tile_front_F1:get_tile(Direction.reverse(facing), 1))
                    break
                end
            end
        end

		local step1 = Battle.Step.new()

        self.blues = nil
        self.tile  = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_2 = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.blues = Battle.Artifact.new()
                ref.blues:set_facing(facing)
                local blues_sprite = ref.blues:sprite()
		    	blues_sprite:set_texture(BLUES_TEXTURE, true)
		    	blues_sprite:set_layer(-3)
                local blues_anim = ref.blues:get_animation()
                blues_anim:load(BLUES_ANIMPATH)
                blues_anim:set_state("SPAWN")
                blues_anim:refresh(blues_sprite)
                --[[if ref.tile ~= nil and not ref.tile:is_hole() and targeted then
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") is NOT a hole!")
                    blues_anim:set_state("SPAWN")
		    	    blues_anim:refresh(blues_sprite)
				else
					print("Tile ("..ref.tile:x()..";"..ref.tile:y()..") IS a hole!")
                    blues_anim:set_state("SPAWN_HOLE")
		    	    blues_anim:refresh(blues_sprite)
				end]]
                blues_anim:set_playback(Playback.Once)
                blues_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                local bc_state = nil
                local bc_tile = nil
                if facing == Direction.Right then
                    if ref.tile:x() + 1 == field:tile_at(tile_array[1]:x(), 2):x() then
                        bc_tile = field:tile_at(tile_array[1]:x(), 2)
                        bc_state = "ATTACK"
                    else
                        bc_tile = ref.tile:get_tile(facing, 1)
                        bc_state = "WARP"
                    end
                else
                    if ref.tile:x() - 1 == field:tile_at(tile_array[1]:x(), 2):x() then
                        bc_tile = field:tile_at(tile_array[1]:x(), 2)
                        bc_state = "ATTACK"
                    else
                        bc_tile = ref.tile:get_tile(facing, 1)
                        bc_state = "WARP"
                    end
                end
                blues_anim:on_frame(8, function()
                    Engine.play_audio(AUDIO_WARP, AudioPriority.Highest)
                end)
                blues_anim:on_frame(9, function()
                    spawn_blues_copy(user, props, team, facing, bc_state, field, bc_tile, field:tile_at(tile_array[1]:x(), 2), field:tile_at(tile_array[1]:x(), 2):x(), ref.blues)
                    --[[if targeted then
                        spawn_blues_copy(user, props, team, facing, "COPY", field, enemy_tile, team_check, dark_query, ref.blues, 1)
                    else
                        blues_anim:set_state("DELAY")
                        blues_anim:refresh(blues_sprite)
                    end]]
                end)
                field:spawn(ref.blues, ref.tile)
            end
            local anim = ref.blues:get_animation()
            if anim:get_state() == "DELAY1" or anim:get_state() == "DELAY2" then
                if do_once_2 then
                    do_once_2 = false
                    anim:on_complete(function()
                        ref.blues:erase()
                        Engine.play_audio(AUDIO_PLAYER, AudioPriority.High)
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function spawn_blues_copy(user, props, team, facing, state, field, tile, target_tile, tile_X, blues)
    local spawn_next
    spawn_next = function()
        local blues_copy = Battle.Artifact.new()
        blues_copy:set_facing(facing)
        local copy_sprite = blues_copy:sprite()
        copy_sprite:set_texture(BLUES_TEXTURE, true)
        copy_sprite:set_layer(-3)
        local copy_anim = blues_copy:get_animation()
        copy_anim:load(BLUES_ANIMPATH)
        copy_anim:set_state(state)
        copy_anim:refresh(copy_sprite)
        --[[copy_anim:on_frame(1, function()
            Engine.play_audio(AUDIO_WARP, AudioPriority.Highest)
        end)]]
        copy_anim:on_frame(5, function()
            if state == "ATTACK" then
                Engine.play_audio(SWORD_SLASH_AUDIO, AudioPriority.High)
                print("WideSword attack tile: ("..tile:get_tile(facing, 1):get_tile(Direction.Up, 1):x()..";"..tile:get_tile(facing, 1):get_tile(Direction.Up, 1):y()..")")
                print("WideSword attack tile: ("..tile:get_tile(facing, 1):x()..";"..tile:get_tile(facing, 1):y()..")")
                print("WideSword attack tile: ("..tile:get_tile(facing, 1):get_tile(Direction.Down, 1):x()..";"..tile:get_tile(facing, 1):get_tile(Direction.Down, 1):y()..")")
                create_effect(facing, SWORD_SLASH_TEXTURE, SWORD_SLASH_ANIMPATH, "WIDE", 0, 0, -9, field, tile:get_tile(facing, 1))
                create_attack(user, props, team, facing, field, tile:get_tile(facing, 1):get_tile(Direction.Up, 1))
                create_attack(user, props, team, facing, field, tile:get_tile(facing, 1))
                create_attack(user, props, team, facing, field, tile:get_tile(facing, 1):get_tile(Direction.Down, 1))
            end
        end)
        copy_anim:on_complete(function()
            if state == "WARP" then
                if facing == Direction.Right then
                    if blues_copy:get_current_tile():x() + 1 == tile_X then
                        tile = target_tile
                        state = "ATTACK"
                        copy_anim:set_state("ATTACK")
                        copy_anim:refresh(copy_sprite)
                    else
                        tile = tile:get_tile(facing, 1)
                    end
                else
                    if blues_copy:get_current_tile():x() - 1 == tile_X then
                        tile = target_tile
                        state = "ATTACK"
                        copy_anim:set_state("ATTACK")
                        copy_anim:refresh(copy_sprite)
                    else
                        tile = tile:get_tile(facing, 1)
                    end
                end
                if not blues_copy:get_current_tile():is_edge() then
                    spawn_next()
                else
                    blues:get_animation():set_state("DELAY2")
                    blues:get_animation():refresh(blues:sprite())
                end
                Engine.play_audio(AUDIO_WARP, AudioPriority.Highest)
            elseif state == "ATTACK" then
                blues:get_animation():set_state("DELAY1")
                blues:get_animation():refresh(blues:sprite())
            end
            blues_copy:erase()
        end)

        field:spawn(blues_copy, tile)
    end

    spawn_next()
end

function create_attack(user, props, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Shake, 
            props.element, 
            user:get_id(), 
            Drag.None
        )
    )

    local anim = spell:get_animation()
    anim:load(_folderpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function()
        spell:erase()
    end)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, ent)
		if Battle.Obstacle.from(ent) == nil then
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
			end
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.High)
		end
	end

    spell.can_move_to_func = function(tile)
        return true
    end

    spell.delete_func = function(self)
        self:erase()
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return blues