nonce = function() end
 
local AUDIO1 = Engine.load_audio(_modpath.."sound.ogg")
 
function package_init(package)
    package:declare_package_id("com.Thor.card.SwapFire")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({"*"})
 
    local props = package:get_card_props()
    props.shortname = "SwapFire"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Fire
    props.secondary_element = Element.None
    props.description = "Navi Fire Element"
    props.card_class = CardClass.Standard
    props.limit = 5

end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")

	action.execute_func = function(self, user)
        actor:set_color(Color.new(255,0,0,200))
		actor:set_element(Element.Fire)
        Engine.play_audio(AUDIO1, AudioPriority.Low)    
    end
    return action
end
