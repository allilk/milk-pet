nonce = function() end

local AUDIO = Engine.load_audio(_modpath .. "sfx.ogg")
local BURST_TEXTURE = Engine.load_texture(_modpath .. "spread_impact.png")
local bolt = Engine.load_texture(_modpath .. "attack.png")
local AUDIO_HIT = Engine.load_audio(_modpath .. "hitsound.ogg")


function package_init(package) --The basic chp data is defined here
    package:declare_package_id("DJ.Sparker1") --The MOD's ID. Always make it unique as otherwise if you have the same ID as another chip; only 1 will load
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png")) --This is the tiny icon that goes in the chip select pez despenser slots
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png")) --This is the actual chip art
    package:set_codes({ "L", "Q", "V" }) --These are the codes of the chip in game

    local props = package:get_card_props() --Define the stat data for the chip here
    props.shortname = "Sparker1" --The name of the chip as it appears in game
    props.damage = 100 --This is the damage of the chip
    props.time_freeze = false --This determines if the chip time freezes when used or not
    props.element = Element.Elec --This determines the chip's Element
    props.secondary_element = Element.None --This determines the chip's Second Element, but currently does not work in the Engine
    props.description = "Sparking Lightning" --This is the description of the chip that shows up under the chip art. The text limit is low; so don't write too much here.
    props.long_description = "Fire a sparking bolt ahead!" --This is extra text that you can get by checking the chip for more info in game. It doesn't really have the same text limit
    props.limit = 3
end --Always end functions with an end at the end

local function create_thunder(user, props, tile, spell_list, first) --This defines the actual damage hitbox; makes sure that you only have User OR Actor and Props here. Not both Actor + User, Props
    local spell = Battle.Spell.new(user:get_team()) --Required to define the actual spell being referenced, and sets the team to that of the user
    spell:set_hit_props(--calls back to the hit props in funciton package_init(package) above
        HitProps.new(--needed to work
            props.damage,
            --looks at damage above, and copies it; needs to be done in this format to be boostable by 2x effects / atk+ chips
            Hit.Impact | Hit.Flinch | Hit.Flash,
            --Impact = needs to actually collide with something to damage, Stun = Paralyze, Flash = makes them in the Invis like state
            props.element, --looks at the Element defined above and copies it
            user:get_context(), --looks at the user of the chip to get context for other things such as direction
            Drag.None--you do not push the target around when hit
        )
    )
    local tile_array = {}
    local self_tile = user:get_tile()
    local y = self_tile:y()
    local x = self_tile:x()
    local increment = 1
    local field = user:get_field()

    

    spell.has_spawned = false --makes a note on if the spell has gone through yet
    spell.tile = nil
    spell.on_spawn_func = function(self)
        if self.tile == nil then self.tile = self:get_tile() end
        self.has_spawned = true
    end

    spell.collision_func = function(self, other)
        print("Collision on "..self.tile:x())
        local can_spread = true

        for i=1, #spell_list
        do
            can_spread = can_spread and spell_list[i].hitbox_once
        end

        if can_spread then
            local tile = other:get_tile()
            spawn_slash_hitbox(self, tile, Direction.Right)
            spawn_slash_hitbox(self, tile, Direction.DownRight)
            spawn_slash_hitbox(self, tile, Direction.Down)
            spawn_slash_hitbox(self, tile, Direction.DownLeft)
            spawn_slash_hitbox(self, tile, Direction.Left)
            spawn_slash_hitbox(self, tile, Direction.UpLeft)
            spawn_slash_hitbox(self, tile, Direction.Up)
            spawn_slash_hitbox(self, tile, Direction.UpRight)
            spell.hitbox_once = false
        end
    end

    spell.attack_once = true
    spell.hitbox_once = true
    spell.update_func = function(self, dt)
        self.tile:attack_entities(self)
        self.tile:highlight(Highlight.Solid)
        
    spell.attack_func = function()
		Engine.play_audio(AUDIO_HIT, AudioPriority.Highest)
	end

    end
    
    

    table.insert(spell_list, spell)

    user:get_field():spawn(spell, tile)

    if first then 
        if user:get_facing() == Direction.Left then increment = -1 end
        for i = 1, 6, 1 do
            local prospective_tile = field:tile_at(x + (i * increment), y)
            if prospective_tile and not prospective_tile:is_edge() then
                table.insert(tile_array, prospective_tile)
            end
        end

        for i = 1, #tile_array, 1 do
            create_thunder(user, props, tile_array[i], spell_list, false)
        end

    end


end

function spawn_slash_hitbox(user, user_tile, direction)
    local tile = user_tile:get_tile(direction, 1)
    if not tile or tile and tile:is_edge() then return end
    tile:highlight(Highlight.Solid)
    local hitbox = Battle.SharedHitbox.new(user, 1)
    hitbox:set_hit_props(user:copy_hit_props())
    user:get_field():spawn(hitbox, tile)

    local fx = Battle.Spell.new(user:get_team())
    local fx_anim = fx:get_animation()
    local fx_sprite = fx:sprite()
    fx:set_texture(BURST_TEXTURE, true)
    fx_sprite:set_layer(-2)
    fx_anim:load(_modpath .. "spread_impact.animation")
    fx_anim:set_state("DEFAULT")
    fx_anim:refresh(fx_sprite)
    fx:set_height(-16.0)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    user:get_field():spawn(fx, tile)
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local field = user:get_field()
    local frame1 = { 1, 0.017 } --buster shot speed(actually im confused wut u do)(nvm u are bustr speed?)
    local frame2 = { 1, 0.100 }
    local frame3 = { 2, 0.100 }
    local frames = make_frame_data(
        {
            frame1,
            frame2, frame3, frame2, frame3
        }
    )
    action:override_animation_frames(frames)
    action:set_lockout(make_animation_lockout())


    local spell_list = {}

    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(Engine.load_texture(_modpath .. "attack.png", true))
        buster_sprite:set_layer(-2)

        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "attack.animation", true)
        buster_anim:set_state("DEFAULT")--now this wont stay...(fixed?)
        
        buster_anim:refresh(buster_sprite)

        self.thunder = nil
        self.animate_component = nil

        self:add_anim_action(3, function()
            local tile = user:get_tile(user:get_facing(), 1)
            self.thunder = create_thunder(user, props, tile, spell_list, true)-- 1/29/23 i givve up lol
            Engine.play_audio(AUDIO, AudioPriority.High)
            local bolt = buster_sprite:create_node()

            bolt:set_texture(Engine.load_texture(_modpath .. "attack.png")) --loads the sprite sheet from the png 
            local bolt_anim =  Engine.Animation.new(_modpath .. "attack.animation") --loads the animation from the .animation file
            bolt_anim:set_state("DEFAULT2")
            bolt_anim:set_playback(Playback.Loop) --loops the animation (deffo not doing so?)(fixed)(unfixed)
            bolt_anim:refresh(bolt)
            self.animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
            self.animate_component.on_update_func = function(comp, dt)
                bolt_anim:update(dt, bolt)
            end
            bolt_anim:on_complete(function()
                if self.thunder ~= nil and not self.thunder:is_deleted() then
                    self.thunder:erase()
                    self.thunder = nil
                end
                if self.animate_component ~= nil then
                    self.animate_component:eject()
                    self.animate_component = nil
                end
            end)
            user:register_component(self.animate_component)
        end)
    end

    action.action_end_func = function(self)
        for i=1, #spell_list 
        do
            local s = spell_list[i]
            if s and not s:is_deleted() then 
                s:delete()
            end
        end

        if self.animate_component ~= nil then
            self.animate_component:eject()
            self.animate_component = nil
        end
        if self.thunder ~= nil and not self.thunder:is_deleted() then
            self.thunder:erase()
            self.thunder = nil
        end
    end


    return action
end
