function package_init(info) 
    info:declare_package_id("Honekaryudo.RunePort.KnightMet")
    info:set_special_description("")
    info:set_speed(1.0)
    info:set_attack(1)
    info:set_charged_attack(10)
    info:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    info:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    info:set_overworld_animation_path(_modpath.."overworld.animation")
    info:set_overworld_texture_path(_modpath.."overworld.png")
    info:set_mugshot_texture_path(_modpath.."mug.png")
    info:set_mugshot_animation_path(_modpath.."mug.animation")
end

local function spawn_shockwave(owner_context, team, field, tile, direction, damage_multiplier, wave_texture, wave_sfx)
    local spawn_next

    spawn_next = function()
        if not tile:is_walkable() then
            return
        end

        Engine.play_audio(wave_sfx, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(
            10 * damage_multiplier,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            owner_context,
            Drag.new()
        ))

        local sprite = spell:sprite()
        sprite:set_texture(wave_texture)

        local animation = spell:get_animation()
        animation:load(_modpath.."shockwave.animation")
        animation:set_state("DEFAULT")
        animation:on_frame(4, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function()
            spell:erase()
        end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function player_init(player)
    player:set_name("KnightMet")
    player:set_health(400)
    player:set_height(41.0)
    player:set_animation(_modpath.."battle.animation")
    player:set_texture(Engine.load_texture(_modpath.."battle.png"), true)
    player:set_fully_charged_color(Color.new(74,178,74,255))
    -- player:set_charge_position(-3, -10)
    player:set_charge_position(1, -17)


    -- hiding section
    local tink_sfx = Engine.load_audio(_modpath.."tink.ogg")
    local hiding = false

    local hiding_defense_rule = Battle.DefenseRule.new(7692, DefenseOrder.Always)

    hiding_defense_rule.can_block_func = function(judge, attacker, defender)
        if not hiding then
            return
        end

        local hitprops = attacker:copy_hit_props()

        if hitprops.flags & Hit.Pierce == Hit.Pierce then
            return
        end

        judge:block_impact()

        if hitprops.damage > 0 then
            judge:block_damage()
            Engine.play_audio(tink_sfx, AudioPriority.Highest)

            local artifact = Battle.Artifact.new()
            artifact:set_texture(Engine.load_texture(_folderpath.."guard_hit.png"))
            artifact:sprite():set_layer(-1)

            local artifact_anim = artifact:get_animation()
            artifact_anim:load(_folderpath.."guard_hit.animation")
            artifact_anim:set_state("DEFAULT")
            artifact_anim:refresh(artifact:sprite())

            artifact_anim:on_complete(function()
                artifact:erase()
            end)

            artifact:set_offset(
                math.floor((math.random() - .5) * player:sprite():get_width()),
                -math.random(math.floor(player:get_height()))
            )

            player:get_field():spawn(artifact, player:get_tile())
        end
    end

    player:add_defense_rule(hiding_defense_rule)

    player.special_attack_func = function(player)
        if hiding then
            return
        end

        local action = Battle.CardAction.new(player, "HIDING_DOWN")
        action:set_lockout(make_sequence_lockout())

        local anim = player:get_animation()

        action.execute_func = function()
            player:get_animation():on_complete(function()
                anim:set_state("HIDING")

                hiding = true
            end)
        end

        local hiding_step = Battle.Step.new()
        local rise_step = Battle.Step.new()
        hiding_step.update_func = function()
            -- can't input attacks at all, directly read inputs to unhide
            if player:input_has(Input.Pressed.Special) then
                anim:set_state("HIDING_UP")
                anim:on_complete(function()
                    player:get_animation():set_state("PLAYER_IDLE")
                    rise_step:complete_step()
                end)

                hiding_step:complete_step()
                hiding = false
            end
        end
        action:add_step(hiding_step)
        action:add_step(rise_step)

        return action
    end

    -- attack section
    local wave_texture = Engine.load_texture(_modpath.."shockwave.png")
    local wave_sfx = Engine.load_audio(_modpath.."shockwave.ogg")

    player.normal_attack_func = function()
    end

    player.charged_attack_func = function(player)
        local action = Battle.CardAction.new(player, "ATTACK")

        action.execute_func = function()
            local animation = player:get_animation()

            animation:on_frame(10, function()
                local direction = player:get_facing()

                spawn_shockwave(
                    player:get_context(),
                    player:get_team(),
                    player:get_field(),
                    player:get_tile(direction, 1),
                    direction,
                    player:get_attack_level(),
                    wave_texture,
                    wave_sfx
                )
            end, true)
        end

        return action
    end
end
