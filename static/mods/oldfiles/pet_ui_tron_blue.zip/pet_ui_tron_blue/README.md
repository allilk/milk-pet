# Installation
- Copy both files and paste them in `resources/ui`
- Overwrite to all


You're done!