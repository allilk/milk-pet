--thank you to dawn and everyone else who helped me make my dreams a reality! I couldnt thank you all enough!
--Navi owned by Cyanman EXE
local sword = include("chargedbusters/Blade/sword.lua")
local blizzard = include("chargedbusters/Aqua/entry.lua")
local Machgun = include("chargedbusters/Buster/entry.lua")
local AirShot = include("chargedbusters/Jester/entry.lua")
local guard = include("guard/guard.lua")
local panelgrab = include("panelgrab/entry.lua")
local IronSwing = include("chargedbusters/Knight/entry.lua")

local function create_special_attack_IronSwing(player)
    local props = Battle.CardProperties:new()
    props.damage = 40 + (player:get_attack_level() * 20)
    local IronSwing_action = IronSwing.card_create_action(player, props)
    return IronSwing_action
end


local function create_special_attack_Machgun(player)
    local props = Battle.CardProperties:new()
    props.damage = 30 + (player:get_attack_level() * 20)
    local Machgun_action = Machgun.card_create_action(player, props)
    return Machgun_action
end

local function create_special_attack_blizzard(player)
    local props = Battle.CardProperties:new()
    props.damage = 30 + (player:get_attack_level() * 20)
    local blizzard_action = blizzard.card_create_action(player, props)
    return blizzard_action
end

local function create_special_attack_guard(player)
    local props = Battle.CardProperties:new()
    props.damage = 40 + (player:get_attack_level() * 10)
    guard.duration = 0.384
    guard.guard_animation = "PROTOGUARD"
    local guard_action = guard.card_create_action(player, props)
    guard_action:set_lockout(make_async_lockout(guard.duration * 2))
    return guard_action
end

local function create_special_attack_grab(player, can_use)
	if can_use then
		local props = Battle.CardProperties:new()
		props.shortname = "Panel Grab"
        props.time_freeze = true
		local grab_action = panelgrab.card_create_action(player, props)
		player:card_action_event(grab_action, ActionOrder.Voluntary)
		can_use = false
	end
	return can_use
end

local function create_special_attack_AirShot(player)
    local props = Battle.CardProperties:new()
    props.damage = 30 + (player:get_attack_level() * 20)
    local Airshot_action = AirShot.card_create_action(player, props)
    return Airshot_action
end

local function create_special_attack_sword(player)
    local props = Battle.CardProperties:new()
    props.damage = 30 + (player:get_attack_level() * 20)
    local sword_action = sword.card_create_action(player, props)
    return sword_action
end

local function execute_special_attack(player)
    return nil
end

local function execute_buster_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

local function execute_charged_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level() * 10)
end

function package_init(info)
    info:declare_package_id("Cyanman")
    info:set_special_description("Cyanman Armor Change Ver.")
    info:set_speed(2.0)
    info:set_attack(1)
    info:set_charged_attack(10)
    info:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    info:set_overworld_animation_path(_folderpath .. "overworld.animation")
    info:set_overworld_texture_path(_folderpath .. "overworld.png")
    info:set_mugshot_texture_path(_folderpath .. "mug.png")
    info:set_mugshot_animation_path(_folderpath .. "mug.animation")
    info:set_emotions_texture_path(_folderpath .. "emotions.png")
end

function player_init(player)
    player:set_name("Cyanman EXE")
    player:set_health(1000)
    player:set_height(49.0)
    player:set_charge_position(1, -20)
    player:set_animation(_folderpath .. "battle.animation")
    player:set_texture(Engine.load_texture(_folderpath .. "battle.png"), true)
    player:set_fully_charged_color(Color.new(255, 255, 255, 255))
    local base_texture = Engine.load_texture(_folderpath .. "battle.png")
    local base_animation_path = _modpath .. ("battle.animation")
    local base_charge_color = Color.new(255, 255, 255, 300)

    --Buster Form
    local Buster = player:create_form()
    Buster:set_mugshot_texture_path(_folderpath .. "Forms/Buster_entry.png")
    Buster.on_activate_func = function()
        -- use Buster assets
        player:set_animation(_folderpath .. "Forms/Buster.animation")
        player:set_texture(Engine.load_texture(_folderpath .. "Forms/Buster.png"), true)
        player:set_fully_charged_color(Color.new(243, 57, 198, 255))
        player:set_element(Element.Cursor)
        player:set_charge_level(player:get_charge_level()+3) --boost charge by 3
    end

    Buster.charged_attack_func = create_special_attack_Machgun

    Buster.on_deactivate_func = function()
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        player:set_animation(base_animation_path)
        -- attack/charge stats are automatically reverted by the engine
    end

    --aqua Form
    local aqua = player:create_form()
    aqua:set_mugshot_texture_path(_folderpath .. "Forms/aqua_entry.png")
    aqua.on_activate_func = function()
        -- use aqua assets
        player:set_animation(_folderpath .. "Forms/aqua.animation")
        player:set_texture(Engine.load_texture(_folderpath .. "Forms/aqua.png"), true)
        player:set_fully_charged_color(Color.new(200, 200, 200, 200))
        player:set_element(Element.Aqua)
        -- buff attack
        player:set_attack_level(player:get_attack_level()+1) --boost attack by 1
    end

    aqua.charged_attack_func = create_special_attack_blizzard

    aqua.on_deactivate_func = function()
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        player:set_animation(base_animation_path)
        -- attack/charge stats are automatically reverted by the engine
    end

    --Knight Form
    local wood = player:create_form()
    wood:set_mugshot_texture_path(_folderpath .. "Forms/wood_entry.png")
    wood.on_activate_func = function()
        -- use wood assets
        player:set_animation(_folderpath .. "Forms/wood.animation")
        player:set_texture(Engine.load_texture(_folderpath .. "Forms/wood.png"), true)
        player:set_fully_charged_color(Color.new(700, 700, 700, 700))
        player:set_element(Element.Wood)
        -- buff attack
        player:set_attack_level(player:get_attack_level()+2) --boost attack by 2
    end

    wood.charged_attack_func = create_special_attack_IronSwing

    wood.special_attack_func = create_special_attack_guard

    wood.on_deactivate_func = function()
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        player:set_animation(base_animation_path)
        -- attack/charge stats are automatically reverted by the engine
    end

    --Jester Form
    local jester = player:create_form()
    jester:set_mugshot_texture_path(_folderpath .. "Forms/jester_entry.png")
    jester.on_activate_func = function()
        -- use Jester assets
        player:set_animation(_folderpath .. "Forms/jester.animation")
        player:set_texture(Engine.load_texture(_folderpath .. "Forms/jester.png"), true)
        player:set_fully_charged_color(Color.new(60, 1, 79, 23))
        player:set_element(Element.Summon)
        -- buff attack
        player:set_charge_level(player:get_charge_level()+1) --boost charge by 1
    end

	local panel_grab_cooldown_max = 1800
	local panel_grab_current_cooldown = 0
	local can_use_panel_grab = true
	jester.update_func = function(self, dt)
		if panel_grab_current_cooldown <= 0 then
			if not can_use_panel_grab then
                can_use_panel_grab = true
            end
		else
			panel_grab_current_cooldown = panel_grab_current_cooldown - 1
		end
	end

	jester.special_attack_func = function()
        if can_use_panel_grab then
		    can_use_panel_grab = create_special_attack_grab(player, can_use_panel_grab)
            panel_grab_current_cooldown = panel_grab_cooldown_max
        end
		return nil
	end
    jester.charged_attack_func = create_special_attack_AirShot

    jester.on_deactivate_func = function()
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        player:set_animation(base_animation_path)
        -- attack/charge stats are automatically reverted by the engine
    end

    --Blade Form
    local blade = player:create_form()
    blade:set_mugshot_texture_path(_folderpath .. "Forms/blade_entry.png")
    blade.on_activate_func = function()
        -- use blade assets
        player:set_animation(_folderpath .. "Forms/blade.animation")
        player:set_texture(Engine.load_texture(_folderpath .. "Forms/blade.png"), true)
        player:set_fully_charged_color(Color.new(999, 999, 999, 0))
        player:set_element(Element.Sword)
        --boost attack & charge by 2
        player:set_attack_level(player:get_attack_level()+2)
        player:set_charge_level(player:get_charge_level()+2)
    end

    blade.charged_attack_func = create_special_attack_sword

    blade.on_deactivate_func = function()
        player:set_texture(base_texture)
        player:set_fully_charged_color(base_charge_color)
        player:set_animation(base_animation_path)
        -- attack/charge stats are automatically reverted by the engine
    end

    player.normal_attack_func = execute_buster_attack
    player.charged_attack_func = execute_charged_attack
    player.special_attack_func = execute_special_attack
end