local DAMAGE = 50

local METEOR_TEXTURE = Engine.load_texture(_modpath.."meteor.png")
local METEOR_ANIMPATH = _modpath.."meteor.animation"
local ATTACK_ANIMPATH = _modpath.."attack.animation"
local AUDIO_METEOR = Engine.load_audio(_modpath.."meteor.ogg")

local BOOM_TEXTURE = Engine.load_texture(_modpath.."boom.png")
local BOOM_ANIMPATH = _modpath.."boom.animation"
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath .. "effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-163-MeteorRain1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"G","L","S","*"})

    local props = package:get_card_props()
    props.shortname = "MtrRain1"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "Fires 5 meteors at enemy!"
    props.long_description = "Fires 5 meteors at a nearby enemy in front of you!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_async_lockout(2.237))
    local override_frames = {{1,0.015},{1,0.050}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local tile = nil
		if team == Team.Red then
			if direction == Direction.Right then
				tile = field:tile_at(1, Y)
			else
				tile = field:tile_at(6, Y)
			end
		else
			if direction == Direction.Left then
				tile = field:tile_at(6, Y)
			else
				tile = field:tile_at(1, Y)
			end
		end

		local tile_array1 = {}
        local tile_array2 = {}
		local count = 1
		local max = 6
		local tile_front = nil
        local enemy_front = false
		local check_front = false
        local targeted = false

        local check = function(ent)
            if not user:is_team(ent:get_team()) then
				return true
			end
        end
        local checkOBS = function(ent)
            return true
        end
		
		for i = count, max, 1 do

			tile_front = tile:get_tile(direction, i)
			
			enemy_front = tile_front and #tile_front:find_characters(check) > 0 and #tile_front:find_obstacles(checkOBS) <= 0
            
            if enemy_front then
                targeted = true
                table.insert(tile_array1, tile_front)
				break
            end
		end

        for i = count, max, 1 do

			tile_front = tile:get_tile(direction, i)

            check_front = tile_front and not user:is_team(tile_front:get_team()) and not tile_front:is_edge() and not tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(direction), 1):get_team())

            if check_front then
                table.insert(tile_array2, tile_front)
                break
            end
		end

        self:add_anim_action(1,function()
            if targeted then
                spawner_meteor(user, props, tile_array1[1], team, direction, field)
            else
                spawner_meteor(user, props, tile_array2[1], team, direction, field)
            end
        end)
    end
    return action
end

function spawner_meteor(owner, props, tile, team, direction, field)
    local meteorspawner = Battle.Spell.new(team)
    meteorspawner:set_facing(direction)
    meteorspawner:highlight_tile(Highlight.Flash)

    local spawner_anim = meteorspawner:get_animation()
    spawner_anim:load(ATTACK_ANIMPATH)
    spawner_anim:set_state("0")
    spawner_anim:on_frame(2, function()
        spawn_meteor(owner, props, tile, team, direction, field)
    end)
    spawner_anim:on_frame(3, function()
        spawn_meteor(owner, props, tile, team, direction, field)
    end)
    spawner_anim:on_frame(4, function()
        spawn_meteor(owner, props, tile, team, direction, field)
    end)
    spawner_anim:on_frame(5, function()
        spawn_meteor(owner, props, tile, team, direction, field)
    end)
    spawner_anim:on_frame(6, function()
        spawn_meteor(owner, props, tile, team, direction, field)
    end)
    spawner_anim:on_complete(function()
        meteorspawner:erase()
    end)

    meteorspawner.can_move_to_func = function(tile)
        return true
    end
    
    field:spawn(meteorspawner, tile)
end

function spawn_meteor(owner, props, tile, team, direction, field)
    local spawn_meteor
    spawn_meteor = function()
        Engine.play_audio(AUDIO_METEOR, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(Direction.Right)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.new())
        )
        spell.attacked = false

        local sprite = spell:sprite()
        sprite:set_texture(BOOM_TEXTURE)
        sprite:set_layer(-99)

        local animation = spell:get_animation()
        animation:load(BOOM_ANIMPATH)
        animation:set_state("0")
        animation:refresh(sprite)
        animation:on_complete(function() 
            spell:erase()
        end)

        local meteor = Battle.Artifact.new()
        meteor:set_facing(direction)
        meteor:highlight_tile(Highlight.Solid)
        local meteor_sprite = meteor:sprite()
        meteor_sprite:set_layer(-11)
        meteor_sprite:set_texture(METEOR_TEXTURE, true)
        local meteor_anim = meteor:get_animation()
	    meteor_anim:load(METEOR_ANIMPATH)
	    meteor_anim:set_state("0")
	    meteor_anim:refresh(meteor_sprite)
        meteor_anim:on_frame(9, function()
            if not tile:is_hole() then
                meteor:shake_camera(9, 0.25)
                field:spawn(spell, tile)
            end
        end, true)
        meteor_anim:on_complete(function()
            meteor:erase()
        end)
        
        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
            animation:on_frame(1, function()
                if not spell.attacked then
                    Engine.play_audio(AUDIO_BOOM, AudioPriority.Highest)
                end
            end)
        end

        spell.attack_func = function()
            spell.attacked = true
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "FIRE", math.random(-15,15), math.random(-15,15), field, spell:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(meteor, tile)
    end

    spawn_meteor()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end