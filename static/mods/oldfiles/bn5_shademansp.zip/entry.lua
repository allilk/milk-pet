local DAMAGE = 190

-- Resource loads
local TEXTURE_NAVI = Engine.load_texture(_modpath .. "shademan.png")
local ANIMPATH_NAVI = _modpath .. "shademan.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath .. "navispawn.ogg")
local AUDIO_PULSE = Engine.load_audio(_modpath .. "elecpulse.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath .. "hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.card.shademansp")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "S" })

    local props = package:get_card_props()
    props.shortname = "ShadeMnSP"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "CrshNoise attck all direction"
    props.long_description = "CrshNoise pulse attack ahead."
    props.can_boost = true
    props.card_class = CardClass.Mega
    props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
        actor:hide()

        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local field = user:get_field()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(user:get_facing())
                ref.navi:set_texture(TEXTURE_NAVI, true)
                ref.navi:sprite():set_layer(-1)
                ref.navi.move_done = false

                navi_anim = ref.navi:get_animation()
                navi_anim:load(ANIMPATH_NAVI)
                navi_anim:set_state("WARP_IN")
                navi_anim:refresh(ref.navi:sprite())
                Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                navi_anim:on_complete(function()

                    navi_anim:set_state("WING_OPEN")
                    navi_anim:on_complete(function()
                        navi_anim:on_complete(function()
                            do_noise_crush(ref.navi, navi_anim)
                        end)
                    end)
                end)

                field:spawn(ref.navi, ref.tile)
            end
            if (ref.navi.move_done) then
                ref.navi:erase()
                step1:complete_step()
            end
            local anim = ref.navi:get_animation()


        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function do_noise_crush(self, anim)
    local field = self:get_field()
    local anim = self:get_animation()
    anim:set_state("WING_LOOP")
    self:toggle_counter(true)

    local noise_crush = create_noise_crush(self)
    local noise_fx = Battle.Spell.new(self:get_team())
    noise_fx:set_facing(self:get_facing())
    noise_fx:set_texture(self:get_texture())
    noise_fx:sprite():set_layer(-2)
    local noise_fx_anim = noise_fx:get_animation()
    noise_fx_anim:copy_from(self:get_animation())
    noise_fx_anim:set_state("NOISE_CRUSH")
    noise_fx_anim:refresh(noise_fx:sprite())
    noise_fx_anim:set_playback(Playback.Loop)
    anim:on_frame(1, function()
        Engine.play_audio(AUDIO_PULSE, AudioPriority.High)
        field:spawn(noise_crush, self:get_tile(self:get_facing(), 1))
        field:spawn(noise_fx, self:get_tile(self:get_facing(), 1))
    end)
    anim:on_frame(16, function() end)
    anim:on_complete(function(act)
        if not noise_crush:is_deleted() then noise_crush:delete() end
        noise_fx:erase()
        anim:set_state("WING_CLOSE")
        anim:on_complete(function()
            anim:set_state("WARP_OUT")
            anim:on_complete(function()
                self.move_done = true
            end)
        end)
    end)
end

function create_noise_crush(shademan)
    print("Shademan Pulse!")
    local spell = Battle.Spell.new(shademan:get_team())
    spell:set_facing(shademan:get_facing())
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            DAMAGE,
            Hit.Impact | Hit.Pierce | Hit.Retangible,
            Element.None,
            shademan:get_context(),
            Drag.None
        )
    )
    local do_once = true
    local spell_timer = 999
    local forward_tile = nil
    local up_tile = nil
    local down_tile = nil
    local spawn_timer = 16
    local has_hit = false
    spell.update_func = function(self, dt)
        if do_once then
            spell_timer = 48
            do_once = false
            forward_tile = self:get_tile(self:get_facing(), 1)
            up_tile = forward_tile:get_tile(Direction.Up, 1)
            down_tile = forward_tile:get_tile(Direction.Down, 1)
        end
        if forward_tile and not forward_tile:is_edge() then forward_tile:highlight(Highlight.Solid) end
        if up_tile and not up_tile:is_edge() then up_tile:highlight(Highlight.Solid) end
        if down_tile and not down_tile:is_edge() then down_tile:highlight(Highlight.Solid) end
        if spawn_timer <= 0 then
            self:get_tile():attack_entities(self)
            forward_tile:attack_entities(self)
            up_tile:attack_entities(self)
            down_tile:attack_entities(self)
            if spell_timer <= 0 then
                self:delete()
            else
                spell_timer = spell_timer - 1
            end
        else
            spawn_timer = spawn_timer - 1
        end
    end
    spell.attack_func = function(self, other)
        local hitbox = Battle.Hitbox.new(self:get_team())
        local props = HitProps.new(
            0,
            Hit.Stun,
            Element.None,
            nil,
            Drag.None
        )
        hitbox:set_hit_props(props)
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
        shademan:get_field():spawn(hitbox, other:get_tile())
        self:erase()
    end
    return spell
end
