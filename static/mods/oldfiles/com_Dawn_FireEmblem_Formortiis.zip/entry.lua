nonce = function() end

function package_init(package) 
	package:declare_package_id("com.Dawn.FireEmblem.Formortiis")
	package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({'F'})
	
	local props = package:get_card_props()
	props.shortname = "Ravager"
	props.damage = 300
	props.time_freeze = true
	props.element = Element.Break
	props.description = "DEMON KING SHATTERS"
	props.limit = 1
	props.card_class = CardClass.Giga
	props.can_boost = false
end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		local step1 = Battle.Step.new()
		local field = user:get_field()
		local user_tile = user:get_tile()
		local tile_array = {}
		local friendly_query = function(ent)
			if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
				if user:is_team(ent:get_team()) then
					return true
				end
			end
		end
		for x = 1, 6, 1 do
			for y = 1, 3, 1 do
				local tile = field:tile_at(x, y)
				if tile ~= user_tile and #tile:find_entities(friendly_query) == 0 then
					table.insert(tile_array, tile)
				end
			end
		end
		local do_once = true
		local do_once_again = true
		local cooldown = 4
		local is_finished = false
		local ref = self
		self.finish_cooldown = 99999999
		step1.update_func = function(self, dt)
			if do_once then
				ref:get_actor():hide()
				do_once = false
				Engine.stream_music(_folderpath.."fort.mid")
				ref.formortiis = Battle.Artifact.new()
				ref.formortiis:set_facing(user:get_facing())
				ref.formortiis:set_texture(Engine.load_texture(_folderpath.."Formortiis.png"), true)
				ref.formortiis:sprite():set_layer(-1)
				
				local boss_anim = ref.formortiis:get_animation()
				boss_anim:load(_folderpath.."Formortiis.animation")
				boss_anim:set_state("BODY")
				boss_anim:refresh(ref.formortiis:sprite())
				
				ref.arm = Battle.Artifact.new()
				ref.arm:set_facing(user:get_facing())
				ref.arm:set_texture(Engine.load_texture(_folderpath.."Formortiis.png"), true)
				ref.arm:sprite():set_layer(-2)
				
				local arm_anim = ref.arm:get_animation()
				arm_anim:load(_folderpath.."Formortiis.animation")
				arm_anim:set_state("ARM_IDLE")
				arm_anim:refresh(ref.arm:sprite())
				ref.original_offset_arm = ref.arm:get_offset()
				ref.original_offset_body = ref.formortiis:get_offset()
				if user:get_facing() == Direction.Right then
					ref.formortiis:set_offset(ref.original_offset_body.x - 12, ref.original_offset_body.y + 100)
					ref.arm:set_offset(ref.original_offset_arm.x - 12, ref.original_offset_arm.y + 100)
				elseif user:get_facing() == Direction.Left then
					ref.formortiis:set_offset(ref.original_offset_body.x + 12, ref.original_offset_body.y + 100)
					ref.arm:set_offset(ref.original_offset_arm.x + 12, ref.original_offset_arm.y + 100)
				end
				
				field:spawn(ref.formortiis, user_tile)
				field:spawn(ref.arm, user_tile)
			end
			if ref.formortiis:get_offset().y ~= ref.original_offset_body.y and ref.arm:get_offset().y ~= ref.original_offset_arm.y then
				ref.formortiis:set_offset(ref.formortiis:get_offset().x, ref.formortiis:get_offset().y - 0.5)
				ref.arm:set_offset(ref.arm:get_offset().x, ref.arm:get_offset().y - 0.5)
			else
				if do_once_again then
					do_once_again = false
					ref.arm:get_animation():set_state("ARM")
					ref.arm:get_animation():refresh(ref.arm:sprite())
					ref.arm:get_animation():on_complete(function()
						ref.arm:shake_camera(15, 2.0)
						create_flashlight(field, action)
						for k = 1, #tile_array, 1 do
							local spell = create_attack(user, props)
							field:spawn(spell, tile_array[k])
						end
					end)
				end
				ref.finish_cooldown = ref.finish_cooldown - 1
				if ref.finish_cooldown <= 0 then
					is_finished = true
				end
			end
			if is_finished then
				ref.arm:erase()
				ref.formortiis:erase()
				ref:get_actor():reveal()
				self:complete_step()
			end
		end
		self:add_step(step1)
	end
	return action
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_texture(Engine.load_texture(_folderpath.."spell_explosion.png"), true)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
            props.element,
            user:get_context(),
            Drag.None
        )
    )
	local anim = spell:get_animation()
    anim:load(_folderpath.."spell_explosion.animation")
    anim:set_state("Default")
	anim:on_complete(function()
		spell:erase()
	end)
	spell:sprite():set_layer(-1)
	local query = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
		if #self:get_tile():find_entities(query) > 0 then
			self:get_tile():set_state(TileState.Cracked)
		else
			self:get_tile():set_state(TileState.Broken)
		end
    end
	
	spell.collision_func = function(self, other)
	end
	spell.can_move_to_func = function(self, other)
		return true
	end
	spell.battle_end_func = function(self)
		spell:erase()
	end
	return spell
end

function create_flashlight(field, action)
	local TEXTURE_FLASHLIGHT = Engine.load_texture(_folderpath.."flashlight.png")
    local ANIMPATH_FLASHLIGHT = _folderpath.."flashlight.animation"
	local flashlight = Battle.Artifact.new()
	flashlight:set_facing(Direction.Right)
	local flashlight_anim = flashlight:get_animation()
	flashlight:set_texture(TEXTURE_FLASHLIGHT, true)
	flashlight:sprite():set_layer(10)
	flashlight_anim:load(ANIMPATH_FLASHLIGHT)
	flashlight_anim:set_state("DEFAULT")
	flashlight_anim:refresh(flashlight:sprite())
	flashlight_anim:on_complete(function()
		flashlight:erase()
	end)
	action.finish_cooldown = 120
	field:spawn(flashlight, 1, 1)
end