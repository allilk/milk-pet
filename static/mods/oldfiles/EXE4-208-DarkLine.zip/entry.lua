local DAMAGE = 0

local AUDIO_DARKHOLE = Engine.load_audio(_modpath.."darkhole.ogg")

function package_init(package) 
    package:declare_package_id("com.Dawn.k1rbyat1na.EXE4-208-DarkLine")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"L"})

    local props = package:get_card_props()
    props.shortname = "DarkLine"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Turns rows into DarkHoles!"
	props.long_description = "Turns all rows you are in into Dark Holes!"
	props.can_boost = false
	props.card_class = CardClass.Mega
	props.limit = 1
end

function create_dark_hole(user, tile)
	local TEXTURE = Engine.load_texture(_modpath.."Hole.png")
	local cube = Battle.Obstacle.new(Team.Other)
	cube:share_tile(true)
	cube:toggle_hitbox(false)
	cube:set_name("DarkHole")
	cube:set_health(0)
	cube:set_facing(user:get_facing())
	cube:set_texture(TEXTURE, true)
	cube:sprite():set_layer(10)
	local anim = cube:get_animation()
	anim:load(_modpath.."Hole.animation")
	anim:set_state("DEFAULT")
	anim:refresh(cube:sprite())
	anim:set_playback(Playback.Loop)
	cube.on_spawn_func = function(self)
		local tile = cube:get_tile()
		if not tile:is_walkable() then
			cube:delete()
		end
		tile:set_state(TileState.Normal)
	end
	cube.can_move_to_func = function(tile)
		return false
	end
	cube.tile = nil
	cube.update_func = function(self, dt)
		if self.tile == nil then self.tile = self:get_tile() end
		if self.tile:get_state() ~= TileState.Normal then self:delete() end
	end
	--[[local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil
	end
	if #tile:find_entities(query) == 0 and not tile:is_edge() then return cube end]]
	if not tile:is_edge() then return cube end
	return nil
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local step1 = Battle.Step.new()
		local direction = user:get_facing()
		local field = user:get_field()
		local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()
		local dark_hole_query = function(hole)
			return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
		end
		local k = 0
		local do_once = true
		step1.update_func = function(self, dt)
			k = k + 1
			if do_once then
				Engine.play_audio(AUDIO_DARKHOLE, AudioPriority.High)
				do_once = false
				for o = 1, 6, 1 do
					local desired_tile = field:tile_at(o, Y)
					local dark_check = desired_tile:find_obstacles(dark_hole_query)
					if not desired_tile:is_edge() and #dark_check <= 0 then
						local dark_hole = create_dark_hole(user, desired_tile)
						desired_tile:set_state(TileState.Normal)
						field:spawn(dark_hole, desired_tile)
					end
				end
			end
			if k == 50 then
				self:complete_step()
			end	
		end
		self:add_step(step1)
	end
    return action
end