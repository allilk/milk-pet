function package_init(package) 
    package:declare_package_id("com.Dawn.ChargeShots.Searchman")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(85)
    package:set_special_description("You're in my sights.")
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."searchmanOW.animation")
    package:set_overworld_texture_path(_modpath.."searchmanOW.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
end

function player_init(player)
    player:set_name("Searchman")
    player:set_health(1500)
    player:set_element(Element.Cursor)
    player:set_height(60.0)
    player:set_charge_position(0,-30)

    local base_animation_path = _modpath.."searchman_atlas.animation"
    local base_texture = Engine.load_texture(_modpath.."searchman_atlas.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(0,128,0, 255))
    
    player.cursor = nil

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
        local field = player:get_field()
        local enemy_filter = function(character)
            return character:get_team() ~= player:get_team()
        end
        --Find an enemy to attack.
        local enemy_list = field:find_nearest_characters(player, enemy_filter)
        --If one exists, start the scope attack.
        if #enemy_list > 0 then
            local action = Battle.CardAction.new(player, "RIFLE FIRE")
            action.action_end_func = function(self)
                player.cursor:erase() --Erase the cursor if interrupted or action finishes
            end
            action.execute_func = function(self, user)
                --Assign the cursor to the player for later erasure
                player.cursor = create_cursor(player)
                --Play the sound.
                Engine.play_audio(Engine.load_audio(_modpath.."BN5_Lockon.ogg"), AudioPriority.High)
                local target = enemy_list[1]
                local tile = target:get_tile()
                --Spawn the cursor.
                field:spawn(player.cursor, target:get_tile())
                --Hit Props are necessary to deal damage.
                local damage_props = HitProps.new(
                    10 + (player:get_attack_level() * 2), --This is the actual damage amount.
                    Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce, --The flags used. Flinch makes them reel back, Flash makes them mercy invulnerable, and Pierce ignores mercy invuln.
                    Element.Cursor, --The element.
                    player:get_context(), --Used for stuff like knowing who fired the attack.
                    Drag.None --Does it move you when it hits? In this case, no.
                )
                local gun = Engine.load_audio(_modpath.."gun.ogg")
                --This feels silly, but it works, so what's really silly here?
                --In the Searchman animation file I cloned the firing frames.
                --So from frames 2 to 10 there's just him shooting.
                --Which means every even frame (2, 4, 6, 8, 10) I need to spawn a bullet.
                --Thus, I can loop over starting at frame 2 and spawn the shot instead of repeating code.
                for i = 2, 10, 2 do
                    self:add_anim_action(i, function()
                        --Play the gun sound. Always, so Highest priority.
                        Engine.play_audio(gun, AudioPriority.Highest)
                        --If the target exists, spawn the hitbox. We don't want to spawn it otherwise.
                        --That's because the hitbox will linger and hit something else.
                        if not target:is_deleted() then
                            --Make it our team.
                            local hitbox = Battle.Hitbox.new(user:get_team())
                            --Use the props.
                            hitbox:set_hit_props(damage_props)
                            --Spawn it!
                            field:spawn(hitbox, tile)
                        end
                    end)
                end
            end
            return action
        else
            --Just shoot if you can't find an enemy lol.
            return Battle.Buster.new(player, false, player:get_attack_level())
        end
    end
end

function create_cursor(player)
    local cursor = Battle.Spell.new(player:get_team())
    cursor:set_texture(Engine.load_texture(_modpath.."cursor.png"))
    local anim = cursor:get_animation()
    anim:load(_modpath.."cursor.animation")
    cursor:sprite():set_layer(-5)
    cursor:set_offset(0, -20)
    anim:set_state("0")
    anim:refresh(cursor:sprite())
    anim:set_playback(Playback.Loop)
    return cursor
end