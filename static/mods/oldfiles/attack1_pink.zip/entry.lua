function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.Attack1.pink.bn6")
    block:set_name("Attack+1")
    block:set_description("MegaBstr\nAttck +1")
    block:set_color(Blocks.Pink)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_attack_level(
        math.min(player:get_attack_level() + 1, 5)
    )
end
