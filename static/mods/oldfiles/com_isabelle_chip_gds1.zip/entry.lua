nonce = function() end

local gunhilt = Engine.load_texture(_modpath .. "gunhilt.png")
local sunray = Engine.load_texture(_modpath .. "sun_ray.png")

function package_init(package)

    package:declare_package_id("com.EXE6.Card015-GunDelSol1")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'C', 'M', 'T', '*' })

    local props = package:get_card_props()
    props.shortname = "GunDelS1"
    props.time_freeze = false
    props.element = Element.None
    props.limit = 5
    props.card_class = CardClass.Standard
    props.can_boost = false
    props.description = "Hits row 2pnl ahd w/sunshne"
    props.long_description = "Sunshine spread drains HP 2 panels ahead!"
end

function card_create_action(actor)
    local STARTUP = { 1, 0.1 } -- Wait 6 frames, yes I counted again and it sounds like you got it
    local THE_REST = { 1, 1.2 } -- Stay posed for 72 frames.

    local FRAMES = make_frame_data({ STARTUP, THE_REST })

    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    action:override_animation_frames(FRAMES)

    action.execute_func = function(self, user)

        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(gunhilt, true)
        buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
        buster_anim:load(_modpath .. "player_fx3B_animations.animation")
        buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        buster_anim:set_state("1")
        buster_anim:set_playback(Playback.Loop)
        buster_anim:refresh(buster:sprite())

        action:add_anim_action(2, function()
            self.ray_of_sun = summon_sun(user)
            local tile = user:get_tile(user:get_facing(), 2)
            actor:get_field():spawn(self.ray_of_sun, tile)
        end)
    end
    action.action_end_func = function(self)
        if self.ray_of_sun and not self.ray_of_sun:is_deleted() then self.ray_of_sun:erase() end
    end
    return action
end

function summon_sun(user)
    local spell = Battle.Spell.new(user:get_team())
    local framedata = 0

    spell:set_facing(user:get_facing())
    spell:set_texture(sunray)

    local anim = spell:get_animation()
    anim:load(_modpath .. "player_fx3c_animations.animation")
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    anim:refresh(spell:sprite())
    spell:sprite():set_layer(-1)
    local sun_noise_countdown = 0
    local sun_noise = Engine.load_audio(_modpath.."song329.ogg", true)
    spell.update_func = function(self, dt)
        if framedata >= 61 then
            self:delete()
        else
            if framedata > 0 then
                local call_hit = spell_damage_summon(self, dt)
                local tile = user:get_tile(user:get_facing(), 2)
                user:get_field():spawn(call_hit, tile)
                if sun_noise_countdown <= 0 then
                    Engine.play_audio(sun_noise, AudioPriority.High)
                    sun_noise_countdown = 2
                end
                sun_noise_countdown = sun_noise_countdown - 1
            end
        end
        framedata = framedata + 1
    end

    spell.can_move_to_func = function(self, other)
        return true
    end

    return spell
end

function spell_damage_summon(user)
    local spell_damage = Battle.Spell.new(user:get_team())



    spell_damage:set_hit_props(
        HitProps.new(
            4,
            Hit.Pierce | Hit.Retangible,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell_damage.update_func = function(self, dt)
        local own_tile = self:get_tile() --Dawn: get the tile this entity is on

        if not own_tile or own_tile and own_tile:is_edge() then
            self:delete()
        else
            own_tile:highlight(Highlight.Flash)
            own_tile:attack_entities(self)
        end
        local up_tile = own_tile:get_tile(Direction.Up, 1) --Dawn: get the tile above
        if up_tile and not up_tile:is_edge() then
            up_tile:highlight(Highlight.Flash)
            up_tile:attack_entities(self)
        end
        local down_tile = own_tile:get_tile(Direction.Down, 1) --Dawn: get the tile below
        if down_tile and not down_tile:is_edge() then
            down_tile:highlight(Highlight.Flash)
            down_tile:attack_entities(self)
        end
        self:erase()
    end

    return spell_damage
end