function package_init(package) 
    package:declare_package_id("sus Green")
    package:set_speed(5.0)
	package:set_attack(5)
	package:set_charged_attack(50)
    package:set_special_description("Sussy wussy")
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Green Imposter")
	player:set_health(1000)
	player:set_element(Element.Wood)
    player:set_height(48.0)
	player:set_charge_position(1,-14)
    player:set_animation(_modpath.."megaman.animation")
    player:set_texture(Engine.load_texture
(_modpath.."amongus.png"), false)
    player:set_fully_charged_color(Color.new(243, 57, 198, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
    print("charged attack")
    return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end