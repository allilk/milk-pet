function package_init(package) 
    package:declare_package_id("com.Darkloid.Shademan")
    package:set_speed(1.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("I'll suffer this indignity...")
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."shademan_ow.animation")
    package:set_overworld_texture_path(_modpath.."shademan_ow.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Shademan")
	player:set_health(1500)
	player:set_element(Element.None)
    player:set_height(78.0)
	player:set_charge_position(3,-30)
    player:set_animation(_modpath.."shademan.animation")
    player:set_texture(Engine.load_texture(_modpath.."shademan.png"), false)
    
    player.update_func = function(self, dt)
        -- nothing in particular
    end
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
end

function create_charged_attack(player)
    print("execute charged attack")
    return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end

function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level())
end