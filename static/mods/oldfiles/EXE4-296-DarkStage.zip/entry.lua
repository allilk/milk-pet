local DAMAGE = 0

local AUDIO1 = Engine.load_audio(_modpath.."panelchange_final.ogg")
local AUDIO2 = Engine.load_audio(_modpath.."panelchange.ogg")
local AUDIO_DARKHOLE = Engine.load_audio(_modpath.."darkhole.ogg")

function package_init(package) 
	package:declare_package_id("com.Dawn.k1rbyat1na.EXE4-296-DarkStage")
	package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"D","S"})

	local props = package:get_card_props()
	props.shortname = "DrkStage"
	props.damage = DAMAGE
	props.time_freeze = true
	props.element = Element.None
	props.description = "STAGE OF DARKNESS"
	props.can_boost = false
	props.card_class = CardClass.Dark
	props.limit = 1
end

function create_dark_hole(user, tile)
	local TEXTURE = Engine.load_texture(_modpath.."Hole.png")
	local cube = Battle.Obstacle.new(Team.Other)
	cube:share_tile(true)
	cube:toggle_hitbox(false)
	cube:set_name("DarkHole")
	cube:set_health(0)
	cube:set_facing(user:get_facing())
	cube:set_texture(TEXTURE, true)
	cube:sprite():set_layer(10)
	local anim = cube:get_animation()
	anim:load(_modpath.."Hole.animation")
	anim:set_state("DEFAULT")
	anim:refresh(cube:sprite())
	anim:set_playback(Playback.Loop)
	cube.on_spawn_func = function(self)
		local tile = cube:get_tile()
		if not tile:is_walkable() then
			cube:delete()
		end
		tile:set_state(TileState.Normal)
	end
	cube.can_move_to_func = function(tile)
		return false
	end
	cube.tile = nil
	cube.update_func = function(self, dt)
		if self.tile == nil then self.tile = self:get_tile() end
		if self.tile:get_state() ~= TileState.Normal then self:delete() end
	end
	--[[local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil
	end
	if #tile:find_entities(query) == 0 and not tile:is_edge() then return cube end]]
	if not tile:is_edge() then return cube end
	return nil
end

function card_create_action(actor, props)
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
		local tile_count = 0
		local other_tile_count = 0
		local field = user:get_field()
		local all_red_tiles = field:find_tiles(function(tile) 
			if tile:get_team() == user:get_team() then 
				tile_count = tile_count+1
				return true 
			end
			return false
		end)
		local all_blue_tiles = field:find_tiles(function(tile) 
			if tile:get_team() ~= user:get_team() then 
				other_tile_count = other_tile_count+1
				return true 
			end
			return false
		end)
		local dark_hole_query = function(hole)
			return hole and hole:get_name() == "DarkHole" and hole:get_animation():get_state() == "DEFAULT"
		end
		local k = 0
		local cooldown = 0
		local step1 = Battle.Step.new()
		local do_once = true
		local is_reveal = false
		local other_tile_original_state_table = {}
		local dark_hole_list = {}
		local other_dark_hole = {}
		step1.update_func = function(self, dt)
			if cooldown <= 0 then
				k = k + 1
				cooldown = 0.03
				if do_once then
					Engine.play_audio(AUDIO_DARKHOLE, AudioPriority.High)
					do_once = false
					for i = 1, tile_count, 1 do
						local dark_hole = create_dark_hole(user, all_red_tiles[i])
						local dark_check = all_red_tiles[i]:find_obstacles(dark_hole_query)
						if dark_hole ~= nil and #dark_check <= 0 then all_red_tiles[i]:set_state(TileState.Normal); field:spawn(dark_hole, all_red_tiles[i]); table.insert(dark_hole_list, dark_hole) end
					end
					for j = 1, other_tile_count, 1 do
						--local dark_check = all_blue_tiles[j]:find_obstacles(dark_hole_query)
						table.insert(other_tile_original_state_table, all_blue_tiles[j]:get_state())
						--if #dark_check > 0 then table.insert(other_dark_hole) end
					end
				end
				Engine.play_audio(AUDIO2, AudioPriority.Highest)
				if is_reveal then
					is_reveal = false
					for j = 1, other_tile_count, 1 do
						--[[local dark_check = all_blue_tiles[j]:find_obstacles(dark_hole_query)
						dark_check[j]:hide()]]
						all_blue_tiles[j]:set_state(other_tile_original_state_table[j])
					end
				else
					is_reveal = true
					for j = 1, other_tile_count, 1 do
						--[[local dark_check = all_blue_tiles[j]:find_obstacles(dark_hole_query)
						dark_check[j]:reveal()]]
						all_blue_tiles[j]:set_state(TileState.Poison)
					end
				end
			else
				cooldown = cooldown - dt
			end
			
			if k == 9 then
				Engine.play_audio(AUDIO1, AudioPriority.High)
				self:complete_step()
			end	
		end
		self:add_step(step1)
	end
	return action
end