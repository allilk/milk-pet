local SUCCESS_AUDIO = Engine.load_audio(_folderpath .. "input.ogg", true)
local BLADE_TEXTURE = Engine.load_texture(_modpath .. "punch.png")
local AUDIO = Engine.load_audio(_modpath .. "sfx.ogg")

function package_init(package)
	package:declare_package_id("com.EXE2.Card087-GoldFist")
	package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
	package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
	package:set_codes({ 'D', 'G', 'L', 'O', 'Z' })

	local props = package:get_card_props()
	props.shortname = "GoldFist"
	props.damage = 180
	props.time_freeze = false
	props.element = Element.None
	props.description = "Fist of death!"
	props.long_description = "Fist of death! Input ??? to...!"
	props.limit = 5
end

local recipes = {
	{
		name = "special",
		pattern = {
			{ "b" },
			{ "down"},
			{ "down", "right" },
			{ "right" },
			{ "b" },
		}
	}
}

local function deep_clone(t)
	if type(t) ~= "table" then
		return t
	end

	local o = {}
	for k, v in pairs(t) do
		o[k] = deep_clone(v)
	end
	return o
end

local function contains(t, value)
	for k, v in ipairs(t) do
		if v == value then
			return true
		end
	end
	return false
end

local function get_first_completed_recipe(matching)
	for _, recipe in ipairs(matching) do
		if recipe.current_step > #recipe.pattern then
			Engine.play_audio(SUCCESS_AUDIO, AudioPriority.High)
			return recipe.name
		end
	end

	return nil
end

function card_create_action(actor, props)
	local matching = deep_clone(recipes)

	for _, recipe in ipairs(matching) do
		recipe.current_step = 1
	end

	local action = Battle.CardAction.new(actor, "IDLE")
	action:set_lockout(make_sequence_lockout())

	local remaining_time = 50 -- 50 frame timer

	local step1 = Battle.Step.new()

	step1.update_func = function()
		remaining_time = remaining_time - 1

		if remaining_time < 0 or not actor:input_has(Input.Pressed.Use) and not actor:input_has(Input.Held.Use) or
			get_first_completed_recipe(matching) ~= nil then
			step1:complete_step()
			return
		end
		local drop_list = {}
		local inputs = {
			up = actor:input_has(Input.Pressed.Up) or actor:input_has(Input.Held.Up),
			down = actor:input_has(Input.Pressed.Down) or actor:input_has(Input.Held.Down),
			left = actor:input_has(Input.Pressed.Left) or actor:input_has(Input.Held.Left),
			right = actor:input_has(Input.Pressed.Right) or actor:input_has(Input.Held.Right),
			b = actor:input_has(Input.Pressed.Shoot) or actor:input_has(Input.Held.Shoot)
		}

		local function inputs_fail(required_inputs)
			-- has an input that should not be held
			for name, held in pairs(inputs) do
				if held and not contains(required_inputs, name) then
					return true
				end
			end
			return false
		end

		local function inputs_match(required_inputs)
			for _, name in ipairs(required_inputs) do
				if not inputs[name] then
					return false
				end
			end
			return true
		end

		for i, recipe in ipairs(matching) do
			local last_required_inputs = recipe.pattern[recipe.current_step - 1]
			local required_inputs = recipe.pattern[math.min(recipe.current_step, #recipe.pattern)]
			local fails_current_requirements = inputs_fail(required_inputs)

			if fails_current_requirements and (not last_required_inputs or inputs_fail(last_required_inputs)) then
				-- has an input that failed to match the current + previous requirements
				drop_list[#drop_list + 1] = i
			elseif not fails_current_requirements and recipe.current_step <= #recipe.pattern and inputs_match(required_inputs) then
				-- has all of the required inputs to continue
				recipe.current_step = recipe.current_step + 1
			end
		end

		for i, v in ipairs(drop_list) do
			table.remove(matching, v - i + 1)
		end
	end
	action:add_step(step1)

	local step2 = Battle.Step.new()
	step2.update_func = function()
		local attack_name = get_first_completed_recipe(matching)

		print(attack_name)

		if attack_name == "special" then
			take_default_action(actor, props, true)
		else
			take_default_action(actor, props, false)
		end
		step2:complete_step()
	end
	action:add_step(step2)

	return action
end

function take_default_action(actor, props, is_special)
	local action = Battle.CardAction.new(actor, "PLAYER_THROW")
	--Get me actual frame data on guts punch and we can replace this.
	action:override_animation_frames(make_frame_data(
		{
			{ 1, 0.067 }, --Add attachment
			{ 2, 0.067 },
			{ 3, 0.067 }, --Create initial punch
			{ 3, 0.067 }, { 3, 0.067 }, --Additional punches (if special)
			{ 3, 0.2 }, --Hold time
			{ 3, 0.067 }, { 3, 0.067 }, { 3, 0.067 }, --Additional punches (if special)
			{ 3, 0.2 }, --Hold time
			{ 3, 0.067 }, { 3, 0.067 }, { 3, 0.067 } --Additional punches (if special)
		}
	))
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		local increment = 1
		local field = user:get_field()
		local facing = user:get_facing()
		if facing == Direction.Left then increment = -1 end
		self:add_anim_action(1, function()
			--Just make the punch a throw attachment to the hand.
			self.blade = self:add_attachment("HAND")
			local blade_sprite = self.blade:sprite()
			blade_sprite:set_texture(BLADE_TEXTURE)
			blade_sprite:set_layer(-1)

			local blade_anim = self.blade:get_animation()
			blade_anim:load(_modpath .. "punch.animation")
			blade_anim:set_state("GOLD")
		end)

		--No visual besides the punch. Also, punch 1.
		--If no input, will end with just this punch.
		self:add_anim_action(3, function()
			self.sword = create_slash(user, props, is_special)
			local tile = user:get_tile(facing, 1)
			if is_special then
				tile = field:tile_at(user:get_tile():x()+increment, 3)
			end
			field:spawn(self.sword, tile)
		end)

		--If input. Punch 2.
		self:add_anim_action(4, function()
			if is_special then self.blade:sprite():hide()
				local tile = field:tile_at(user:get_tile():x()+increment, 2)
				if tile and not tile:is_edge() then
					local spare_spell = create_slash(user, props, is_special)
					field:spawn(spare_spell, tile)
				end
			end
		end)

		--If input. Punch 3.
		self:add_anim_action(5, function()
			if is_special then
				local tile = field:tile_at(user:get_tile():x()+increment, 1)
				if tile and not tile:is_edge() then
					local spare_spell = create_slash(user, props, is_special)
					field:spawn(spare_spell, tile)
				end
			end
		end)

		--If input. Punch 4. End action otherwise.
		self:add_anim_action(7, function()
			if not is_special then self:end_action() return end
			local tile = field:tile_at(user:get_tile():x()+increment, 3)
			if tile and not tile:is_edge() then
				local sword = create_slash(user, props, is_special)
				field:spawn(sword, tile)
			end
		end)

		--If input. Punch 5.
		self:add_anim_action(8, function()
			local tile = field:tile_at(user:get_tile():x()+increment, 2)
			if tile and not tile:is_edge() then
				local spare_spell = create_slash(user, props, is_special)
				field:spawn(spare_spell, tile)
			end
		end)

		--If input. Punch 6.
		self:add_anim_action(9, function()
			local tile = field:tile_at(user:get_tile():x()+increment, 1)
			if tile and not tile:is_edge() then
				local spare_spell = create_slash(user, props, is_special)
				field:spawn(spare_spell, tile)
			end
		end)

		--If input. Punch 7.
		self:add_anim_action(11, function()
			local tile = field:tile_at(user:get_tile():x()+increment, 3)
			if tile and not tile:is_edge() then
				local sword = create_slash(user, props, is_special)
				field:spawn(sword, tile)
			end
		end)

		--If input. Punch 8.
		self:add_anim_action(12, function()
			local tile = field:tile_at(user:get_tile():x()+increment, 2)
			if tile and not tile:is_edge() then
				local spare_spell = create_slash(user, props, is_special)
				field:spawn(spare_spell, tile)
			end
		end)

		--If input. Punch 9.
		self:add_anim_action(13, function()
			local tile = field:tile_at(user:get_tile():x()+increment, 1)
			if tile and not tile:is_edge() then
				local spare_spell = create_slash(user, props, is_special)
				field:spawn(spare_spell, tile)
			end
		end)
	end

	action.action_end_func = function(self)
		--handle removing the punch's tile attack on action end
		if not is_special and self.sword and self.sword ~= nil and not self.sword:is_deleted() then self.sword:delete() end
	end

	action.animation_end_func = function(self)
		--handle removing the punch's tile attack on animation end
		if not is_special and self.sword and self.sword ~= nil and not self.sword:is_deleted() then self.sword:delete() end
	end
	actor:card_action_event(action, ActionOrder.Involuntary)
end

function create_slash(user, props, is_special, tile)
	local spell = Battle.Spell.new(user:get_team())
	local facing = user:get_facing()
	if is_special then
		spell:set_texture(BLADE_TEXTURE)
		local spell_anim = spell:get_animation()
		spell_anim:load(_modpath .. "punch.animation")
		spell_anim:set_state("GOLD")
		local sprite = spell:sprite()
		spell_anim:refresh(sprite)
		spell_anim:set_playback(Playback.Reverse)
		spell_anim:set_playback_speed(0)
		spell:set_offset(0, -40)
	end

	--Set the facing of the FISTS
	spell:set_facing(facing)

	spell:highlight_tile(Highlight.Flash)
	--Give it breaking props. Gutspunch pierces guard.
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Breaking,
			props.element,
			user:get_context(),
			Drag.None
		)
	)

	spell.update_func = function(self, dt)
		if self and self:is_deleted() then return end
		self:get_tile():attack_entities(self)
		if is_special and not self:is_sliding() then
			local own_tile = self:get_tile()
			if own_tile and own_tile:is_edge() then self:delete() return end
			local dest = self:get_tile(spell:get_facing(), 1)
			self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, nil)
		end
	end

	spell.collision_func = function(self)
		self:delete()
	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end
