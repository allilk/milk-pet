local DAMAGE = 40

local RYOUTEKUNAI_TEXTURE = Engine.load_texture(_folderpath.."ryoutekunai.png")
local RYOUTEKUNAI_ANIMPATH = _folderpath.."ryoutekunai.animation"
local RYOUTEKUNAI_AUDIO = Engine.load_audio(_folderpath.."ryoutekunai.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local frame_data = make_frame_data({
	{1, 0.033}, {2, 0.033}, {3, 0.033}, {4, 0.416}
})

local ryoutekunai = {
	kunai_offset = 0,

	codes = {"E","I","L","P","S"},
	shortname = "DblKunai1",
	damage = DAMAGE,
	time_freeze = false,
	element = Element.None,
	description = "Kunais up and down 1 square",
	long_description = "3-hit kunais up and down 1 square",
	can_boost = true,
	card_class = CardClass.Standard,
	memory = 48,
	limit = 5
}

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-033-RyuoteKunai1")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes(ryoutekunai.codes)

    local props = package:get_card_props()
    props.shortname = ryoutekunai.shortname
    props.damage = ryoutekunai.damage
    props.time_freeze = ryoutekunai.time_freeze
    props.element = ryoutekunai.element
    props.description = ryoutekunai.description
    props.long_description = ryoutekunai.long_description
    props.can_boost = ryoutekunai.can_boost
	props.card_class = ryoutekunai.card_class
	props.limit = ryoutekunai.limit
end

ryoutekunai.card_create_action = function(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
        local facing = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset = nil
        local Y_offset_1 = Y - 1
        local Y_offset_2 = Y + 1

        if facing == Direction.Right then
            X_offset = X + 1
        else
            X_offset = X - 1
        end

        self:add_anim_action(2, function()
            user:toggle_counter(true)
        end)

        self:add_anim_action(3, function()
            Engine.play_audio(RYOUTEKUNAI_AUDIO, AudioPriority.High)
            local offset_tile = user:get_tile(facing, ryoutekunai.kunai_offset)
            if facing == Direction.Right then
                print("Kunai created at tile ("..offset_tile:get_tile(Direction.UpRight, 1):x()..";"..offset_tile:get_tile(Direction.UpRight, 1):y()..")")
                print("Kunai created at tile ("..offset_tile:get_tile(Direction.DownRight, 1):x()..";"..offset_tile:get_tile(Direction.DownRight, 1):y()..")")
                create_kunai(user, props, team, field, offset_tile:get_tile(Direction.UpRight, 1), 1)
                create_kunai(user, props, team, field, offset_tile:get_tile(Direction.DownRight, 1), 1)
            else
                print("Kunai created at tile ("..offset_tile:get_tile(Direction.UpLeft, 1):x()..";"..offset_tile:get_tile(Direction.UpLeft, 1):y()..")")
                print("Kunai created at tile ("..offset_tile:get_tile(Direction.DownLeft, 1):x()..";"..offset_tile:get_tile(Direction.DownLeft, 1):y()..")")
                create_kunai(user, props, team, field, offset_tile:get_tile(Direction.UpLeft, 1), 1)
                create_kunai(user, props, team, field, offset_tile:get_tile(Direction.DownLeft, 1), 1)
            end
		end)

        self:add_anim_action(4, function()
            user:toggle_counter(false)
        end)
    end
    action.action_end_func = function(self)
		actor:toggle_counter(false)
	end
    return action
end

function create_kunai(user, props, team, field, tile, soundnumber)
    local hits = 2
    local spawn_next
    spawn_next = function()
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(Direction.Right)
        spell:set_hit_props(
            HitProps.new(
                props.damage, 
                Hit.Impact | Hit.Flinch, 
                props.element, 
                user:get_context(), 
                Drag.None
            )
        )
        local sprite = spell:sprite()
        sprite:set_layer(-4)
        sprite:set_texture(RYOUTEKUNAI_TEXTURE)
        local anim = spell:get_animation()
        anim:load(RYOUTEKUNAI_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)
        anim:on_complete(function()
            if hits > 1 then
                soundnumber = soundnumber + 1
                spawn_next()
                spell:erase()
                hits = hits - 1
            elseif hits <= 1 then
                soundnumber = soundnumber + 1
                create_kunai_flash(user, props, team, field, tile, soundnumber)
                spell:erase()
            end
        end, true)

        spell.update_func = function(self)
            self:get_current_tile():attack_entities(self)
        end

        spell.can_move_to_func = function(self, other)
            return true
        end

        spell.delete_func = function(self)
            spell:erase()
        end
    
        spell.battle_end_func = function(self)
            spell:erase()
        end

        spell.attack_func = function(self)
            Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
            create_effect(Direction.Right, EFFECT_TEXTURE, EFFECT_ANIMPATH, "8", math.random(-7, 7), math.random(-7, 7), -999999, field, self:get_current_tile())
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_kunai_flash(user, props, team, field, tile, soundnumber)
    local spell = Battle.Spell.new(team)
    spell:set_facing(Direction.Right)
    spell:set_texture(RYOUTEKUNAI_TEXTURE)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
        )
    )
    local sprite = spell:sprite()
    sprite:set_layer(-4)
    sprite:set_texture(RYOUTEKUNAI_TEXTURE)
    local anim = spell:get_animation()
    anim:load(RYOUTEKUNAI_ANIMPATH)
    anim:set_state("0")
    anim:refresh(sprite)
    anim:on_complete(function()
        spell:erase()
    end, true)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(self, other)
        return true
    end

    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
        spell:erase()
    end

    spell.attack_func = function(self)
        Engine.play_audio(Engine.load_audio(_folderpath.."hitsound"..soundnumber..".ogg"), AudioPriority.High)
        create_effect(Direction.Right, EFFECT_TEXTURE, EFFECT_ANIMPATH, "8", math.random(-11,11), math.random(-11,11), -999999, field, self:get_current_tile())
    end

    field:spawn(spell, tile)

    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return ryoutekunai