local ryoutekunai = include("ryoutekunai/ryoutekunai.lua")

local DAMAGE = 40

ryoutekunai.kunai_offset = 1

ryoutekunai.codes = {"D","F","J","Q","R"}
ryoutekunai.shortname = "DblKunai2"
ryoutekunai.damage = DAMAGE
ryoutekunai.time_freeze = false
ryoutekunai.element = Element.None
ryoutekunai.description = "Kunais up and down 2 squares"
ryoutekunai.long_description = "3-hit kunais up and down 2 squares"
ryoutekunai.can_boost = true
ryoutekunai.card_class = CardClass.Standard
ryoutekunai.memory = 64
ryoutekunai.limit = 5

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE2-034-RyuoteKunai2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(ryoutekunai.codes)

    local props = package:get_card_props()
    props.shortname = ryoutekunai.shortname
    props.damage = ryoutekunai.damage
    props.time_freeze = ryoutekunai.time_freeze
    props.element = ryoutekunai.element
    props.description = ryoutekunai.description
    props.long_description = ryoutekunai.long_description
    props.can_boost = ryoutekunai.can_boost
	props.card_class = ryoutekunai.card_class
	props.limit = ryoutekunai.limit
end

card_create_action = ryoutekunai.card_create_action