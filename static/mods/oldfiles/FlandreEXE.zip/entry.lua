function package_init(package) 
    package:declare_package_id("com.alrysc.player.FlandreEXE")
    package:set_special_description("A strange Navi roaming the DeepNet...")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Flandre")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(70)
    player:set_animation(_modpath.."Flandre.animation")
    player:set_texture(Engine.load_texture(_modpath.."Flandre.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(0, -30)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        sword = Engine.load_audio(_modpath.."swing_sword.ogg"),
        bright = Engine.load_audio(_modpath.."bright.ogg"),
        wing = Engine.load_audio(_modpath.."wing.ogg"),
        charge = Engine.load_audio(_modpath.."charge.ogg"),
        crack = Engine.load_audio(_modpath.."break.ogg"),
        hit2 = Engine.load_audio(_modpath.."hit_big.ogg")

    }

    player.cooldown = 0

    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

   
    
    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())

    end

    player.normal_attack_func = base_normal_attack
    
    
    local function create_hitbox(user, tile, spell_list, time)
        if not tile or tile:is_edge() then return end

        local spell = Battle.Spell.new(user:get_team())

        local damage = 50 + user:get_attack_level() * 20

  
        local hit_props = HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire, 
            user:get_context(), 
            Drag.None
        )

        spell:set_hit_props(hit_props)
        spell:set_facing(user:get_facing())
        
        local lifetime = time
        spell.has_hit = false
        spell.update_func = function(self, dt)
            local can_hit = true
            for i=1, #spell_list
            do
                if not spell_list[i]:is_deleted() then 
                    can_hit = can_hit and not spell_list[i].has_hit

                    if not can_hit then 
                        break
                    end
                end
            end

            self:get_tile():highlight(Highlight.Solid)
            if lifetime == 0 then 
                self:delete()
            end
            lifetime = lifetime - 1

            if not can_hit then 
                return 
            end

            self:get_tile():attack_entities(self)
    
        end
    
        spell.can_move_to_func = function(tile)
            return true
        end
    
        spell.attack_func = function(self, other)
            Engine.play_audio(user.sounds.hit, AudioPriority.Low)
            self:get_field():spawn(graphic_init("artifact", 0, 0, "effect.png", "effect.animation", -6, "DEFAULT", self, self:get_facing(), true), other:get_current_tile())

        end
    
        spell.collision_func = function(self, other)
            self.has_hit = true
        end

        table.insert(spell_list, spell)
        user:get_field():spawn(spell, tile)
    end
    

    
        
    local function charge_attack(player)
        local action = Battle.CardAction.new(player, "LAEVATEINN")
        local field = player:get_field()
        local start_tile = nil
        local spell_list = {}


        local function check_characters(tile, self)
            local characters = tile:find_characters(function(c)
                return c:get_id() ~= self:get_id() 
            end)
        
            return #characters > 0
        
        end

        local function check_obstacles(tile, self)
            local ob = tile:find_obstacles(function(o)
                return o:get_health() > 0 
            end)
        
            return #ob > 0 
        end

        local function find_dest(player)
            local chosen_tile = nil
            start_tile = player:get_current_tile()
            local cur_tile = start_tile
            local facing = player:get_facing()

            for i=1, field:width()
            do
                cur_tile = cur_tile:get_tile(facing, 1)
                if not cur_tile or cur_tile:is_edge() then 
                    break
                end

                if check_characters(cur_tile, player) or check_characters(cur_tile:get_tile(Direction.Up, 1), player) or check_characters(cur_tile:get_tile(Direction.Down, 1), player) then 
                    local t = cur_tile:get_tile(Direction.reverse(facing), 2)
                    local t2 = cur_tile:get_tile(Direction.reverse(facing), 1)
                    if t2 ~= start_tile and not check_characters(t, player) and not check_obstacles(t) then 
                        chosen_tile = t
                        break
                    else 
                        if not check_characters(t2, player) and not check_obstacles(t2) then 
                            chosen_tile = t2
                            break
                        end
                    end
                end

            end

            if not chosen_tile then chosen_tile = start_tile end

            return chosen_tile

        end

       
        action.execute_func = function()
            action:add_anim_action(6, function()
                local tile = find_dest(player)
                start_tile:remove_entity_by_id(player:get_id())
                tile:add_entity(player)
                start_tile:reserve_entity_by_id(player:get_id())

            end)

            action:add_anim_action(9, function()
                local facing = player:get_facing()
                local t = player:get_tile(facing, 1)
                local time = 8
                Engine.play_audio(player.sounds.sword, AudioPriority.Low)
                create_hitbox(player, t, spell_list, time)
                create_hitbox(player, t:get_tile(Direction.Up, 1), spell_list, time)
                create_hitbox(player, t:get_tile(facing, 1), spell_list, time)
                create_hitbox(player, t:get_tile(Direction.Down, 1), spell_list, time)
                create_hitbox(player, t:get_tile(Direction.join(Direction.Up, facing), 1), spell_list, time)
                create_hitbox(player, t:get_tile(Direction.join(Direction.Down, facing), 1), spell_list, time)

            end)

          
        end

        action.action_end_func = function()
            for i=1, #spell_list
            do
                local s = spell_list[i]
                if s and not s:is_deleted() then 
                    s:delete()
                end

            end

        end

        return action
    end

    player.charged_attack_func = charge_attack


    local function destroy(player)
        if player.cooldown > 0 then return end
        local action = Battle.CardAction.new(player, "DESTROY_1")
        action:set_lockout(make_sequence_lockout())
        local actor = nil
        local target = nil
        local check_tile = nil
        local facing = nil

        local enemy_query = function(c)
            return c:get_team() ~= player:get_team()
        end

        local search_step = Battle.Step.new()
        local should_search = false
        local search_counter = 60

        local destroy_step = Battle.Step.new()
        local destroy_first = true

        
        search_step.update_func = function()
            if not should_search then return end
            if search_counter % 10 == 0 then
                if check_tile then  
                    check_tile = check_tile:get_tile(facing, 1)
                end

                if check_tile and not check_tile:is_edge() then 
                    local c = check_tile:find_characters(enemy_query)
                    if c and c[1] then
                        target = c[1]
                        search_step:complete_step()
                        action:add_step(destroy_step)
                    end
                end
            end

            search_counter = search_counter -1

            if search_counter < 0 then 
                search_step:complete_step()
            end
        end


        local function destroy_attack(target)
            if target:is_deleted() then return end
            local orders = {
                0, 1, 713, 777, 20000 -- Guard, barrier, antirecov, antidamage, invis
            }

            for i=1, #orders
            do
                local replace = Battle.DefenseRule.new(orders[i], DefenseOrder.CollisionOnly)
                target:add_defense_rule(replace)
            end

            local props = HitProps.new(
                player:get_attack_level()*20,
                Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Pierce | Hit.Breaking,
                Element.None,
                nil,
                Drag.None

            )

            local spell = Battle.Spell.new(player:get_team())
            spell:set_hit_props(props)

            spell.on_spawn_func = function(self)
                target:get_current_tile():attack_entities(self)
                self:delete()
            end

            spell.attack_func = function()
                Engine.play_audio(player.sounds.hit2, AudioPriority.Low)

            end

            player:get_field():spawn(spell, player:get_field():tile_at(7, 4))
        end


        destroy_step.update_func = function()
            if destroy_first then 
                local anim = actor:get_animation()
                anim:set_state("DESTROY_2")

                anim:on_frame(1, function()
                    Engine.play_audio(player.sounds.bright, AudioPriority.Low)
                end)

                anim:on_frame(5, function()
                    Engine.play_audio(player.sounds.wing, AudioPriority.Low)
                    Engine.play_audio(player.sounds.charge, AudioPriority.Low)
                end)

                anim:on_frame(21, function()
                    local shake = Battle.Artifact.new()
                    shake.time = 0
                    shake.update_func = function()
                
                        shake:shake_camera(200, 0.016)
                        if shake.time == 8 then 
                            shake:delete()
                        end
                  
                        shake.time = shake.time+1
                    end

                    player:get_field():spawn(shake, player:get_current_tile())

                    destroy_attack(target)
                    Engine.play_audio(player.sounds.crack, AudioPriority.Low)               
                end)

                anim:on_complete(function()
                    destroy_step:complete_step()
                end)

                anim:refresh(actor:sprite())

                destroy_first = false
            end

        end

   

        action.execute_func = function()
            player.cooldown = 600
            actor = action:get_actor()
            facing = player:get_facing()
            check_tile = player:get_current_tile()

            action:add_anim_action(3, function()
                should_search = true
            end)

            action:add_step(search_step)
        end

        
        return action
    end


    player.special_attack_func = destroy

    player.update_func = function(self)
        if self.cooldown > 0 then 
            self.cooldown = self.cooldown - 1
        end

    end
end