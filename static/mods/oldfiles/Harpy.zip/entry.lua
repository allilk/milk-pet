function package_init(package)
    package:declare_package_id("com.Dawn.personal.HarpyEXE")
    package:set_special_description("Personal Navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."harpyow.animation")
    package:set_overworld_texture_path(_modpath.."harpyow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
	player:set_name("Harpy")
	player:set_health(1500)
	player:set_element(Element.Wind)
    player:set_height(70.0)
    player:set_animation(_modpath.."harpybat.animation")
    player:set_texture(Engine.load_texture(_modpath.."harpybat.greyscaled.png"), false)
	local base_palette = Engine.load_texture(_modpath.."harpybat.palette.png")
	local charged_texture = Engine.load_texture(_folderpath.."custom_charge.png")
	local base_charge_color = Color.new(0, 100, 200, 255)
	local shadowing_charge_color = Color.new(200, 0, 100, 255)
	local snowtalon_charge_color = Color.new(250, 250, 250, 255)
	local dragon_charge_color = Color.new(175, 0, 200, 255)
	local phoenix_charge_color = Color.new(160, 32, 0, 255)
	local shocktrick_charge_color = Color.new(224, 224, 0, 255)
	player:set_fully_charged_color(base_charge_color)
	player:set_charge_position(0, -35)
	
	player:set_palette(base_palette)
	
	player:set_float_shoe(true)
	player:set_air_shoe(true)
	local function get_charge_time()
		local level = player:get_charge_level()
		if level == 5 then return 110
		elseif level == 4 then return 115
		elseif level == 3 then return 120
		elseif level == 2 then return 130
		else return 140 end
	end

	local snowslash = include("Chips/Snowslash/entry.lua")
	local comet = include("Chips/Meteor/entry.lua")
	local dragonswipe = include("Chips/Moonblade/entry.lua")
	local triple_fire = include("Chips/TripleFire/entry.lua")
	local invis = include("Chips/Invis/entry.lua")
	local powdershot = include("Chips/Powdershot/entry.lua")
	local hypnopulse = include("Chips/Hypnopulse/entry.lua")
	local RapidBuster = include("Chips/RapidBuster/entry.lua")
	local PhoenixFire = include("Chips/PhoenixFire/entry.lua")
	local Shockblast = include("Chips/Shockblast/entry.lua")
	local Rootroar = include("Chips/Rootroar/entry.lua")

	local shadowing = player:create_form()
	local snowtalon = player:create_form()
	local dragon = player:create_form()
	local phoenix = player:create_form()
	local shocktrick = player:create_form()
	
	local shadowing_special_cooldown = 0 --How long to wait before using the invisible special again.
	local comet_cooldown = 0 --If this is 0, then you can use the bombardment special of Snowtalon.
	local comet_cooldown_max = 300 --Assign a max value it returns to. You have to wait 5 seconds to use it again.
	local roar_cooldown = 0
	local roar_cooldown_max = 240
	local dragon_fireball_cooldown = 180 --How long to wait before using Triple Fire again. You have to wait 3 seconds to use it again.
	local dragon_fireball_current = 0 --How long it's been since using Triple Fire.
	local current_form = "base"

	shocktrick:set_mugshot_texture_path(_modpath.."shocktrick_entry.png")
	shocktrick.on_activate_func = function()
		current_form = "shocktrick"
		player:set_element(Element.Elec)
		player:set_palette(Engine.load_texture(_modpath.."shocktrick.palette.png"))
		player:set_fully_charged_color(shocktrick_charge_color)
	end
	
	shocktrick.charged_attack_func = function()
		local props = Battle.CardProperties.new()
		props.damage = player:get_attack_level() * 30
		return Shockblast.card_create_action(player, props)
	end
	
	shocktrick.calculate_charge_time_func = function(level)
		return frames(300)
	end
	
	shocktrick.on_deactivate_func = function()
		current_form = "base"
		player:set_element(Element.Wind)
		player:set_palette(Engine.load_texture(_modpath.."harpybat.palette.png"))
		player:set_fully_charged_color(base_charge_color)
	end
	
	shocktrick.update_func = function(self, dt)
		if roar_cooldown > 0 then roar_cooldown = roar_cooldown - 1 end
	end
	
	shocktrick.special_attack_func = function()
		if roar_cooldown <= 0 then
			roar_cooldown = roar_cooldown_max
			return Rootroar.card_create_action(player)
		else
			local action = Battle.CardAction.new(player, "PLAYER_IDLE")
			action.execute_func = function(self, user) self:end_action() end
			return action
		end
	end
	
	phoenix:set_mugshot_texture_path(_modpath.."phoenix_entry.png")
	phoenix.on_activate_func = function(self, player)
		current_form = "phoenix"
		--Usually set an element, pallet, and charge color.
		player:set_element(Element.Fire)
		player:set_palette(Engine.load_texture(_modpath.."phoenix.palette.png"))
		player:set_fully_charged_color(phoenix_charge_color)
	end

	phoenix.charged_attack_func = function()
		local props = HitProps.new(
			player:get_attack_level() * 20,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Fire,
			nil,
			Drag.None
		)
		return PhoenixFire.card_create_action(player, props)
	end

	local player_anim = player:get_animation()
    local desired_charge_start = math.floor(get_charge_time() / 4)
    local desired_charge_finish = get_charge_time()
    local sound_first = true
    local sound_second = true
	local is_charged = false
  	local current_charge_time = 0

    local function reset_charge_variables()
      current_charge_time = 0
      is_charged = false
      sound_first = true
      sound_second = true
      player.charge:hide()
    end

	player.is_rapid_buster = false
	local player_anim = player:get_animation()
	phoenix.update_func = function(self, dt)
		if player_anim:get_state() ~= "PLAYER_IDLE" and not player:is_moving() then
			reset_charge_variables()
		end
		if not player:input_has(Input.Held.Use) and (player:input_has(Input.Released.Shoot) or not player:input_has(Input.Held.Shoot)) then
			if player.charge ~= nil then
				current_charge_time = current_charge_time + 1
			  	if current_charge_time >= desired_charge_finish and sound_second then
					sound_second = false
					Engine.play_audio(AudioType.BusterCharged, AudioPriority.High)
					is_charged = true
					player.charge:show()
					player.charge_animation:set_state("CHARGED")
					player.charge_animation:set_playback(Playback.Loop)
			  	elseif current_charge_time >= desired_charge_start and sound_first then
					sound_first = false
					Engine.play_audio(AudioType.BusterCharging, AudioPriority.High)
					player.charge:show()
					player.charge_animation:set_state("CHARGING")
					player.charge_animation:set_playback(Playback.Loop)
			  	end
			end
			player.is_rapid_buster = false
		end
		if not player:input_has(Input.Held.Use) then
			if is_charged and player:input_has(Input.Pressed.Shoot) and not player:is_moving() and player_anim:get_state() == "PLAYER_IDLE" then
			  current_charge_time = 0
			  local action = phoenix.charged_attack_func()
			  player:card_action_event(action, ActionOrder.Involuntary)
			  player.charge:hide()
			elseif not is_charged and not player.is_rapid_buster and player:input_has(Input.Held.Shoot) and not player:is_moving() and player_anim:get_state() == "PLAYER_IDLE" then
			  reset_charge_variables()
			  player.is_rapid_buster = true
			  local action = RapidBuster.card_create_action(player)
			  player:card_action_event(action, ActionOrder.Immediate)
			end
		  end
		end
	phoenix.on_deactivate_func = function(self, player)
		player.is_rapid_buster = false
		current_form = "base"
		if player.charge ~= nil then
			player:sprite():remove_node(player.charge)
			player.charge = nil
		end
		if player.charge_animate_component ~= nil then
			player.charge_animate_component:eject()
			player.charge_animate_component = nil
		end
		player:set_palette(Engine.load_texture(_modpath.."harpybat.palette.png"))
		player:set_fully_charged_color(base_charge_color)
		player:set_element(Element.Wind)
	end
	player.battle_start_func = function()
		player.charge = player:create_node()
		player.charge:hide()
		player.charge:set_layer(3)
		player.charge:set_texture(charged_texture)
		player.charge_animation = Engine.Animation.new(_folderpath.."custom_charge.animation")
		player.charge_animation:set_state("CHARGING")
		player.charge_animation:refresh(player.charge)
		player.charge_animation:set_playback(Playback.Loop)
  
		player.charge_animate_component = Battle.Component.new(player, Lifetimes.Battlestep)
        
        player.charge_animate_component.update_func = function(self, dt)
			if self and player.charge ~= nil then player.charge_animation:update(dt, player.charge) end
		end
	 	player:register_component(player.charge_animate_component)
	end

	dragon:set_mugshot_texture_path(_modpath.."dragon_entry.png")
	dragon.on_activate_func = function(self, player)
		current_form = "dragon"
		player:set_element(Element.Fire)
		player:set_palette(Engine.load_texture(_modpath.."dragon.palette.png"))
		player:set_fully_charged_color(dragon_charge_color)
	end
	
	dragon.on_deactivate_func = function(self, player)
		current_form = "base"
		player:set_palette(Engine.load_texture(_modpath.."harpybat.palette.png"))
		player:set_fully_charged_color(base_charge_color)
		player:set_element(Element.Wind)
	end
	
	
	dragon.update_func = function(self, dt)
		--Handle recharging the Triple Fire attack. Do not go below 0. Subtract 1 every frame.
		if dragon_fireball_current > 0 then dragon_fireball_current = dragon_fireball_current - 1 end
	end
	
	dragon.special_attack_func = function(player)
		if dragon_fireball_current <= 0 then
			dragon_fireball_current = dragon_fireball_cooldown
			local props = HitProps.new(
				(player:get_attack_level() * 5), --Damage equal to 5 times the player attack. It's three hits so this is pretty big.
				Hit.Impact | Hit.Flinch, --Flinch them.
				Element.Fire,
				nil,
				Drag.None
			)
			return triple_fire.card_create_action(player, props)
		else
			local action = Battle.CardAction.new(player, "PLAYER_IDLE")
			action.execute_func = function(self, user) self:end_action() end
			return action
		end
	end
	
	dragon.charged_attack_func = function(player)
		local props = HitProps.new(
            (player:get_attack_level() * 20) + 10,
            Hit.Impact | Hit.Flinch,
            Element.None,
            nil,
            Drag.None
        )
		return dragonswipe.card_create_action(player, props)
	end
	
	snowtalon:set_mugshot_texture_path(_modpath.."snowtalon_entry.png")
	snowtalon.on_activate_func = function(self, player)
		current_form = "snow"
		player:set_element(Element.Aqua)
		player:set_palette(Engine.load_texture(_modpath.."snowtalon.palette.png"))
		player:set_fully_charged_color(snowtalon_charge_color)
	end
	
	snowtalon.on_deactivate_func = function(self, player)
		current_form = "base"
		player:set_palette(Engine.load_texture(_modpath.."harpybat.palette.png"))
		player:set_fully_charged_color(base_charge_color)
		player:set_element(Element.Wind)
	end
	
	snowtalon.special_attack_func = function(player)
		if comet_cooldown <= 0 then
			comet_cooldown = comet_cooldown_max
			local props = HitProps.new(
				100,
				Hit.Impact | Hit.Flash,
				Element.Aqua,
				nil,
				Drag.None
			)
			return comet.card_create_action(player, props)
		else
			local action = Battle.CardAction.new(player, "PLAYER_IDLE")
			action.execute_func = function(self, user) self:end_action() end
			return action
		end
	end
	
	snowtalon.charged_attack_func = function(player)
		--Give it Gregar tier strength.
		local props = HitProps.new(
			(player:get_attack_level() * 20) + 30,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Aqua,
			nil,
			Drag.None
		)
		return snowslash.card_create_action(player, props)
	end

	snowtalon.update_func = function(self, dt)
		--Handle reducing the cooldown. If it reaches 0 then we can use the special again.
		if comet_cooldown > 0 then comet_cooldown = comet_cooldown - 1 end
	end
	
	shadowing:set_mugshot_texture_path(_modpath.."shadowing_entry.png")
	shadowing.on_activate_func = function(self, player)
		current_form = "shadow"
		player:set_element(Element.Wind)
		player:set_palette(Engine.load_texture(_modpath.."shadowing.palette.png"))
		player:set_fully_charged_color(shadowing_charge_color)
	end
	
	shadowing.on_deactivate_func = function(self, player)
		current_form = "base"
		player:set_palette(Engine.load_texture(_modpath.."harpybat.palette.png"))
		player:set_fully_charged_color(base_charge_color)
		player:set_element(Element.Wind)
	end
	
	shadowing.special_attack_func = function(player)
		if shadowing_special_cooldown <= 0 then
			shadowing_special_cooldown = 900
			return invis.card_create_action(player)
		else
			local action = Battle.CardAction.new(player, "PLAYER_IDLE")
			action.execute_func = function(self, user) self:end_action() end
			return action
		end
	end
	
	shadowing.update_func = function(self, dt)
		--Handle reducing the cooldown. If it reaches 0 then we can use the special again.
		if shadowing_special_cooldown > 0 then shadowing_special_cooldown = shadowing_special_cooldown - 1 end
	end
	
	shadowing.charged_attack_func = function(player)
		local props = HitProps.new(
			(player:get_attack_level() * 10),
			Hit.Impact,
			Element.Wood,
			nil,
			Drag.None
		)
		return powdershot.card_create_action(player, props)
	end
	
    player.normal_attack_func = function(player)
		return Battle.Buster.new(player, false, player:get_attack_level() * 1)
	end
    player.charged_attack_func = function(player)
		if current_form == "phoenix" then
			return phoenix.charged_attack_func(player)
		else
			local props = HitProps.new(
				(player:get_attack_level() * 10),
				Hit.Impact,
				Element.Wind,
				player:get_context(),
				Drag.None
			)
			return hypnopulse.card_create_action(player, props)
		end
	end
	player.battle_end_func = function(self)
		if player.charge ~= nil then
			player:sprite():remove_node(player.charge)
			player.charge = nil
		end
        if player.charge_animate_component then
			player.charge_animate_component:eject()
			player.charge_animate_component = nil
		end
    end
end

function buster_spam_action(dark_rock, damage)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            nil,
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end