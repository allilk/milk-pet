local card = {}

card.card_create_action = function(player, props)
    local action = Battle.CardAction.new(player, "PLAYER_THROW")
    action.execute_func = function(self, user)
        print("executing action")
        create_meteor_component(player, props) --Create the component, this will inject it as well.
    end
    return action
end

function create_meteor_component(player, props)
    if not player or player and player:is_deleted() then return end
    print("starting component creation")
    local meteor_component = Battle.Component.new(player, Lifetimes.Battlestep)
    meteor_component.count = math.random(3, 6)
    meteor_component.attack_cooldown_max = 32
    meteor_component.highlight_cooldown_max = 24
    meteor_component.highlight_cooldown = 24
    meteor_component.initial_cooldown = 40
    meteor_component.attack_cooldown = 0
    meteor_component.owner = player
    meteor_component.accuracy_chance = 20
    meteor_component.tile_list = {}
    meteor_component.create_once = true
    meteor_component.next_tile = nil
    meteor_component.desired_cooldown = 0
    meteor_component.props = props
    meteor_component.field = player:get_field()
	meteor_component.stored_team = player:get_team()
	meteor_component.enemy_filter = function(character)
		return character:get_team() ~= meteor_component.stored_team
	end
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local desired_tile = meteor_component.field:tile_at(x, y)
            --Neat trick: if you only have one declaration, you can put it all in a single line like this with the if statement.
            if not desired_tile or desired_tile and not desired_tile:is_edge() and not player:is_team(desired_tile:get_team()) then table.insert(meteor_component.tile_list, desired_tile) end
        end
    end
    meteor_component.update_func = function(self, dt)
        if self.owner:is_deleted() then return end
        if self.count <= 0 then
            self:eject()
        else
            print("updating meteor component")
            if self.initial_cooldown > 0 then self.initial_cooldown = self.initial_cooldown - 1 return end
            if self.next_tile ~= nil then print("flashing tile"); self.next_tile:highlight(Highlight.Flash) end
            if self.highlight_cooldown <= 0 then
                --Use less than or equal to copmarison to confirm a d100 roll of accuracy.
                --Example: if a player has an accuracy chance of 20, then a 1 to 100 roll will
                --Only target the player's tile on a roll of 1-20, leading to an 80% chance of
                --Targeting a random player tile.
                if math.random(1, 100) <= self.accuracy_chance then
                    local target_list = self.field:find_nearest_characters(self.owner, self.enemy_filter)
                    local target = nil
                    if #target_list > 0 then target = target_list[1] end
                    if target ~= nil then
                        self.next_tile = target:get_tile()
                    else
                        self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                    end
                else
                    self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                end
                self.highlight_cooldown = self.highlight_cooldown_max
            else
                self.highlight_cooldown = self.highlight_cooldown - 1
            end
            if self.attack_cooldown <= self.desired_cooldown and self.next_tile ~= nil then
                self.count = self.count - 1
                self.attack_cooldown_max = self.attack_cooldown_max
                self.attack_cooldown = self.attack_cooldown_max
                self.field:spawn(create_meteor(self.owner, self.props), self.next_tile)
            else
                self.attack_cooldown = self.attack_cooldown - 1
            end
        end
    end
    player:register_component(meteor_component)
end

function create_meteor(player, props)
    if not player or player and player:is_deleted() then return end
    local meteor = Battle.Spell.new(player:get_team())
    meteor:highlight_tile(Highlight.Flash)
    meteor:set_facing(player:get_facing())
    meteor:set_hit_props(props)
    meteor.field = player:get_field()
    meteor:set_texture(Engine.load_texture(_folderpath.."meteor.png"))
    local anim = meteor:get_animation()
    anim:load(_folderpath.."meteor.animation")
    anim:set_state("DEFAULT")
    anim:refresh(meteor:sprite())
    meteor:sprite():set_layer(-2)
    meteor.boom = Engine.load_texture(_folderpath.."ring_explosion.png")
    meteor.cooldown = 16
    local x = 224
    meteor.increment_x = 14
    meteor.increment_y = 14
	local y = 224
	if player:get_facing() == Direction.Right then x = x * - 1 end
    local sound_1 = Engine.load_audio(_modpath.."sounds/meteor_land.ogg")
    local sound_2 = Engine.load_audio(_modpath.."sounds/meteor_explosion.ogg")
    meteor:set_offset(meteor:get_offset().x+x, meteor:get_offset().y-y)
    meteor.update_func = function(self, dt)
        if self.cooldown <= 0 then
            local tile = self:get_tile()
            if tile and tile:is_walkable() then
                tile:attack_entities(self)
                self:shake_camera(5, 0.3)
                local explosion = Battle.Spell.new(self:get_team())
                explosion:set_texture(self.boom)
                local new_anim = explosion:get_animation()
                new_anim:load(_folderpath.."ring_explosion.animation")
                new_anim:set_state("DEFAULT")
                new_anim:refresh(explosion:sprite())
                explosion:sprite():set_layer(-2)
                Engine.play_audio(sound_1, AudioPriority.Low)
                self.field:spawn(explosion, tile)
                new_anim:on_frame(3, function()
                    Engine.play_audio(sound_2, AudioPriority.Low)
                end)
                new_anim:on_complete(function()
                    explosion:erase()
                end)
            end
            self:erase()
        else
            local offset = self:get_offset()
			if self:get_facing() == Direction.Right then
				self:set_offset(offset.x+self.increment_x, offset.y+self.increment_y)
			else
            	self:set_offset(offset.x-self.increment_x, offset.y+self.increment_y)
			end
            self.cooldown = self.cooldown - 1
        end
    end
    meteor.can_move_to_func = function(tile)
        return true
    end
    return meteor
end

return card