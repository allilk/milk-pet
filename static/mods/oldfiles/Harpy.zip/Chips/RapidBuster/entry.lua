local card = {}

card.card_create_action = function(player)
    local rapid_buster_cooldown = 0
    local rapid_buster_cooldown_max = 8
    local feather = Engine.load_texture(_folderpath.."feather.png")
    local flare_texture = Engine.load_texture(_folderpath.."busterflare.png")
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    local sound = Engine.load_audio(_modpath.."sounds/meteor_land.ogg")
    local hit_sound = Engine.load_audio(_modpath.."sounds/meteor_explosion.ogg")
    action:set_lockout(make_sequence_lockout())
    action.action_end_func = function(self)       
        player.is_rapid_buster = false
    end
    action.animation_end_func = function(self)
        local p_anim = player:get_animation()
        p_anim:set_state("PLAYER_SHOOTING")
        p_anim:set_playback(Playback.Loop)
        p_anim:refresh(player:sprite())
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(player:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(player:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster:sprite())
        buster_anim:set_playback(Playback.Loop)
        buster_anim:on_frame(2, function()
            local first_flare = buster:add_attachment("endpoint")
            first_flare:sprite():set_texture(flare_texture)
            local flare_anim = first_flare:get_animation()
            flare_anim:load(_folderpath.."busterflare.animation")
            flare_anim:set_state("DEFAULT")
            flare_anim:refresh(first_flare:sprite())
            flare_anim:set_playback(Playback.Loop)
        end)
    end
    action.execute_func = function(self, user)
        local step = Battle.Step.new()
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)

        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        buster_anim:refresh(buster:sprite())
        buster_anim:on_frame(2, function()
            local first_flare = buster:add_attachment("endpoint")
            first_flare:sprite():set_texture(flare_texture)
            local flare_anim = first_flare:get_animation()
            flare_anim:load(_folderpath.."busterflare.animation")
            flare_anim:set_state("DEFAULT")
            flare_anim:refresh(first_flare:sprite())
            flare_anim:set_playback(Playback.Loop)
        end)
        buster_anim:set_playback(Playback.Loop)
        local tile = player:get_tile(player:get_facing(), 1)
        local tile2 = tile:get_tile(Direction.Up, 1)
        local tile3 = tile:get_tile(Direction.Down, 1)
        local field = player:get_field()
        step.update_func = function(self, dt)
            if player:input_has(Input.Released.Shoot) or not player:input_has(Input.Held.Shoot) then
                player.is_rapid_buster = false
            end
            if rapid_buster_cooldown <= 0 then
                if not player.is_rapid_buster then
                    player:get_animation():set_state("PLAYER_IDLE")
                    self:complete_step()
                else
                    rapid_buster_cooldown = rapid_buster_cooldown_max
                    local spell = buster_spam_action(player, player:get_attack_level()*3, feather, false, sound, hit_sound)
                    field:spawn(spell, tile)
                end
            else
                rapid_buster_cooldown = rapid_buster_cooldown - 1
            end
        end
        self:add_step(step)
    end
    return action
end

function buster_spam_action(dark_rock, damage, texture, is_side, sound, hit_sound)
    dark_rock:set_health(dark_rock:get_health() - damage)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_texture(texture)
    spell:set_float_shoe(true)
    spell:set_air_shoe(true)
    local anim = spell:get_animation()
    anim:load(_folderpath.."feather.animation")
    anim:set_state("DEFAULT")
    anim:refresh(spell:sprite())
    anim:set_playback(Playback.Loop)
    local x = math.random(0, 30)
    local y = math.random(90, 120)
    y = y * - 1
    if dark_rock:get_facing() == Direction.Right then x = x * - 1 end
    spell:set_offset(x, y)
    spell:set_facing(dark_rock:get_facing())
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.Fire,
            nil,
            Drag.None
        )
    )
    local limit = 0
    if is_side then limit = 2 end
    local current = 0
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if not self:is_sliding() then
            --Delete the attack if it hits an edge tile.
            if self:get_current_tile():is_edge() and self.slide_started then self:delete() end 
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            --0 frame slide so that it's instantly across the field.
            self:slide(dest, frames(8), frames(0), ActionOrder.Voluntary, function()
                if limit > 0 then
                    current = current + 1
                    if current >= limit then ref:delete() end
                end
                ref.slide_started = true
            end)
        end
    end
    --Delete the buster shot on collision with something it can hurt.
    spell.collision_func = function(self, other)
        Engine.play_audio(hit_sound, AudioPriority.Low)
        self:delete()
    end
    spell.delete_func = function(self) self:erase() end
    --Can move anywhere.
    spell.can_move_to_func = function(tile) return true end
    --Play the buster pea shot sound effect. Low priority so as not to be too annoying, but also so it can override itself.
    Engine.play_audio(sound, AudioPriority.Low)
    return spell
end

return card