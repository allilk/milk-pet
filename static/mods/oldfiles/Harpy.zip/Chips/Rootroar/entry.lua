local chip = {}

chip.card_create_action = function(player)
    local action = Battle.CardAction.new(player, "PLAYER_HIT")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        local step = Battle.Step.new()
        local tremor_component = Battle.Component.new(user, Lifetimes.Battlestep)
        local field = user:get_field()
        --c is a character. check the team. if not the same, return true.
        local query = function(c) return c:get_team() ~= user:get_team() and not c:is_moving() end
        local targets = field:find_characters(query) --acquire a list of all characters meeting the above condition.
        tremor_component.targets = targets
        tremor_component.field = field
        tremor_component.index = 1
        tremor_component.update_func = function(self, dt)
            local owner = self:get_owner()
            if self.index > #self.targets then self:eject() return end
            local foe = self.targets[self.index]
            local hitbox = Battle.Spell.new(owner:get_team())
            hitbox:set_hit_props(
                HitProps.new(
                    0, --Damage
                    Hit.Root, --Hit Flags. Use without Impact to hit through defenses.
                    Element.None, --Element
                    nil, --Context, set to nil so as not to counter in build 2.0
                    Drag.None --Drag direction
                )
            )
            hitbox.cooldown = 3
            hitbox.update_func = function(self, dt)
                local tile = self:get_tile()
                --Only root if tile is walkable.
                if tile:is_walkable() then tile:attack_entities(self) end
                self.cooldown = self.cooldown - 1
                --Nesting bullshit. Reads as "if cooldown is less than 0, and if I'm not deleted, then erase myself."
                if self.cooldown <= 0 then if not self:is_deleted() then self:erase() end end
            end
            self.field:spawn(hitbox, foe:get_tile())
            self.index = self.index + 1
        end
        step.update_func = function(self, dt)
            user:shake_camera(5.0, 1.0)
            Engine.play_audio(Engine.load_audio(_folderpath.."falzar.ogg"), AudioPriority.High)
            user:register_component(tremor_component)
            self:complete_step()
        end
        self:add_step(step)
    end
    return action
end

return chip