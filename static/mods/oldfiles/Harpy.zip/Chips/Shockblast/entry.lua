local chip = {}

chip.card_create_action = function(player, props)
    local action = Battle.CardAction.new(player, "PLAYER_HIT")
	action:override_animation_frames(make_frame_data({{1, 0.5}, {1, 0.5}, {2, 0.2}}))
	action:set_lockout(make_animation_lockout())
	local facing = player:get_facing()
	local direction_list = {
		Direction.Up,
		Direction.join(facing, Direction.Up),
		facing,
		Direction.join(facing, Direction.Down),
		Direction.Down
	}
    action.execute_func = function(self, user)
		local field = user:get_field()
		self:add_anim_action(1, function()
			Engine.play_audio(Engine.load_audio(_folderpath.."sfx.ogg"), AudioPriority.Low)
			local tile = user:get_tile()
			local attack = create_spell(player, props, tile)
			field:spawn(attack, tile)
		end)
        self:add_anim_action(2, function()
			Engine.play_audio(Engine.load_audio(_folderpath.."sfx.ogg"), AudioPriority.High)
			for i = 1, #direction_list, 1 do
				local tile = user:get_tile(direction_list[i], 1)
				local spell = create_spell(user, props, tile)
				field:spawn(spell, tile)
			end
        end)
    end
    return action
end

function create_spell(player, props, tile)
	local spell = Battle.Spell.new(Team.Other)
	spell:set_facing(player:get_facing())
	local animation = spell:get_animation()
	spell.timer = 42
	local flags = Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Blind
	if tile == player:get_tile() then
		spell:set_texture(Engine.load_texture(_folderpath.."Shockblast.png"))
		animation:load(_folderpath.."Shockblast.animation")
		spell.timer = 72
		flags = Hit.Flinch | Hit.Flash | Hit.Blind
	else
		spell:set_team(player:get_team())
		spell:set_texture(Engine.load_texture(_folderpath.."Bolt.png"))
		animation:load(_folderpath.."Bolt.animation")
	end
	local sprite = spell:sprite()
	sprite:set_layer(-3)
	animation:set_state("DEFAULT")
	animation:refresh(sprite)
	animation:set_playback(Playback.Loop)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			flags,
			Element.Elec,
			nil,
			Drag.None
		)
	)
	spell.update_func = function(self, dt)
		if self.timer <= 0 then self:erase() return end
		self:get_tile():attack_entities(self)
		self.timer = self.timer - 1
	end
	return spell
end

return chip