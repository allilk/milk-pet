local card = {}

card.card_create_action = function(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	local TEXTURE = Engine.load_texture(_folderpath.."Moonblade.png")
	local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local tile = user:get_current_tile()
		
		self:add_anim_action(1, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(actor:get_texture())
			hilt_sprite:set_layer(-2)
			hilt_sprite:enable_parent_shader(true)
			
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(actor:get_animation())
			hilt_anim:set_state("HAND")
		end)
		
		self:add_anim_action(3, function()
			local slash = create_slash("0", user, props, TEXTURE, AUDIO)
			actor:get_field():spawn(slash, tile)
		end)
	end
    return action
end

function create_slash(animation_state, user, props, TEXTURE, AUDIO)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(TEXTURE, true)
	spell:set_facing(user:get_facing())
    spell:set_hit_props(props)
    local anim = spell:get_animation()
    anim:load(_folderpath.."Moonblade.animation")
    anim:set_state(animation_state)
	spell:get_animation():on_complete(function() spell:erase() end)
	local field = user:get_field()
	local attack_once = true
    spell.update_func = function(self, dt)
		if attack_once then
			local tile = self:get_tile()
			if tile:get_tile(Direction.UpLeft, 1) then
				tile:get_tile(Direction.UpLeft, 1):highlight(Highlight.Flash)
				local hitbox_ul = Battle.SharedHitbox.new(self, 1)
				hitbox_ul:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_ul, tile:get_tile(Direction.UpLeft, 1))
			end
			if tile:get_tile(Direction.Up, 1) then
				tile:get_tile(Direction.Up, 1):highlight(Highlight.Flash)
				local hitbox_u = Battle.SharedHitbox.new(self, 1)
				hitbox_u:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_u, tile:get_tile(Direction.Up, 1))
			end
			if tile:get_tile(Direction.UpRight, 1) then
				tile:get_tile(Direction.UpRight, 1):highlight(Highlight.Flash)
				local hitbox_ur = Battle.SharedHitbox.new(self, 1)
				hitbox_ur:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_ur, tile:get_tile(Direction.UpRight, 1))
			end
			if tile:get_tile(Direction.Right, 1) then
				tile:get_tile(Direction.Right, 1):highlight(Highlight.Flash)
				local hitbox_r = Battle.SharedHitbox.new(self, 1)
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile:get_tile(Direction.Right, 1))
			end
			if tile:get_tile(Direction.Left, 1) then
				tile:get_tile(Direction.Left, 1):highlight(Highlight.Flash)
				local hitbox_l = Battle.SharedHitbox.new(self, 1)
				hitbox_l:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_l, tile:get_tile(Direction.Left, 1))
			end
			if tile:get_tile(Direction.DownLeft, 1) then
				tile:get_tile(Direction.DownLeft, 1):highlight(Highlight.Flash)
				local hitbox_dl = Battle.SharedHitbox.new(self, 1)
				hitbox_dl:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_dl, tile:get_tile(Direction.DownLeft, 1))
			end
			if tile:get_tile(Direction.Down, 1) then
				tile:get_tile(Direction.Down, 1):highlight(Highlight.Flash)
				local hitbox_d = Battle.SharedHitbox.new(self, 1)
				hitbox_d:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_d, tile:get_tile(Direction.Down, 1))
			end
			if tile:get_tile(Direction.DownRight, 1) then
				tile:get_tile(Direction.DownRight, 1):highlight(Highlight.Flash)
				local hitbox_dr = Battle.SharedHitbox.new(self, 1)
				hitbox_dr:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_dr, tile:get_tile(Direction.DownRight, 1))
			end
			attack_once = false
		end
    end
	spell.collision_func = function(self, other)
	end
    spell.attack_func = function(self, other)
    end
    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	Engine.play_audio(AUDIO, AudioPriority.High)

    return spell
end

return card