local card = {}

card.card_create_action = function(player, props)
    --Use frames with specific timing.
    local frame1 = {1, 0.03}
    local frame2 = {2, 0.03}
    local frame3 = {3, 0.03}
    local frame4 = {4, 0.17}
    --Override the shooting animation with 3 sets of buster attacks.
    local frame_sequence = make_frame_data({frame1, frame2, frame1, frame1, frame1, frame2, frame1, frame1, frame1, frame2, frame3, frame4})
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    action:override_animation_frames(frame_sequence)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)
        
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        self:add_anim_action(2, function()
            local spell1 = create_fireball(player, props)
            player:get_field():spawn(spell1, player:get_tile(player:get_facing(), 1))
        end)
        
        self:add_anim_action(6, function()
            local spell2 = create_fireball(player, props)
            player:get_field():spawn(spell2, player:get_tile(player:get_facing(), 1))
        end)
        
        self:add_anim_action(10, function()
            props.flags = props.flags & Hit.Flash --Add flashing to the final hit
            local spell3 = create_fireball(player, props)
            player:get_field():spawn(spell3, player:get_tile(player:get_facing(), 1))
        end)
    end
    return action
end

function create_fireball(player, props)
	local spell = Battle.Spell.new(player:get_team())
	spell:set_texture(Engine.load_texture(_folderpath.."fireball.png", true))
	local direction = player:get_facing()
	spell:set_facing(direction)
	spell:highlight_tile(Highlight.Solid)
	spell:set_hit_props(props)
	local query = function(ent)
		return Battle.Obstacle.from(ent) ~= nil and not ent:is_team(spell:get_team()) or Battle.Character.from(ent) ~= nil and not ent:is_team(spell:get_team())
	end
	local sprite = spell:sprite()
	sprite:set_layer(-1)
	local animation = spell:get_animation()
	animation:load(_folderpath .. "fireball.animation")
	animation:set_state("DEFAULT")
	animation:refresh(sprite)
	spell.has_hit = false
	spell:set_height(50)
	
	spell.update_func = function(self, dt)
		spell:get_current_tile():attack_entities(spell)
		if self:get_current_tile():is_edge() and self.slide_started then 
			self:delete()
		end
		local dest = self:get_tile(spell:get_facing(), 1)
		local ref = self
		if not self.has_hit then
            --Slide to the next tile at 5 frames per tile. Fast.
			self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
		end
	end
	local field = player:get_field()
	spell.collision_func = function(self, other)
		self.has_hit = true
        --Use a spell instead of an artifact so it doesn't animate during time freeze.
        --An artifact would, so use it if you WANT it to animate during time freeze.
		local fx1 = Battle.Spell.new(self:get_team())
		fx1:set_texture(Engine.load_texture(_folderpath.."spell_explosion.png"), true)
		local fx1_anim = fx1:get_animation()
		fx1_anim:load(_folderpath.."spell_explosion.animation")
		fx1_anim:set_state("Default")
		fx1_anim:refresh(fx1:sprite())
        --Set the layer to -2 so it appears on top of enemies and stuff.
		fx1:sprite():set_layer(-2)
		fx1_anim:on_complete(function() fx1:erase() end)
        --Actually spawn it on the tile you want it to spawn on.
		field:spawn(fx1, self:get_tile())
		self:erase()
	end
    --You can put simple functions that only do one thing in a single line, like this.
	spell.can_move_to_func = function(tile) return true end
    --You don't need to store everything in a variable, not if it's only going to be used once.
	Engine.play_audio(Engine.load_audio(_modpath.."sounds/fireball.ogg"), AudioPriority.Highest)
	return spell
end

return card