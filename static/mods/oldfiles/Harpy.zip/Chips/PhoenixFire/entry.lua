local card = {}

card.wave_texture = Engine.load_texture(_folderpath .. "firewave.png")
card.wave_animation = "firewave.animation"

card.card_create_action = function(player, props)
    local action = Battle.CardAction.new(player, "PLAYER_THROW")
    action.execute_func = function(self, user)
        self:add_anim_action(3, function()
            spawn_shockwave(player, player:get_tile(player:get_facing(), 1), player:get_facing(), props)
        end)
    end
    return action
end

function spawn_shockwave(owner, tile, direction, props)
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end
        Engine.play_audio(AudioType.Meteor, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(props)

        local sprite = spell:sprite()
        sprite:set_texture(card.wave_texture)
        sprite:set_layer(-1)

        local animation = spell:get_animation()
        animation:load(_folderpath .. card.wave_animation)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)

        animation:on_frame(3, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() end)

        spell.attack_func = function(self, other)
            owner:set_health(owner:get_health() + props.damage)
        end

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

return card