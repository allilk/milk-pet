local card = {}

card.card_create_action = function(player, props)
    local tile = player:get_tile(player:get_facing(), 1)
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(user:get_texture())
        buster_sprite:set_layer(-2)
        buster_sprite:enable_parent_shader(true)
        
        local buster_anim = buster:get_animation()
        buster_anim:copy_from(user:get_animation())
        buster_anim:set_state("BUSTER")
        self:add_anim_action(2, function()
            local spell = create_powder(player, props)
            player:get_field():spawn(spell, tile)
        end)
    end
	return action
end

function create_powder(user, props)
	local spell = Battle.Spell.new(user:get_team())
	local direction = user:get_facing()
	spell:highlight_tile(Highlight.Solid)
	spell:set_facing(direction)
	spell:set_hit_props(props)
	local TEXTURE = Engine.load_texture(_folderpath.."scalepowder.png", true)
	spell:set_texture(TEXTURE, true)
	local fx_anim = spell:get_animation()
	fx_anim:load(_folderpath.."powder.animation")
	fx_anim:set_state("DEFAULT")
	fx_anim:set_playback(Playback.Loop)
	
	local teleport_cooldown = 12
	spell.update_func = function(self, dt)
		spell:get_tile():attack_entities(self)
		if spell:get_tile():is_edge() then
			spell:delete()
		end
		if teleport_cooldown <= 0 and not self:is_teleporting() then
			self:teleport(self:get_tile(self:get_facing(), 1), ActionOrder.Immediate, function() end)
			teleport_cooldown = 12
		else
			teleport_cooldown = teleport_cooldown - 1
		end
	end
	
	spell.collision_func = function(self, other)
		self:delete()
	end

	spell.delete_func = function(self)
		self:erase()
	end
	
    spell.can_move_to_func = function(self, tile)
        return true
	end
	
	return spell
end

return card