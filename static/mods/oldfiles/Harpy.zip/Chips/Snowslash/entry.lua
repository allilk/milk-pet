local card = {}
card.card_create_action = function(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SWORD")
	local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_slashes.png")
	--Specially time the sword arm attack.
	local frame1 = {4, 0.1500}
	local frame2 = {3, 0.0750}
	local frame3 = {2, 0.0750}
	local frame4 = {1, 0.1700}
	--Override the animation.
	local frame_override = make_frame_data({frame1, frame2, frame3, frame4})
	action:override_animation_frames(frame_override)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		self:add_anim_action(1, function()
			--When we create the attachment, we want to grab the sprite as well.
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-2)
			--Set the shader so it mimics the pallet.
			hilt_sprite:enable_parent_shader(true)
			
			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HAND")
			--Refresh so it's frame perfect.
			hilt_anim:refresh(hilt_sprite)
			--Reverse the animation to play properly with the frame override we used.
			hilt_anim:set_playback(Playback.Reverse)
		end)

		self:add_anim_action(3,	function()
			--Create the wide sword.
			local sword = create_slash(user, props)
			--Grab the tile directly ahead of us in the direction we're facing.
			local tile = user:get_tile(user:get_facing(), 1)
			--Make two shared hitboxes that share the properties of the sword.
			local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
			sharebox1:set_hit_props(sword:copy_hit_props())
			local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
			sharebox2:set_hit_props(sword:copy_hit_props())
			--Spawn all three attacks.
			user:get_field():spawn(sharebox1, tile:get_tile(Direction.Up, 1))
			user:get_field():spawn(sword, tile)
			user:get_field():spawn(sharebox2, tile:get_tile(Direction.Down, 1))
			--Create a spell to animate the slash.
			local fx = Battle.Spell.new(user:get_team())
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			--Give it its texture and animation.
			fx:set_texture(Engine.load_texture(_folderpath.."spell_sword_slashes.png"), true)
			anim:load(_folderpath.."spell_sword_slashes.animation")
			anim:set_state("WIDE")
			--Reverse it too, so that its animation makes sense with the downswing we're making.
			anim:set_playback(Playback.Reverse)
			--Delete the animation and attack
			anim:on_complete(function()
				fx:erase()
				--if the sword didn't delete on impact then get rid of it.
				if not sword:is_deleted() then sword:erase() end
			end)
			user:get_field():spawn(fx, tile)
		end)
	end
	return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:highlight_tile(Highlight.Flash)
	spell:set_hit_props(props)
	spell.update_func = function(self, dt)
		--Highlight the tiles up and down.
		local tile = self:get_tile()
		if not tile:get_tile(Direction.Up, 1):is_edge() then tile:get_tile(Direction.Up, 1):highlight(Highlight.Flash) end
		if not tile:get_tile(Direction.Down, 1):is_edge() then tile:get_tile(Direction.Down, 1):highlight(Highlight.Flash) end
		tile:attack_entities(self)
	end
	spell.collision_func = function(self, other)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(Engine.load_audio(_folderpath.."sfx.ogg"), AudioPriority.Low)

	return spell
end

return card