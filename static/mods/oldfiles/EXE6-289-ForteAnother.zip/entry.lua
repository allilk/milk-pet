local DAMAGE = 160

local FORTE_TEXTURE = Engine.load_texture(_modpath.."forte.png")
local FORTE_ANIMPATH = _modpath.."forte.animation"
local FORTE_AUDIO_CHARGE = Engine.load_audio(_modpath.."forte-charge.ogg")
local HELLSROLLING_TEXTURE = Engine.load_texture(_modpath.."hellsrolling.png")
local HELLSROLLING_ANIMPATH = _modpath.."hellsrolling.animation"
local HELLSROLLING_AUDIO = Engine.load_audio(_modpath.."hellsrolling.ogg")
local AFTERIMAGE_TEXTURE = Engine.load_texture(_modpath.."hellsrolling_afterimage.png")
local AFTERIMAGE_ANIMPATH = _modpath.."hellsrolling_afterimage.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."exe6-spawn.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_modpath.."effect.png")
local EFFECT_ANIMPATH = _modpath.."effect.animation"

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-289-ForteAnother")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F"})

    local props = package:get_card_props()
    props.shortname = "ForteAno"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "4 rings that turn 1 time!"
    props.long_description = "Throw 4 rings that turn only once!"
    props.can_boost = true
	props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local VOICEACTING = false
        local input_time = 40
        local voiceline_number = 0

        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()
        local self_tile = user:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)

		local step1 = Battle.Step.new()

        self.forte = nil
        self.tile    = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if input_time > 0 then
                --print("READING")
                input_time = input_time - 1
                if user:input_has(Input.Held.Use) then
                    --print("VOICE")
                    VOICEACTING = true
                end
            end

            if do_once then
                do_once = false
                ref.forte = Battle.Artifact.new()
                ref.forte:set_facing(direction)
                local forte_sprite = ref.forte:sprite()
		    	forte_sprite:set_texture(FORTE_TEXTURE, true)
		    	forte_sprite:set_layer(-2)
                local forte_anim = ref.forte:get_animation()
                forte_anim:load(FORTE_ANIMPATH)
                --[[if self_tile ~= nil or not self_tile:is_hole() then
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") is NOT a hole!")
                    forte_anim:set_state("0")
		    	    forte_anim:refresh(forte_sprite)
				else
					print("Tile ("..self_tile:x()..";"..self_tile:y()..") IS a hole!")
                    forte_anim:set_state("1")
		    	    forte_anim:refresh(forte_sprite)
				end]]
                forte_anim:set_state("0")
		    	forte_anim:refresh(forte_sprite)
                forte_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
                end)
                forte_anim:on_frame(10, function()
                    Engine.play_audio(FORTE_AUDIO_CHARGE, AudioPriority.High)
                end)
                forte_anim:on_frame(10, function()
                    print("Forte: Hell's Rolling!")
                end)
                for i = 26, 28, 2 do
                    forte_anim:on_frame(i, function()
                        spawn_hellsrolling(user, props, user:get_tile(direction, 1), team, direction, field, -1, false)
                    end)
                end
                for j = 27, 29, 2 do
                    forte_anim:on_frame(j, function()
                        spawn_hellsrolling(user, props, user:get_tile(direction, 1), team, direction, field,  1, false)
                    end)
                end
		    	forte_anim:on_complete(function()
		    		ref.forte:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.forte, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		actor:reveal()
	end
	return action
end

function spawn_hellsrolling(owner, props, tile, team, direction, field, up_or_down, debug)
    local spawn_next
    spawn_next = function()
        --if tile:is_hole() then return end

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            owner:get_id(),
            Drag.None)
        )
        spell.frms = 4
        spell.timing = 0
        spell.offsetX = nil
        spell.afterimages = false

        local diagTargeted = false
        local dirDiag
        if direction == Direction.Right then
            spell.offsetX = -33
            if    up_or_down == -1 then
                dirDiag = Direction.DownRight
            elseif up_or_down == 1 then
                dirDiag = Direction.UpRight
            end
        else
            spell.offsetX = 33
            if    up_or_down == -1 then
                dirDiag = Direction.DownLeft
            elseif up_or_down == 1 then
                dirDiag = Direction.UpLeft
            end
        end

        local query = function(ent)
			if not owner:is_team(ent:get_team()) then
				return true
			end
		end

        local sprite = spell:sprite()
        sprite:set_texture(HELLSROLLING_TEXTURE)
        sprite:set_layer(-3)

        local animation = spell:get_animation()
        animation:load(HELLSROLLING_ANIMPATH)
        animation:set_state("0")
        animation:refresh(sprite)

        local destStart
        if    up_or_down == -1 then
            if direction == Direction.Right then
                destStart = tile:get_tile(Direction.UpLeft, 1)
            else
                destStart = tile:get_tile(Direction.UpRight,  1)
            end
        elseif up_or_down == 1 then
            if direction == Direction.Right then
                destStart = tile:get_tile(Direction.DownLeft, 1)
            else
                destStart = tile:get_tile(Direction.DownRight,  1)
            end
        end

        local doOnce = true
        spell.update_func = function(self)
            self:get_current_tile():attack_entities(spell)
            if debug then
                print(spell.frms)
            end

            if animation:get_state() == "0" then
                animation:on_complete(function() 
                    animation:set_state("1")
                    animation:refresh(sprite)
                end)
            end

            if animation:get_state() == "1" then
                for i = 1, 18, 6 do
                    animation:on_frame(i, function()
                        if spell.timing > 40 then
                            create_effect(AFTERIMAGE_TEXTURE, AFTERIMAGE_ANIMPATH, "0", 0, 0, -2, field, self:get_current_tile())
                        elseif spell.timing < 40 then
                            create_effect(AFTERIMAGE_TEXTURE, AFTERIMAGE_ANIMPATH, "0", spell.offsetX, 0, -2, field, self:get_current_tile())
                        elseif spell.timing == 40 then
                            create_effect(AFTERIMAGE_TEXTURE, AFTERIMAGE_ANIMPATH, "0", 0, 0, -2, field, destStart)
                        end
                    end)
                end
                animation:on_complete(function()
                    animation:set_playback(Playback.Loop)
                end)
            end

            if animation:get_state() == "2" then
                animation:on_complete(function() 
                    spell:delete()
                end)
            end

            --[[if doOnce then
                doOnce = false
                if animation:get_state() == "1" then
                    for i = 1, 18, 6 do
                        animation:on_frame(i, function()
                            create_effect(AFTERIMAGE_TEXTURE, AFTERIMAGE_ANIMPATH, "0", 0, 0, -2, field, self:get_current_tile())
                        end)
                    end
                    animation:on_complete(function()
                        animation:set_playback(Playback.Loop)
                    end)
                end
            end]]

            if spell.timing < 200 then
                spell.timing = spell.timing + 1
            end

            --[[if spell.timing > 40 and spell.frms < 2 then
                spell.frms = spell.frms - 1
            end

            local dest = self:get_tile(direction, 1)
            if spell.timing > 40 then
                self:slide(dest, frames(spell.frms), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true 
                end)
            end
            
            if     spell.timing > 40 and spell.timing < 40+10 then
                spell.frms = 14
            elseif spell.timing > 50 and spell.timing < 50+10 then
                spell.frms = 12
            elseif spell.timing > 60 and spell.timing < 60+10 then
                spell.frms = 10
            elseif spell.timing > 70 and spell.timing < 70+10 then
                spell.frms = 8
            elseif spell.timing > 80 and spell.timing < 80+10 then
                spell.frms = 6
            elseif spell.timing > 90 and spell.timing < 90+10 then
                spell.frms = 4
            elseif spell.timing > 100 and spell.timing < 100+10 then
                spell.frms = 2
            end]]
            if not self:get_current_tile():is_hole() then
                if direction == Direction.Right then
                    if     spell.timing < 10 then
                        spell.offsetX = spell.offsetX - 4.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 10 and spell.timing < 15 then
                        spell.offsetX = spell.offsetX - 2.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 15 and spell.timing < 25 then
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 25 and spell.timing < 30 then
                        spell.offsetX = spell.offsetX + 5.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 30 and spell.timing < 40 then
                        spell.offsetX = spell.offsetX + 9.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing == 40 then
                        spell:set_offset(0, 0)
                    end
                else
                    if     spell.timing < 10 then
                        spell.offsetX = spell.offsetX + 4.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 10 and spell.timing < 15 then
                        spell.offsetX = spell.offsetX + 2.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 15 and spell.timing < 25 then
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 25 and spell.timing < 30 then
                        spell.offsetX = spell.offsetX - 5.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing > 30 and spell.timing < 40 then
                        spell.offsetX = spell.offsetX - 9.0
                        spell:set_offset(spell.offsetX, 0)
                    elseif spell.timing == 40 then
                        spell:set_offset(0, 0)
                    end
                end
            else
                if doOnce then
                    doOnce = false
                    animation:set_state("2")
                    animation:refresh(sprite)
                end
            end

            if self:is_sliding() == false then 
                --[[if self:get_current_tile():is_hole() and self.slide_started then
                    animation:set_state("2")
                    animation:refresh(sprite)
                end]]
    
                local dest = self:get_tile(direction, 1)
                local destDiag = self:get_tile(dirDiag, 1)
                --local destDiag2 = self:get_tile(dirDiag, 1):get_tile(dirDiag, 1)
                
                if not diagTargeted then
                    if spell.timing > 45 then
                        if destDiag ~= nil then
                            if #destDiag:find_characters(query) > 0 then
                                diagTargeted = true
                            end
                        end
                        if self:get_facing() == Direction.Right then
                            if self:get_current_tile():x() <= 4 then
                                if self:get_tile(dirDiag, 2) ~= nil then
                                    if #self:get_tile(dirDiag, 2):find_characters(query) > 0 then
                                        diagTargeted = true
                                    end
                                end
                            end
                        else
                            if self:get_current_tile():x() >= 3 then
                                if self:get_tile(dirDiag, 2) ~= nil then
                                    if #self:get_tile(dirDiag, 2):find_characters(query) > 0 then
                                        diagTargeted = true
                                    end
                                end
                            end
                        end
                    end
                    --[[if destDiag2 ~= nil then
                        if self:get_facing() == Direction.Right then
                            if self:get_current_tile():x() <= 4 then
                                if #destDiag2:find_characters(query) > 0 then
                                    diagTargeted = true
                                end
                            end
                        else
                            if self:get_current_tile():x() >= 3 then
                                if #destDiag2:find_characters(query) > 0 then
                                    diagTargeted = true
                                end
                            end
                        end
                    end]]
                end
                local ref = self
                if spell.timing == 1 then
                    self:slide(destStart, frames(32), frames(0), ActionOrder.Voluntary, function()
                        ref.slide_started = true 
                    end)
                elseif spell.timing > 40 and spell.timing < 45 then
                    self:slide(dest, frames(spell.frms), frames(0), ActionOrder.Immediate, function()
                        ref.slide_started = true 
                    end)
                elseif spell.timing > 45 then
                    if diagTargeted then
                        self:slide(destDiag, frames(spell.frms), frames(0), ActionOrder.Immediate, function()
                            ref.slide_started = true 
                        end)
                    else
                        self:slide(dest, frames(spell.frms), frames(0), ActionOrder.Immediate, function()
                            ref.slide_started = true 
                        end)
                    end
                end
            end
        end

        spell.attack_func = function(self)
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            --create_effect(EFFECT_TEXTURE, EFFECT_ANIMPATH, "0", math.random(-10,10), math.random(-10,10), -99999, field, self:get_current_tile())
        end

        spell.delete_func = function(self)
            print("Hell's Rolling DELETED at tile ("..self:get_current_tile():x()..";"..self:get_current_tile():y()..")")
            --create_effect(HELLSROLLING_TEXTURE, HELLSROLLING_ANIMPATH, "2", 0, 0, -3, field, self:get_current_tile())
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        if    up_or_down == -1 then
            print("Hell's Rolling SPAWNED at tile ("..tile:get_tile(Direction.Up, 1):x()..";"..tile:get_tile(Direction.Up, 1):y()..")")
        elseif up_or_down == 1 then
            print("Hell's Rolling SPAWNED at tile ("..tile:get_tile(Direction.Down, 1):x()..";"..tile:get_tile(Direction.Down, 1):y()..")")
        end

        Engine.play_audio(HELLSROLLING_AUDIO, AudioPriority.Highest)

        field:spawn(spell, tile)
    end

    spawn_next()
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end