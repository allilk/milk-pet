function package_init(package) 
    package:declare_package_id("com.claris.rescued.Roll")
    package:set_special_description("Custom Heal animation!")
    package:set_speed(2.0)
    package:set_attack(5)
    package:set_charged_attack(50)
    package:set_icon_texture(Engine.load_texture(_modpath.."roll_face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
    player:set_name("Roll")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(70.0)
    player:set_animation(_modpath.."roll.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_roll_atlas.png"), true)
    player:set_fully_charged_color(Color.new(255,200,200,255))
	
	local base_animation_path = _modpath.."roll.animation"
    local base_texture = Engine.load_texture(_modpath.."navi_roll_atlas.png", true)
	
    player.update_func = function(self, dt) 
        -- nothing in particular
    end

    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
	
	local sol = player:create_form()
	sol:set_mugshot_texture_path(_modpath.."forms/sol_entry.png")
	sol.on_activate_func = function(self, player)
        player:set_animation(_modpath.."forms/sol_roll.animation")
        player:set_texture(Engine.load_texture(_modpath.."forms/navi_sol_roll_atlas.png"))
        local anim = player:get_animation() 
        anim:refresh(player:sprite())
    end
	
	sol.on_deactivate_func = function(self, player)
        player:set_animation(base_animation_path)
        player:set_texture(base_texture)
        local anim = player:get_animation() 
        anim:refresh(player:sprite())
    end
	sol.charged_attack_func = function()
		print("buster attack charged")
		local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
		action:set_lockout(make_animation_lockout())
		action.execute_func = function(self, user)
			local buster = self:add_attachment("BUSTER")
			buster:sprite():set_texture(Engine.load_texture(_modpath.."forms/navi_sol_roll_atlas.png"))
			buster:sprite():set_layer(-1)
			local buster_anim = buster:get_animation()
			buster_anim:load(_modpath.."forms/sol_roll.animation")
			buster_anim:set_state("BUSTER")
			local do_attack = function()
				local t1 = player:get_tile(player:get_facing(), 1)
				local arrow = create_solar_shot(player)
				player:get_field():spawn(arrow, t1)
			end
			self:add_anim_action(2, do_attack)
		end
		return action
	end
end

function create_normal_attack(player)
    print("buster attack")
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
    print("buster attack charged")
	local action = Battle.CardAction.new(player, "PLAYER_SPECIAL")
    action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
        local do_attack = function()
            local t1 = player:get_tile(player:get_facing(), 1)
			local arrow = create_arrow(player)
			player:get_field():spawn(arrow, t1)
        end
        self:add_anim_action(2, do_attack)
	end
    return action
end

function create_arrow(user)
    local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_offset(-30.0, -82.0)
	spell:set_texture(Engine.load_texture(_modpath.."roll_arrow.png"), true)
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(
        HitProps.new(
            user:get_attack_level() * 10, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            Element.None, 
            user:get_context(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
		if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other) 
    end
	spell.collision_func = function(self, other)
		local gain = math.floor(user:get_max_health()*0.05)
		local TEXTURE = Engine.load_texture(_modpath.."spell_heal.png")
		local AUDIO = Engine.load_audio(_modpath.."sfx.ogg")
		local fx = Battle.Artifact.new()
		fx:set_texture(TEXTURE, true)
		local anim = fx:get_animation()
		anim:load(_modpath.."spell_heal.animation")
		anim:set_state("DEFAULT")
		anim:on_complete(function()
			fx:erase()
		end)
		Engine.play_audio(AUDIO, AudioPriority.Low)
		user:set_health(user:get_health() + gain)
		user:get_field():spawn(fx, user:get_tile())
		self:erase()
	end
    spell:highlight_tile(Highlight.Flash)
	spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end

function create_solar_shot(user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_offset(-30.0, -117.0)
	spell:set_texture(Engine.load_texture(_modpath.."forms/sol_shot.png"), true)
	spell.slide_started = false
	local direction = spell:get_facing()
    spell:set_hit_props(
        HitProps.new(
            user:get_attack_level() * 5, 
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Root, 
            Element.None,
            user:get_context(), 
            Drag.None
        )
    )

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
		if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(5), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other) 
    end
	spell.collision_func = function(self, other)
		self:erase()
	end
    spell:highlight_tile(Highlight.Flash)
	spell.can_move_to_func = function(tile)
        return true
    end
    return spell
end