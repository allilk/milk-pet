function package_init(block)
    block:declare_package_id("com.example.block.SetIce")
    block:set_name("SetIce")
    block:as_program()
    block:set_description("Set all ice tiles")
    block:set_color(Blocks.Green)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        1, 1, 1, 0, 0,
        0, 1, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player) 
    local f = player:get_field()

    for i=1, 6 do
        for j=1, 3 do
            f:tile_at(i, j):set_state(TileState.Ice)
        end
    end

    print("set ice!")
end