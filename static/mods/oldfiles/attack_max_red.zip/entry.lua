function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.AttackMAX.red.bn6")
    block:set_name("AttackMAX")
    block:set_description("MegaBstr\nAttck\nbecomes 5")
    block:set_color(Blocks.Red)
    block:set_shape({
        0, 1, 1, 0, 0,
        0, 1, 1, 0, 0,
        0, 1, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_attack_level(5)
end
