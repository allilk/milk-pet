function package_init(package) 
    package:declare_package_id("com.Rework.A.S573")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'Q', 'R', 'S', 'T'})

    local props = package:get_card_props()
    props.shortname = "Tremor"
    props.damage = 0
    props.time_freeze = false
    props.element = Element.None
    props.description = "Dstructve full scrn shake!"
	props.card_class = CardClass.Standard
	props.limit = 1
	props.long_description = "Shake the arena, cracking panels and rooting enemies!"
	props.can_boost = false
end

function card_create_action(player, props)
	print("in create_card_action()!")
    local action = Battle.CardAction.new(player, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        local step = Battle.Step.new()
        local tremor_component = Battle.Component.new(user, Lifetimes.Battlestep)
        local field = user:get_field()
        --c is a character. check the team. if not the same, return true.
        local query = function(c) return c:get_team() ~= user:get_team() end
        local targets = field:find_characters(query) --acquire a list of all characters meeting the above condition.
        tremor_component.targets = targets
        tremor_component.field = field
        for x = 1, 6, 1 do
            for y = 1, 3, 1 do
                local tile = field:tile_at(x, y)
                if tile:is_walkable() then
                    --If not cracked then crack it.
                    --Else if it IS cracked, break it.
                    if tile:get_state() ~= TileState.Cracked then tile:set_state(TileState.Cracked)
                    else tile:set_state(TileState.Broken) end
                end
            end
        end
        tremor_component.index = 1
        tremor_component.update_func = function(self, dt)
            local owner = self:get_owner()
            if self.index > #self.targets then self:eject() return end
            local foe = self.targets[self.index]
            local hitbox = Battle.Spell.new(owner:get_team())
            hitbox:set_hit_props(
                HitProps.new(
                    0, --Damage
                    Hit.None | Hit.Root, --Hit Flags
                    Element.None, --Element
                    nil, --Context, set to nil so as not to counter in build 2.0
                    Drag.None --Drag direction
                )
            )
            hitbox.cooldown = 3
            hitbox.update_func = function(self, dt)
                local tile = self:get_tile()
                --Only root if tile is walkable.
                if tile:is_walkable() then tile:attack_entities(self) end
                self.cooldown = self.cooldown - 1
                --Nesting bullshit. Reads as "if cooldown is less than 0, and if I'm not deleted, then erase myself."
                if self.cooldown <= 0 then if not self:is_deleted() then self:erase() end end
            end
            self.field:spawn(hitbox, foe:get_tile())
            self.index = self.index + 1
        end
        step.update_func = function(self, dt)
            user:shake_camera(8.0, 1.0)
            Engine.play_audio(Engine.load_audio(_modpath.."boom.ogg"), AudioPriority.Low)
            user:register_component(tremor_component)
            self:complete_step()
        end
        self:add_step(step)
    end
    return action
end