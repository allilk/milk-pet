function package_init(package) 
    package:declare_package_id("com.alrysc.player.MedicineEXE")
    package:set_special_description("Yamame's navi!")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(50)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."MedicineOw.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
   -- package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Medicine")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(70)
    player:set_animation(_modpath.."Medicine.animation")
    player:set_texture(Engine.load_texture(_modpath.."Medicine.png"), true)
    player:set_fully_charged_color(Color.new(255,255,0,255))
    player:set_charge_position(-4, -28)

    player.sounds = {
        hit = Engine.load_audio(_modpath.."hit.ogg"),
        bomb = Engine.load_audio(_modpath.."bomb.ogg")

    }

    player:set_float_shoe(true)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end

    local defense = Battle.DefenseRule.new(224,DefenseOrder.CollisionOnly)

    defense.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()
        if attacker_hit_props.damage > 0 then

            if attacker_hit_props.element == Element.Fire or attacker_hit_props.element == Element.Elec then 
                attacker_hit_props.damage = attacker_hit_props.damage + attacker_hit_props.damage
                attacker:set_hit_props(attacker_hit_props)

                local alert = graphic_init("artifact", 32, 0, "overlay_fx07_animations.png", "overlay_fx07_animations.animation", -9, "0", defender, defender:get_facing(), true)
                local y = defender:get_height()+14
                if y < 20 then 
                    y = 40
                end
                alert:set_elevation(y)
                defender:get_field():spawn(alert, defender:get_current_tile())

            end

        end


    end

    player:add_defense_rule(defense)

    
    local function base_normal_attack(player)
        return Battle.Buster.new(player, false, player:get_attack_level())

    end

    player.normal_attack_func = base_normal_attack


    

    function create_poison(user, tile, facing, context)
        if user:is_deleted() or not tile or tile:is_edge() or not tile:is_walkable() then 
            return 
        end
    
        local spell = graphic_init("spell", 0, 0, "MedicineAttack.png", "Medicine.animation", -4, "GAS", user, facing, true)
        local spell_anim = spell:get_animation()
        spell:set_name("Element.Poison")
        spell.attacking = true
    
        local hit_props = HitProps.new(
            10 + user:get_attack_level()*20,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None, 
            context, 
            Drag.None
        )
    
        spell:set_hit_props(hit_props)
    
        spell_anim:on_frame(1, function()
            Engine.play_audio(user.sounds.bomb, AudioPriority.Low)
            if tile:get_state() == TileState.Grass then 
                tile:set_state(TileState.Poison)
            end
        end)
        spell_anim:on_frame(3, function()
            spell.attacking = false
        end)
    
    
        spell_anim:on_frame(6, function()
            create_poison(user, tile:get_tile(facing, 1), spell:get_facing(), context)
    
        end)
    
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(user.sounds.hit, AudioPriority.Low)

        end
    
    
        user:get_field():spawn(spell, tile)
    end
        
    local function charge_attack(player)
        local action = Battle.CardAction.new(player, "CHARGE_ATTACK")



        action.execute_func = function()
            action:add_anim_action(2, function()
                local facing = player:get_facing()
                create_poison(player, player:get_current_tile():get_tile(facing, 1), facing, player:get_context())
            
            end)

        end

        return action
    end

    player.charged_attack_func = charge_attack

end