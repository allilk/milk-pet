local DAMAGE = 160

local TEXTURE_NAVI = Engine.load_texture(_modpath.."colonel.png")
local SLASH_TEXTURE = Engine.load_texture(_modpath.."colonel_slash.png")
local SLASH_ANIMATION = _modpath.."colonel_slash.animation"
local NAVI_ANIMATION = _modpath.."colonel.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_SCREENDIVIDE = Engine.load_audio(_modpath.."screendivide.ogg")

local TEXTURE_FLASH = Engine.load_texture(_modpath.."flash.png")
local ANIMPATH_FLASH = _modpath.."flash.animation"

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.louise.k1rbyat1na.card.EXE6-273-Colonel")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"C","*"})

    local props = package:get_card_props()
    props.shortname = "Colonel"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Sword
    props.description = "Cut enmy lines in Zshape!"
    props.long_description = "Cut the enemy area into a Z shape!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()
        local team = user:get_team()
        local field = user:get_field()
        local direction = user:get_facing()

        local tile = nil
		if user:get_team() == Team.Red then
			if direction == Direction.Right then
				tile = user:get_field():tile_at(1, 2)
			else
				tile = user:get_field():tile_at(6, 2)
			end
		else
			if direction == Direction.Left then
				tile = user:get_field():tile_at(6, 2)
			else
				tile = user:get_field():tile_at(1, 2)
			end
		end
		local tile_array = {}
		local count = 1
		local max = 6
		local tile_front = nil
		local tile_up = nil
		local tile_down = nil
        local tile_front2 = nil
		local check_front = false
		local check_up = false
		local check_down = false
        local check_front2 = false
		
		for i = count, max, 1 do
			
			tile_front = tile:get_tile(direction, i)
            tile_up = tile_front:get_tile(Direction.Up, 1)
			tile_down = tile_front:get_tile(Direction.Down, 1)
            tile_front2 = tile_front:get_tile(direction, 1)
			
			check_front = tile_front and not user:is_team(tile_front:get_team()) and not tile_front:is_edge() and not tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(direction), 1):get_team())
			check_up = tile_up and not user:is_team(tile_up:get_team()) and not tile_up:is_edge() and not tile_up:get_team() ~= Team.Other and user:is_team(tile_up:get_tile(Direction.reverse(direction), 1):get_team())
			check_down = tile_down and not user:is_team(tile_down:get_team()) and not tile_down:is_edge() and not tile_down:get_team() ~= Team.Other and user:is_team(tile_down:get_tile(Direction.reverse(direction), 1):get_team())
			check_front2 = tile_front2 and not user:is_team(tile_front2:get_team()) and not tile_front2:is_edge() and not tile_front2:get_team() ~= Team.Other and user:is_team(tile_front2:get_tile(Direction.reverse(direction), 1):get_team())

            if check_up and check_down then
                --print("up and down!")
                table.insert(tile_array, tile_front)
				break
            elseif check_front then
                --print("front!")
				table.insert(tile_array, tile_front2)
				break
			end
		end

        local offtile = tile_array[1]:get_tile(direction, 1)
        local tiles = {
            offtile,
            offtile:get_tile(Direction.UpLeft, 1),
            offtile:get_tile(Direction.Up, 1),
            offtile:get_tile(Direction.UpRight, 1),
            offtile:get_tile(Direction.DownLeft, 1),
            offtile:get_tile(Direction.Down, 1),
            offtile:get_tile(Direction.DownRight, 1)
        }

		local step1 = Battle.Step.new()

        self.navi = nil
        self.tile = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.navi = Battle.Artifact.new()
                ref.navi:set_facing(direction)
		    	ref.navi:set_texture(TEXTURE_NAVI, true)
		    	ref.navi:sprite():set_layer(-1)

                navi_anim = ref.navi:get_animation()
                navi_anim:load(NAVI_ANIMATION)
                navi_anim:set_state("SPAWN")
		    	navi_anim:refresh(ref.navi:sprite())
                navi_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	navi_anim:on_complete(function()
		    		navi_anim:set_state("ATTACK")
		    		navi_anim:refresh(ref.navi:sprite())
		    	end)
                field:spawn(ref.navi, ref.tile)
            end
            local anim = ref.navi:get_animation()
            if anim:get_state() == "ATTACK" then
                if do_once_part_two then
                    do_once_part_two = false
                    local sword = create_slash(team, direction, user, props, tiles)
                    local fx = Battle.Artifact.new()
                    fx:set_facing(sword:get_facing())
                    fx:sprite():set_layer(-3)
                    local fx_anim = fx:get_animation()
                    fx:set_texture(SLASH_TEXTURE, true)
                    fx_anim:load(SLASH_ANIMATION)
                    fx_anim:set_state("Slash")
                    fx_anim:refresh(fx:sprite())
                    fx_anim:on_complete(function()
                        fx:erase()
                    end)
                    anim:on_frame(2, function()
                        print("Colonel: NeoScreenDivide!")
                        Engine.play_audio(AUDIO_SCREENDIVIDE, AudioPriority.High)
                    end)
                    anim:on_frame(6, function()
                        create_flashlight(field)
                        for i, tile in ipairs(tiles) do
                            local sharebox = Battle.SharedHitbox.new(sword, 0.05)
                            sharebox:set_hit_props(sword:copy_hit_props())
                            field:spawn(sharebox, tile)
                        end
                    end)
                    anim:on_frame(7, function()
                        ref.navi:shake_camera(25, 0.7)
				        field:spawn(fx, offtile)
                    end)
                    anim:on_frame(8, function()
                        create_flashlight(field)
                    end)
                    anim:on_frame(9, function()
                        create_flashlight(field)
                    end)
                    anim:on_complete(function()
                        sword:erase()
                        ref.navi:erase()
                        step1:complete_step()
                    end)
                end
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action    
end

function create_slash(team, direction, user, props, tiles)
	local spell = Battle.Spell.new(team)
	spell:set_facing(direction)
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_id(),
			Drag.None
		)
	)
    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.High)
    end
    return spell
end

function create_flashlight(field)
    local flashlight = Battle.Artifact.new()
    flashlight:set_facing(Direction.Right)
    flashlight:sprite():set_layer(10)
    flashlight:set_texture(TEXTURE_FLASH, true)
    local flashlight_anim = flashlight:get_animation()
	flashlight_anim:load(ANIMPATH_FLASH)
	flashlight_anim:set_state("0")
	flashlight_anim:refresh(flashlight:sprite())
    flashlight_anim:on_complete(function()
        flashlight:erase()
    end)
    field:spawn(flashlight, 3, 2)
    
    return flashlight
end