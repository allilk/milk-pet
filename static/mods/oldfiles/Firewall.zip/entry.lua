local DAMAGE = 130

local TEXTURE_FLAMETOWER = Engine.load_texture(_modpath.."flametower.png")
local ANIMPATH_FLAMETOWER = _modpath .. "flametower.animation"
local AUDIO_FLAMETOWER = Engine.load_audio(_modpath.."flametower.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath .. "effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.Rework.G.EX1")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"F"})

    local props = package:get_card_props()
    props.shortname = "Firewall"
    props.damage = 240
    props.time_freeze = false
    props.element = Element.Fire
    props.description = "You shall not pass!"
	props.long_description = "The latest in cyber security!"
	props.can_boost = false
    props.card_class = CardClass.Giga
	props.limit = 1
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_HIT")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.1},{2,0.050},{2,0.050},{2,0.050},{2,0.255}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    
    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        local tile = user:get_current_tile()
        self:add_anim_action(2,function()
            user:toggle_counter(true)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self:add_anim_action(5,function()
            spawn_flametower(user, props, tile, team, direction, field)
        end)
    end
    return action
end

function spawn_flametower(owner, props, tile, team, direction, field)
    local spawn_next
    spawn_next = function()
        local tile_U = tile:get_tile(Direction.join(Direction.Up, direction), 1)
        local tile_D = tile:get_tile(Direction.join(Direction.Down, direction), 1)
        local tile_L = tile:get_tile(Direction.reverse(direction), 1)
        local tile_R = tile:get_tile(direction, 1)
        spawn_flametower_next(owner, props, tile_U, team, direction, field, true, true)
        spawn_flametower_next(owner, props, tile_D, team, direction, field, true, true)
        spawn_flametower_next(owner, props, tile_L, team, direction, field, true, true)
        spawn_flametower_next(owner, props, tile_R, team, direction, field, true, true)
    end

    spawn_next()
end

function spawn_flametower_next(owner, props, tile, team, direction, field, is_audio, is_continue)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() or not is_continue then return end
        if is_audio then
            is_audio = false
            Engine.play_audio(AUDIO_FLAMETOWER, AudioPriority.Highest)
        end

        local spell = Battle.Spell.new(Team.Other)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            props.element, 
            owner:get_id(), 
            Drag.new())
        )

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_FLAMETOWER)
        sprite:set_layer(-999)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_FLAMETOWER)
        animation:set_state("SPAWN")
        animation:refresh(sprite)

        animation:on_complete(function()
            animation:set_state("DEFAULT")
            animation:set_playback(Playback.Loop)
        end)

        spell.update_func = function(self, dt)
            if self:is_deleted() then return end
            local own_tile = self:get_tile()
            if not own_tile:is_walkable() then self:delete() return end
            if animation:get_state() == "DEFAULT" then
                own_tile:attack_entities(self)
            end
        end

        spell.collision_func = function(self, other)
            is_continue = false
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-30,30), math.random(-30,30), field, self:get_current_tile())
            animation:set_state("FADE")
            animation:on_complete(function()
                self:erase()
            end)
        end

        spell.attack_func = function(self, other)
            is_continue = false
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
            create_effect(TEXTURE_EFFECT, ANIMPATH_EFFECT, "FIRE", math.random(-30,30), math.random(-30,30), field, self:get_current_tile())
            animation:set_state("FADE")
            animation:on_complete(function()
                self:erase()
            end)
        end

        spell.battle_end_func = function(self)
            is_continue = false
            if not self:is_erased() then
                animation:set_state("FADE")
                animation:on_complete(function()
                    self:erase()
                end)
            end
        end
        spell.can_move_to_func = function(tile)
            return true
        end
        field:spawn(spell, tile)
    end
    if is_continue then
        spawn_next()
        is_continue = false
    end
end

function create_effect(effect_texture, effect_animpath, effect_state, offset_x, offset_y, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(Direction.Right)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-99999)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end