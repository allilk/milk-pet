-- Insert imports here..

local LASERS_TEXTURE = Engine.load_texture(_folderpath .. "lasers.png")
local LASERS_ANIM = _folderpath .. "lasers.animation"
local ROW_LASER_SFX = Engine.load_audio(_folderpath .. "row_laser.ogg")
local BUSTER_TEXTURE = Engine.load_texture(_folderpath .. "buster.png")
local BUSTER_ANIM = _folderpath .. "buster.animation"

local DAMAGE = 150

function package_init(package)
    local props = package:get_card_props()
    props.shortname = "Laser"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "A Laser pierces thru."
    props.long_description = "A laser pierces through."
    props.limit = 3
    package:declare_package_id("com.loui.Laser")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ 'A', 'E', 'L', 'R', 'S' })
end

local frame1 = { 1, 0.033 }
local frame2 = { 2, 0.033 }
local frame3 = { 3, 0.6 }
local frame_data = make_frame_data({
    frame1, frame2, frame3, frame3
})

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")

    action:override_animation_frames(frame_data)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self)
        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(BUSTER_TEXTURE, true)
        buster:sprite():set_layer(-1)
        local buster_anim = buster:get_animation()
        buster_anim:load(BUSTER_ANIM)
        buster_anim:set_state("1")


        self:add_anim_action(2, function()

            local beam = buster:sprite():create_node()
            beam:set_texture(LASERS_TEXTURE)
            local anim = Engine.Animation.new(LASERS_ANIM)
            anim:set_state("ROW_LASER")
            anim:refresh(beam)
            self.animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
            self.animate_component.update_func = function(self, dt)
                anim:update(dt, beam)
                anim:on_complete(function()
                    self:eject()
                end)

            end
            create_laser(user, props.damage, self.animate_component)
            user:register_component(self.animate_component)
        end)
    end
    action.action_end_func = function(self)
        self.animate_component:eject()
    end

    return action
end

function create_laser(user, damage, animate_component)
    local lasers = {}
    local spell = Battle.Spell.new(user:get_team())
    local origin_tile = user:get_current_tile()
    local laser_Hitprops = HitProps.new(
        damage,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None,
        user:get_context(),
        Drag.None
    )
    local duration = 70
    spell:set_hit_props(laser_Hitprops)
    spell.update_func = function(self, dt)
        if (duration == 66) then
            local prev_tile = origin_tile
            while true do
                prev_tile = prev_tile:get_tile(user:get_facing(), 1)
                if (prev_tile == nil) then break end
                local laser = laser_hitbox(prev_tile, user:get_team(), user:get_facing(), user:get_field(),
                    laser_Hitprops)
                table.insert(lasers, laser)
            end
        end
        duration = duration - 1
        if (duration < 0) then
            for index, laser in ipairs(lasers) do
                laser:erase()
            end
            spell:erase()
        end
    end
    spell.attack_func = function(self, other)
    end
    spell.delete_func = function(self)
    end
    Engine.play_audio(ROW_LASER_SFX, AudioPriority.High)


    user:get_field():spawn(spell, origin_tile)
    table.insert(lasers, spell)


    return lasers
end

function laser_hitbox(tile, team, direction, field, laser_Hitprops)
    local spawn

    local spell = Battle.Spell.new(team)
    spawn = function()
        if tile == nil or tile:is_edge() then return end

        spell:set_facing(direction)
        spell:set_hit_props(laser_Hitprops)
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end
        spell.attack_func = function()
            --Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end
        field:spawn(spell, tile)
    end

    spawn()
    return spell
end
