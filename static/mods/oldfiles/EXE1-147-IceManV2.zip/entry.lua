local iceman = include("iceman/iceman.lua")

local DAMAGE = 100

iceman.codes = {"I"}
iceman.shortname = "IceManV2"
iceman.damage = DAMAGE
iceman.time_freeze = true
iceman.element = Element.Aqua
iceman.description = "Blizzard on enemy area!"
iceman.long_description = "Blizzard attack on the entire enemy area!"
iceman.can_boost = true
iceman.card_class = CardClass.Mega
iceman.limit = 1

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE1-147-IceManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(iceman.codes)

    local props = package:get_card_props()
    props.shortname = iceman.shortname
    props.damage = iceman.damage
    props.time_freeze = iceman.time_freeze
    props.element = iceman.element
    props.description = iceman.description
    props.long_description = iceman.long_description
    props.can_boost = iceman.can_boost
	props.card_class = iceman.card_class
	props.limit = iceman.limit
end

card_create_action = iceman.card_create_action