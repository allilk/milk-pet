local DAMAGE = 0

local TEXTURE_METALL = Engine.load_texture(_modpath.."metall.png")
local ANIMPATH_METALL = _modpath .. "metall.animation"
local TEXTURE_SHOCKWAVE = Engine.load_texture(_modpath.."shockwave.png")
local ANIMPATH_SHOCKWAVE = _modpath .. "shockwave.animation"
local TEXTURE_BUTTON = Engine.load_texture(_modpath.."button.png")
local ANIMPATH_BUTTON = _modpath .. "button.animation"
local AUDIO_FALL = Engine.load_audio(_modpath.."metallspawn.ogg")
local AUDIO_SHOCKWAVE = Engine.load_audio(_modpath.."shockwave.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE3-174-Metall")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"E","L","M","O","T"})

    local props = package:get_card_props()
    props.shortname = "Metall"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Summons a Metall to fight!"
	props.long_description = "Summons a Metall to attack!"
	props.can_boost = false
    props.card_class = CardClass.Standard
	props.limit = 3
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
		local step1 = Battle.Step.new()
		local metall = Battle.Artifact.new()
		local do_once0 = true
		local do_once = true
        local do_once1 = true
		local do_once2 = true
		local metall_type = 1
		local attacked = false
        local time_over = false
		step1.update_func = function(self, dt)
			if do_once0 then
                do_once0 = false
                local query = function() return true end
                local tile = user:get_tile(direction, 1)
				metall:set_facing(direction)
				metall:set_texture(TEXTURE_METALL, true)
				local metall_sprite = metall:sprite()
				metall_sprite:set_layer(-3)
                local metall_anim = metall:get_animation()
                metall_anim:load(ANIMPATH_METALL)
                metall_anim:set_state("START")
		    	metall_anim:refresh(metall_sprite)
		    	metall_anim:on_complete(function()
                    if not tile:is_walkable() or #tile:find_characters(query)~= 0 then
		    		    metall_anim:set_state("END")
                    else
                        metall_anim:set_state("SPAWN")
                    end
                    metall_anim:refresh(metall_sprite)
		    	end)
                field:spawn(metall, tile)
            end
			local anim = metall:get_animation()
            if anim:get_state() == "SPAWN" then
                if do_once then
					do_once = false
                    anim:on_frame(2, function()
                        Engine.play_audio(AUDIO_FALL, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                        anim:set_state("SELECT")
                        anim:refresh(metall:sprite())
                        anim:set_playback(Playback.Loop)
                    end)
                end
            end
            if anim:get_state() == "SELECT" then
				if do_once1 then
					do_once1 = false

					local query = function() return true end
                    local tile1 = user:get_tile(direction, 1)
					local tile2 = user:get_tile(direction, 2)

					local button_gui = Battle.Artifact.new()
					button_gui:set_facing(Direction.Right)
		    		button_gui:set_texture(TEXTURE_BUTTON, true)
					local button_sprite = button_gui:sprite()
					button_sprite:set_layer(-9999999)
					local button_anim = button_gui:get_animation()
					button_anim:load(ANIMPATH_BUTTON)
					button_anim:set_state("0")
					button_anim:set_playback(Playback.Loop)
		    		button_anim:refresh(button_sprite)
					field:spawn(button_gui, tile1)

                    local metall_sprite = metall:sprite()

                    local frames = {1,2,1,2,3,2,1,4,1,4,1,3,1,3,1,2,4,1,
                                    2,1,3,1,2,3,1,3,1,2,1,2,1,3,1,4,1,2,
                                    1,2,3,1,2,1,2,3,1,4,2,1,2,1,2,1,2,3,
                                    1,2,4,2,1,3,1,2,1,3,1,3,1,4,1,2,1,3,1}

                    for f = 1, 75, 1 do
                        anim:on_frame(f,function()
                            if      frames[f] == 1 then
                                    metall_type=1
                                    --anim:refresh(metall_sprite)
                            elseif  frames[f] == 2 then
                                    metall_type=2
                                    --anim:refresh(metall_sprite)
                            elseif  frames[f] == 3 then
                                    metall_type=3
                                    --anim:refresh(metall_sprite)
                            else
                                    metall_type=4
                                    --anim:refresh(metall_sprite)
                            end
                        end)
                    end
                    anim:on_complete(function()
                        time_over=true
                    end)

					metall.update_func = function(self, dt)
						if not attacked then
						    if user:input_has(Input.Pressed.Use) or user:input_has(Input.Pressed.Shoot) or time_over then
						    	if do_once2 then
						    		button_gui:erase()
						    		anim:set_state("V"..metall_type.."_ATTACK")
						    		anim:refresh(metall_sprite)
                                    anim:set_playback(Playback.Once)
                                    anim:on_frame(9, function()
                                        print("Metall: Metto!")
						    		end)
						    		anim:on_frame(13, function()
                                        spawn_shockwave(user, team, field, tile2, direction, metall_type)
						    		end)
                                    anim:on_complete(function()
                                        anim:set_state("END")
                                        anim:refresh(metall_sprite)
                                    end)
						    		attacked = true
						    		do_once2=false
						    	end
						    end
					    end
				    end
			    end
			end
            if anim:get_state() == "END" then
                anim:on_complete(function()
                    metall:erase()
                    step1:complete_step()
                end)
            end
		end
		self:add_step(step1)
	end
    return action
end

function spawn_shockwave(owner, team, field, tile, direction, metall_type)
    local damage = getDamageForMetallType(metall_type)
    local frame  = getFrameForMetallType(metall_type)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        Engine.play_audio(AUDIO_SHOCKWAVE, AudioPriority.Highest)

        local spell = Battle.Spell.new(team)
        spell:set_facing(direction)
        spell:set_hit_props(HitProps.new(damage, Hit.Impact|Hit.Flash, Element.None, owner:get_id() , Drag.None))

        local sprite = spell:sprite()
        sprite:set_texture(TEXTURE_SHOCKWAVE)

        local animation = spell:get_animation()
        animation:load(ANIMPATH_SHOCKWAVE)
        animation:set_state("0")
        animation:refresh(sprite)
        animation:on_frame(1, function()
            if metall_type == 4 then
                if spell:get_current_tile():get_state() ~= TileState.Cracked then
                    spell:get_current_tile():set_state(TileState.Cracked)
                else
                    spell:get_current_tile():set_state(TileState.Broken)
                end
            end
        end)
        animation:on_frame(frame, function()
            tile = tile:get_tile(direction, 1)
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end

        spell.attack_func = function()
            Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        end

        field:spawn(spell, tile)
    end

    spawn_next()
end

function getDamageForMetallType(metall_type) 
    if metall_type==1 then
		return 40
	elseif metall_type==2 then
        return 80
    elseif metall_type==3 then
        return 120
    end
	return 150
end

function getFrameForMetallType(metall_type) 
    if metall_type==1 then
		return 10
	elseif metall_type==2 then
        return 7
    elseif metall_type==3 then
        return 5
    end
	return 3
end