

function package_init(package) 
    package:declare_package_id("com.alrysc.card.OmegaRocketBeta")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_codes({'R'})
  
    local props = package:get_card_props()
    props.shortname = "OmgaRktB"
    props.damage = 300
    props.time_freeze = true
    props.element = Element.None
    props.card_class = CardClass.Mega
    props.description = "Fire a delayed rocket!"
    props.limit = 1
  
  end


function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local IDLE = {0, 0.3 }
    local FRAMES = make_frame_data({IDLE})
        
    action:set_lockout(make_animation_lockout())
    action:override_animation_frames(FRAMES)
    local field = user:get_field()
    -- I didn't want to roll random numbers, but I wanted the explosions to look semi-random, so I 
        -- just threw a list together in some sort of non-sequential order
    local tile_list = {
        field:tile_at(3, 1),
        field:tile_at(5, 2),
        field:tile_at(1, 3),
        field:tile_at(6, 2),
        field:tile_at(3, 2),
        field:tile_at(4, 1),
        field:tile_at(2, 2),
        field:tile_at(5, 1),
        field:tile_at(2, 3),
        field:tile_at(4, 2),
        field:tile_at(1, 1),
        field:tile_at(6, 1),
        field:tile_at(2, 1),
        field:tile_at(6, 3),
        field:tile_at(5, 3),
        field:tile_at(1, 2),
        field:tile_at(4, 3),
        field:tile_at(3, 3),
        
        
    }

    local tile_counter = 0
    local explosion_counter = 0
    local explosion_texture = Engine.load_texture(_folderpath.."explosion.png")
    local explosion_animation = _folderpath.."explosion.animation"
    local nextExplosion
    local create_explosion

    
    nextExplosion = function(number)
        if tile_list[1] then 
            if number < 29 then 
                local tile = (number % 18) + 1
                create_explosion(tile_list[tile])
            end
        end
    end

    create_explosion = function(tile)
        if tile then
            local offsetY = 20
            local explosion = Battle.Artifact.new()
            explosion:sprite():set_layer((-1*explosion_counter))
            explosion:set_facing(user:get_facing())
            explosion:set_texture(explosion_texture, false)
            explosion:set_offset(0, offsetY)
            explosion:get_animation():load(explosion_animation)
            explosion:get_animation():set_state("EXPLOSION")

            explosion:get_animation():refresh(explosion:sprite())

            explosion:get_animation():on_complete(function()
                explosion:erase()
            end)
        
            explosion:get_animation():on_frame(3, function()
                explosion_counter = explosion_counter+1
                nextExplosion(explosion_counter)
            end)
            user:get_field():spawn(explosion, tile)
        
        end
    end

    local function create_flash()
        local color = Color.new(0, 0, 0, 0)
        local field = user:get_field()
        local offsetX = 0
        local offsetY = 0
        local flash = Battle.Artifact.new()
        flash:sprite():set_layer(10)
        flash:set_facing(user:get_facing())
        flash:set_texture(Engine.load_texture(_folderpath.."flash.png"), true)
        flash:set_offset(offsetX, offsetY)
        flash:get_animation():load(_folderpath.."flash.animation")
        flash:get_animation():set_state("FLASH")

        flash:get_animation():refresh(flash:sprite())

        flash:get_animation():on_complete(function()
            flash:erase()
        end)

        flash:get_animation():on_frame(2, function()
            color.a = 64
        end)

        flash:get_animation():on_frame(3, function()
            color.a = 128
        end)

        flash:get_animation():on_frame(4, function()
            color.a = 191
        end)

        flash:get_animation():on_frame(5, function()
            color.a = 255
        end)

        flash:get_animation():on_frame(6, function()
            color.a = 191
        end)

        flash:get_animation():on_frame(7, function()
            color.a = 128
        end)

        flash:get_animation():on_frame(8, function()
            color.a = 64
        end)

        flash:get_animation():on_frame(9, function()
            color.a = 0
        end)

       
        
        flash.update_func = function()
            flash:set_color(color)


        end

       field:spawn(flash, field:tile_at(3, 2))

    end

    local function create_attack(user, props)
        local spell = Battle.Spell.new(Team.Other)
        spell:set_hit_props(
            HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            props.element,
            user:get_context(),
            Drag.None
            )
        )

        local effected_tile
        local first_run = true
        spell.update_func = function(self)
            if first_run then 
                for i=1, 18, 1
                do
                    tile_list[i]:attack_entities(self)
                end
                first_run = false
            else
                -- Making sure tiles crack after damage is dealt

                for i=2, 5, 1
                do
                    effected_tile = field:tile_at(i, 1)
                    if effected_tile:get_state() == TileState.Cracked then 
                        effected_tile:set_state(TileState.Broken)
                    else
                        effected_tile:set_state(TileState.Cracked)
                    end
                end

                for i=3, 4, 1
                do
                    effected_tile = field:tile_at(i, 2)
                    if effected_tile:get_state() == TileState.Cracked then 
                        effected_tile:set_state(TileState.Broken)
                    else
                        effected_tile:set_state(TileState.Cracked)
                    end
                end

                self:delete()
            end
        end

        field:spawn(spell, 1, 1)
    end

    local function create_rocket(user, texture, animation)
        local rocket = Battle.Spell.new(user:get_team())
        -- Time here is a bit weird. I resize based on scale, so the missile will explode before it reaches full size
        local scale = 840
        local end_time = scale-100
        local current_time = 0
        local starting_y = -150
        local x = 42
        local color = Color.new(0, 0, 0, 255)
        local shake_timer = 0

        rocket:sprite():set_layer(10)
        rocket:set_texture(texture, false)
        
        if user:get_facing() == Direction.Left then 
        --  x = x * -1
        end
        rocket:set_offset(x, starting_y)
        rocket:get_animation():load(animation)

        rocket:get_animation():set_state("DEFAULT")
        rocket:get_animation():refresh(rocket:sprite())
        rocket:get_animation():set_playback(Playback.Loop)

        user:get_field():spawn(rocket, 3, 1)
        --user:get_field():tile_at(3,1)

        local initial_height = rocket:sprite():get_height() 
        local initial_width = rocket:sprite():get_width()
        rocket:sprite():set_height(0)
        rocket:sprite():set_width(0)
        rocket.update_func = function(self)
            if current_time ~= scale then 
                current_time = current_time+1

                if current_time % 5 == 0 then 
                    rocket:sprite():set_height(math.floor(initial_height * (current_time/end_time)))
                    rocket:sprite():set_width(math.floor(initial_width * (current_time/end_time)))
                    rocket:set_offset(x, (starting_y + math.floor(current_time/6)))

                    
                end
            end

            if current_time > end_time-100 then 
                color.r = color.r + 2
                color.g = color.r
                color.b = color.r

                rocket:set_color(color)

            end

            if current_time == end_time-10 then
                create_flash()
            end


            if current_time == end_time then
                nextExplosion(1)
                Engine.play_audio(Engine.load_audio(_modpath.."impact.ogg"), AudioPriority.Low)
                rocket:get_animation():set_state("GONE")
                create_attack(user, props)
                rocket.update_func = function()
                
                    rocket:shake_camera(450, 0.016)
                    if shake_timer == 81 then 
                        rocket:delete()
                    end
              
                    shake_timer = shake_timer+1
                end
            end
        end

    end

    -- Give custom frame data later, spawn noise
    action.execute_func = function()
        Engine.play_audio(Engine.load_audio(_modpath.."appear.ogg"), AudioPriority.Low)
        local texture = Engine.load_texture(_folderpath.."omegarocketbeta.png")
        local animation = _folderpath.."omegarocketbeta.animation"
        create_rocket(user, texture, animation)
        
    end


    return action
end


