nonce = function() end

local AUDIO = Engine.load_audio(_modpath.."boom.ogg")
local TEXTURE = Engine.load_texture(_modpath.."Cube.png")
local MOB_MOVE_TEXTURE = Engine.load_texture(_modpath.."mob_move.png")
local EXPLOSION_TEXTURE = Engine.load_texture(_modpath.."spell_explosion.png")

function package_init(package) 
    package:declare_package_id("com.Dawn.PAIN.Cube")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'P'})

    local props = package:get_card_props()
    props.shortname = "PainCube"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.Summon
    props.description = "Look out above!"
	props.can_boost = false
	props.long_description = "There was something on your face! IT WAS PAIN!"
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
	
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")		
		local cube = Battle.Obstacle.new(Team.Other)

		cube:set_facing(user:get_facing())
		cube:set_texture(TEXTURE, true)
		local anim = cube:get_animation()
		anim:load(_modpath.."PainCube.animation")
		anim:set_state("FALL")
		anim:set_playback(Playback.Loop)
		anim:refresh(cube:sprite())
		anim:on_complete(function()
			anim:set_state("IDLE")
			anim:refresh(cube:sprite())
			anim:set_playback(Playback.Loop)
		end)
		cube:set_health(200)
		cube:sprite():set_layer(-2)

		-- deletion process var
		local delete_self = nil
		local spawned_hitbox = false
		local countdown = 6000
		-- slide tracker
		local continue_slide = false
		local prev_tile = {}
		local cube_speed = 4

		-- define cube collision hitprops
		local props = HitProps.new(
			200,
			Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking, 
			Element.Break,
			user:get_context(),
			Drag.None)


		-- upon tangible collision
		cube.collision_func = function(self)
			-- define the hitbox with its props every frame
			local hitbox = Battle.Hitbox.new(cube:get_team())
			hitbox:set_hit_props(props)

			if not spawned_hitbox then
				cube:get_field():spawn(hitbox, cube:get_current_tile())
				spawned_hitbox = true
			end
			cube.delete_func()
		end
		-- upon passing the defense check
		cube.attack_func = function(self)
		end

		cube.can_move_to_func = function(self, tile)
			if tile then
				-- get a list of every obstacle with Team.Other on the field
				local field = cube:get_field()
				local cube_team = cube:get_team()
				local Other_obstacles = function(obstacle)
					return obstacle:get_team() == cube_team
				end
				local obstacles_here = field:find_obstacles(Other_obstacles)
				local donotmove = false
				-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
				for ii=1,#obstacles_here do
					if tile == obstacles_here[ii]:get_tile() then
						donotmove = true
					end
				end

				if tile:is_edge() or donotmove or not tile:is_walkable() then
					return false
				end
			end
			return true
		end
		local field = user:get_field()
		local shake = true
		local shake_cooldown = 30
		local query = function(ent)
			if ent == cube then
				return false
			else
				return ent and not ent:is_deleted() and #ent:get_name() > 0
			end
		end
		cube.update_func = function(self, dt)
			if self:get_offset().y >= 0 then
				if shake then
					if not self:get_tile():is_walkable() or self:get_tile():is_edge() then
						local fx = Battle.Artifact.new()
						fx:set_texture(MOB_MOVE_TEXTURE, true)
						local fx_anim = fx:get_animation()
						fx_anim:load(_modpath.."mob_move.animation")
						fx_anim:set_state("DEFAULT")
						fx_anim:refresh(fx:sprite())
						fx_anim:on_complete(function()
							fx:erase()
						end)
						fx:sprite():set_layer(-2)
						user:get_field():spawn(fx, self:get_tile())
						self:delete()
					elseif #self:get_tile():find_characters(query) > 0 or #self:get_tile():find_obstacles(query) > 0 then
						self:shake_camera(5.0, 0.5)
						local hitbox = Battle.Hitbox.new(user:get_team())
						hitbox:set_hit_props(
							HitProps.new(
								200,
								Hit.Impact | Hit.Breaking,
								Element.None,
								user:get_context(),
								Drag.None
							)
						)
						local fx = Battle.Artifact.new()
						fx:set_texture(EXPLOSION_TEXTURE, true)
						local fx_anim = fx:get_animation()
						fx_anim:load(_modpath.."spell_explosion.animation")
						fx_anim:set_state("Default")
						fx_anim:refresh(fx:sprite())
						fx_anim:on_complete(function()
							fx:erase()
						end)
						fx:sprite():set_layer(-2)
						user:get_field():spawn(fx, self:get_tile())
						field:spawn(hitbox, self:get_tile())
						Engine.play_audio(AUDIO, AudioPriority.Low)
						self:delete()
					else
						self:shake_camera(5.0, 0.5)
					end
					shake = false
				end
				if shake_cooldown <= 0 then
					local tile = cube:get_current_tile()
					if not tile then
						cube.delete_func()
					end
					if not tile:is_walkable() or tile:is_edge() then
						cube.delete_func()
					end
					if not delete_self then
						tile:attack_entities(cube)
					end
					local direction = self:get_facing()
					if self:is_sliding() then
						table.insert(prev_tile,1, tile)
						prev_tile[cube_speed+1] = nil
						local target_tile = tile:get_tile(direction, 1)
						if self:can_move_to_func(target_tile) then
							continue_slide = true
						else
							continue_slide = false
						end
					else
						-- become aware of which direction you just moved in, turn to face that direction
						if prev_tile[cube_speed] then
							if prev_tile[cube_speed]:get_tile(direction, 1):x() ~= tile:x() then
								direction = self:get_facing_away()
								self:set_facing(direction)
							end
						end
					end
					if not self:is_sliding() and continue_slide then
						self:slide(self:get_tile(direction, 1), frames(cube_speed), frames(0), ActionOrder.Voluntary, function() end)
					end
					if self:get_health() <= 0 then
						cube.delete_func()
					end
					if countdown > 0 then countdown = countdown - 1 else cube.delete_func() end
					-- deletion handler in main loop, starts running once something in here has requested deletion
					if delete_self then
						if type(delete_self) ~= "number" then
							delete_self = 2
						end
						if delete_self > 0 then
							delete_self = delete_self - 1
						elseif delete_self == 0 then
							delete_self = -1
							self:erase()
						end
					end
				else
					shake_cooldown = shake_cooldown - 1
				end
			else
				self:set_offset(self:get_offset().x, self:get_offset().y + 16.0)
			end
		end
		cube.delete_func = function(self)
			if type(delete_self) ~= "number" then
				delete_self = true
			end
		end
		cube:set_offset(0.0, -192.0)
		user:get_field():spawn(cube, user:get_tile(user:get_facing(), 1))
	end
    return action
end