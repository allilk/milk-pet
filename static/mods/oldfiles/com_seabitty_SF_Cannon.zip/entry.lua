local buster_texture = Engine.load_texture(_modpath.."cannon_buster.png")
local buster_animation_path = _modpath.."cannon_buster.animation"
local impact_texture = Engine.load_texture(_modpath.."cannon_impact.png")
local cannon_sfx = Engine.load_audio(_modpath.."sfx.ogg")

function package_init(package) 
    package:declare_package_id("com.seabitty_sfcannon")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"A","B","C"})

    local props = package:get_card_props()
    props.shortname = "Cannon"
    props.damage = 40
    props.time_freeze = false
    props.element = Element.None
    props.description = "Cannon atk 1 emy."
	props.card_class = CardClass.Standard
	props.limit = 5
end

function card_create_action(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	local frame1 = {1, 0.1}
	local frame2 = {2, 0.1}
	local frame3 = {3, 0.1}
	local frame4 = {4, 0.1}
	local frame5 = {5, 0.1}
	local frame6 = {6, 0.02}
	local frame7 = {7, 0.02}
	local frame8 = {8, 0.02}
	local frame9 = {9, 0.0165}
	local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9})
	local original_offset = actor:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(buster_texture, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(buster_animation_path)
		buster_anim:set_state("DEFAULT")
		
		self:add_anim_action(1, function()
			actor:toggle_counter(true)
		end)
		
		self:add_anim_action(3, function()
			local recoil_component = Battle.Component.new(actor, Lifetimes.Battlestep)
			recoil_component.update_func = function(self, dt)
				local goal_offset_x = original_offset.x - 12
				if self:get_owner():get_offset().x <= goal_offset_x then
					self:eject()
				else
					self:get_owner():set_offset(self:get_owner():get_offset().x - 4, self:get_owner():get_offset().y)
				end
			end
			actor:register_component(recoil_component)
		end)

		self:add_anim_action(5, function()
			Engine.play_audio(cannon_sfx, AudioPriority.High)
		end)
		
		self:add_anim_action(7, function()
			actor:toggle_counter(false)
			local cannonshot = create_attack(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			actor:get_field():spawn(cannonshot, tile)
		end)
		
		self:add_anim_action(9, function()
			actor:set_offset(original_offset.x, original_offset.y)
		end)
	end
	action.action_end_func = function(self)
		actor:toggle_counter(false)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	local direction = user:get_facing()
	spell:set_facing(direction)
	spell.slide_started = false
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	spell.collision_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(impact_texture, true)
		fx:get_animation():load(_modpath.."cannon_impact.animation")
		fx:get_animation():set_state("DEFAULT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
		local tile = self:get_current_tile()
		if tile and not tile:is_edge() then
			spell:get_field():spawn(fx, tile)
		end
	end
    spell.attack_func = function(self, other)
		local fx = Battle.Artifact.new()
		fx:set_texture(impact_texture, true)
		fx:get_animation():load(_modpath.."cannon_impact.animation")
		fx:get_animation():set_state("DEFAULT")
		fx:get_animation():on_complete(function()
			fx:erase()
		end)
		fx:set_height(-16.0)
		local tile = self:get_current_tile():get_tile(direction, 1)
		if tile and not tile:is_edge() then
			spell:get_field():spawn(fx, tile)
			tile:attack_entities(self)
		end
		
		local fx2 = Battle.Artifact.new()
		fx2:set_texture(impact_texture, true)
		fx2:get_animation():load(_modpath.."cannon_impact.animation")
		fx2:get_animation():set_state("DEFAULT")
		fx2:get_animation():on_complete(function()
			fx2:erase()
		end)
		fx2:set_height(-16.0)
		
		local tile2 = self:get_current_tile():get_tile(direction, 1)
		if tile2 and not tile2:is_edge() then
			spell:get_field():spawn(fx2, tile2)
			tile2:attack_entities(self)
		end
		self:erase()
    end
    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
	return spell
end