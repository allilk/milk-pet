function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.Charge1.blue.bn6")
    block:set_name("Charge+1")
    block:set_description("MegaBstr\nCharge +1")
    block:set_color(Blocks.Blue)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    player:set_charge_level(
        math.min(player:get_charge_level() + 1, 5)
    )
end
