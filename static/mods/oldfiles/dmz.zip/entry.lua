function package_init(block)
    block:declare_package_id("com.discord.Konstinople#7692.block.DMZ.white")
    block:set_name("DMZ")
    block:set_description("")
    block:set_color(Blocks.White)
    block:as_program()
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)
    local component = Battle.Component.new(player, Lifetimes.Scene)

    component.update_func = function()
        local field = player:get_field()

        local x_start = math.floor(field:width() / 2)

        for x = x_start, x_start + 1 do
            for y = 0, field:height() do
                field:tile_at(x, y):set_team(Team.Other, false)
            end
        end
    end

    player:register_component(component)
end
