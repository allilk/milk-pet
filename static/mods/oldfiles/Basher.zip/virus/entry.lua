local function find_best_target(self)
    local target = self:get_target()
    local field = self:get_field()
    local query = function(c)
        return c:get_team() ~= self:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 99999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp and possible_target:get_health() > 0 then
                target = possible_target
            end
        end
    end
    return target
end

local function spawn_hit_effect(field, tile)
    local effect = Battle.Spell.new(Team.Other)
    effect:set_texture(Engine.load_texture(_folderpath.."Hit Effect.png"), true)
    local anim = effect:get_animation()
    anim:load(_folderpath.."Hit Effect.animation")
    anim:set_state("DEFAULT")
    anim:refresh(effect:sprite())
    anim:on_complete(function()
        effect:erase()
    end)
    field:spawn(effect, tile)
end

local function tile_logic(self)
    local tiles = {}
    local tile = self.field:tile_at(self:get_tile():x(), 2)
    local dir = self:get_facing(self)
    local count = 1
    local max = 6
    local tile_front = nil
    local tile_up = nil
    local tile_down = nil
    local check1 = false
    local check_front = false
    local check_up = false
    local check_down = false
    for i = count, max, 1 do
        tile_front = tile:get_tile(dir, i)
        tile_up = tile_front:get_tile(Direction.Up, 1)
        tile_down = tile_front:get_tile(Direction.Down, 1)
        
        check_front = tile_front and self:get_team() ~= tile_front:get_team() and not tile_front:is_edge() and tile_front:get_team() ~= Team.Other and self:is_team(tile_front:get_tile(Direction.reverse(dir), 1):get_team())
        check_up = tile_up and self:get_team() ~= tile_up:get_team() and not tile_up:is_edge() and tile_up:get_team() ~= Team.Other and self:is_team(tile_up:get_tile(Direction.reverse(dir), 1):get_team())
        check_down = tile_down and self:get_team() ~= tile_down:get_team() and not tile_down:is_edge() and tile_down:get_team() ~= Team.Other and self:is_team(tile_down:get_tile(Direction.reverse(dir), 1):get_team())
        
        if check_front or check_up or check_down then
            table.insert(tiles, tile_front)
            table.insert(tiles, tile_up)
            table.insert(tiles, tile_down)
            break
        end
    end
    return tiles
end

local function spawn_cursors(self)
    --Don't do anything if the target is dead.
    if not self.target or self.target and self.target:is_deleted() then return end
    local tile_array = tile_logic(self)
    self.action = "CURSOR"
    for i = 1, #tile_array, 1 do
        local spell = Battle.Spell.new(self:get_team())
        spell.spawn_sound = Engine.load_audio(_folderpath.."Sounds/scanning_click.ogg")
        spell.lock_sound = Engine.load_audio(_folderpath.."Sounds/scanning_lock.ogg")
        spell.can_move_to_func = function(tile) return true end
        spell:set_facing(self:get_facing())
        spell:sprite():set_layer(-2)
        spell:set_texture(Engine.load_texture(_folderpath.."Cursor.png"))
        local anim = spell:get_animation()
        anim:load(_folderpath.."Cursor.animation")
        anim:refresh(spell:sprite())
        anim:set_state("SPAWN")
        Engine.play_audio(spell.spawn_sound, AudioPriority.Low)
        spell.find_foes = function(foe)
            return foe and foe:get_health() > 0 and foe:get_team() ~= spell:get_team()
        end
        spell.is_attack = false
        spell.owner = self
        spell.anim = spell:get_animation()
        spell.anim:on_complete(function()
            if #spell:get_tile():find_characters(spell.find_foes) > 0 then
                Engine.play_audio(spell.lock_sound, AudioPriority.Low)
                for i = 1, #self.cursor_table, 1 do
                    local cursor = self.cursor_table[i]
                    local c_anim = cursor:get_animation()
                    c_anim:set_state("LOCKON")
                    c_anim:refresh(cursor:sprite())
                    cursor.cooldown = 99999
                    cursor.hide_cooldown = 99999
                    c_anim:on_complete(function()
                        self.is_attack = true
                        cursor.is_attack = true
                        cursor:sprite():hide()
                    end)
                end
            end
        end)
        anim:set_playback(Playback.Once)
        spell.cooldown = 30
        spell.hide_cooldown = 30
        spell.delete_func = function(self)
            self.owner.is_attack = false
            self.owner.action = nil
            self.owner.cooldown = 54
            self.owner.cursor_table = {}
        end
        spell.audio_once = true
        spell.is_hidden = false
        spell.update_func = function(self, dt)
            if self.is_hidden then
                self.hide_cooldown = self.hide_cooldown - 1
                if self.hide_cooldown == 0 then
                    local dest = self:get_tile(self:get_facing(), 1)
                    if dest and not dest:is_edge() then
                        self.is_hidden = false
                        self.cooldown = 30
                        self:sprite():show()
                        self:teleport(dest, ActionOrder.Involuntary, function()
                            anim:set_state("SPAWN")
                            Engine.play_audio(self.spawn_sound, AudioPriority.Low)
                        end)
                    else
                        self:delete()
                    end
                end
                return
            else
                self.cooldown = self.cooldown - 1
                if self.cooldown == 0 then
                   self.is_hidden = true
                   self.hide_cooldown = 30
                   self:sprite():hide()
                end
            end
            self.is_attack = #self:get_tile():find_characters(self.find_foes) > 0
            if self.is_attack then
                if self.audio_once then
                    self.audio_once = false
                    self.cooldown = 99999
                    self.hide_cooldown = 99999
                    Engine.play_audio(self.lock_sound, AudioPriority.Low)
                    for i = 1, #self.owner.cursor_table, 1 do
                        local cursor = self.owner.cursor_table[i]
                        local c_anim = cursor:get_animation()
                        c_anim:set_state("LOCKON")
                        c_anim:refresh(cursor:sprite())
                        cursor.cooldown = 99999
                        cursor.hide_cooldown = 99999
                        c_anim:on_complete(function()
                            self.owner.is_attack = true
                            cursor.is_attack = true
                            cursor:sprite():hide()
                        end)
                    end
                end
            end
        end
        table.insert(self.cursor_table, spell)
        self.field:spawn(spell, tile_array[i])
    end
end

function package_init(self)
    self:set_texture(Engine.load_texture(_folderpath.."Basher.png"))
    local rank = self:get_rank()
    local anim = self:get_animation()
    anim:load(_folderpath.."Basher.animation")
    anim:set_state("SPAWN")
    anim:refresh(self:sprite())
    if rank == Rank.V1 then
        self:set_name("Basher")
        self:set_health(150)
        self.attack = 50
    end
    self.field = nil
    self.battle_start_func = function(self)
        self.field = self:get_field()
        anim:set_state("IDLE")
        anim:refresh(self:sprite())
        anim:set_playback(Playback.Loop)
    end
    self.target = nil
    self.panels = nil
    self.find_enemy_query = function(c)
        return c and c:get_health() > 0 and (Battle.Character.from(c) ~= nil or Battle.Player.from(c) ~= nil)
    end
    self.cursor_table = {}
    self.virus_body = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.virus_body)
    self.can_move_to_func = function(tile) return false end
    self.cooldown = 54
    self.is_attack = false
    self.action = nil
    self.anim_once = true
    self.update_func = function(self, dt)
        if self:is_deleted() then return end
        if self:get_health() <= 0 then return end
        self.cooldown = self.cooldown - 1
        if self.cooldown <= 0 then
            if self.is_attack then
                if self.anim_once then
                    self.anim_once = false
                    anim:set_state("RISE")
                    anim:refresh(self:sprite())
                    anim:on_frame(9, function()
                        self:toggle_counter(true)
                    end)
                    anim:on_complete(function()
                        anim:set_state("SHOOT")
                        anim:refresh(self:sprite())
                        anim:on_frame(1, function()
                            for a = 1, #self.cursor_table, 1 do
                                local cursor = self.cursor_table[a]
                                Engine.play_audio(AudioType.Explode, AudioPriority.High)
                                local props = HitProps.new(
                                    self.attack,
                                    Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
                                    Element.None,
                                    self:get_context(),
                                    Drag.None
                                )
                                local hitbox = Battle.Spell.new(self:get_team())
                                hitbox:set_hit_props(props)
                                local spawn_tile = cursor:get_tile()
                                local ref = self
                                hitbox.update_func = function(self, dt)
                                    spawn_hit_effect(ref.field, spawn_tile)
                                    spawn_tile:attack_entities(self)
                                    spawn_tile:set_state(TileState.Cracked)
                                    spawn_tile:set_state(TileState.Broken)
                                    self:erase()
                                end
                                self.field:spawn(hitbox, spawn_tile)
                            end
                            self:shake_camera(8.0, 0.6)
                            for b = 1, #self.cursor_table, 1 do
                                local cursor = self.cursor_table[b]
                                cursor:erase()
                            end
                            self.cursor_table = {}
                            self:toggle_counter(false)
                        end)
                        anim:on_complete(function()
                            anim:set_state("LOWER")
                            anim:refresh(self:sprite())
                            anim:on_complete(function()
                                anim:set_state("IDLE")
                                anim:refresh(self:sprite())
                                anim:set_playback(Playback.Loop)
                                self.is_attack = false
                                self.action = nil
                                self.anim_once = true
                                self.cooldown = 54
                            end)
                        end)
                    end)
                end
                return
            end
            if self.action ~= nil then return end
            self.target = find_best_target(self)
            spawn_cursors(self)
        end
    end
end