local package_id = "com.EXE3.Basher"
local character_id = "com.EXE3.Basher.Enemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Basher")
    package:set_description("TARGET LOCKED.\nFIRING.\nAREA ANNIHILATED.")
    package:set_speed(1)
    package:set_attack(50)
    package:set_health(150)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end