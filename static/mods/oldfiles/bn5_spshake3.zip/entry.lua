local DAMAGE = 100

local attack_sprite = Engine.load_texture(_modpath .. "satellite.png")
local attack_anim = _modpath .. "satellite.animation"
local HIT_TEXTURE = Engine.load_texture(_modpath .. "effect.png")
local HIT_ANIM_PATH = _modpath .. "effect.animation"
local HIT_SOUND = Engine.load_audio(_modpath .. "hitsound.ogg")
local AUDIO_SHOOT = Engine.load_audio(_modpath .. "elec.ogg")

local SHAKE_SPEED = 14
function package_init(package)
    package:declare_package_id("com.louise.card.SpShake3")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes({ "S", "T", "U", "*" })

    local props = package:get_card_props()
    props.shortname = "SpShake3"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Shakey shivers 3sq ahead"
    props.long_description = "Shakey zigzags across the field."
    props.can_boost = true
    props.card_class = CardClass.Standard
    props.limit = 2
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    local frame1 = { 1, 0.033 }
    local frame2 = { 1, 0.305 }
    action.frames = { frame1, frame1, frame1, frame2 }
    local frame_data = make_frame_data(action.frames)
    action:override_animation_frames(frame_data)
    action.execute_func = function(self, user)
        local buster_attachment = self:add_attachment("BUSTER")
        local buster_sprite = buster_attachment:sprite()
        buster_sprite:set_texture(user:get_texture(), false)
        buster_sprite:set_layer(-2)
        local buster_animation = buster_attachment:get_animation()
        buster_animation:copy_from(user:get_animation())
        buster_animation:set_state("BUSTER")
        buster_animation:refresh(buster_sprite)


        local attacking = false

        self:add_anim_action(1, function()
            user:toggle_counter(true)
            attacking = true
        end)

        self:add_anim_action(3, function()
            if attacking then
                Engine.play_audio(AUDIO_SHOOT, AudioPriority.Highest)
                create_satellite(user, props.damage)
            end
        end)
        self:add_anim_action(4, function()
            user:toggle_counter(false)
            attacking = false
        end)

    end
    action.action_end_func = function()
        user:toggle_counter(false)
    end
    return action
end

---@param user Entity The user summoning a spell
---@param damage number The amount of damage the spell will do
---@param speed number The number of frames it takes the spell to travel 1 tile.
---@param direction any The direction the
function create_satellite(user, damage)
    -- Creates a new spell that belongs to the user's team.
    local spell = Battle.Obstacle.new(user:get_team())
    local field = user:get_field()
    spell:set_health(damage)
    spell:set_palette(Engine.load_texture(_folderpath .. "palette.png"))
    local tile = user:get_tile():get_tile(user:get_facing(), 1)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact | Hit.Flinch,
            Element.Elec,
            user:get_context(),
            Drag.new()
        )
    )
    -- Setup sprite of the spell
    local sprite = spell:sprite()
    sprite:set_texture(attack_sprite)
    sprite:set_layer(-1)
    -- Setup animation of the spell
    local anim = spell:get_animation()
    anim:load(attack_anim)
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    spell.base_tile = tile
    spell:set_facing(user:get_facing())
    anim:refresh(sprite)
    local round = function(val)
        if user:get_facing() == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end

    --54: spshake1
    --38: spshake2/BN6ver
    --28: spshake3

    local pi = math.pi
    tileWidth = tile:width()
    tileHeight = tile:height()

    local x_speed = tileWidth / SHAKE_SPEED
    if (user:get_facing() == Direction.Left) then
        x_speed = -x_speed
    end
    spell.x_coord = 0
    spell.time = 0
    local start_y = user:get_tile():y()
    local tileOffsetY = 0
    spell.update_func = function(self, dt)
        spell.x_coord = spell.x_coord + x_speed
        spell.y_coord = -round(math.sin((pi * spell.time) / (SHAKE_SPEED)) * tileHeight)
        -- Once shakey has moved half a tile, needs to change its tile
        if (spell.y_coord > tileHeight / 2) then
            --in bottom tile
            tileOffsetY = 1
        elseif (spell.y_coord < -tileHeight / 2) then
            --in top tile
            tileOffsetY = -1
        else
            -- same row
            tileOffsetY = 0
        end
        local prospective_y = tileOffsetY + start_y
        if (spell:get_current_tile():y() ~= prospective_y) then
            --check if tile should be updated
            spell:teleport(field:tile_at(spell:get_current_tile():x(), prospective_y))
        end
        if (spell:get_facing() == Direction.Right and round(spell.x_coord) >= tileWidth / 2) then
            spell:teleport(spell:get_tile(Direction.Right, 1), ActionOrder.Immediate)
            spell.x_coord = -tileWidth / 2
        elseif (spell:get_facing() == Direction.Left and round(spell.x_coord) <= -tileWidth / 2) then
            spell:teleport(spell:get_tile(Direction.Left, 1), ActionOrder.Immediate)
            spell.x_coord = tileWidth / 2
        end
        --Teleporting increases the offsetY.
        local relativeOffsetY = (tileOffsetY * (tileHeight * 0.8))
        local adjusted_y = spell.y_coord - relativeOffsetY
        spell:set_offset(spell.x_coord, adjusted_y)
        spell:get_current_tile():attack_entities(self)
        spell:get_current_tile():highlight(Highlight.Solid)
        spell.time = spell.time + 1
        if (spell.time == SHAKE_SPEED * 2) then
            spell.time = 0
        end
        if (spell:get_current_tile():x() > 6 or spell:get_current_tile():x() < 1) then
            spell:erase()
        end
    end
    spell.attack_func = function(self, other)
        create_hit_effect(spell:get_field(), spell:get_current_tile(), HIT_TEXTURE, HIT_ANIM_PATH, "ELEC", HIT_SOUND)
        if (other:get_health() > 0) then
            spell:erase()
        end
    end

    spell.delete_func = function(self)
        spell:erase()
    end
    spell.battle_end_func = function(self)
        spell:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

--- create hit effect.
function create_hit_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state, sfx)
    local hitfx = Battle.Artifact.new()
    hitfx:set_texture(hit_texture, true)
    hitfx:set_offset(math.random(-25, 25), math.random(-25, 25))
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(-3)
    local hitfx_anim = hitfx:get_animation()
    hitfx_anim:load(hit_anim_path)
    hitfx_anim:set_state(hit_anim_state)
    hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_frame(1, function()
        Engine.play_audio(sfx, AudioPriority.Highest)
    end)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)
    return hitfx
end
