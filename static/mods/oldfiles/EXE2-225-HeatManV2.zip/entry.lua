local DAMAGE = 130

local TEXTURE_HEATMAN = Engine.load_texture(_modpath.."heatman.png")
local TEXTURE_FLAME = Engine.load_texture(_modpath.."flame.png")
local ANIMPATH_HEATMAN = _modpath.."heatman.animation"
local ANIMPATH_FLAME = _modpath.."flame.animation"
local AUDIO_NAVI = Engine.load_audio(_modpath.."navispawn.ogg")
local AUDIO_GROUNDBURNER = Engine.load_audio(_modpath.."groundburner.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_modpath.."effect.png")
local ANIMPATH_EFFECT = _modpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE2-225-HeatManV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"H"})

    local props = package:get_card_props()
    props.shortname = "HeatManV2"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.Fire
    props.description = "Flame attack! Range: 3"
    props.long_description = "Flame attack spreads to the ground! Range: 3 squares"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
		actor:hide()

        local team = actor:get_team()
        local field = actor:get_field()
        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

		local step1 = Battle.Step.new()

        self.heatman = nil
        self.tile   = user:get_current_tile()

        local ref = self

        local do_once = true
        local do_once_part_two = true
        step1.update_func = function(self, dt)
            if do_once then
                do_once = false
                ref.heatman = Battle.Artifact.new()
                ref.heatman:set_facing(direction)
		    	ref.heatman:set_texture(TEXTURE_HEATMAN, true)
		    	ref.heatman:sprite():set_layer(-1)

                heat_anim = ref.heatman:get_animation()
                heat_anim:load(ANIMPATH_HEATMAN)
                heat_anim:set_state("DEFAULT")
		    	heat_anim:refresh(ref.heatman:sprite())

                local flamehit1 = create_flame(user, props)
                local flamehit2 = create_flame(user, props)
                local flamehit3 = create_flame(user, props)
                local flamehit4 = create_flame(user, props)
                local flamehit5 = create_flame(user, props)
                local flamehit6 = create_flame(user, props)
                local flamehit7 = create_flame(user, props)

                heat_anim:on_frame(2, function()
                    Engine.play_audio(AUDIO_NAVI, AudioPriority.High)
                end)
                heat_anim:on_frame(30, function()
                    Engine.play_audio(AUDIO_GROUNDBURNER, AudioPriority.High)
                    if direction == Direction.Right then
                        if Y == 1 then
                            field:spawn(flamehit1, X + 1, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit1, X + 1, 2)
                        else
                            field:spawn(flamehit1, X + 1, 3)
                        end
                    else
                        if Y == 1 then
                            field:spawn(flamehit1, X - 1, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit1, X - 1, 2)
                        else
                            field:spawn(flamehit1, X - 1, 3)
                        end
                    end
                end)
                heat_anim:on_frame(32, function()
                    if direction == Direction.Right then
                        field:spawn(flamehit3, X + 2, 2)
                        if Y == 1 then
                            field:spawn(flamehit2, X + 2, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit2, X + 2, 1)
                            field:spawn(flamehit4, X + 2, 3)
                        else
                            field:spawn(flamehit4, X + 2, 3)
                        end
                    else
                        field:spawn(flamehit3, X - 2, 2)
                        if Y == 1 then
                            field:spawn(flamehit2, X - 2, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit2, X - 2, 1)
                            field:spawn(flamehit4, X - 2, 3)
                        else
                            field:spawn(flamehit4, X - 2, 3)
                        end
                    end
                end)
                heat_anim:on_frame(34, function()
                    if direction == Direction.Right then
                        field:spawn(flamehit5, X + 3, 1)
                        field:spawn(flamehit6, X + 3, 2)
                        field:spawn(flamehit7, X + 3, 3)
                    else
                        field:spawn(flamehit5, X - 3, 1)
                        field:spawn(flamehit6, X - 3, 2)
                        field:spawn(flamehit7, X - 3, 3)
                    end
                end)
		    	heat_anim:on_complete(function()
		    		ref.heatman:erase()
                    step1:complete_step()
		    	end)
                field:spawn(ref.heatman, ref.tile)
            end
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)
        self:get_actor():reveal()
    end
    return action
end

function create_flame(actor, props)
    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellanim = spell:get_animation()
    local direction = actor:get_facing()
    spell:set_facing(direction)
    spell:set_texture(TEXTURE_FLAME, true)
    spellanim:load(ANIMPATH_FLAME)
    spellanim:set_state("DEFAULT")
    spellanim:refresh(spell:sprite())
    spellanim:on_complete(function()
        spell:erase()
    end)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            props.element,
            actor:get_id(),
            Drag.None
        )
    )

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

    return spell
end