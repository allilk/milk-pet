function package_init(package) 
    package:declare_package_id("com.alrysc.card.Hakkero3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'D','F', 'V', 'Y'})

    local props = package:get_card_props()
    props.shortname = "Hakkero3"
    props.damage = 150
    props.time_freeze = false
    props.element = Element.Elec
    props.description = "Piercing laser ahead!"
    props.limit = 3

end



local HIT = Engine.load_audio(_modpath .. "hit.ogg")
local BLOCK = Engine.load_audio(_modpath .. "tink.ogg")
local SHOOT = Engine.load_audio(_modpath .. "beam.ogg")

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())
    local override_frames = {
        {1, 0.166}, {1, 0.016}, {2, 0.066}, {2, 0.15}, {1, 0.084}
    }
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)
    local field = user:get_field()

    -- graphic_init("artifact", 0, 0, "Medicine.png", "Medicine.animation", -4, "GAS", user, facing, true\)
    local function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
        flip = flip or false
        delete_on_complete = delete_on_complete or false
        facing = facing or nil
        
        local graphic = nil
        if type == "artifact" then 
            graphic = Battle.Artifact.new()

        elseif type == "spell" then 
            graphic = Battle.Spell.new(user:get_team())
        
        elseif type == "obstacle" then 
            graphic = Battle.Obstacle.new(user:get_team())

        end

        graphic:sprite():set_layer(layer)
        graphic:never_flip(flip)
        graphic:set_texture(Engine.load_texture(_folderpath..texture), false)
        if facing then 
            graphic:set_facing(facing)
        end
        
        if user:get_facing() == Direction.Left then 
            x = x * -1
        end
        graphic:set_offset(x, y)
        local anim = graphic:get_animation()
        anim:load(_folderpath..animation)

        anim:set_state(state)
        anim:refresh(graphic:sprite())

        if delete_on_complete then 
            anim:on_complete(function()
                graphic:delete()
            end)
        end

        return graphic
    end


    local ending = false

    local spell_list = {}

    local function extra_laser(user, tile, facing, elevation, hit_props)
        if not tile or tile:is_edge() then 
            return 
        end
        local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER", user, facing)
        spell:highlight_tile(Highlight.Solid)
        spell:set_elevation(elevation)
        spell:set_hit_props(hit_props)


        local anim = spell:get_animation()
        anim:on_frame(2, function()
            extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)

        end)
        local fade = false
        spell.update_func = function(self)
            if not fade then 
                if ending == true then 
                    anim:set_state("LASER_END")
                    anim:refresh(self:sprite())

                    fade = true
                end

            end

            self:get_tile():attack_entities(self)

        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        spell_list[#spell_list+1] = spell
        field:spawn(spell, tile)
    end

    local function shoot_laser(user, starting_tile, facing, elevation)
        local spell = graphic_init("spell", 0, 0, "laser.png", "laser.animation", -4, "LASER_START", user, facing, true)
        spell:highlight_tile(Highlight.Solid)
        spell:set_elevation(elevation)

        local hit_props = HitProps.new(props.damage,
                                   Hit.Impact | Hit.Flinch | Hit.Flash,
                                   props.element, user:get_context(), Drag.None)

        local anim = spell:get_animation()
        spell:set_hit_props(hit_props)

        anim:on_frame(7, function()
            extra_laser(user, spell:get_tile(facing, 1), facing, elevation, hit_props)
        end)

        anim:on_frame(8, function()
            ending = true
        
        end)

        anim:on_frame(13, function()
            spell:highlight_tile(Highlight.None)

        end)

        anim:on_frame(14, function()
            spell:highlight_tile(Highlight.None)
            stop = true
            spell:delete()

            for i=1, #spell_list
            do
                local spell = spell_list[i]
                if spell and not spell:is_deleted() then 
                    spell:delete()
                end
            end
        end)


        local stop = false

        spell.update_func = function(self)
            if not stop then 
                self:get_tile():attack_entities(self)
            end

        end

        spell.attack_func = function()
            Engine.play_audio(HIT, AudioPriority.Low)
        end

        field:spawn(spell, starting_tile)
    end


    action.execute_func = function(self)
        action:add_anim_action(1, function()
            local hakkero = self:add_attachment("Buster")
            local hakkero_sprite = hakkero:sprite()
            hakkero_sprite:set_texture(Engine.load_texture(_modpath.."hakkero.png"), false)
            hakkero_sprite:set_layer(-2)
            hakkero_sprite:enable_parent_shader(false)
            
            local hakkero_anim = hakkero:get_animation()
            hakkero_anim:load(_modpath.."hakkero.animation")
            hakkero_anim:set_state("HAKKERO")

            local defense = Battle.DefenseRule.new(0, DefenseOrder.CollisionOnly)
            defense.can_block_func = function(judge, attacker, defender)
                local attacker_hit_props = attacker:copy_hit_props()
                if attacker_hit_props.damage > 0 then
                    if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                        return
                    end
                    judge:block_impact()
                    judge:block_damage()
                    Engine.play_audio(BLOCK, AudioPriority.Low)
                    local artifact = graphic_init("artifact", 0, 0, "guard.png", "guard.animation", -4, "DEFAULT", user, facing, true)

                    field:spawn(artifact, user:get_current_tile())
                end
            end
            
            user:add_defense_rule(defense)

            action.action_end_func = function()
                user:remove_defense_rule(defense)

            end
        
        end)

        action:add_anim_action(4, function()
            local point = user:get_animation():point("buster")
            local origin = user:get_animation():point("origin")
            local elevation = ((origin.y - point.y)*2)
            shoot_laser(user, user:get_current_tile():get_tile(user:get_facing(), 1), user:get_facing(), elevation)
            Engine.play_audio(SHOOT, AudioPriority.Low)

        end)
    end

    return action
end