
local SLASH_TEXTURE = Engine.load_texture(_modpath.."spell_sword_slashes.png")
local BLADE_TEXTURE = Engine.load_texture(_modpath.."spell_sword_blades.png")
local AUDIO = Engine.load_audio(_modpath.."swing_sword.ogg")
local HIT = Engine.load_audio(_modpath.."hit.ogg")

function package_init(package) 
    package:declare_package_id("com.alrysc.card.Roukanken")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'K', 'N', 'R', 'Y'})

    local props = package:get_card_props()
    props.shortname = "Roukankn"
    props.damage = 200
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Legendary Sword! 2x on Null!"
    props.limit = 2
end

function card_create_action(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_SWORD")
	action:set_lockout(make_animation_lockout())
    local sword = {}
    action.execute_func = function(self, user)
		self:add_anim_action(2,function()
            local hilt = self:add_attachment("HILT")
            local hilt_sprite = hilt:sprite()
            hilt_sprite:set_texture(actor:get_texture())
            hilt_sprite:set_layer(-2)
            hilt_sprite:enable_parent_shader(true)
            
            local hilt_anim = hilt:get_animation()
            hilt_anim:copy_from(actor:get_animation())
            hilt_anim:set_state("HILT")

            local blade = hilt:add_attachment("ENDPOINT")
            local blade_sprite = blade:sprite()
            blade_sprite:set_texture(BLADE_TEXTURE)
            blade_sprite:set_layer(-1)

            local blade_anim = blade:get_animation()
            blade_anim:load(_modpath.."spell_sword_blades.animation")
            blade_anim:set_state("DEFAULT")

        
            sword[1] = create_slash(user, props, sword)
            sword[2] = create_slash(user, props, sword)
            sword[3] = create_slash(user, props, sword)

            local tile = user:get_tile(user:get_facing(), 1)
    --		local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
    --		sharebox1:set_hit_props(sword:copy_hit_props())
    --		local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
        --	sharebox2:set_hit_props(sword:copy_hit_props())
        --	actor:get_field():spawn(sharebox1, tile:get_tile(Direction.Up, 1))
        --	actor:get_field():spawn(sword, tile)
        --	actor:get_field():spawn(sharebox2, tile:get_tile(Direction.Down, 1))
            local fx = Battle.Artifact.new()
            fx:set_facing(sword[1]:get_facing())
            local anim = fx:get_animation()
            fx:set_texture(SLASH_TEXTURE, true)
            anim:load(_modpath.."spell_sword_slashes.animation")
            anim:set_state("WIDE")
            anim:on_complete(function()
                fx:erase()
            end)
            actor:get_field():spawn(fx, tile)
            actor:get_field():spawn(sword[1], tile)
            local t2 = tile:get_tile(Direction.Up, 1)
            if t2 and not t2:is_edge() then 
                print("Spawn 2")
                actor:get_field():spawn(sword[2], t2)

            end

            local t3 = tile:get_tile(Direction.Down, 1)
            if t3 and not t3:is_edge() then 
                print("Spawn 3")
                actor:get_field():spawn(sword[3], t3)

            end
    
        end)
		
	end

    action.action_end_func = function()
        if sword[1] and not sword[1]:is_deleted() then 
            sword[1]:delete()
            sword[2]:delete()
            sword[3]:delete()
        end
    end

    return action
end

function create_slash(user, props, list)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
    local lifetime = 7
    local first = true
    spell.has_hit = false
	spell.update_func = function(self, dt)
        if first then 
            first = false
            return 
        end

        local can_hit = not (list[1].has_hit or list[2].has_hit or list[3].has_hit)
        self:get_tile():highlight(Highlight.Solid)

        if not can_hit then 
            return 
        end
		self:get_tile():attack_entities(self)

        if lifetime == 0 then 
            self:delete()
        end
        lifetime = lifetime - 1

	end

	spell.can_move_to_func = function(tile)
		return true
	end

    spell.attack_func = function(self, other)
        Engine.play_audio(HIT, AudioPriority.Low)
    end

    spell.collision_func = function(self, other)
        self.has_hit = true
        if other:get_element() ~= Element.None or not Battle.Character.from(other) then 
            return
        end
        self:set_hit_props(
            HitProps.new(
                props.damage*2,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Sword,
                user:get_context(),
                Drag.None
            )
	    )

        local alert = Battle.Artifact.new()
        alert:set_texture(Engine.load_texture(_modpath.."overlay_fx07_animations.png", false))
        alert:get_animation():load(_modpath.."overlay_fx07_animations.animation")
        alert:get_animation():set_state("0")
        alert:get_animation():on_complete(function()
            alert:delete()
        end)

        local x = 32
        if other:get_facing() == Direction.Left then 
            x = x * -1
        end

        alert:set_facing(other:get_facing())
        alert:set_offset(x, 0)
        alert:get_animation():refresh(alert:sprite())
        local y = other:get_height()+14
        if y < 20 then 
            y = 40
        end
        alert:set_elevation(y)
        other:get_field():spawn(alert, other:get_current_tile())


    end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end