--Mod by Thor.  Needs update to emotion windows and a special_attack_func

local penguin_texture = Engine.load_texture(_modpath.."penguin.png")
local penguin_animation_path = _modpath.."penguin.animation"
local bubble_texture = Engine.load_texture(_modpath.."snowball.png")
local bubble_animation_path = _modpath.."snowball.animation"
local elecpenguin_texture = Engine.load_texture(_modpath.."elecpenguin.png")
local elecpenguin_animation_path = _modpath.."elecpenguin.animation"
local zap_texture = Engine.load_texture(_modpath.."zap.png")
local zap_animation_path = _modpath.."zap.animation"
local bool = false

local damage = 50



function package_init(package)
    package:declare_package_id("com.Thor.player.Neku")
    package:set_special_description("The World Ends with You!")
    package:set_speed(1.0)
    package:set_attack(5)
    package:set_charged_attack(50)
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_emotions_texture_path(_modpath.."emotions.png")
	
end

function player_init(player)
    player:set_name("Neku")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(60.0)
	player:set_shadow(Shadow.Small)
	player:show_shadow(true)
	player:set_offset(0.0, -8)

    local base_texture = Engine.load_texture(_modpath.."battle.png")
    local base_animation_path = _modpath.."battle.animation"
    local base_charge_color = Color.new(120, 48, 176, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -30)
	player.normal_attack_func = create_normal_attack_norm
	player.charged_attack_func = create_charged_attack_zap
	--player.special_attack_func = create_special_attack_norm
	player.update_func = function()
		bool = not bool
		
		if bool == true then
			player.charged_attack_func = create_charged_attack_zap
		elseif bool == false then
			player.charged_attack_func = create_charged_attack_snowball
		end
		
		
	end
	
	
end
	
function create_normal_attack_norm(player)
	return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack_norm(player)
	return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end

function create_special_attack_norm(player)
	return Battle.Buster.new(player, true, player:get_attack_level() * 10)
end








function create_charged_attack_snowball(player)
	print("charged attack")
    local props = Battle.CardProperties:new()
    props.damage = 20
    local buster_action = card_create_action_snowball(player,props)
    return buster_action
end

function card_create_action_snowball(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_LONG_SHOOT")
	local has_something = false
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local penny = create_penguin(user)
		local tile = user:get_tile(user:get_facing(), 1)
		
		tile:find_characters(function(c)
			if c ~= nil then
				has_something = true
			end
			return false
		end)
			
		tile:find_obstacles(function(c)
			if c ~= nil then
				has_something = true
			end
			return false
		end)
		
		
		if has_something == false and tile:is_walkable() then
			user:get_field():spawn(penny, tile)
		end
	end
    return action
end

function create_penguin(user)

	local penguin = Battle.Obstacle.new(user:get_team())
	penguin:set_texture(penguin_texture, true)
	penguin:never_flip(true)
	penguin:set_health(9999999)
	penguin:show_shadow(true)
	penguin:set_shadow(Shadow.Small)
	penguin:set_offset(0.0, -8.0)
	
	local anim = penguin:get_animation()
    anim:load(penguin_animation_path)
    anim:set_state("ATTACK")
	anim:on_frame(7, function()
		local cannonshot = create_snowball("DEFAULT", user)
		local tile = user:get_tile(user:get_facing(), 1)
		user:get_field():spawn(cannonshot, tile)
	end)
	anim:on_complete(function()
		penguin:erase()
	end)
	
	return penguin
	


end

function create_snowball(animation_state, user)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(bubble_texture, true)
    spell:highlight_tile(Highlight.Solid)
	spell:set_offset(0.0, 0.0)
	local direction = user:get_facing()
    spell.slide_started = false
	
    spell:set_hit_props(
        HitProps.new(
            damage, 
            Hit.Impact | Hit.Freeze | Hit.Flinch , 
            Element.Aqua,
            user:get_context(),
            Drag.None
        )
    )
	
    local anim = spell:get_animation()
    anim:load(bubble_animation_path)
    anim:set_state("SNOWBALL")

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other) 
        -- nothing
    end
	
	spell.collision_func = function(self, other)
		
		self:erase()

	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	--Engine.play_audio(ZAP_AUDIO, AudioPriority.Low)

    return spell
end






















function create_charged_attack_zap(player)
	print("charged attack")
    local props = Battle.CardProperties:new()
    props.damage = 20
    local buster_action = card_create_action_zap(player,props)
    return buster_action
end

function card_create_action_zap(actor, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(actor, "PLAYER_LONG_SHOOT")
	local has_something = false
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local zappenny = create_penguin_zap(user)
		local tile = user:get_tile(user:get_facing(), 1)
		
		tile:find_characters(function(c)
			if c ~= nil then
				has_something = true
			end
			return false
		end)
			
		tile:find_obstacles(function(c)
			if c ~= nil then
				has_something = true
			end
			return false
		end)
		
		
		if has_something == false and tile:is_walkable() then
			user:get_field():spawn(zappenny, tile)
		end
	end
    return action
end

function create_penguin_zap(user)

	local penguin = Battle.Obstacle.new(user:get_team())
	penguin:set_texture(elecpenguin_texture, true)
	penguin:never_flip(true)
	penguin:set_health(9999999)
	penguin:show_shadow(true)
	penguin:set_shadow(Shadow.Small)
	penguin:set_offset(0.0, -8.0)
	
	local anim = penguin:get_animation()
    anim:load(elecpenguin_animation_path)
    anim:set_state("ATTACK")
	anim:on_frame(7, function()
		local cannonshot = create_zap("DEFAULT", user)
		local tile = user:get_tile(user:get_facing(), 1)
		user:get_field():spawn(cannonshot, tile)
	end)
	anim:on_complete(function()
		penguin:erase()
	end)
	
	return penguin
	


end

function create_zap(animation_state, user)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_texture(zap_texture, true)
    spell:highlight_tile(Highlight.Solid)
	spell:set_offset(0.0, 0.0)
	local direction = user:get_facing()
    spell.slide_started = false
	
    spell:set_hit_props(
        HitProps.new(
            damage, 
            Hit.Impact | Hit.Stun | Hit.Flinch , 
            Element.Elec,
            user:get_context(),
            Drag.None
        )
    )
	
    local anim = spell:get_animation()
    anim:load(zap_animation_path)
    anim:set_state("ZAP")

    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end

    spell.attack_func = function(self, other) 
        -- nothing
    end
	
	spell.collision_func = function(self, other)
		
		self:erase()

	end
	
    spell.delete_func = function(self) 
    end

    spell.can_move_to_func = function(tile)
        return true
    end

	--Engine.play_audio(ZAP_AUDIO, AudioPriority.Low)

    return spell
end
