local roll = include("roll/roll.lua")

local DAMAGE = 40

roll.codes = {"R"}
roll.shortname = "RollV2"
roll.damage = DAMAGE
roll.time_freeze = true
roll.element = Element.None
roll.description = "Attacks 1 enemy and heals you"
roll.long_description = "Attacks 1 enemy, then heals you with a healing heart"
roll.can_boost = true
roll.card_class = CardClass.Mega
roll.memory = 40
roll.limit = 2

function package_init(package) 
    package:declare_package_id("com.k1rbyat1na.card.EXE6-223-RollV2")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes(roll.codes)

    local props = package:get_card_props()
    props.shortname = roll.shortname
    props.damage = roll.damage
    props.time_freeze = roll.time_freeze
    props.element = roll.element
    props.description = roll.description
    props.long_description = roll.long_description
    props.can_boost = roll.can_boost
	props.card_class = roll.card_class
	props.limit = roll.limit
end

card_create_action = roll.card_create_action