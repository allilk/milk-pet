local DAMAGE = 140

local TEXTURE_SWALLOWMAN = Engine.load_texture(_modpath.."swallowman.png")
local ANIMPATH_SWALLOWMAN = _modpath.."swallowman.animation"
local AUDIO_SPAWN = Engine.load_audio(_modpath.."spawn.ogg")
local AUDIO_INPUT = Engine.load_audio(_modpath.."input.ogg")
local AUDIO_SWALLOWDRIVE = Engine.load_audio(_modpath.."swallowdrive.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE5-271-SwallowMan")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"S"})

    local props = package:get_card_props()
    props.shortname = "SwalwMan"
    props.damage = DAMAGE
    props.time_freeze = true
    props.element = Element.None
    props.description = "Whirl forward and atk!"
    props.long_description = "Take the route 2 squares forward and turn around to attack enemies!"
    props.can_boost = true
	props.card_class = CardClass.Mega
	props.limit = 1
end

function card_create_action(actor, props)
    print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local input_1 = false
        local input_2 = false
        local B_held = false
        local input_success = false
        local success_played = false

        local actor = self:get_actor()
		actor:hide()

        local direction = user:get_facing()

        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset_1 = nil
        local X_offset_2 = nil
        local X_offset_3 = nil

        if direction == Direction.Right then
            X_offset_1 = X - 1
            X_offset_2 = X + 1
            X_offset_3 = X + 2
        else
            X_offset_1 = X + 1
            X_offset_2 = X - 1
            X_offset_3 = X - 2
        end

		local step1 = Battle.Step.new()

        self.swallowman     = nil
        self.swallowdrive   = nil
        self.tile           = user:get_current_tile()
        
        local field = user:get_field()

        local ref = self

        local remaining_time = 150

        local input_once = true
        local input_once_part_two = true
        local input_once_part_three = true

        local do_once = true
        local do_once_part_two = true
        local do_once_part_three = true
        step1.update_func = function(self, dt)
            remaining_time = remaining_time - 1
            if remaining_time > 0 and remaining_time < 60 then
                --print("read")
                if user:input_has(Input.Held.Shoot) then
                    --print("HELD")
                    B_held = true
                else
                    --print("UNHELD")
                    B_held = false
                end
                if user:input_has(Input.Pressed.Up) and B_held and not input_1 and not input_2 then
                    --print("PRESSED")
                    input_1 = true
                end
                if user:input_has(Input.Pressed.Right) and B_held and input_1 and not input_2 then
                    --print("PRESSED")
                    input_2 = true
                end
                if user:input_has(Input.Pressed.Down) and B_held and input_1 and input_2 then
                    --print("PRESSED")
                    input_success = true
                end
                if input_success then
                    if not success_played then
                        print("SUCCESS")
                        Engine.play_audio(AUDIO_INPUT, AudioPriority.High)
                        success_played = true
                    end
                end
            end
            if remaining_time <= 1 then
                --print("read_input: OFF")
                step1:complete_step()
            end
            if do_once then
                do_once = false

                ref.swallowman = Battle.Artifact.new()
                ref.swallowman:set_facing(user:get_facing())
		    	ref.swallowman:set_texture(TEXTURE_SWALLOWMAN, true)
		    	ref.swallowman:sprite():set_layer(-1)

                swallow_anim = ref.swallowman:get_animation()
                swallow_anim:load(ANIMPATH_SWALLOWMAN)
                swallow_anim:set_state("SPAWN")
		    	swallow_anim:refresh(ref.swallowman:sprite())
                swallow_anim:on_frame(2, function()
		    		Engine.play_audio(AUDIO_SPAWN, AudioPriority.High)
		    	end)
		    	swallow_anim:on_complete(function()
                    ref.swallowman:erase()
		    	end)
                field:spawn(ref.swallowman, ref.tile)
            end
        end
        self:add_step(step1)

        local step2 = Battle.Step.new()
        step2.update_func = function(self, dt)
            if do_once_part_two then
                do_once_part_two = false

                ref.swallowdrive = Battle.Artifact.new()
                ref.swallowdrive:set_facing(user:get_facing())
		    	ref.swallowdrive:set_texture(TEXTURE_SWALLOWMAN, true)
		    	ref.swallowdrive:sprite():set_layer(-1)

                swallow_anim = ref.swallowdrive:get_animation()
                swallow_anim:load(ANIMPATH_SWALLOWMAN)
                swallow_anim:set_state("MID")
		    	swallow_anim:refresh(ref.swallowdrive:sprite())
                swallow_anim:on_complete(function()
                    if input_success then
                        print("ATTACK: 2")
                        swallow_anim:set_state("ATTACK2")
                    else
                        print("ATTACK: 1")
                        swallow_anim:set_state("ATTACK1")
                    end
		    	end)
                field:spawn(ref.swallowdrive, ref.tile)
            end
            local anim = ref.swallowdrive:get_animation()
            if anim:get_state() == "ATTACK1" or anim:get_state() == "ATTACK2" then
                if do_once_part_three then
                    do_once_part_three = false

                    local attack_1 = create_attack(user, props)
                    local attack_2 = create_attack(user, props)
                    local attack_3 = create_attack(user, props)
                    local attack_4 = create_attack(user, props)
                    local attack_5 = create_attack(user, props)
                    local attack_6 = create_attack(user, props)
                    local attack_7 = create_attack(user, props)
                    local attack_8 = create_attack(user, props)
                    local attack_9 = create_attack(user, props)

                    local attack_1_barrier = create_attack_barrier(user, props)
                    local attack_2_barrier = create_attack_barrier(user, props)
                    local attack_3_barrier = create_attack_barrier(user, props)
                    local attack_4_barrier = create_attack_barrier(user, props)
                    local attack_5_barrier = create_attack_barrier(user, props)
                    local attack_6_barrier = create_attack_barrier(user, props)
                    local attack_7_barrier = create_attack_barrier(user, props)
                    local attack_8_barrier = create_attack_barrier(user, props)
                    local attack_9_barrier = create_attack_barrier(user, props)

                    anim:on_frame(1, function()
                        print("SwallowMan: SwallowDrive!")
                        Engine.play_audio(AUDIO_SWALLOWDRIVE, AudioPriority.Highest)
                    end)
                    anim:on_frame(6, function()
                        if input_success then
                            field:spawn(attack_1, X_offset_1, 3)
                        else
                            field:spawn(attack_1_barrier, X_offset_1, 3)
                        end
                    end)
                    anim:on_frame(11, function()
                        if input_success then
                            attack_1:erase()
                            field:spawn(attack_2, X, 2)
                        else
                            attack_1_barrier:erase()
                            field:spawn(attack_2_barrier, X, 2)
                        end
                    end)
                    anim:on_frame(16, function()
                        if input_success then
                            attack_2:erase()
                            field:spawn(attack_3, X_offset_2, 1)
                        else
                            attack_2_barrier:erase()
                            field:spawn(attack_3_barrier, X_offset_2, 1)
                        end
                    end)
                    anim:on_frame(21, function()
                        if input_success then
                            attack_3:erase()
                            field:spawn(attack_4, X_offset_3, 1)
                        else
                            attack_3_barrier:erase()
                            field:spawn(attack_4_barrier, X_offset_3, 1)
                        end
                    end)
                    anim:on_frame(23, function()
                        if input_success then
                            attack_4:erase()
                            field:spawn(attack_5, X_offset_3, 2)
                        else
                            attack_4_barrier:erase()
                            field:spawn(attack_5_barrier, X_offset_3, 2)
                        end
                    end)
                    anim:on_frame(26, function()
                        if input_success then
                            attack_5:erase()
                            field:spawn(attack_6, X_offset_3, 3)
                        else
                            attack_5_barrier:erase()
                            field:spawn(attack_6_barrier, X_offset_3, 3)
                        end
                    end)
                    anim:on_frame(29, function()
                        if input_success then
                            attack_6:erase()
                            field:spawn(attack_7, X_offset_2, 3)
                        else
                            attack_6_barrier:erase()
                            field:spawn(attack_7_barrier, X_offset_2, 3)
                        end
                    end)
                    anim:on_frame(34, function()
                        if input_success then
                            attack_7:erase()
                            field:spawn(attack_8, X, 2)
                        else
                            attack_7_barrier:erase()
                            field:spawn(attack_8_barrier, X, 2)
                        end
                    end)
                    anim:on_frame(39, function()
                        if input_success then
                            attack_8:erase()
                            field:spawn(attack_9, X_offset_1, 1)
                        else
                            attack_8_barrier:erase()
                            field:spawn(attack_9_barrier, X_offset_1, 1)
                        end
                    end)
                    anim:on_complete(function()
                        if input_success then
                            attack_9:erase()
                        else
                            attack_9_barrier:erase()
                        end
                        ref.swallowdrive:erase()
                        step2:complete_step()
                    end)
                end
            end
        end
        self:add_step(step2)
    end
    action.action_end_func = function(self)
		self:get_actor():reveal()
	end
	return action
end

function create_attack(actor, props)
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    local field = actor:get_field()
    local anim = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.None, 
            actor:get_id(), 
            Drag.None
        )
    )
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.can_move_to_func = function(tile)
        return true
    end
    
    return spell
end

function create_attack_barrier(actor, props)
    local spell = Battle.Spell.new(actor:get_team())
    local direction = actor:get_facing()
    local field = actor:get_field()
    local anim = spell:get_animation()
    spell:set_hit_props(
        HitProps.new(
            props.damage, 
            Hit.Impact | Hit.Flash | Hit.Flinch, 
            Element.Wind, 
            actor:get_id(), 
            Drag.None
        )
    )
    
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other) 
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end
    
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
        spell:erase()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.can_move_to_func = function(tile)
        return true
    end
    
    return spell
end