local DAMAGE = 140

local SEARCHBOMB_TEXTURE = Engine.load_texture(_modpath.."searchbomb.png")
local SEARCHBOMB_ANIMPATH = _modpath.."searchbomb.animation"
local AUDIO_THROW = Engine.load_audio(_modpath.."throw.ogg")

local BOOM_TEXTURE = Engine.load_texture(_modpath.."boom.png")
local BOOM_ANIMPATH = _modpath.."boom.animation"
local AUDIO_BOOM = Engine.load_audio(_modpath.."boom.ogg")

local AUDIO_DAMAGE = Engine.load_audio(_modpath.."hitsound.ogg")

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE4-162-SearchBomb3")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({"M","U","W"})

    local props = package:get_card_props()
    props.shortname = "SrchBom3"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.None
    props.description = "Throw a bomb at enemy!"
    props.long_description = "Aim and throw a bomb at the enemy!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 4
end

function card_create_action(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_THROW")
	action:set_lockout(make_animation_lockout())
    local override_frames = {{1,0.064},{2,0.064},{3,0.064},{4,0.064},{5,0.075}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    local hit_props = HitProps.new(
        props.damage,
        Hit.Impact | Hit.Flinch | Hit.Flash, 
        props.element,
        user:get_context(),
        Drag.None
    )

    action.execute_func = function(self, user)
        local field = user:get_field()
		local team = user:get_team()
		local direction = user:get_facing()
        
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local enemy_filter = function(character)
            return character:get_team() ~= user:get_team()
        end
    
        local enemy_list = nil
        enemy_list = field:find_nearest_characters(user, enemy_filter)

        --local props = self:copy_metadata()
        local attachment = self:add_attachment("HAND")
        local attachment_sprite = attachment:sprite()
        attachment_sprite:set_texture(SEARCHBOMB_TEXTURE)
        attachment_sprite:set_layer(-2)

        local attachment_animation = attachment:get_animation()
        attachment_animation:load(SEARCHBOMB_ANIMPATH)
        attachment_animation:set_state("0")

        user:toggle_counter(true)
        self:add_anim_action(3,function()
            attachment_sprite:hide()
            --self.remove_attachment(attachment)
            local frames_in_air = 40
            local toss_height = 70
            local target_tile = enemy_list[1]:get_current_tile()
            if not target_tile then
                return
            end
            action.on_landing = function()
                if target_tile:is_walkable() then
                    hit_explosion(user, hit_props, team, direction, field, target_tile)
                end
            end
            toss_spell(user, team, toss_height, frames_in_air, action.on_landing, field, target_tile)
		end)
        self:add_anim_action(4,function()
            user:toggle_counter(false)
		end)
        self.action_end_func = function()
            user:toggle_counter(false)
        end

        Engine.play_audio(AUDIO_THROW, AudioPriority.Highest)
    end
    return action
end

function toss_spell(tosser, team, toss_height, frames_in_air, arrival_callback, field, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local spell = Battle.Spell.new(team)
    spell:set_shadow(Shadow.Small)
    local spell_animation = spell:get_animation()
    spell_animation:load(SEARCHBOMB_ANIMPATH)
    spell_animation:set_state("1")
    spell_animation:set_playback(Playback.Loop)
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(SEARCHBOMB_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function hit_explosion(user, props, team, direction, field, target_tile)
    local spell = Battle.Spell.new(team)
    spell:get_facing(direction)
    local spell_animation = spell:get_animation()
    spell_animation:load(BOOM_ANIMPATH)
    spell_animation:set_state("0")
    local sprite = spell:sprite()
    sprite:set_texture(BOOM_TEXTURE)
    spell_animation:refresh(sprite)
    spell_animation:on_complete(function()
		spell:erase()
	end)

    spell:set_hit_props(props)
    spell.has_attacked = false
    spell.update_func = function(self)
        spell:get_current_tile():attack_entities(self)
        if not spell.has_attacked then
            spell_animation:on_frame(2, function()
                Engine.play_audio(AUDIO_BOOM, AudioPriority.High)
            end)
        end
    end
    spell.attack_func = function(self)
        spell.has_attacked = true
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
    end

    field:spawn(spell, target_tile)
end