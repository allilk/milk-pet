function package_init(block)
    block:declare_package_id("com.example.block.BossBattle")
    block:set_name("Power")
    block:set_description("That's Spicy")
    block:set_color(Blocks.Yellow)
    block:set_shape({
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    })
    block:set_mutator(modify)
end

function modify(player)    
	local music_player = Battle.Component.new(player, Lifetimes.Local)
	local cooldown = 1
	music_player.update_func = function(self, dt)
		if cooldown <= 0 then
			Engine.stream_music(_modpath.."powersurge.mid")
			self:eject()
		else
			cooldown = cooldown - 1
		end
	end
	player:register_component(music_player)
end